internal delegate bool fhj8g0k1GEigfdpNCgo(object P_0);
