using System;
using System.Globalization;

internal delegate bool a2cQXy8fIYSgw3ffcnu(string P_0, NumberStyles P_1, IFormatProvider P_2, ref long P_3);
