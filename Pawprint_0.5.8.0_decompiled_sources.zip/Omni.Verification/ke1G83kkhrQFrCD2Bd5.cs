using System.Text.Json;

internal delegate JsonElement ke1G83kkhrQFrCD2Bd5(ref JsonElement P_0, string P_1);
