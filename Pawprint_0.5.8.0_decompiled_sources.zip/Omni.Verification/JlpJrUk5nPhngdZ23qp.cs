using System;

internal delegate string JlpJrUk5nPhngdZ23qp(ref Guid P_0, string P_1);
