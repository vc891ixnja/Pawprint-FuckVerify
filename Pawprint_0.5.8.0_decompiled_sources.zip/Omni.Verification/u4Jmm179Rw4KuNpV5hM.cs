internal delegate string u4Jmm179Rw4KuNpV5hM(object P_0);
