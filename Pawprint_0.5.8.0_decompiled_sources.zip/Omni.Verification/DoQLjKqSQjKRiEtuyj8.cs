using System;

internal delegate bool DoQLjKqSQjKRiEtuyj8(Type P_0, Type P_1);
