using Microsoft.Win32;

internal delegate RegistryKey r3pgNS2pt7RGdN2Hsww(object P_0, string P_1, bool P_2);
