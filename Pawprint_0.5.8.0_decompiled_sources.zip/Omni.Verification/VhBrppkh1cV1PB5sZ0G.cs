using System;

internal delegate DateTimeOffset VhBrppkh1cV1PB5sZ0G(long P_0);
