using System;

internal delegate string ex1VWV8CCt83bsAPSPj(ref long P_0, IFormatProvider P_1);
