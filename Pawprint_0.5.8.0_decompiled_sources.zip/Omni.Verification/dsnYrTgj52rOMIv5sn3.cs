internal delegate void dsnYrTgj52rOMIv5sn3(object P_0, ref bool P_1);
