internal delegate bool BT1PdogU5Tl9Qh1AUpI(nint P_0, string P_1, ref nint P_2);
