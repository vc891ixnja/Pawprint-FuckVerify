using System.Threading.Tasks;

internal delegate Task cWm1owgZH5odeoEWNuP();
