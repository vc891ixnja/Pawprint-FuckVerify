using System.Text.Json;

internal delegate bool COoacL8jcSB9Xv74JU4(ref JsonElement P_0);
