using System;

internal delegate TimeSpan cgZHwhgfRgjHEgYuQac(long P_0);
