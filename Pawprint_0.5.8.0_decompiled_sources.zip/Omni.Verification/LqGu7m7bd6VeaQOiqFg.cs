internal delegate byte[] LqGu7m7bd6VeaQOiqFg(byte[] P_0);
