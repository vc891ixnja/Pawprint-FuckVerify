internal delegate string qt8YYi7kVTrq4fMdmFb(object P_0);
