internal delegate uint hoM4Nt4qtFsVaCVDUcT(ref nuint P_0);
