using System;

internal delegate Type gftEB2iKJcSmRNMI5ew(object P_0);
