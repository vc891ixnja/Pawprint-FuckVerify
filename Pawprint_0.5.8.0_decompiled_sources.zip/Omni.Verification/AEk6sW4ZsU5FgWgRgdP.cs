using System;

internal delegate Exception AEk6sW4ZsU5FgWgRgdP(object P_0);
