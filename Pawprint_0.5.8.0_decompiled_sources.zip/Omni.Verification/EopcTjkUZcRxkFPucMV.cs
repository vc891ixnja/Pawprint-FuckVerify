internal delegate string EopcTjkUZcRxkFPucMV(object P_0);
