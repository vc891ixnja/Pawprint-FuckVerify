using System;

internal delegate void lvi6LOi5C9OOdbWFMx2(Array P_0, RuntimeFieldHandle P_1);
