using System;

internal delegate DateTimeOffset tqLTH6gbE2ebMtEL5Ph();
