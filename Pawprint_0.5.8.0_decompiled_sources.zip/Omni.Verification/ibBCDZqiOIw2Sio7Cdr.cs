internal delegate bool ibBCDZqiOIw2Sio7Cdr(object P_0);
