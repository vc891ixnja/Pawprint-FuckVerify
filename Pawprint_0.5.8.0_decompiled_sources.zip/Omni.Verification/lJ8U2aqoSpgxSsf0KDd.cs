using System;

internal delegate object lJ8U2aqoSpgxSsf0KDd(Type P_0, ushort P_1);
