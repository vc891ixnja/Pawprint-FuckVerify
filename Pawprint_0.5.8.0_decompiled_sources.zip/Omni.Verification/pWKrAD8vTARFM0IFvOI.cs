using System.Reflection;

internal delegate Module pWKrAD8vTARFM0IFvOI(object P_0);
