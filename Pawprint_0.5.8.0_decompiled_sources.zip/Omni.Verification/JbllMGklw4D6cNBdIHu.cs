using System.Runtime.CompilerServices;

internal delegate bool JbllMGklw4D6cNBdIHu(ref ConfiguredTaskAwaitable.ConfiguredTaskAwaiter P_0);
