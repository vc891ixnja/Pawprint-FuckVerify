using System.Reflection;

internal delegate FieldInfo I7SHdl8eCEtIdU3qNu5(object P_0, int P_1);
