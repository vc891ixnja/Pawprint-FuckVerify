internal delegate void rL7e5xgvjUcwWGWo1BL(bool P_0, object P_1);
