internal delegate void UQA4wigSOjpwSeByqpD(nint P_0);
