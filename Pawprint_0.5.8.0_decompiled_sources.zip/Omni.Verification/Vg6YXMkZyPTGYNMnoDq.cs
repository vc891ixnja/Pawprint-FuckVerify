using System;
using System.Runtime.CompilerServices;

internal delegate void Vg6YXMkZyPTGYNMnoDq(ref AsyncTaskMethodBuilder P_0, Exception P_1);
