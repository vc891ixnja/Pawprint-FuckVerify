using System.Text;

internal delegate StringBuilder bdiaIO2gltm5JoYaroV(object P_0, string P_1);
