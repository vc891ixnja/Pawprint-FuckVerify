using System.Reflection;
using System.Reflection.Emit;

internal delegate void ukcWM7ipJIxSMI3vqak(object P_0, OpCode P_1, FieldInfo P_2);
