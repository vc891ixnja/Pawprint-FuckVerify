using System.Security.Cryptography;

internal delegate CngKeyBlobFormat FnH22m2jVNqL86PdvY0();
