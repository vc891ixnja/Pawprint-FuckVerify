using System.Text;

internal delegate StringBuilder r5V63c2kxZesT4t4dMB(object P_0, char P_1);
