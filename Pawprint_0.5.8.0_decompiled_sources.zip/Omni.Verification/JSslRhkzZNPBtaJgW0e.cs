using System;

internal delegate long JSslRhkzZNPBtaJgW0e(ref DateTimeOffset P_0);
