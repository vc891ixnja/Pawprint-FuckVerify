internal delegate string O11Ojo491Mx38vO9Ulm(ref ulong P_0);
