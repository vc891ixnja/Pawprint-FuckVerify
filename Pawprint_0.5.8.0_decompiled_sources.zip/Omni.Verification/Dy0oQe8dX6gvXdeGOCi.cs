using System.Text;

internal delegate Encoding Dy0oQe8dX6gvXdeGOCi();
