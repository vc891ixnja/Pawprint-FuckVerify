using System.Net.Http.Headers;

internal delegate HttpResponseHeaders kntXIt89XiIIU67JUcU(object P_0);
