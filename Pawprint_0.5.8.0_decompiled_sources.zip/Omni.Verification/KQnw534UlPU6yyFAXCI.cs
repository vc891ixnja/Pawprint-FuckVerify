internal delegate string KQnw534UlPU6yyFAXCI(ref uint P_0);
