using System.Reflection;

internal delegate bool b3CWRi4acLtpIHNI7LS(FieldInfo P_0, FieldInfo P_1);
