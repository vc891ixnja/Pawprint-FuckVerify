using System.Threading;

internal delegate CancellationToken EP0begkgBpCIGbHofwv(object P_0);
