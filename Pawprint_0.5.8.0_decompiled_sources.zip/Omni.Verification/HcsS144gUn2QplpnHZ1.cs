using System;

internal delegate Type HcsS144gUn2QplpnHZ1(object P_0);
