internal delegate string TXMWGR7zVBGOoESeAeT(object P_0);
