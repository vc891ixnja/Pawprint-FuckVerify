using System;

internal delegate Type OcEwxP418R00yAbuoWd(object P_0);
