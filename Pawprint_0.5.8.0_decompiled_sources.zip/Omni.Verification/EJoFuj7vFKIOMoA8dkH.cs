using System;

internal delegate ReadOnlySpan<char> EJoFuj7vFKIOMoA8dkH(string P_0);
