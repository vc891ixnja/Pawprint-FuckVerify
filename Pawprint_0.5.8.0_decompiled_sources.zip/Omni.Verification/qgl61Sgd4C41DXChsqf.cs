internal delegate bool qgl61Sgd4C41DXChsqf(string P_0, ref nint P_1);
