using System;

internal delegate long MqhlBl8gB9RtZUWaLuj(ref DateTimeOffset P_0);
