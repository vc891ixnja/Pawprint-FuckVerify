using System.Runtime.CompilerServices;

internal delegate string neLCOG7t9FNg5FEFTKp(ref DefaultInterpolatedStringHandler P_0);
