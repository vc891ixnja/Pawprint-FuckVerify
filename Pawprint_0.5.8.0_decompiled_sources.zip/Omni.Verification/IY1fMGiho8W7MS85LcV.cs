internal delegate bool IY1fMGiho8W7MS85LcV(object P_0);
