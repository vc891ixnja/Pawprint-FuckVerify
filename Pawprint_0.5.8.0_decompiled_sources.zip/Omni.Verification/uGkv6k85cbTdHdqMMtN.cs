internal delegate void uGkv6k85cbTdHdqMMtN(object P_0, long P_1);
