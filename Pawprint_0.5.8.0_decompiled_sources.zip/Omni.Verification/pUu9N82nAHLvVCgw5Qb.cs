using System.Security.Cryptography;

internal delegate byte[] pUu9N82nAHLvVCgw5Qb(object P_0, CngKeyBlobFormat P_1);
