internal delegate byte Sd8lOfq9QNgaoGWNTGx(object P_0);
