using System;

internal delegate string DWnBRb7Z8eyxlCccRTn(string P_0, EnvironmentVariableTarget P_1);
