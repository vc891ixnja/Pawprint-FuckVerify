using System;
using System.Reflection.Emit;

internal delegate LocalBuilder nZQe1riaTaJlln0nGQh(object P_0, Type P_1);
