using System;

internal delegate Type ASUs3L7efSqEBtRbXyW(RuntimeTypeHandle P_0);
