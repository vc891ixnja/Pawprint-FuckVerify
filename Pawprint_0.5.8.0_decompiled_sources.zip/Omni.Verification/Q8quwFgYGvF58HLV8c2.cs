using System.Threading;

internal delegate CancellationToken Q8quwFgYGvF58HLV8c2();
