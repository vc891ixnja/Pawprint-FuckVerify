using System;

internal delegate DateTimeOffset QMKFx3g12pMDhVeyeWP(ref DateTimeOffset P_0, long P_1);
