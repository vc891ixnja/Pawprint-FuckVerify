using System;

internal delegate RuntimeMethodHandle LtwdZV4Jbk8m5La8Wlc(object P_0);
