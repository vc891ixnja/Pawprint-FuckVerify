using System.Reflection;

internal delegate MemberInfo NNkSvu8KtQ7RaOgMu6P(object P_0, int P_1);
