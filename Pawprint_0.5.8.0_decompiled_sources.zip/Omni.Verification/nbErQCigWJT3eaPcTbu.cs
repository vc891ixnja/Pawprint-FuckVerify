using System;
using System.Reflection.Emit;

internal delegate void nbErQCigWJT3eaPcTbu(object P_0, OpCode P_1, Type P_2);
