internal delegate void g1Knk04h0TlZ3PHuWaL(object P_0, object P_1, int P_2);
