using System;

internal delegate StringComparer aqNWaOg97ZiMZWBE7He();
