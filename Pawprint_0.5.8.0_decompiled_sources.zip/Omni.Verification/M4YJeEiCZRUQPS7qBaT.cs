internal delegate bool M4YJeEiCZRUQPS7qBaT(double P_0);
