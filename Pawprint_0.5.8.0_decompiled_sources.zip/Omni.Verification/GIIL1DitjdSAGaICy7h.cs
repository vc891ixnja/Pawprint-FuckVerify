using System.Reflection.Emit;

internal delegate void GIIL1DitjdSAGaICy7h(object P_0, OpCode P_1, LocalBuilder P_2);
