internal delegate bool GkKwW0gCRAqdPRoBPNc();
