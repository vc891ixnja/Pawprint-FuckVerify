internal delegate bool NDdI2GijaILNoslEK2p(object P_0);
