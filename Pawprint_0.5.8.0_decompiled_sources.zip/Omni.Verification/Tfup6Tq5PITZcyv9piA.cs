using System;

internal delegate object Tfup6Tq5PITZcyv9piA(Type P_0, long P_1);
