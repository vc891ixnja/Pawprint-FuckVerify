internal delegate void mHIV2EkRp73p3KRPbUJ(object P_0, string P_1, string P_2);
