using System.Runtime.CompilerServices;

internal delegate AsyncTaskMethodBuilder v8KEb8gJvmseLGOvGrO();
