internal delegate object oppSPm4jIRRICkgDQ36(object P_0, object P_1);
