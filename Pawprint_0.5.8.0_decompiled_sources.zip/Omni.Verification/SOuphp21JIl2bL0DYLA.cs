internal delegate string SOuphp21JIl2bL0DYLA(byte[] P_0);
