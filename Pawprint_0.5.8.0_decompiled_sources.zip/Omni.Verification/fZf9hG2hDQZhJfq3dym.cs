using System.Security.Cryptography;

internal delegate CngKey fZf9hG2hDQZhJfq3dym(string P_0, CngProvider P_1, CngKeyOpenOptions P_2);
