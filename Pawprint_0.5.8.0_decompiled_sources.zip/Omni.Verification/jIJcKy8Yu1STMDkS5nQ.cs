using System;
using System.Reflection;

internal delegate MethodBase jIJcKy8Yu1STMDkS5nQ(RuntimeMethodHandle P_0);
