using System;

internal delegate UInt128 hHvdmH7aTAH98gGcw2K(UInt128 P_0, UInt128 P_1);
