internal delegate nint rI258W4oNWMUGSUpZij(int P_0);
