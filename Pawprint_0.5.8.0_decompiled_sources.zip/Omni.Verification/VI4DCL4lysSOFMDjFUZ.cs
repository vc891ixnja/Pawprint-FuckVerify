internal delegate int VI4DCL4lysSOFMDjFUZ(object P_0);
