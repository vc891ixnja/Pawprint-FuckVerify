using System;
using System.Reflection;
using System.Reflection.Emit;

internal delegate void KTTVt4iljsJV2K44YnN(object P_0, OpCode P_1, MethodInfo P_2, Type[] P_3);
