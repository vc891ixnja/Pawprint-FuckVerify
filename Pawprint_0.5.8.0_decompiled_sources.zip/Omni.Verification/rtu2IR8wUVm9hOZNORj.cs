using System.Reflection;

internal delegate MethodBase rtu2IR8wUVm9hOZNORj(object P_0, int P_1);
