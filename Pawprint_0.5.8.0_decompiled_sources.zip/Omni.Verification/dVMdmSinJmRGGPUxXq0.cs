internal delegate string dVMdmSinJmRGGPUxXq0(object P_0);
