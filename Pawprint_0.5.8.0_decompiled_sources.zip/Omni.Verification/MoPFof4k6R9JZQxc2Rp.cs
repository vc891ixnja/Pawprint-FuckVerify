internal delegate ulong MoPFof4k6R9JZQxc2Rp(ref nuint P_0);
