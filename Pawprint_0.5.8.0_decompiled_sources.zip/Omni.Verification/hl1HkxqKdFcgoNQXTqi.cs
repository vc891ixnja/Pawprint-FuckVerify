using System;

internal delegate object hl1HkxqKdFcgoNQXTqi(Type P_0, int P_1);
