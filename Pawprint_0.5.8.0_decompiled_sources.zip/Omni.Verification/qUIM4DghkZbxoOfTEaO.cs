internal delegate int qUIM4DghkZbxoOfTEaO(object P_0);
