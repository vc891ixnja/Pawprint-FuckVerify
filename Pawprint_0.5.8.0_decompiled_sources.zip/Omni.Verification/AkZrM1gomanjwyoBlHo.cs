using System.Threading.Tasks;

internal delegate TaskScheduler AkZrM1gomanjwyoBlHo();
