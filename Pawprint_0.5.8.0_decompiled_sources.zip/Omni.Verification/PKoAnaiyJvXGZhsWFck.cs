using System.Reflection;

internal delegate bool PKoAnaiyJvXGZhsWFck(MethodBase P_0, MethodBase P_1);
