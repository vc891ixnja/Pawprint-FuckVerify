internal delegate void NF0XiHgkmFfgrdXQBsN(object P_0, long P_1);
