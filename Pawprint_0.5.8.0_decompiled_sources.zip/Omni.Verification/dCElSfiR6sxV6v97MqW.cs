using System;

internal delegate object dCElSfiR6sxV6v97MqW(object P_0, Type P_1);
