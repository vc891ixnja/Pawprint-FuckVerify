internal delegate bool GxKCaY7SgPqGH2LnEAB(object P_0);
