internal delegate void QPGGdkglkF8Wt0q399Z(object P_0);
