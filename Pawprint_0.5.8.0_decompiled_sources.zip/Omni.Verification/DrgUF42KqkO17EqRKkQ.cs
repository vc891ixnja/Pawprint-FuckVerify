using Microsoft.Win32;

internal delegate RegistryKey DrgUF42KqkO17EqRKkQ(RegistryHive P_0, RegistryView P_1);
