using System.Threading;
using System.Threading.Tasks;

internal delegate Task<string> qC4qYP8hDPTfGStqht0(object P_0, CancellationToken P_1);
