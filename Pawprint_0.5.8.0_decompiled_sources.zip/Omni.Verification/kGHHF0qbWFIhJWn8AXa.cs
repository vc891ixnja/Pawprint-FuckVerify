internal delegate bool kGHHF0qbWFIhJWn8AXa(object P_0);
