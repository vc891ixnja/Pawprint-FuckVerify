using System;

internal delegate Type uOfhdkcU01OTeKJNUjY(object P_0, Type[] P_1);
