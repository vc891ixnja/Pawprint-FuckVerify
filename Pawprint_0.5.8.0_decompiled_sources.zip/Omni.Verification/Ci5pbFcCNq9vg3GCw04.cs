using System;

internal delegate RuntimeFieldHandle Ci5pbFcCNq9vg3GCw04(object P_0);
