using System.Text.Json;

internal delegate JsonValueKind OP6YbikKdqSekw3nJW1(ref JsonElement P_0);
