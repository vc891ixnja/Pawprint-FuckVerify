using System;

internal delegate Delegate SdYkc5ief1DOYFiHbw3(object P_0, Type P_1);
