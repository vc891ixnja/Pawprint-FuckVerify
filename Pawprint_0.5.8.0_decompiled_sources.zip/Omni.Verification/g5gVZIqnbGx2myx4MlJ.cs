using System.IO;

internal delegate Stream g5gVZIqnbGx2myx4MlJ(object P_0, string P_1);
