internal delegate string diXVVcqlA5xwGnunUQx(object P_0, byte[] P_1);
