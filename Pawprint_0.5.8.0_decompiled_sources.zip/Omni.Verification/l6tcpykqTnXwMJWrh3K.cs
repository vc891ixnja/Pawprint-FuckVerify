using System.Text.Json;

internal delegate string l6tcpykqTnXwMJWrh3K(ref JsonElement P_0);
