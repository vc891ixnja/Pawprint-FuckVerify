internal delegate bool fLMmjqidDAI5XigiQcB(double P_0);
