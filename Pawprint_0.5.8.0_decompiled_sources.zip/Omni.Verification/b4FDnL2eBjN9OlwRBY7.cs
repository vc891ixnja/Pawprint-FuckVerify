internal delegate bool b4FDnL2eBjN9OlwRBY7(object P_0);
