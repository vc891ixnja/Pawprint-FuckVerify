using System;

internal delegate Type cMKUcdqeYkDVp0cvvWL(Type P_0);
