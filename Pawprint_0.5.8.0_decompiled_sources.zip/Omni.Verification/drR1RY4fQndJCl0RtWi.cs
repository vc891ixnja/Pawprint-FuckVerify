internal delegate int drR1RY4fQndJCl0RtWi(ref nint P_0);
