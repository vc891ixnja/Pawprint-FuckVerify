using System.Reflection;

internal delegate MethodInfo UyohT3i9kFqOIuifo6p(object P_0);
