internal delegate object h06ot82YEO7hPSVjr6t(object P_0, string P_1);
