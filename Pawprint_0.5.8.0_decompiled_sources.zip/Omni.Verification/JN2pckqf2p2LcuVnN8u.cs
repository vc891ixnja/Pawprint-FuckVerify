internal delegate float JN2pckqf2p2LcuVnN8u(object P_0);
