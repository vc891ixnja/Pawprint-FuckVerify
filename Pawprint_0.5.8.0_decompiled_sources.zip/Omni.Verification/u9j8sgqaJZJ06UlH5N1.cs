internal delegate void u9j8sgqaJZJ06UlH5N1(object P_0);
