internal delegate int GKyDvv4z8Tms21FdwkM(object P_0);
