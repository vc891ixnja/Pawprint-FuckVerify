using System.IO;

internal delegate Stream HClJkX8J7UpbuPEobJa(object P_0);
