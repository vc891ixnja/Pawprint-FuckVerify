using System;
using System.Reflection;

internal delegate FieldInfo CvEjKY8otbQK6EGG2wj(RuntimeFieldHandle P_0, RuntimeTypeHandle P_1);
