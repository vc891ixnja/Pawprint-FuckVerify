internal delegate bool ofyWVi7oQKkPNkLJJOR(object P_0);
