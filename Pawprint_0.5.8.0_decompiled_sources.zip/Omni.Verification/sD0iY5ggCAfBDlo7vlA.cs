using System;

internal delegate void sD0iY5ggCAfBDlo7vlA(object P_0, TimeSpan P_1);
