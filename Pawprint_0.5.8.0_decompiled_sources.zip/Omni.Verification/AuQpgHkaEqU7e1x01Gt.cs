using System.Threading;
using System.Threading.Tasks;

internal delegate Task AuQpgHkaEqU7e1x01Gt(object P_0, CancellationToken P_1);
