using System;

internal delegate Type ubtdeJqZTPFlx4Zwn6e(Type P_0);
