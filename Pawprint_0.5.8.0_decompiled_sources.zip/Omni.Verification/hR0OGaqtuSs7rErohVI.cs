using System.Text;

internal delegate Encoding hR0OGaqtuSs7rErohVI();
