internal delegate void QWIDKPgKdfLJGOlpgCC(object P_0);
