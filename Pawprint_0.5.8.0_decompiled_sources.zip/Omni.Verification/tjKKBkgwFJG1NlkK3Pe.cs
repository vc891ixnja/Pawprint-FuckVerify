using System;
using System.Threading.Tasks;

internal delegate Task tjKKBkgwFJG1NlkK3Pe(ReadOnlySpan<Task> P_0);
