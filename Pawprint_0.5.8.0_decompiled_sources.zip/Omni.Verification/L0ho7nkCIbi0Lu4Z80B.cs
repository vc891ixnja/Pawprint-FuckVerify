internal delegate string L0ho7nkCIbi0Lu4Z80B(object P_0);
