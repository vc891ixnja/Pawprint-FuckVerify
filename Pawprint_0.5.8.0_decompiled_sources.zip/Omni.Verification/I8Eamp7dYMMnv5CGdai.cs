internal delegate char I8Eamp7dYMMnv5CGdai(object P_0, int P_1);
