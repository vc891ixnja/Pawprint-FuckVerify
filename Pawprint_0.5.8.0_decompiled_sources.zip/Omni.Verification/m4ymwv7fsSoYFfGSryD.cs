using System.Globalization;

internal delegate CultureInfo m4ymwv7fsSoYFfGSryD();
