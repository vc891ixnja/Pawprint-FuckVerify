using System.Text.Json;

internal delegate int GOwQ5I8aeGJdH4hwMKi(ref JsonElement P_0);
