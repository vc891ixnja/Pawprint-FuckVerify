internal delegate string j3HKc52qPj9bB1cwR8k(object P_0);
