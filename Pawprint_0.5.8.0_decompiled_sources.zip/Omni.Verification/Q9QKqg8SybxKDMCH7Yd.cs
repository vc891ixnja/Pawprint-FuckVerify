using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

internal delegate Task<HttpResponseMessage> Q9QKqg8SybxKDMCH7Yd(object P_0, HttpRequestMessage P_1, CancellationToken P_2);
