using System;

internal delegate RuntimeTypeHandle D1egx8cdrN7DoHWoauy(object P_0);
