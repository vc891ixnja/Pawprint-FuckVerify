using System.Reflection.Emit;

internal delegate void IyfOVGikv3D0ZQgsRDa(object P_0, OpCode P_1);
