using System;

internal delegate ReadOnlySpan<char> GwX5857lt9lGP9FWBYn(string P_0, int P_1);
