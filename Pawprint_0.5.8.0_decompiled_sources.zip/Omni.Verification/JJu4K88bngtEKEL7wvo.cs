using System.Text.Json;

internal delegate JsonDocument JJu4K88bngtEKEL7wvo(string P_0, JsonDocumentOptions P_1);
