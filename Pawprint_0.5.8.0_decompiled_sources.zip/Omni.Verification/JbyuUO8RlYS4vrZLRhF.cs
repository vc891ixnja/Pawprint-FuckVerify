using System;
using System.Reflection;

internal delegate FieldInfo JbyuUO8RlYS4vrZLRhF(RuntimeFieldHandle P_0);
