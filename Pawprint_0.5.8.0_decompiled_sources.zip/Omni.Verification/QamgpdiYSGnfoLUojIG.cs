using System.Reflection.Emit;

internal delegate void QamgpdiYSGnfoLUojIG(object P_0, OpCode P_1, sbyte P_2);
