using System;

internal delegate Type oRZfnViwH9AtKsqtQtX(object P_0);
