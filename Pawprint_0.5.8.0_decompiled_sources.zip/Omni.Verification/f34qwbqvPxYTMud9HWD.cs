internal delegate long f34qwbqvPxYTMud9HWD(object P_0);
