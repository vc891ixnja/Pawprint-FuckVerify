using System;

internal delegate Type QjtkbvqClTTRXZxsDfq(object P_0);
