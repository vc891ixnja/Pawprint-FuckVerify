internal delegate bool MavIPHqw73qOfK1BlCw(object P_0);
