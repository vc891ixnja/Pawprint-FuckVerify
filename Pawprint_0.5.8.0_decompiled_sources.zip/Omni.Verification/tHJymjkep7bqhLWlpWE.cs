using System.Runtime.CompilerServices;

internal delegate void tHJymjkep7bqhLWlpWE(ref AsyncTaskMethodBuilder P_0, IAsyncStateMachine P_1);
