using System.Reflection;

internal delegate bool BYZ5ZuiiQ7j8MkPFahX(MethodInfo P_0, MethodInfo P_1);
