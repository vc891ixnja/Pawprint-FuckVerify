using System;

internal delegate object Ho3jh3qJJ2s6JG8IGEU(Type P_0, sbyte P_1);
