using System.Reflection;

internal delegate Assembly KvXJa97KgIUGkGn5ClT(object P_0);
