internal delegate byte[] ekgWU9qjhLosZJFDVOB(object P_0, int P_1);
