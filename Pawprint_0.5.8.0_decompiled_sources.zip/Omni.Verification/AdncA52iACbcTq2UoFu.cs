internal delegate int AdncA52iACbcTq2UoFu(object P_0);
