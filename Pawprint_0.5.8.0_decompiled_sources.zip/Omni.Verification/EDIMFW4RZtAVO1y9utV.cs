using System;

internal delegate bool EDIMFW4RZtAVO1y9utV(object P_0, Type P_1);
