internal delegate bool MWXTbP75cksyqwJpbsc(string P_0, string P_1);
