using System.Text.Json;

internal delegate JsonElement MYVPOS8npUctubUB1Pf(object P_0);
