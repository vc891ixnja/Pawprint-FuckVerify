internal delegate void UQkD9s4vhSNc9SShvmn(nint P_0);
