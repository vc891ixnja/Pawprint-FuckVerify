using System.Net.Http;

internal delegate void CwxWBJ8UYQgllOoIS0d(object P_0, HttpContent P_1);
