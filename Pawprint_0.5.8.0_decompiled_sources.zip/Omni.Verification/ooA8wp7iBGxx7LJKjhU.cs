internal delegate string ooA8wp7iBGxx7LJKjhU(string P_0, string P_1);
