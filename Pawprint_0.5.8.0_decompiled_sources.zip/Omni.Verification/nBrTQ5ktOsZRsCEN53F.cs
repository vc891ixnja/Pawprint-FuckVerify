using System.Runtime.CompilerServices;

internal delegate ConfiguredTaskAwaitable nBrTQ5ktOsZRsCEN53F(object P_0, bool P_1);
