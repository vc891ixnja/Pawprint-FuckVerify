internal delegate string hAkocm2okeMu0egHEtV(object P_0);
