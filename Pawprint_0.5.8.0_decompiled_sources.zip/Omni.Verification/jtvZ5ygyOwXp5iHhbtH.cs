internal delegate void jtvZ5ygyOwXp5iHhbtH(object P_0, bool P_1);
