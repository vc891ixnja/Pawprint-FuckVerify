using System.Runtime.CompilerServices;

internal delegate void qnRCrRkwIAZjkQCgKmv(ref AsyncTaskMethodBuilder P_0);
