internal delegate int O2heIhizFNql32UYNC1(ref int P_0, int P_1);
