internal delegate bool JmDcoj7yvowe1r4WLnj(string P_0);
