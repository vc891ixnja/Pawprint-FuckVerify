internal delegate object pxLfZS2ZbFEsuk6b7Tb(object P_0, string P_1);
