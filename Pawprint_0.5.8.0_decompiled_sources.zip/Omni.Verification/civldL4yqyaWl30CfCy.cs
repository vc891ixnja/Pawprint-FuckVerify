internal delegate long civldL4yqyaWl30CfCy(ref nint P_0);
