using System.Reflection;

internal delegate bool gI0nis8lImkSgUh4UbJ(Module P_0, Module P_1);
