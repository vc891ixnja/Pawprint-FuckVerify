using System.Text.Json;

internal delegate long ssrmPnki9TOSFG54shB(ref JsonElement P_0);
