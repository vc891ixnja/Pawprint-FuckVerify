internal delegate long PtMBRC8kJTYfuoKaPx5(ref long P_0, long P_1);
