using System;

internal delegate bool RMdyZq7RCSmR89qiqV1(string P_0, UriKind P_1, ref Uri P_2);
