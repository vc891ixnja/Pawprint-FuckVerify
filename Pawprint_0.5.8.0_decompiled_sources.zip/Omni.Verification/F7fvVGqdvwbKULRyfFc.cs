internal delegate bool F7fvVGqdvwbKULRyfFc(object P_0);
