using System.Runtime.CompilerServices;

internal delegate void UhgxyKkvu9M2VZoIZsW(ref ConfiguredTaskAwaitable.ConfiguredTaskAwaiter P_0);
