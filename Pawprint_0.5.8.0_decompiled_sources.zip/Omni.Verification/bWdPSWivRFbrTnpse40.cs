using System.Reflection;
using System.Reflection.Emit;

internal delegate void bWdPSWivRFbrTnpse40(object P_0, OpCode P_1, ConstructorInfo P_2);
