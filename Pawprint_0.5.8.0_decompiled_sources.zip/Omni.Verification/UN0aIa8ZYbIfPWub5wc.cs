using System;

internal delegate Type UN0aIa8ZYbIfPWub5wc(object P_0, int P_1);
