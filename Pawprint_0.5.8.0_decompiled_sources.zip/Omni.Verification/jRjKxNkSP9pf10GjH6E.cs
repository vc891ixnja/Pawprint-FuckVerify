using System;

internal delegate string jRjKxNkSP9pf10GjH6E(object P_0, UriPartial P_1);
