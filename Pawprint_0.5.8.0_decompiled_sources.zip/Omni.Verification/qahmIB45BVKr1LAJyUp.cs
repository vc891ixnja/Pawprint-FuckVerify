using System;

internal delegate nint qahmIB45BVKr1LAJyUp(ref RuntimeMethodHandle P_0);
