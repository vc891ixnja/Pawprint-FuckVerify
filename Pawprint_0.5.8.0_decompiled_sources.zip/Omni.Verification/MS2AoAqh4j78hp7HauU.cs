using System;

internal delegate Type MS2AoAqh4j78hp7HauU(object P_0);
