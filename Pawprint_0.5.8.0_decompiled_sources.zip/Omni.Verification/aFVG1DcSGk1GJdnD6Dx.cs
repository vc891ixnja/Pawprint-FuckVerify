using System.Text;

internal delegate StringBuilder aFVG1DcSGk1GJdnD6Dx(object P_0, string P_1, object P_2);
