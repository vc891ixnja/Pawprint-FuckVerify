using System.Reflection.Emit;

internal delegate ILGenerator Dm1sSkifHRKbYtinr0o(object P_0);
