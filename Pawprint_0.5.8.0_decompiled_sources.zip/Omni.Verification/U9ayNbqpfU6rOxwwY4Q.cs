using System;

internal delegate object U9ayNbqpfU6rOxwwY4Q(Type P_0, uint P_1);
