internal delegate string QK4cIM4ehSCBgpJ3Zq4(object P_0);
