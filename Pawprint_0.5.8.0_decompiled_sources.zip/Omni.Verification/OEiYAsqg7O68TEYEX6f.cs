internal delegate double OEiYAsqg7O68TEYEX6f(object P_0);
