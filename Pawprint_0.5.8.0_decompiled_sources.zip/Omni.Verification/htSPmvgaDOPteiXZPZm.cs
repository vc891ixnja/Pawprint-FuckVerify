using System;

internal delegate bool htSPmvgaDOPteiXZPZm(DateTimeOffset P_0, DateTimeOffset P_1);
