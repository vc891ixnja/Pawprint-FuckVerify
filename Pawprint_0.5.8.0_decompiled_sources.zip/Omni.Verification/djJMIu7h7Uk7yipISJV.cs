internal delegate byte[] djJMIu7h7Uk7yipISJV(object P_0, string P_1);
