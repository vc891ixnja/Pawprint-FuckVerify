internal delegate string SnvENR2tBcAmPyhC35k(string P_0, string P_1, string P_2, string P_3);
