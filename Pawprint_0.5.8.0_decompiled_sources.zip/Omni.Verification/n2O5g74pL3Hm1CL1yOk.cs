internal delegate string n2O5g74pL3Hm1CL1yOk(object P_0, int P_1);
