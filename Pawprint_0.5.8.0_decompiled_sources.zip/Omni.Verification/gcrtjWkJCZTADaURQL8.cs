using System;

internal delegate Guid gcrtjWkJCZTADaURQL8();
