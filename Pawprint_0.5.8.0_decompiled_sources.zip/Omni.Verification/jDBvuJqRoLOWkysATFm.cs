using System;

internal delegate object jDBvuJqRoLOWkysATFm(Type P_0, byte P_1);
