internal delegate char cH4oNw2zMx7qx9kYsuq(char P_0);
