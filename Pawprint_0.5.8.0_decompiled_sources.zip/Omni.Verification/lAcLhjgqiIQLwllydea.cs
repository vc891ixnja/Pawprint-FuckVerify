internal delegate void lAcLhjgqiIQLwllydea(string P_0, string P_1);
