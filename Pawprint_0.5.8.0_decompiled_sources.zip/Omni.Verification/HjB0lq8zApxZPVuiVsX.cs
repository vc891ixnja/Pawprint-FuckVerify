using System.Reflection;

internal delegate ParameterInfo[] HjB0lq8zApxZPVuiVsX(object P_0);
