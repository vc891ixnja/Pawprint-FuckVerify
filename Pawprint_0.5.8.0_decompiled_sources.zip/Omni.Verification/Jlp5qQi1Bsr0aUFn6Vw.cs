internal delegate bool Jlp5qQi1Bsr0aUFn6Vw(object P_0);
