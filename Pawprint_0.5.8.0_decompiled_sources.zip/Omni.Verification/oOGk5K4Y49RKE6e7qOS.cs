using System;

internal delegate Array oOGk5K4Y49RKE6e7qOS(Type P_0, int P_1);
