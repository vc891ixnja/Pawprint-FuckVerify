internal delegate string cZ6HT84iDiToQtUK2rL(ref double P_0);
