internal delegate string p4IRrNkdj61GHDDbW0b(object P_0);
