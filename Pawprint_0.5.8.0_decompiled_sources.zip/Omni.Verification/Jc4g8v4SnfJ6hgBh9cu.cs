internal delegate string Jc4g8v4SnfJ6hgBh9cu(ref long P_0);
