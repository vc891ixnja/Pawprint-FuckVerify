using System.Text;

internal delegate StringBuilder M27Eepk9fvn2abWbktP(object P_0, object P_1);
