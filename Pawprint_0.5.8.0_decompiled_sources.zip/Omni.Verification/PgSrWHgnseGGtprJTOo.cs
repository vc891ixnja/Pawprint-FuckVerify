internal delegate long PgSrWHgnseGGtprJTOo(ref long P_0);
