internal delegate void dRF4so7URq6nKpuGr71(object P_0, string P_1);
