using System;

internal delegate Type q1w4W5qkhnq3Nrp6wKl(object P_0);
