internal delegate string PbY3kb7YQk2b1T8Cfvs(object P_0);
