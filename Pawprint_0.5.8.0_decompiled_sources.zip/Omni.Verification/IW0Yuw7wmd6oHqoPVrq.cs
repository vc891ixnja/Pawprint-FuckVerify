internal delegate string IW0Yuw7wmd6oHqoPVrq(object P_0);
