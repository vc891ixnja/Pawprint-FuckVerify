using System.Reflection;

internal delegate FieldInfo[] Svhgq1iJtKG2Y65Raj8(object P_0, BindingFlags P_1);
