using System;
using System.Reflection;

internal delegate MethodBase jswfuq8pWGd8m1GCqW2(RuntimeMethodHandle P_0, RuntimeTypeHandle P_1);
