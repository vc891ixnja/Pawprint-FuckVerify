internal delegate long oxLwyKq1REd9d0S7aC6(object P_0);
