using System.Reflection.Emit;

internal delegate void Cj9UDbiodtletAjhuUv(object P_0, OpCode P_1, int P_2);
