internal delegate bool hlDsd781od2Egg8Chmg(object P_0);
