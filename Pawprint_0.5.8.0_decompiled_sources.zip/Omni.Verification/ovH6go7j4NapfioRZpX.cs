using System;

internal delegate UInt128 ovH6go7j4NapfioRZpX(UInt128 P_0, int P_1);
