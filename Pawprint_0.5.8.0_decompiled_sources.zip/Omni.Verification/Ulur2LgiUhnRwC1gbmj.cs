using System;

internal delegate bool Ulur2LgiUhnRwC1gbmj(string P_0, ref Version P_1);
