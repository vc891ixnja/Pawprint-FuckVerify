internal delegate long PdR30Uqyi7Sw11lZPMW(object P_0);
