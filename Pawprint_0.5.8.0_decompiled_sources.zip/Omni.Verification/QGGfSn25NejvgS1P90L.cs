internal delegate bool QGGfSn25NejvgS1P90L(char P_0);
