using System;

internal delegate object hImhmlqz9IHm2d1atZY(Type P_0, ulong P_1);
