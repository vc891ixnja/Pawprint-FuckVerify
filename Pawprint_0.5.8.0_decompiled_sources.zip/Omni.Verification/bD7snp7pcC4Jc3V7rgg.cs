internal delegate string bD7snp7pcC4Jc3V7rgg(object P_0);
