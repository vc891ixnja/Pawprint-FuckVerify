using System;

internal delegate Type LDlGdeiUgaBNTdmaUY9(object P_0);
