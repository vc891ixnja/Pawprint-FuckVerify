using System;

internal delegate Type Efas8H4wsmE1vRRJsdc(object P_0);
