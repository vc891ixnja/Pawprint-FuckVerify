using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Dalamud.Plugin;

namespace Beastmaster.Integrations;

internal sealed class IntegrationHub
{
	public Configuration? Settings { get; set; }

	public VnavmeshClient Navigation { get; } = new VnavmeshClient();

	public LifestreamClient Travel { get; } = new LifestreamClient();

	public TextAdvanceClient TextAdvance { get; } = new TextAdvanceClient();

	public BossModClient BossMod { get; } = new BossModClient();

	public PromeRotationClient PromeRotation { get; } = new PromeRotationClient();

	public DailyRoutinesClient DailyRoutines { get; } = new DailyRoutinesClient();

	public AutoDutyClient AutoDuty { get; } = new AutoDutyClient();

	public IReadOnlyList<IntegrationStatus> Statuses { get; private set; } = Array.Empty<IntegrationStatus>();

	public IReadOnlyList<DependencyStatus> Dependencies { get; private set; } = Array.Empty<DependencyStatus>();

	public bool RequiredReady
	{
		get
		{
			if (Dependencies.Count > 0)
			{
				return Dependencies.Where((DependencyStatus d) => d.Required).All((DependencyStatus d) => d.Ready);
			}
			return false;
		}
	}

	public void Refresh()
	{
		DependencyStatus[] obj = new DependencyStatus[6]
		{
			Dependency("Lifestream", "跨区域传送到已解锁的大水晶", required: true, () => (Ready: Travel.CanTeleport, Detail: (!Travel.CanTeleport) ? "已加载，但传送接口不可用；请检查版本" : (Travel.IsBusy ? "已启用，正在处理其他行程；请等待结束" : "已启用，传送接口可用"))),
			Dependency("vnavmesh", "地面寻路、接近魔物与到点停止", required: true, () => (Ready: Navigation.MovementAllowed, Detail: (!Navigation.MovementAllowed) ? "插件已加载，但允许移动开关未开启" : ((Navigation.IsRunning || Navigation.IsPathfinding) ? "已启用，正在执行路径；请等待结束" : (Navigation.IsReady ? "已启用，移动允许，当前区域网格就绪" : "已启用，移动允许；进入目标区域后等待网格加载")))),
			Dependency("AutoDuty", "选择副本魔物时运行已有路线，发现目标后交接捕获", required: false, () => (Ready: AutoDuty.Available, Detail: AutoDuty.Available ? $"接口可用；正在运行：{AutoDuty.IsRunning}" : "运行或停止接口不可用")),
			null,
			null,
			null
		};
		Configuration settings = Settings;
		obj[3] = Dependency("PromeRotation", "XSZYYS 驯兽师 ACR", settings != null && settings.CombatBackend == CombatBackend.PromeRotation, delegate
		{
			new PromeTaskBackend(PromeRotation).RequireReady();
			return (Ready: true, Detail: "XSZYYS 与捕捉模式已就绪");
		});
		obj[4] = DodgeDependency(FieldDodgeBackend.BossMod);
		obj[5] = DodgeDependency(FieldDodgeBackend.BossModReborn);
		Dependencies = new global::_003C_003Ez__ReadOnlyArray<DependencyStatus>(obj);
		Statuses = new global::_003C_003Ez__ReadOnlyArray<IntegrationStatus>(new IntegrationStatus[6]
		{
			Probe("Lifestream", () => $"行程运行：{Travel.IsBusy}"),
			Probe("vnavmesh", () => (!Navigation.IsReady) ? "IPC 可用，当前网格未就绪" : "网格就绪"),
			Probe("BossMod", () => "当前预设：" + (BossMod.ActivePreset ?? "无（或多个）")),
			Probe("PromeRotation", () => $"循环运行：{PromeRotation.IsRunning}；ACR：{PromeRotation.CurrentAcr}"),
			Probe("Prome GreenMove", () => $"移动运行：{PromeRotation.IsMoving}"),
			Probe("AutoDuty", () => $"运行：{AutoDuty.IsRunning}；已停止：{AutoDuty.IsStopped}")
		});
	}

	private DependencyStatus DodgeDependency(FieldDodgeBackend backend)
	{
		string name = backend.ToString();
		Configuration settings = Settings;
		return Dependency(name, "野外战斗自动躲避", settings != null && settings.CombatEnabled && Settings.FieldDodge == backend, delegate
		{
			new BossModDodgeSession(backend).RequireReady();
			return (Ready: true, Detail: "AI 移动接口已就绪");
		});
	}

	public void RequireHunting()
	{
		Refresh();
		DependencyStatus[] array = Dependencies.Where((DependencyStatus d) => d.Required && !d.Ready).ToArray();
		if (array.Length != 0)
		{
			throw new InvalidOperationException("请先完成依赖配置：" + string.Join("；", array.Select((DependencyStatus d) => d.Name + "：" + d.Detail)));
		}
		if (Travel.IsBusy)
		{
			throw new InvalidOperationException("Lifestream 正在执行其他行程，请等待结束。");
		}
		if (Navigation.IsRunning || Navigation.IsPathfinding)
		{
			throw new InvalidOperationException("vnavmesh 正在执行其他路径，请等待结束。");
		}
	}

	internal static IExposedPlugin? FindInstalledPlugin(string name)
	{
		return PluginInstanceSelector.Select(Services.PluginInterface.InstalledPlugins, name, (IExposedPlugin p) => p.InternalName, (IExposedPlugin p) => p.IsLoaded);
	}

	private static DependencyStatus Dependency(string name, string purpose, bool required, Func<(bool Ready, string Detail)> read)
	{
		IExposedPlugin val = FindInstalledPlugin(name);
		if (val == null)
		{
			return new DependencyStatus(name, purpose, required, Ready: false, "尚未安装；请在插件安装器中安装");
		}
		if (!val.IsLoaded)
		{
			return new DependencyStatus(name, purpose, required, Ready: false, "已安装但未加载；请在插件安装器中启用");
		}
		try
		{
			(bool, string) tuple = read();
			return new DependencyStatus(name, purpose, required, tuple.Item1, $"{tuple.Item2}（{val.Version}）");
		}
		catch (Exception ex)
		{
			return new DependencyStatus(name, purpose, required, Ready: false, $"已加载 {val.Version}；{ex.Message}", ProbeFailed: true);
		}
	}

	private static IntegrationStatus Probe(string name, Func<string> read)
	{
		try
		{
			return new IntegrationStatus(name, Available: true, read());
		}
		catch (Exception ex)
		{
			return new IntegrationStatus(name, Available: false, "IPC 不可用或版本不匹配：" + ex.GetType().Name);
		}
	}
}
