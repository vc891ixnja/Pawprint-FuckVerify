using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Dalamud.Game.Command;
using Dalamud.Plugin;
using Dalamud.Plugin.Ipc;

namespace Beastmaster.Integrations;

internal sealed class BossModDodgeSession : IDisposable
{
	private PluginSettingsScope? settings;

	private object? ownedBehavior;

	private bool restoreForceDisabled;

	private readonly string name = backend.ToString();

	private static readonly Dictionary<string, string> LastReadErrors = new Dictionary<string, string>();

	private static readonly Dictionary<string, string> Desired = new Dictionary<string, string>
	{
		["ForbidActions"] = "True",
		["ForbidMovement"] = "False",
		["ManualTarget"] = "True",
		["FocusTargetMaster"] = "False",
		["FollowSlot"] = "0",
		["FollowOutOfCombat"] = "False",
		["FollowDuringCombat"] = "True",
		["FollowDuringActiveBossModule"] = "True",
		["FollowTarget"] = "True",
		["AutoAFK"] = "False",
		["Preset"] = "<none>"
	};

	public BossModDodgeSession(FieldDodgeBackend backend)
	{
	}

	internal BossModAiBinding Resolve()
	{
		IExposedPlugin[] array = Services.PluginInterface.InstalledPlugins.Where(delegate(IExposedPlugin p)
		{
			bool flag = p.IsLoaded;
			if (flag)
			{
				string internalName = p.InternalName;
				bool flag2 = ((internalName == "BossMod" || internalName == "BossModReborn") ? true : false);
				flag = flag2;
			}
			return flag;
		}).ToArray();
		if (array.Length != 1 || array[0].InternalName != name)
		{
			throw new InvalidOperationException("请只启用所选的 " + name + "，避免共享 IPC 冲突");
		}
		return BossModAiBinding.Resolve((from a in AppDomain.CurrentDomain.GetAssemblies()
			where a.GetName().Name == name
			select a.GetType("BossMod.AI.AIManager")).OfType<Type>(), Services.Commands.Commands.Select((KeyValuePair<string, IReadOnlyCommandInfo> c) => (Key: c.Key, (Delegate)(object)c.Value.Handler)));
	}

	public void RequireReady()
	{
		RequireSettings();
	}

	private Dictionary<string, string> RequireSettings()
	{
		Resolve();
		foreach (string key in Desired.Keys)
		{
			Read(key);
		}
		Dictionary<string, string> dictionary = new Dictionary<string, string>(Desired);
		foreach (KeyValuePair<string, string> item in BossModDistanceSettings.Resolve(Query))
		{
			dictionary.Add(item.Key, item.Value);
		}
		if (!((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<string, object>("BossMod.AI.SetPreset")).HasAction || !((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<bool>("BossMod.Presets.GetForceDisabled")).HasFunction || !((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<bool>("BossMod.Presets.SetForceDisabled")).HasFunction || !((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<string, bool>("BossMod.Presets.SetActive")).HasFunction)
		{
			throw new InvalidOperationException(name + " 缺少 AI 移动或预设接口");
		}
		return dictionary;
	}

	internal static List<string> Query(string key)
	{
		ICallGateSubscriber<List<string>, bool, List<string>> ipcSubscriber = Services.PluginInterface.GetIpcSubscriber<List<string>, bool, List<string>>("BossMod.Configuration");
		int num = 2;
		List<string> list = new List<string>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<string> span = CollectionsMarshal.AsSpan(list);
		span[0] = "AIConfig";
		span[1] = key;
		return ipcSubscriber.InvokeFunc(list, false);
	}

	internal static string Read(string key)
	{
		if (key == "Preset")
		{
			string text = Services.PluginInterface.GetIpcSubscriber<string>("BossMod.AI.GetPreset").InvokeFunc();
			if (!string.IsNullOrEmpty(text))
			{
				return text;
			}
			return "<none>";
		}
		List<string> list = Query(key);
		if (list.Count != 1 || string.IsNullOrWhiteSpace(list[0]))
		{
			string text2 = ((list.Count == 0) ? "接口返回空结果" : string.Join("；", list.Take(4)));
			if (LastReadErrors.GetValueOrDefault(key) != text2)
			{
				LastReadErrors[key] = text2;
				Services.Log.Warning("BossMod.Configuration read AIConfig." + key + ": " + string.Join(" | ", list), Array.Empty<object>());
			}
			throw new InvalidOperationException("BossMod 配置接口读取 " + key + " 失败：" + text2);
		}
		LastReadErrors.Remove(key);
		double result2;
		bool result;
		bool flag = !bool.TryParse(list[0], out result) && !double.TryParse(list[0], out result2);
		if (flag)
		{
			result = key == "DesiredPositional";
			if (result)
			{
				bool flag2;
				switch (list[0])
				{
				case "Any":
				case "Rear":
				case "Flank":
				case "Front":
					flag2 = true;
					break;
				default:
					flag2 = false;
					break;
				}
				result = flag2;
			}
			flag = !result;
		}
		if (flag)
		{
			throw new InvalidOperationException("BossMod 不支持设置 " + key + "：" + list[0]);
		}
		return list[0];
	}

	internal static void Write(string key, string value)
	{
		if (key == "Preset")
		{
			Services.PluginInterface.GetIpcSubscriber<string, object>("BossMod.AI.SetPreset").InvokeAction((value == "<none>") ? "" : value);
			return;
		}
		ICallGateSubscriber<List<string>, bool, List<string>> ipcSubscriber = Services.PluginInterface.GetIpcSubscriber<List<string>, bool, List<string>>("BossMod.Configuration");
		int num = 3;
		List<string> list = new List<string>(num);
		CollectionsMarshal.SetCount(list, num);
		Span<string> span = CollectionsMarshal.AsSpan(list);
		span[0] = "AIConfig";
		span[1] = key;
		span[2] = value;
		List<string> list2 = ipcSubscriber.InvokeFunc(list, false);
		if (list2.Count == 0)
		{
			return;
		}
		throw new InvalidOperationException("BossMod 无法设置 " + key + "：" + string.Join("；", list2));
	}

	public void Start()
	{
		BossModAiBinding bossModAiBinding = Resolve();
		if (ownedBehavior != null)
		{
			if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) != ownedBehavior)
			{
				throw new InvalidOperationException("BossMod AI 已在外部改变，任务已停止");
			}
			return;
		}
		Dictionary<string, string> values = RequireSettings();
		if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) != null)
		{
			throw new InvalidOperationException("BossMod AI 已在运行，请先关闭后启动 Pawprint 任务");
		}
		restoreForceDisabled = Services.PluginInterface.GetIpcSubscriber<bool>("BossMod.Presets.GetForceDisabled").InvokeFunc();
		if (!restoreForceDisabled && Services.PluginInterface.GetIpcSubscriber<string>("BossMod.Presets.GetActive").InvokeFunc() != null)
		{
			throw new InvalidOperationException("请先停用 BossMod 输出预设；野外躲避由 Pawprint 单独管理 AI");
		}
		settings = new PluginSettingsScope(Read, Write);
		try
		{
			settings.Apply(values);
			bossModAiBinding.SetEnabled(enabled: true);
			ownedBehavior = bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) ?? throw new InvalidOperationException("BossMod AI 未启动");
		}
		catch
		{
			Dispose();
			throw;
		}
	}

	public void Dispose()
	{
		try
		{
			if (ownedBehavior == null)
			{
				return;
			}
			BossModAiBinding bossModAiBinding = Resolve();
			if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) == ownedBehavior)
			{
				string text = Services.PluginInterface.GetIpcSubscriber<string>("BossMod.Presets.GetActive").InvokeFunc();
				bool num = Services.PluginInterface.GetIpcSubscriber<bool>("BossMod.Presets.GetForceDisabled").InvokeFunc();
				bossModAiBinding.SetEnabled(enabled: false);
				if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) != null)
				{
					throw new InvalidOperationException("BossMod AI 未能停止");
				}
				if (num || (text == null && restoreForceDisabled))
				{
					Services.PluginInterface.GetIpcSubscriber<bool>("BossMod.Presets.SetForceDisabled").InvokeFunc();
				}
				else if (text != null && !Services.PluginInterface.GetIpcSubscriber<string, bool>("BossMod.Presets.SetActive").InvokeFunc(text))
				{
					throw new InvalidOperationException("BossMod 外部预设恢复失败");
				}
			}
		}
		finally
		{
			ownedBehavior = null;
			restoreForceDisabled = false;
			PluginSettingsScope? pluginSettingsScope = settings;
			settings = null;
			pluginSettingsScope?.Dispose();
		}
	}
}
