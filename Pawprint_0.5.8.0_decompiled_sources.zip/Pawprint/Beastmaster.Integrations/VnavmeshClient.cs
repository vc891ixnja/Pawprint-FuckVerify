using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using Beastmaster.Core.Automation;

namespace Beastmaster.Integrations;

internal sealed class VnavmeshClient : INavigationProvider
{
	public bool IsReady => Services.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Nav.IsReady").InvokeFunc();

	public bool IsRunning => Services.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Path.IsRunning").InvokeFunc();

	public bool IsPathfinding => Services.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.SimpleMove.PathfindInProgress").InvokeFunc();

	public bool MovementAllowed => Services.PluginInterface.GetIpcSubscriber<bool>("vnavmesh.Path.GetMovementAllowed").InvokeFunc();

	public Task<List<Vector3>> FindPath(Vector3 from, Vector3 to, CancellationToken token, bool fly = false)
	{
		return Services.PluginInterface.GetIpcSubscriber<Vector3, Vector3, bool, CancellationToken, Task<List<Vector3>>>("vnavmesh.Nav.PathfindCancelable").InvokeFunc(from, to, fly, token);
	}

	public void Move(List<Vector3> points, bool fly = false)
	{
		Services.PluginInterface.GetIpcSubscriber<List<Vector3>, bool, object>("vnavmesh.Path.MoveTo").InvokeAction(points, fly);
	}

	public void Stop()
	{
		Services.PluginInterface.GetIpcSubscriber<object>("vnavmesh.Path.Stop").InvokeAction();
	}

	public Vector3? PointOnFloor(Vector3 position)
	{
		return Services.PluginInterface.GetIpcSubscriber<Vector3, bool, float, Vector3?>("vnavmesh.Query.Mesh.PointOnFloor").InvokeFunc(position, false, 5f);
	}
}
