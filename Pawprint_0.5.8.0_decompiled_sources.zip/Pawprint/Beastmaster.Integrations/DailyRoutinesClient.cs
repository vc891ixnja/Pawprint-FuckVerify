namespace Beastmaster.Integrations;

internal sealed class DailyRoutinesClient
{
	public bool? AutoFateEnabled => Services.PluginInterface.GetIpcSubscriber<string, bool?>("DailyRoutines.IsModuleEnabled").InvokeFunc("AutoFate");

	public bool EnableAutoFateModule()
	{
		return Services.PluginInterface.GetIpcSubscriber<string, bool, bool>("DailyRoutines.LoadModule").InvokeFunc("AutoFate", true);
	}
}
