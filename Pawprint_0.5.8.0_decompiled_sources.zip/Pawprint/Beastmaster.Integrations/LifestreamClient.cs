using Dalamud.Plugin.Ipc;

namespace Beastmaster.Integrations;

internal sealed class LifestreamClient
{
	public bool CanTeleport => ((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<uint, byte, bool>("Lifestream.Teleport")).HasFunction;

	public bool IsBusy => Services.PluginInterface.GetIpcSubscriber<bool>("Lifestream.IsBusy").InvokeFunc();

	public bool Teleport(uint aetheryteId)
	{
		return Services.PluginInterface.GetIpcSubscriber<uint, byte, bool>("Lifestream.Teleport").InvokeFunc(aetheryteId, (byte)0);
	}
}
