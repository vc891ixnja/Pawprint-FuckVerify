using System;
using System.Collections.Generic;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Dalamud.Plugin.Ipc;
using FFXIVClientStructs.FFXIV.Client.Game.UI;

namespace Beastmaster.Integrations;

internal sealed class AutoDutyClient : IAutoDutyNavigator
{
	private PluginSettingsScope? settings;

	private uint currentTerritory;

	public bool Available
	{
		get
		{
			if (((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<uint, int, bool, object>("AutoDuty.Run")).HasAction && ((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<object>("AutoDuty.Stop")).HasAction && ((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<string, string>("AutoDuty.GetConfig")).HasFunction)
			{
				return ((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<string, object, object>("AutoDuty.SetConfig")).HasAction;
			}
			return false;
		}
	}

	public bool IsRunning
	{
		get
		{
			if (!Services.PluginInterface.GetIpcSubscriber<bool>("AutoDuty.IsNavigating").InvokeFunc())
			{
				return Services.PluginInterface.GetIpcSubscriber<bool>("AutoDuty.IsLooping").InvokeFunc();
			}
			return true;
		}
	}

	public bool IsStopped => Services.PluginInterface.GetIpcSubscriber<bool>("AutoDuty.IsStopped").InvokeFunc();

	public bool HasPath(uint territory)
	{
		return Services.PluginInterface.GetIpcSubscriber<uint, bool>("AutoDuty.ContentHasPath").InvokeFunc(territory);
	}

	private unsafe void Prepare(uint territory)
	{
		if ((territory == 174 || territory == 355) ? true : false)
		{
			throw new InvalidOperationException("该多人副本暂不支持");
		}
		if (settings != null)
		{
			throw new InvalidOperationException("AutoDuty 捕获配置仍被占用");
		}
		currentTerritory = territory;
		settings = new PluginSettingsScope((string key) => Services.PluginInterface.GetIpcSubscriber<string, string>("AutoDuty.GetConfig").InvokeFunc(key), delegate(string key, string value)
		{
			Services.PluginInterface.GetIpcSubscriber<string, object, object>("AutoDuty.SetConfig").InvokeAction(key, (object)value);
		});
		settings.Apply(new Dictionary<string, string>
		{
			["Unsynced"] = "True",
			["dutyModeEnum"] = ((territory == 369) ? "Trial" : "Regular"),
			["AutoExitDuty"] = "False"
		});
		ContentsFinder* intPtr = ContentsFinder.Instance();
		if (intPtr == null)
		{
			throw new InvalidOperationException("任务搜索器尚未就绪");
		}
		((ContentsFinder)intPtr).IsUnrestrictedParty = true;
		((ContentsFinder)intPtr).IsLevelSync = false;
	}

	public void Run(uint territory)
	{
		try
		{
			Prepare(territory);
			Services.PluginInterface.GetIpcSubscriber<uint, int, bool, object>("AutoDuty.Run").InvokeAction(territory, 1, false);
		}
		catch
		{
			settings?.Dispose();
			settings = null;
			throw;
		}
	}

	public void Resume()
	{
		try
		{
			Prepare(currentTerritory);
			Services.PluginInterface.GetIpcSubscriber<bool, object>("AutoDuty.Start").InvokeAction(false);
		}
		catch
		{
			settings?.Dispose();
			settings = null;
			throw;
		}
	}

	public void Stop()
	{
		try
		{
			Services.PluginInterface.GetIpcSubscriber<object>("AutoDuty.Stop").InvokeAction();
		}
		finally
		{
			try
			{
				settings?.Dispose();
			}
			finally
			{
				settings = null;
			}
		}
	}
}
