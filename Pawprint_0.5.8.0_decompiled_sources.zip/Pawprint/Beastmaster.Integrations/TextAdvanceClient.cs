namespace Beastmaster.Integrations;

internal sealed class TextAdvanceClient
{
	public bool IsEnabled => Services.PluginInterface.GetIpcSubscriber<bool>("TextAdvance.IsEnabled").InvokeFunc();

	public bool IsExternallyControlled => Services.PluginInterface.GetIpcSubscriber<bool>("TextAdvance.IsInExternalControl").InvokeFunc();
}
