using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Hunting;
using Dalamud.Plugin;
using Dalamud.Plugin.Ipc;

namespace Beastmaster.Integrations;

internal sealed class PromeTaskBackend(PromeRotationClient client) : ITaskRotationBackend
{
	private object? owner;

	private object Settings
	{
		get
		{
			if (!Services.Commands.Commands.TryGetValue("/pr", out var value))
			{
				throw new InvalidOperationException("PromeRotation 尚未加载");
			}
			return ((Delegate)(object)value.Handler).Method.Module.Assembly.GetType("PromeRotation.Data.PromeSettings", throwOnError: true).GetProperty("Instance", BindingFlags.Static | BindingFlags.Public)?.GetValue(null) ?? throw new InvalidOperationException("PR 设置读取接口不兼容");
		}
	}

	public bool IsRunning => client.IsRunning;

	internal void BindToCurrentSettings()
	{
		if (owner == null)
		{
			owner = BoundSettings();
		}
	}

	public void RequireReady()
	{
		if (!Services.PluginInterface.InstalledPlugins.Any((IExposedPlugin p) => p.InternalName == "PromeRotation" && p.IsLoaded))
		{
			throw new InvalidOperationException("请安装并启用 PromeRotation");
		}
		if (!client.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("请在 PR 中选择 XSZYYS 驯兽师 ACR");
		}
		if (!Services.Commands.Commands.ContainsKey("/pr"))
		{
			throw new InvalidOperationException("PR 命令接口未就绪");
		}
		if (!((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.IPC.Start")).HasFunction || !((ICallGateSubscriber)Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.IPC.Stop")).HasFunction)
		{
			throw new InvalidOperationException("PR 启停接口未就绪");
		}
		Read("CaptureMode");
		Read("AutoPull");
		Read("TargetSelectorMode");
	}

	private object BoundSettings()
	{
		object settings = Settings;
		if (owner != null && owner != settings)
		{
			throw new InvalidOperationException("PR 已重载，任务已停止");
		}
		if (!client.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			throw new InvalidOperationException("PR 已切换 ACR，任务已停止");
		}
		return settings;
	}

	public string Read(string key)
	{
		object obj = BoundSettings();
		if (key == "CaptureMode")
		{
			if (!(obj.GetType().GetProperty("QuickToggles")?.GetValue(obj) is IReadOnlyDictionary<string, bool> readOnlyDictionary) || !readOnlyDictionary.TryGetValue("捕捉模式", out var value))
			{
				throw new InvalidOperationException("当前 ACR 没有“捕捉模式”QT，请加载下载版 XSZYYS");
			}
			return value.ToString();
		}
		return obj.GetType().GetProperty(key)?.GetValue(obj)?.ToString() ?? throw new InvalidOperationException("PR 缺少设置：" + key);
	}

	public void Write(string key, string value)
	{
		object obj = BoundSettings();
		if (owner == null)
		{
			owner = obj;
		}
		bool flag;
		switch (key)
		{
		case "CaptureMode":
		{
			bool flag2 = ArenaCombatPolicy.CaptureMode(Services.ClientState.TerritoryType, bool.Parse(value));
			if (!Services.Commands.ProcessCommand("/pr qt 捕捉模式 " + flag2.ToString().ToLowerInvariant()))
			{
				throw new InvalidOperationException("PR 未接受捕捉模式命令");
			}
			return;
		}
		case "AutoPull":
		case "TargetSelectorMode":
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag)
		{
			throw new ArgumentOutOfRangeException("key");
		}
		PropertyInfo propertyInfo = obj.GetType().GetProperty(key) ?? throw new InvalidOperationException("PR 缺少设置：" + key);
		propertyInfo.SetValue(obj, propertyInfo.PropertyType.IsEnum ? Enum.Parse(propertyInfo.PropertyType, value) : ((object)bool.Parse(value)));
	}

	public void Start()
	{
		if (!Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.IPC.Start").InvokeFunc() || !IsRunning)
		{
			throw new InvalidOperationException("PR 未能启动，请检查验证状态和当前 ACR");
		}
	}

	public void Stop()
	{
		if (!Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.IPC.Stop").InvokeFunc())
		{
			throw new InvalidOperationException("PR 未能停止");
		}
	}
}
