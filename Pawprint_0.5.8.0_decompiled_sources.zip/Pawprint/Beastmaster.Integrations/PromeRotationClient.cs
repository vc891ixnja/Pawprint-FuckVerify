namespace Beastmaster.Integrations;

internal sealed class PromeRotationClient
{
	public bool IsRunning => Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.IPC.IsRunning").InvokeFunc();

	public string CurrentAcr => Services.PluginInterface.GetIpcSubscriber<string>("PromeRotation.IPC.GetCurrentAcrName").InvokeFunc();

	public bool IsMoving => Services.PluginInterface.GetIpcSubscriber<bool>("PromeRotation.GreenMove.IsRunning").InvokeFunc();
}
