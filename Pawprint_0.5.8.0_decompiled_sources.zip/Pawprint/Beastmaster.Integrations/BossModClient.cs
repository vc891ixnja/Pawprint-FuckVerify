namespace Beastmaster.Integrations;

internal sealed class BossModClient
{
	public string? ActivePreset => Services.PluginInterface.GetIpcSubscriber<string>("BossMod.Presets.GetActive").InvokeFunc();

	public bool HasModule(uint dataId)
	{
		return Services.PluginInterface.GetIpcSubscriber<uint, bool>("BossMod.HasModuleByDataId").InvokeFunc(dataId);
	}
}
