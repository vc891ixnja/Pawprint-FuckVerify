namespace Beastmaster.Integrations;

internal sealed record DependencyStatus(string Name, string Purpose, bool Required, bool Ready, string Detail, bool ProbeFailed = false);
