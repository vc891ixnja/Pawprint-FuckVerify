using System;
using System.Collections;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Hunting;
using Beastmaster.Hunting;
using Dalamud.Game;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin;
using Lumina.Excel.Sheets;

namespace Beastmaster.Integrations;

internal sealed class TaskCombatSupport(Configuration config, IntegrationHub hub, Func<bool> authorized) : ITaskCombatSupport
{
	private TaskRotationSession? rotation;

	private BossModDodgeSession? dodge;

	public bool UsesExternalRotation => config.CombatBackend == CombatBackend.PromeRotation;

	private IBattleNpc Bind(ulong id)
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		if (authorized())
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && !((IGameObject)localPlayer).IsDead && ((ICharacter)localPlayer).ClassJob.RowId == 43 && !Services.Condition[(ConditionFlag)4] && !Services.Condition[(ConditionFlag)77] && !Services.Condition[(ConditionFlag)45] && !Services.Condition[(ConditionFlag)51])
			{
				IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc t) => ((IGameObject)t).GameObjectId == id && DalamudCombatWorld.IsAttackable(t))) ?? throw new InvalidOperationException("战斗目标已失效");
				IGameObject target = Services.Targets.Target;
				if (target == null || target.GameObjectId != id)
				{
					Services.Targets.Target = (IGameObject)(object)val;
				}
				IGameObject target2 = Services.Targets.Target;
				if (target2 == null || target2.GameObjectId != id)
				{
					throw new InvalidOperationException("无法锁定战斗目标");
				}
				return val;
			}
		}
		throw new InvalidOperationException("当前任务或角色状态不允许战斗");
	}

	public void Prepare()
	{
		if (!authorized())
		{
			throw new InvalidOperationException("任务未授权 PR 战斗");
		}
		if (!UsesExternalRotation)
		{
			RequireExclusiveBuiltIn();
			return;
		}
		if (rotation == null)
		{
			rotation = new TaskRotationSession(new PromeTaskBackend(hub.PromeRotation));
		}
		rotation.Prepare();
	}

	public void RunRotation(ulong targetId, bool capture)
	{
		capture = ArenaCombatPolicy.CaptureMode(Services.ClientState.TerritoryType, capture);
		IBattleNpc val = Bind(targetId);
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (((ICharacter)val).Level == 0 || (capture && ((ICharacter)localPlayer).Level < ((ICharacter)val).Level))
		{
			throw new InvalidOperationException("目标等级不满足当前任务条件");
		}
		if (Vector3.Distance(((IGameObject)localPlayer).Position, ((IGameObject)val).Position) - ((IGameObject)val).HitboxRadius > 3f)
		{
			StopRotation();
			return;
		}
		Prepare();
		rotation.Run(capture);
	}

	public void StopRotation()
	{
		TaskRotationSession taskRotationSession = rotation;
		rotation = null;
		try
		{
			taskRotationSession?.Dispose();
		}
		finally
		{
			if (taskRotationSession != null)
			{
				DalamudCombatWorld.DisableAutoAttack();
			}
		}
	}

	public bool WantsMovement(CombatTarget target)
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		TerritoryType val = default(TerritoryType);
		if (!authorized() || config.FieldDodge == FieldDodgeBackend.None || !Services.Condition[(ConditionFlag)26] || Services.Condition[(ConditionFlag)4] || Services.Condition[(ConditionFlag)77] || Services.Condition[(ConditionFlag)34] || Services.Condition[(ConditionFlag)56] || !Services.Data.GetExcelSheet<TerritoryType>((ClientLanguage?)null, (string)null).TryGetRow(Services.ClientState.TerritoryType, ref val) || ((TerritoryType)(ref val)).ContentFinderCondition.RowId != 0 || Services.Objects.LocalPlayer == null)
		{
			return false;
		}
		return true;
	}

	public void UpdateMovement(ulong targetId)
	{
		Bind(targetId);
		if (hub.Navigation.IsRunning)
		{
			throw new InvalidOperationException("等待 vnavmesh 释放路径后才能启用野外躲避");
		}
		if (!hub.Navigation.IsPathfinding)
		{
			if (dodge == null)
			{
				dodge = new BossModDodgeSession(config.FieldDodge);
			}
			dodge.Start();
		}
	}

	public void StopMovement()
	{
		BossModDodgeSession? bossModDodgeSession = dodge;
		dodge = null;
		bossModDodgeSession?.Dispose();
	}

	public void Stop()
	{
		try
		{
			StopRotation();
		}
		finally
		{
			StopMovement();
		}
	}

	public void RequireReady()
	{
		if (UsesExternalRotation)
		{
			new PromeTaskBackend(hub.PromeRotation).RequireReady();
		}
		else
		{
			RequireExclusiveBuiltIn();
		}
		if (config.FieldDodge != FieldDodgeBackend.None)
		{
			new BossModDodgeSession(config.FieldDodge).RequireReady();
		}
	}

	private void RequireExclusiveBuiltIn()
	{
		if (Services.PluginInterface.InstalledPlugins.Any((IExposedPlugin p) => p.InternalName == "PromeRotation" && p.IsLoaded) && hub.PromeRotation.IsRunning)
		{
			throw new InvalidOperationException("PR 正在运行，请停止 PR 或在插件配置选择 PR ACR");
		}
	}

	public void StopBeforeTravel()
	{
		if (UsesExternalRotation)
		{
			new PromeTaskBackend(hub.PromeRotation).Stop();
		}
	}

	public void ResetCaptureAfterNotebook()
	{
		StopRotation();
		IExposedPlugin val = IntegrationHub.FindInstalledPlugin("PromeRotation");
		if (val != null && val.IsLoaded && hub.PromeRotation.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			ArenaCombatPolicy.EnsureCaptureOff(new PromeTaskBackend(hub.PromeRotation), forceReset: true);
		}
	}
}
