namespace Beastmaster.Integrations;

public sealed record IntegrationStatus(string Name, bool Available, string Detail);
