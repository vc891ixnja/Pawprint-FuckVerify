namespace Beastmaster.Hunting;

internal sealed record LiveMonsterIdentity(uint NameId, uint BaseId, string Name, uint TerritoryId, ulong ObjectId, byte Level, float X, float Y, float Z);
