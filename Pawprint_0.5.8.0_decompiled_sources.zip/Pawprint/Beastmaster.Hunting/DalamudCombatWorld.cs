using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;
using Dalamud.Game;
using Dalamud.Game.ClientState.Aetherytes;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using Lumina.Excel.Sheets;

namespace Beastmaster.Hunting;

internal sealed class DalamudCombatWorld(DalamudHuntingWorld movement, CombatEvents events, NotebookReader notebook, Func<bool> canUseTaskActions, ITaskCombatSupport? combatSupport = null) : ILevelingWorld, ICombatWorld
{
	private int? confirmationNumber;

	private bool confirmationStarted;

	private bool confirmationFinished;

	public ITaskCombatSupport? CombatSupport => combatSupport;

	public ulong ContentId => movement.ContentId;

	public uint TerritoryId => movement.TerritoryId;

	public byte PlayerLevel => movement.PlayerLevel;

	public bool IsOnFoot
	{
		get
		{
			if (!movement.IsMounted && !movement.IsFlying)
			{
				return !movement.IsMountTransition;
			}
			return false;
		}
	}

	public bool InCombat => Services.Condition[(ConditionFlag)26];

	public WorldPoint? Player => movement.Player;

	public bool HasAttackTarget
	{
		get
		{
			IGameObject target = Services.Targets.Target;
			IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
			if (val != null)
			{
				return IsAttackable(val);
			}
			return false;
		}
	}

	public float PlayerHpRatio
	{
		get
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || ((ICharacter)localPlayer).MaxHp == 0)
			{
				return 0f;
			}
			return (float)((ICharacter)localPlayer).CurrentHp / (float)((ICharacter)localPlayer).MaxHp;
		}
	}

	public unsafe uint ComboAction
	{
		get
		{
			ActionManager* ptr = ActionManager.Instance();
			if (ptr == null || !(((ComboDetail)(&((ActionManager)ptr).Combo)).Timer > 0f))
			{
				return 0u;
			}
			return ((ComboDetail)(&((ActionManager)ptr).Combo)).Action;
		}
	}

	public long EventSequence => events.Sequence;

	internal static bool IsLivingCombatant(IBattleNpc target)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)target.BattleNpcKind == 5 && ((IGameObject)target).IsTargetable && !((IGameObject)target).IsDead)
		{
			return ((ICharacter)target).CurrentHp != 0;
		}
		return false;
	}

	internal unsafe static bool IsAttackable(IBattleNpc target)
	{
		if (IsLivingCombatant(target))
		{
			return ActionManager.CanUseActionOnTarget(44879u, (GameObject*)((IGameObject)target).Address);
		}
		return false;
	}

	public void StopAndClearTarget()
	{
		StopAutoAttack();
		IGameObject target = Services.Targets.Target;
		IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
		if (val != null && IsAttackable(val))
		{
			Services.Targets.Target = null;
		}
	}

	public bool CanTravelTo(uint territory)
	{
		if (territory != TerritoryId)
		{
			return ((IEnumerable<IAetheryteEntry>)Services.Aetherytes).Any((IAetheryteEntry a) => a.TerritoryId == territory && a.SubIndex == 0);
		}
		return true;
	}

	private static bool IsRegularEnemy(IBattleNpc target)
	{
		BNpcBase val = default(BNpcBase);
		if (IsAttackable(target) && ((GameObject)(nint)((IGameObject)target).Address).FateId == 0 && Services.Data.GetExcelSheet<BNpcBase>((ClientLanguage?)null, (string)null).TryGetRow(((IGameObject)target).BaseId, ref val))
		{
			return ((BNpcBase)(ref val)).Rank == 0;
		}
		return false;
	}

	public CombatTarget? FindLevelingTarget()
	{
		IPlayerCharacter player = Services.Objects.LocalPlayer;
		if (player == null)
		{
			return null;
		}
		IBattleNpc val = (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>()
			where IsRegularEnemy(n) && ((ICharacter)n).Level >= Math.Max(1, PlayerLevel - 2) && ((ICharacter)n).Level <= PlayerLevel && (!((Enum)((ICharacter)n).StatusFlags).HasFlag((Enum)(object)(StatusFlags)2) || ((IGameObject)n).TargetObjectId == ((IGameObject)player).GameObjectId)
			orderby ((IGameObject)n).TargetObjectId == ((IGameObject)player).GameObjectId descending, Vector3.DistanceSquared(((IGameObject)n).Position, ((IGameObject)player).Position)
			select n).FirstOrDefault();
		if (val != null)
		{
			return ReadTarget(((IGameObject)val).GameObjectId);
		}
		return null;
	}

	private unsafe static bool IsEngaged(IBattleNpc target)
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		if (IsAttackable(target))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null)
			{
				UIState* ptr = UIState.Instance();
				if (ptr != null)
				{
					for (int i = 0; i < Math.Clamp(((Hater)(&((UIState)ptr).Hater)).HaterCount, 0, 32); i++)
					{
						if (((Hater)(&((UIState)ptr).Hater)).Haters[i].EntityId == ((IGameObject)target).EntityId)
						{
							return true;
						}
					}
				}
				if (((Enum)((ICharacter)target).StatusFlags).HasFlag((Enum)(object)(StatusFlags)2))
				{
					return ((IGameObject)target).TargetObjectId == ((IGameObject)localPlayer).GameObjectId;
				}
				return false;
			}
		}
		return false;
	}

	public bool IsEngagedTarget(ulong id)
	{
		return ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Any((IBattleNpc n) => ((IGameObject)n).GameObjectId == id && IsEngaged(n));
	}

	public CombatTarget? FindEngagedTarget()
	{
		IPlayerCharacter player = Services.Objects.LocalPlayer;
		if (player == null)
		{
			return null;
		}
		IBattleNpc val = (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(IsEngaged)
			orderby Vector3.DistanceSquared(((IGameObject)n).Position, ((IGameObject)player).Position)
			select n).FirstOrDefault();
		if (val != null)
		{
			return ReadTarget(((IGameObject)val).GameObjectId);
		}
		return null;
	}

	public CombatTarget? ReadTarget(ulong id)
	{
		IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc n) => ((IGameObject)n).GameObjectId == id && (int)n.BattleNpcKind == 5));
		if (val == null)
		{
			return null;
		}
		Vector3 position = ((IGameObject)val).Position;
		return new CombatTarget(((IGameObject)val).GameObjectId, ((ICharacter)val).NameId, new WorldPoint(TerritoryId, position.X, position.Y, position.Z), ((ICharacter)val).Level, ((ICharacter)val).CurrentHp, ((ICharacter)val).MaxHp, ((IGameObject)val).IsDead, ((IGameObject)val).IsTargetable, ((IGameObject)val).HitboxRadius, IsAttackable(val));
	}

	public IReadOnlyList<CombatEvent> EventsAfter(long sequence)
	{
		return events.After(sequence);
	}

	public unsafe bool TryAction(uint actionId, ulong targetId)
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		if (!canUseTaskActions())
		{
			return false;
		}
		if (!ArenaCombatPolicy.AllowsAction(TerritoryId, actionId))
		{
			return false;
		}
		ITaskCombatSupport? combatSupport = CombatSupport;
		if (combatSupport != null && combatSupport.UsesExternalRotation && actionId != 44882)
		{
			return false;
		}
		bool flag;
		switch (actionId)
		{
		case 44879u:
		case 44880u:
		case 44882u:
		case 44883u:
		case 44885u:
			flag = true;
			break;
		default:
			flag = false;
			break;
		}
		if (!flag)
		{
			return false;
		}
		if (!IsOnFoot || movement.IsTransitioning || movement.IsCasting || PlayerLevel < BeastmasterActions.RequiredLevel(actionId))
		{
			return false;
		}
		IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc n) => ((IGameObject)n).GameObjectId == targetId && IsAttackable(n)));
		if (val != null)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && ((ICharacter)localPlayer).ClassJob.RowId == 43)
			{
				if (Vector3.Distance(((IGameObject)localPlayer).Position, ((IGameObject)val).Position) - ((IGameObject)val).HitboxRadius > 3f || !ActionManager.CanUseActionOnTarget(actionId, (GameObject*)((IGameObject)val).Address))
				{
					return false;
				}
				IGameObject target = Services.Targets.Target;
				if (target == null || target.GameObjectId != targetId)
				{
					Services.Targets.Target = (IGameObject)(object)val;
				}
				IGameObject target2 = Services.Targets.Target;
				if (target2 == null || target2.GameObjectId != targetId)
				{
					return false;
				}
				ActionManager* ptr = ActionManager.Instance();
				if (ptr == null || ((ActionManager)ptr).GetActionStatus((ActionType)1, actionId, targetId, true, true, (uint*)null) != 0)
				{
					return false;
				}
				return ((ActionManager)ptr).UseAction((ActionType)1, actionId, targetId, 0u, (UseActionMode)0, 0u, (bool*)null);
			}
		}
		return false;
	}

	public void StopAutoAttack()
	{
		DisableAutoAttack();
	}

	internal unsafe static void DisableAutoAttack()
	{
		UIState* ptr = UIState.Instance();
		if (ptr != null && ((AutoAttackState)(&((WeaponState)(&((UIState)ptr).WeaponState)).AutoAttackState)).Get())
		{
			((AutoAttackState)(&((WeaponState)(&((UIState)ptr).WeaponState)).AutoAttackState)).Set(false);
		}
	}

	public void RequestCaptureConfirmation(int number)
	{
		confirmationNumber = number;
		confirmationStarted = (confirmationFinished = false);
	}

	public CaptureState ReadCaptureConfirmation(int number)
	{
		if (confirmationNumber != number || !confirmationFinished)
		{
			return CaptureState.Unknown;
		}
		return notebook.GetFresh(number);
	}

	public void CancelCaptureConfirmation()
	{
		if (confirmationStarted && !confirmationFinished)
		{
			notebook.CancelScan("捕获确认已停止");
			notebook.Close();
		}
		confirmationNumber = null;
		confirmationStarted = (confirmationFinished = false);
	}

	public void UpdateConfirmation()
	{
		if (!confirmationNumber.HasValue || confirmationFinished || notebook.IsScanning)
		{
			return;
		}
		if (confirmationStarted)
		{
			if (notebook.TryClose())
			{
				confirmationFinished = true;
			}
		}
		else
		{
			notebook.RequestScan();
			confirmationStarted = true;
		}
	}
}
