using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Threading;
using Beastmaster.Core.Hunting;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Hooking;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.Character;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;
using FFXIVClientStructs.FFXIV.Component.Text;
using FFXIVClientStructs.STD;

namespace Beastmaster.Hunting;

internal sealed class CombatEvents : IDisposable
{
	private Hook<Receive>? effects;

	private Hook<ShowLogMessageSourceObjectTargetObject>? messages;

	private Hook<ShowLogMessageSourceObjectTargetObjectTextParameters>? parameterMessages;

	private readonly ConcurrentQueue<CombatEvent> inbox = new ConcurrentQueue<CombatEvent>();

	private readonly Queue<CombatEvent> history = new Queue<CombatEvent>();

	private readonly ConcurrentQueue<object> messageInbox = new ConcurrentQueue<object>();

	private readonly Queue<object> recentMessages = new Queue<object>();

	private long sequence;

	private uint localEntity;

	public object[] RecentMessages => recentMessages.ToArray();

	public long Sequence => Interlocked.Read(in sequence);

	public bool Ready { get; private set; }

	public string Status { get; private set; } = "捕获事件尚未初始化";

	public unsafe CombatEvents()
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Expected O, but got Unknown
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Expected O, but got Unknown
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Expected O, but got Unknown
		try
		{
			effects = Services.Interop.HookFromAddress<Receive>((IntPtr)(nint)MemberFunctionPointers.Receive, new Receive(OnEffect), (HookBackend)0);
			messages = Services.Interop.HookFromAddress<ShowLogMessageSourceObjectTargetObject>((IntPtr)(nint)MemberFunctionPointers.ShowLogMessageSourceObjectTargetObject, new ShowLogMessageSourceObjectTargetObject(OnMessage), (HookBackend)0);
			parameterMessages = Services.Interop.HookFromAddress<ShowLogMessageSourceObjectTargetObjectTextParameters>((IntPtr)(nint)MemberFunctionPointers.ShowLogMessageSourceObjectTargetObjectTextParameters, new ShowLogMessageSourceObjectTargetObjectTextParameters(OnParameterMessage), (HookBackend)0);
			effects.Enable();
			messages.Enable();
			parameterMessages.Enable();
			Ready = true;
			Status = "技能效果及识破/捕获消息 ID 监听已就绪";
		}
		catch (Exception ex)
		{
			Dispose();
			Status = "捕获事件不可用：" + ex.Message;
			Services.Log.Warning(ex, "Capture event hooks unavailable", Array.Empty<object>());
		}
	}

	private unsafe void OnEffect(uint casterId, Character* caster, Vector3* position, Header* header, TargetEffects* targetEffects, GameObjectId* targets)
	{
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		effects.Original.Invoke(casterId, caster, position, header, targetEffects, targets);
		try
		{
			bool flag = casterId != Volatile.Read(in localEntity) || localEntity == 0 || header == null || targets == null || targetEffects == null;
			if (!flag)
			{
				byte numTargets = ((Header)header).NumTargets;
				bool flag2 = ((numTargets > 32 || numTargets == 0) ? true : false);
				flag = flag2;
			}
			bool flag3 = flag;
			if (!flag3)
			{
				bool flag2;
				switch (((Header)header).ActionId)
				{
				case 44879u:
				case 44880u:
				case 44882u:
				case 44883u:
				case 44885u:
				case 46751u:
					flag2 = true;
					break;
				default:
					flag2 = false;
					break;
				}
				flag3 = !flag2;
			}
			if (flag3)
			{
				return;
			}
			for (int i = 0; i < ((Header)header).NumTargets; i++)
			{
				uint num = 0u;
				for (int j = 0; j < 8; j++)
				{
					Effect val = ((TargetEffects)((byte*)targetEffects + (nint)i * (nint)Unsafe.SizeOf<TargetEffects>())).Effects[j];
					if (val.Type == 3 && (val.Param4 & 0x80) == 0)
					{
						num += (uint)(val.Value + (((val.Param4 & 0x40) != 0) ? (val.Param3 << 16) : 0));
					}
				}
				Add(GameObjectId.op_Implicit(((GameObjectId*)targets)[i]), ((Header)header).ActionId, 0u, num);
			}
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Capture action observation failed", Array.Empty<object>());
		}
	}

	private unsafe void OnMessage(RaptureLogModule* module, uint id, GameObject* source, GameObject* target)
	{
		ObserveMessage(id, source, target);
		messages.Original.Invoke(module, id, source, target);
	}

	private unsafe void OnParameterMessage(RaptureLogModule* module, uint id, GameObject* source, GameObject* target, StdDeque<TextParameter>* parameters)
	{
		ObserveMessage(id, source, target);
		parameterMessages.Original.Invoke(module, id, source, target, parameters);
	}

	private unsafe void ObserveMessage(uint id, GameObject* source, GameObject* target)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			bool flag = CaptureMessages.IsInspect(id);
			if (!flag)
			{
				bool flag2 = ((id == 11400 || id == 11425) ? true : false);
				flag = flag2;
			}
			if (flag)
			{
				messageInbox.Enqueue(new
				{
					MessageId = id,
					Source = ((source == null) ? 0 : GameObjectId.op_Implicit(((GameObject)source).GetGameObjectId())),
					Target = ((target == null) ? 0 : GameObjectId.op_Implicit(((GameObject)target).GetGameObjectId())),
					LocalSource = (source != null && ((GameObject)source).EntityId == Volatile.Read(in localEntity))
				});
				if (source != null && target != null && localEntity != 0 && ((GameObject)source).EntityId == Volatile.Read(in localEntity))
				{
					Add(GameObjectId.op_Implicit(((GameObject)target).GetGameObjectId()), 0u, id, 0u);
				}
			}
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Capture log ID observation failed", Array.Empty<object>());
		}
	}

	private void Add(ulong target, uint action, uint message, uint damage)
	{
		inbox.Enqueue(new CombatEvent(0L, target, action, message, damage));
	}

	public void Update()
	{
		ref uint location = ref localEntity;
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		Volatile.Write(ref location, (localPlayer != null) ? ((IGameObject)localPlayer).EntityId : 0u);
		CombatEvent result;
		while (inbox.TryDequeue(out result))
		{
			history.Enqueue(result with
			{
				Sequence = Interlocked.Increment(ref sequence)
			});
			while (history.Count > 256)
			{
				history.Dequeue();
			}
		}
		object result2;
		while (messageInbox.TryDequeue(out result2))
		{
			recentMessages.Enqueue(result2);
			while (recentMessages.Count > 64)
			{
				recentMessages.Dequeue();
			}
		}
	}

	public IReadOnlyList<CombatEvent> After(long cursor)
	{
		return history.Where((CombatEvent e) => e.Sequence > cursor).ToArray();
	}

	public void Dispose()
	{
		Ready = false;
		effects?.Dispose();
		messages?.Dispose();
		parameterMessages?.Dispose();
	}
}
