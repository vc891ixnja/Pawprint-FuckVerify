using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Hunting;
using Dalamud.Game;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Lumina.Excel.Sheets;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Hunting;

internal sealed class MonsterDataService
{
	private MonsterNameIndex? index;

	private MonsterNameIndex Index => index ?? (index = new MonsterNameIndex(((IEnumerable<BNpcName>)Services.Data.GetExcelSheet<BNpcName>((ClientLanguage?)null, (string)null)).Select(delegate(BNpcName row)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		uint rowId = ((BNpcName)(ref row)).RowId;
		ReadOnlySeString singular = ((BNpcName)(ref row)).Singular;
		return new MonsterNameRow(rowId, ((ReadOnlySeString)(ref singular)).ExtractText());
	})));

	public MonsterNameSearch Search(string query)
	{
		return Index.Search(query);
	}

	public object Nearby(MonsterEntry entry)
	{
		return (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().OrderBy(delegate(IBattleNpc n)
			{
				IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
				return (localPlayer == null) ? 0f : Vector3.DistanceSquared(((IGameObject)n).Position, ((IGameObject)localPlayer).Position);
			}).Take(50)
			select new
			{
				Name = ((IGameObject)n).Name.TextValue,
				NameId = ((ICharacter)n).NameId,
				BaseId = ((IGameObject)n).BaseId,
				Level = ((ICharacter)n).Level,
				GameObjectId = ((IGameObject)n).GameObjectId,
				BattleNpcKind = n.BattleNpcKind,
				IsTargetable = ((IGameObject)n).IsTargetable,
				IsDead = ((IGameObject)n).IsDead,
				CurrentHp = ((ICharacter)n).CurrentHp,
				Flags = ((object)((ICharacter)n).StatusFlags/*cast due to .constrained prefix*/).ToString(),
				NameMatches = MonsterNameMatcher.Matches(entry, ((IGameObject)n).Name.TextValue),
				IdMatches = MonsterNameMatcher.MatchesId(entry, ((ICharacter)n).NameId),
				TargetCandidate = MonsterNameMatcher.IsCandidate(entry, ((IGameObject)n).Name.TextValue, (int)n.BattleNpcKind == 5, ((IGameObject)n).IsTargetable, ((IGameObject)n).IsDead, ((ICharacter)n).CurrentHp, ((ICharacter)n).NameId),
				LivingCombatant = DalamudCombatWorld.IsLivingCombatant(n),
				Attackable = DalamudCombatWorld.IsAttackable(n),
				X = ((IGameObject)n).Position.X,
				Y = ((IGameObject)n).Position.Y,
				Z = ((IGameObject)n).Position.Z
			}).ToArray();
	}

	public LiveMonsterIdentity? ReadCurrentTarget()
	{
		IGameObject target = Services.Targets.Target;
		IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
		if (val == null)
		{
			return null;
		}
		Vector3 position = ((IGameObject)val).Position;
		return new LiveMonsterIdentity(((ICharacter)val).NameId, ((IGameObject)val).BaseId, ((IGameObject)val).Name.TextValue, Services.ClientState.TerritoryType, ((IGameObject)val).GameObjectId, ((ICharacter)val).Level, position.X, position.Y, position.Z);
	}
}
