using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;
using Beastmaster.Integrations;
using Dalamud.Game;
using Dalamud.Game.ClientState.Aetherytes;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Character;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.UI;
using Lumina.Excel;
using Lumina.Excel.Sheets;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Hunting;

internal sealed class DalamudHuntingWorld(VnavmeshClient nav, LifestreamClient travel) : IHuntingWorld
{
	public ulong ContentId => Services.PlayerState.ContentId;

	public uint TerritoryId => Services.ClientState.TerritoryType;

	public bool IsTransitioning
	{
		get
		{
			if (!Services.Condition[(ConditionFlag)45])
			{
				return Services.Condition[(ConditionFlag)51];
			}
			return true;
		}
	}

	public bool IsInCutscene
	{
		get
		{
			if (!Services.Condition[(ConditionFlag)58] && !Services.Condition[(ConditionFlag)78])
			{
				return Services.Condition[(ConditionFlag)35];
			}
			return true;
		}
	}

	public bool IsCasting
	{
		get
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null)
			{
				return false;
			}
			return ((IBattleChara)localPlayer).IsCasting;
		}
	}

	public byte PlayerLevel
	{
		get
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null)
			{
				return 0;
			}
			return ((ICharacter)localPlayer).Level;
		}
	}

	public unsafe bool CanFlyInTerritory
	{
		get
		{
			if (!IsTransitioning && PlayerState.Instance() != null)
			{
				return ((PlayerState)PlayerState.Instance()).CanFly;
			}
			return false;
		}
	}

	public bool IsMounted
	{
		get
		{
			if (!Services.Condition[(ConditionFlag)4])
			{
				IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
				if (localPlayer != null)
				{
					return ((Character)(nint)((IGameObject)localPlayer).Address).IsMounted();
				}
				return false;
			}
			return true;
		}
	}

	public bool IsFlying => Services.Condition[(ConditionFlag)77];

	public bool IsMountTransition
	{
		get
		{
			if (!Services.Condition[(ConditionFlag)64] && !Services.Condition[(ConditionFlag)71])
			{
				return Services.Condition[(ConditionFlag)57];
			}
			return true;
		}
	}

	public bool CanTakeOff
	{
		get
		{
			if (IsMounted)
			{
				return Control.CanFly;
			}
			return false;
		}
	}

	public WorldPoint? Player
	{
		get
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null)
			{
				return null;
			}
			return new WorldPoint(TerritoryId, ((IGameObject)localPlayer).Position.X, ((IGameObject)localPlayer).Position.Y, ((IGameObject)localPlayer).Position.Z);
		}
	}

	public unsafe bool TryMount()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		if (!CanFlyInTerritory || IsMounted || IsMountTransition || IsCasting || Services.Condition[(ConditionFlag)26])
		{
			return false;
		}
		TerritoryType row = Services.Data.GetExcelSheet<TerritoryType>((ClientLanguage?)null, (string)null).GetRow(TerritoryId);
		if (!((TerritoryType)(ref row)).Mount)
		{
			return false;
		}
		ActionManager* ptr = ActionManager.Instance();
		Services.Targets.Target = null;
		Services.Targets.SoftTarget = null;
		if (ptr == null || ((ActionManager)ptr).GetActionStatus((ActionType)5, 9u, 3758096384uL, true, true, (uint*)null) != 0)
		{
			return false;
		}
		return ((ActionManager)ptr).UseAction((ActionType)5, 9u, 3758096384uL, 0u, (UseActionMode)0, 0u, (bool*)null);
	}

	public unsafe bool TryDismount()
	{
		ActionManager* ptr = ActionManager.Instance();
		if (IsMounted && !IsMountTransition && !IsCasting && ptr != null && ((ActionManager)ptr).GetActionStatus((ActionType)5, 23u, 3758096384uL, true, true, (uint*)null) == 0)
		{
			return ((ActionManager)ptr).UseAction((ActionType)5, 23u, 3758096384uL, 0u, (UseActionMode)0, 0u, (bool*)null);
		}
		return false;
	}

	public unsafe bool TryTakeOff()
	{
		if (CanTakeOff && !IsFlying && !IsMountTransition && !IsCasting && ActionManager.Instance() != null)
		{
			return ((ActionManager)ActionManager.Instance()).UseAction((ActionType)5, 2u, 3758096384uL, 0u, (UseActionMode)0, 0u, (bool*)null);
		}
		return false;
	}

	public AetheryteDestination? SelectAetheryte(MapDestination monster)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0168: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0171: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		Vector2 xz = GetWorldXZ(monster);
		List<AetheryteDestination> list = new List<AetheryteDestination>();
		foreach (IAetheryteEntry item in (IEnumerable<IAetheryteEntry>)Services.Aetherytes)
		{
			if (item.TerritoryId != monster.TerritoryId || item.SubIndex != 0)
			{
				continue;
			}
			Aetheryte row = Services.Data.GetExcelSheet<Aetheryte>((ClientLanguage?)null, (string)null).GetRow(item.AetheryteId);
			if (!((Aetheryte)(ref row)).IsAetheryte)
			{
				continue;
			}
			Map row2 = Services.Data.GetExcelSheet<Map>((ClientLanguage?)null, (string)null).GetRow(monster.MapId);
			Enumerator<MapMarker> enumerator2 = Services.Data.GetSubrowExcelSheet<MapMarker>((ClientLanguage?)null, (string)null).GetRow((uint)((Map)(ref row2)).MapMarkerRange).GetEnumerator();
			try
			{
				while (enumerator2.MoveNext())
				{
					MapMarker current2 = enumerator2.Current;
					if (((MapMarker)(ref current2)).DataType == 3)
					{
						RowRef dataKey = ((MapMarker)(ref current2)).DataKey;
						if (((RowRef)(ref dataKey)).RowId == item.AetheryteId)
						{
							Vector2 position = new Vector2(((float)((MapMarker)(ref current2)).X - 1024f) * 100f / (float)(int)((Map)(ref row2)).SizeFactor - (float)((Map)(ref row2)).OffsetX, ((float)((MapMarker)(ref current2)).Y - 1024f) * 100f / (float)(int)((Map)(ref row2)).SizeFactor - (float)((Map)(ref row2)).OffsetY);
							uint aetheryteId = item.AetheryteId;
							uint territoryId = monster.TerritoryId;
							PlaceName value = ((Aetheryte)(ref row)).PlaceName.Value;
							ReadOnlySeString name = ((PlaceName)(ref value)).Name;
							list.Add(new AetheryteDestination(aetheryteId, territoryId, ((ReadOnlySeString)(ref name)).ExtractText(), item.GilCost, position));
							break;
						}
					}
				}
			}
			finally
			{
				((IDisposable)enumerator2/*cast due to .constrained prefix*/).Dispose();
			}
		}
		return list.OrderBy((AetheryteDestination c) => Vector2.DistanceSquared(c.Position, xz)).FirstOrDefault();
	}

	public bool Teleport(AetheryteDestination destination)
	{
		if (IsTransitioning || IsCasting || Services.Condition[(ConditionFlag)26])
		{
			return false;
		}
		if (!((IEnumerable<IAetheryteEntry>)Services.Aetherytes).Any((IAetheryteEntry a) => a.AetheryteId == destination.Id && a.SubIndex == 0))
		{
			return false;
		}
		if (!travel.IsBusy)
		{
			return travel.Teleport(destination.Id);
		}
		return false;
	}

	public WorldPoint ResolveGround(MapDestination monster, Vector2 offset)
	{
		if (TerritoryId != monster.TerritoryId)
		{
			throw new InvalidOperationException("尚未抵达目标区域");
		}
		Vector2 vector = GetWorldXZ(monster) + offset;
		Vector3 vector2 = nav.PointOnFloor(new Vector3(vector.X, 1024f, vector.Y)) ?? throw new GroundPointUnavailableException("分布坐标附近没有可达地面");
		return new WorldPoint(TerritoryId, vector2.X, vector2.Y, vector2.Z);
	}

	private static Vector2 GetWorldXZ(MapDestination monster)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		if (!monster.IsValid)
		{
			throw new InvalidOperationException("目的地坐标不完整");
		}
		Map row = Services.Data.GetExcelSheet<Map>((ClientLanguage?)null, (string)null).GetRow(monster.MapId);
		if (((Map)(ref row)).TerritoryType.RowId != monster.TerritoryId)
		{
			throw new InvalidOperationException("地图与区域不匹配");
		}
		return MapCoordinates.ToWorld(monster.MapX, monster.MapY, ((Map)(ref row)).SizeFactor, ((Map)(ref row)).OffsetX, ((Map)(ref row)).OffsetY);
	}

	public MonsterObservation? FindMonster(MonsterEntry monster, IReadOnlySet<ulong>? excludedObjectIds = null, ulong? preferredObjectId = null)
	{
		if (TerritoryId != monster.TerritoryId || Player == null)
		{
			return null;
		}
		Vector3 player = Player.Position;
		IBattleNpc val = (from n in (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(delegate(IBattleNpc n)
				{
					IReadOnlySet<ulong>? readOnlySet = excludedObjectIds;
					return readOnlySet == null || !readOnlySet.Contains(((IGameObject)n).GameObjectId);
				})
				where MonsterNameMatcher.IsCandidate(monster, ((IGameObject)n).Name.TextValue, (int)n.BattleNpcKind == 5, ((IGameObject)n).IsTargetable, ((IGameObject)n).IsDead, ((ICharacter)n).CurrentHp, ((ICharacter)n).NameId)
				select n).Where(DalamudCombatWorld.IsAttackable)
			orderby ((IGameObject)n).GameObjectId == preferredObjectId && ((ICharacter)n).Level > 0 && ((ICharacter)n).Level <= PlayerLevel descending, ((ICharacter)n).Level > 0 && ((ICharacter)n).Level <= PlayerLevel descending, Vector3.DistanceSquared(((IGameObject)n).Position, player)
			select n).FirstOrDefault();
		if (val != null)
		{
			return new MonsterObservation(((IGameObject)val).GameObjectId, ((ICharacter)val).NameId, new WorldPoint(TerritoryId, ((IGameObject)val).Position.X, ((IGameObject)val).Position.Y, ((IGameObject)val).Position.Z), ((ICharacter)val).Level, ((IGameObject)val).HitboxRadius);
		}
		return null;
	}

	public bool SelectMonster(MonsterObservation monster)
	{
		IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc n) => ((IGameObject)n).GameObjectId == monster.ObjectId && ((ICharacter)n).NameId == monster.NameId && ((IGameObject)n).IsTargetable && !((IGameObject)n).IsDead && ((ICharacter)n).CurrentHp != 0 && DalamudCombatWorld.IsAttackable(n)));
		if (val == null || TerritoryId != monster.Location.TerritoryId)
		{
			return false;
		}
		IGameObject target = Services.Targets.Target;
		if (((target != null) ? new ulong?(target.GameObjectId) : ((ulong?)null)) != ((IGameObject)val).GameObjectId)
		{
			Services.Targets.Target = (IGameObject)(object)val;
		}
		return IsMonsterSelected(monster);
	}

	public bool IsMonsterSelected(MonsterObservation monster)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Invalid comparison between Unknown and I4
		IGameObject target = Services.Targets.Target;
		IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
		if (val != null && ((IGameObject)val).GameObjectId == monster.ObjectId && ((ICharacter)val).NameId == monster.NameId && ((IGameObject)val).IsTargetable && !((IGameObject)val).IsDead && ((ICharacter)val).CurrentHp != 0 && (int)val.BattleNpcKind == 5)
		{
			return TerritoryId == monster.Location.TerritoryId;
		}
		return false;
	}
}
