using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using Beastmaster.Core.Hunting;
using Dalamud.Game.Addon.Lifecycle;
using Dalamud.Game.Addon.Lifecycle.AddonArgTypes;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Hunting;

internal sealed class NotebookPaging(string version) : IDisposable
{
	private sealed record EventSample(string Kind, byte Type, int Parameter, int? Page, uint NodeId);

	private sealed record RegisteredEvent(uint NodeId, uint EventNodeId, byte Type, uint Parameter, bool Visible, bool Enabled, bool AddonListener);

	private readonly Queue<EventSample> events = new Queue<EventSample>();

	private readonly NotebookPageTurnController turns = new NotebookPageTurnController();

	private nint scanAddon;

	public void Initialize()
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected O, but got Unknown
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Expected O, but got Unknown
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Expected O, but got Unknown
		Services.AddonLifecycle.RegisterListener((AddonEvent)11, "XBMMonsterNotebook", new AddonEventDelegate(OnEvent));
		Services.AddonLifecycle.RegisterListener((AddonEvent)12, "XBMMonsterNotebook", new AddonEventDelegate(OnEvent));
		Services.AddonLifecycle.RegisterListener((AddonEvent)6, "XBMMonsterNotebook", new AddonEventDelegate(OnFinalize));
	}

	public void Reset()
	{
		turns.Reset();
		scanAddon = 0;
	}

	private void OnFinalize(AddonEvent kind, AddonArgs args)
	{
		Reset();
	}

	private void Record(EventSample sample)
	{
		events.Enqueue(sample);
		while (events.Count > 256)
		{
			events.Dequeue();
		}
	}

	private unsafe void OnEvent(AddonEvent kind, AddonArgs args)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Expected I4, but got Unknown
		AddonReceiveEventArgs e = (AddonReceiveEventArgs)(object)((args is AddonReceiveEventArgs) ? args : null);
		if (e != null)
		{
			AtkEvent* atkEvent = (AtkEvent*)e.AtkEvent;
			Record(new EventSample(((object)(*(AddonEvent*)(&kind))/*cast due to .constrained prefix*/).ToString(), (byte)(int)e.AtkEventType, e.EventParam, GetPage((AtkUnitBase*)args.Addon.Address), (atkEvent != null && ((AtkEvent)atkEvent).Node != null) ? ((AtkResNode)((AtkEvent)atkEvent).Node).NodeId : 0u));
		}
	}

	private unsafe static int? GetPage(AtkUnitBase* addon)
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Invalid comparison between Unknown and I4
		if (addon != null && ((AtkUnitBase)addon).IsVisible && ((AtkUnitBase)addon).AtkValues != null && ((AtkUnitBase)addon).AtkValuesCount >= 224 && (int)((AtkValue)((byte*)((AtkUnitBase)addon).AtkValues + (nint)10 * (nint)Unsafe.SizeOf<AtkValue>())).Type == 5 && ((AtkValue)((byte*)((AtkUnitBase)addon).AtkValues + (nint)10 * (nint)Unsafe.SizeOf<AtkValue>())).UInt <= 1)
		{
			return (int)((AtkValue)((byte*)((AtkUnitBase)addon).AtkValues + (nint)10 * (nint)Unsafe.SizeOf<AtkValue>())).UInt;
		}
		return null;
	}

	public unsafe bool TryFlip(int page)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		if (version != "2026.09.01.0000.0000")
		{
			return false;
		}
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName("XBMMonsterNotebook", 1).Address;
		if (GetPage(address) != page)
		{
			return false;
		}
		if (scanAddon != (nint)address)
		{
			Reset();
			scanAddon = (nint)address;
		}
		if (!UiInteractionDelay.Ready($"notebook/page/{address}/{page}"))
		{
			return true;
		}
		if (!turns.TryRequest(page, TimeSpan.FromMilliseconds(Environment.TickCount64)))
		{
			return true;
		}
		NotebookPageCallback notebookPageCallback = NotebookPageTurnController.CallbackFor(page);
		AtkValue* ptr = (AtkValue*)stackalloc AtkValue[2];
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = notebookPageCallback.Callback;
		Unsafe.Write(ptr, val);
		byte* num = (byte*)ptr + Unsafe.SizeOf<AtkValue>();
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)5;
		val.UInt = notebookPageCallback.Page;
		Unsafe.Write(num, val);
		Record(new EventSample("AutomaticPageCallback", 0, (int)notebookPageCallback.Page, page, 0u));
		if (!((AtkUnitBase)address).FireCallback(2u, ptr, true))
		{
			Services.Log.Warning("Notebook page callback was rejected on attempt {Attempt}", new object[1] { turns.Attempts });
		}
		return true;
	}

	private unsafe static bool Visible(AtkResNode* node)
	{
		int num = 0;
		while (node != null && num < 32)
		{
			if (!((AtkResNode)node).IsVisible())
			{
				return false;
			}
			num++;
			node = ((AtkResNode)node).ParentNode;
		}
		return node == null;
	}

	private unsafe static void Find(AtkUldManager* manager, AtkEventListener* listener, Dictionary<nint, RegisteredEvent> result, int depth)
	{
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Invalid comparison between Unknown and I4
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Expected I4, but got Unknown
		if (depth > 4 || ((AtkUldManager)manager).NodeListCount > 2048 || ((AtkUldManager)manager).NodeList == null)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null)
			{
				continue;
			}
			AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)ptr).AtkEventManager)).Event;
			for (int j = 0; ptr2 != null && j < 64; j++, ptr2 = ((AtkEvent)ptr2).NextEvent)
			{
				if (((AtkEvent)ptr2).Listener != listener)
				{
					if (depth != 0)
					{
						continue;
					}
					uint nodeId = ((AtkResNode)ptr).NodeId;
					if (nodeId < 13 || nodeId > 23)
					{
						continue;
					}
				}
				result.TryAdd((nint)ptr2, new RegisteredEvent(((AtkResNode)ptr).NodeId, (((AtkEvent)ptr2).Node != null) ? ((AtkResNode)((AtkEvent)ptr2).Node).NodeId : 0u, (byte)(int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType, ((AtkEvent)ptr2).Param, Visible(ptr), ((Enum)((AtkResNode)ptr).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32), ((AtkEvent)ptr2).Listener == listener));
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
				if (component != null)
				{
					Find(&((AtkComponentBase)component).UldManager, listener, result, depth + 1);
				}
			}
		}
	}

	public unsafe object Diagnostics()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<nint, RegisteredEvent> dictionary = new Dictionary<nint, RegisteredEvent>();
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName("XBMMonsterNotebook", 1).Address;
		if (address != null)
		{
			Find(&((AtkUnitBase)address).UldManager, (AtkEventListener*)address, dictionary, 0);
		}
		return new
		{
			WaitingPage = turns.WaitingPage,
			Attempts = turns.Attempts,
			Events = events.ToArray(),
			RegisteredEvents = dictionary.Values.ToArray()
		};
	}

	public void Dispose()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected O, but got Unknown
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Expected O, but got Unknown
		Services.AddonLifecycle.UnregisterListener((AddonEventDelegate[])(object)new AddonEventDelegate[1] { OnEvent });
		Services.AddonLifecycle.UnregisterListener((AddonEventDelegate[])(object)new AddonEventDelegate[1] { OnFinalize });
	}
}
