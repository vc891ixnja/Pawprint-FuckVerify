using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Hunting;
using Dalamud.Configuration;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;

namespace Beastmaster.Hunting;

internal sealed class NotebookReader : IDisposable
{
	private readonly NotebookPaging paging;

	private readonly Configuration config;

	private bool scanning;

	private bool openRequested;

	private DateTimeOffset scanStarted;

	private ulong scanCharacter;

	private long lastScanRefresh;

	private bool scanSawWindow;

	private string lastReadError = "";

	private string? lastRosterError;

	private readonly PagedCaptureJournal journal = new PagedCaptureJournal();

	private ulong character;

	public string GameVersion { get; } = ReadGameVersion();

	public string Status { get; private set; } = "点击读取图鉴，检查全部 50 项收集状态。";

	public bool IsOpen { get; private set; }

	public bool IsScanning => scanning;

	public long CompletedScans { get; private set; }

	public unsafe bool IsVisibleNow
	{
		get
		{
			//IL_000b: Unknown result type (might be due to invalid IL or missing references)
			AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName("XBMMonsterNotebook", 1).Address;
			if (address != null)
			{
				return ((AtkUnitBase)address).IsVisible;
			}
			return false;
		}
	}

	public CaptureState GetFresh(int number)
	{
		return journal.Get(number, Services.PlayerState.ContentId, DateTimeOffset.UtcNow);
	}

	public CaptureState Get(int number)
	{
		CaptureState fresh = GetFresh(number);
		if (fresh == CaptureState.Unknown)
		{
			return config.NotebookCaches.FirstOrDefault((NotebookCache c) => c.ContentId == Services.PlayerState.ContentId && c.GameVersion == GameVersion)?.Get(number, Services.PlayerState.ContentId, GameVersion) ?? CaptureState.Unknown;
		}
		return fresh;
	}

	public NotebookReader(Configuration config)
	{
		this.config = config;
		if (config.NotebookCaches == null)
		{
			List<NotebookCache> list = (config.NotebookCaches = new List<NotebookCache>());
		}
		paging = new NotebookPaging(GameVersion);
		paging.Initialize();
	}

	public void RequestScan()
	{
		journal.Reset();
		paging.Reset();
		character = Services.PlayerState.ContentId;
		scanCharacter = character;
		scanning = true;
		scanSawWindow = false;
		lastReadError = "";
		scanStarted = DateTimeOffset.UtcNow;
		openRequested = true;
		Status = "正在打开魔物图鉴，等待数据刷新…";
	}

	public void CancelScan(string reason)
	{
		if (scanning)
		{
			Status = reason;
		}
		scanning = (openRequested = false);
		paging.Reset();
	}

	public void Update()
	{
		if (openRequested)
		{
			if (!Services.ClientState.IsLoggedIn || Services.PlayerState.ContentId != scanCharacter)
			{
				CancelScan("角色变化，图鉴扫描已取消");
				return;
			}
			if (IsVisibleNow)
			{
				openRequested = false;
			}
			else if (UiInteractionDelay.Ready("notebook/open"))
			{
				openRequested = false;
				try
				{
					Open();
				}
				catch
				{
					scanning = false;
					throw;
				}
			}
		}
		if (scanning && Environment.TickCount64 - lastScanRefresh >= 250)
		{
			lastScanRefresh = Environment.TickCount64;
			Refresh();
		}
	}

	public unsafe void Open()
	{
		if (!Services.ClientState.IsLoggedIn)
		{
			throw new InvalidOperationException("请先登录角色");
		}
		AgentModule* intPtr = AgentModule.Instance();
		if (intPtr == null)
		{
			throw new InvalidOperationException("游戏界面尚未加载");
		}
		AgentInterface* agentByInternalId = ((AgentModule)intPtr).GetAgentByInternalId((AgentId)500);
		if (agentByInternalId == null)
		{
			throw new InvalidOperationException("魔物图鉴界面不可用");
		}
		((AgentInterface)agentByInternalId).Show();
	}

	public unsafe void Close()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		openRequested = false;
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName("XBMMonsterNotebook", 1).Address;
		if (address != null && ((AtkUnitBase)address).IsVisible)
		{
			((AtkUnitBase)address).Close(true);
		}
	}

	public bool TryClose()
	{
		if (!IsVisibleNow)
		{
			openRequested = false;
			return true;
		}
		if (!UiInteractionDelay.Ready("notebook/close"))
		{
			return false;
		}
		Close();
		return true;
	}

	public void Refresh()
	{
		if (character != Services.PlayerState.ContentId || !Services.ClientState.IsLoggedIn)
		{
			journal.Reset();
			character = Services.PlayerState.ContentId;
			CancelScan("角色发生变化，图鉴扫描已取消。");
		}
		if (scanning && (scanCharacter == 0L || scanCharacter != character || DateTimeOffset.UtcNow - scanStarted > TimeSpan.FromSeconds(30L)))
		{
			journal.Reset();
			CancelScan("图鉴扫描超时或角色发生变化，已取消。" + lastReadError);
			return;
		}
		try
		{
			NotebookSnapshot notebookSnapshot = Read();
			IsOpen = notebookSnapshot != null;
			if (notebookSnapshot == null)
			{
				if (scanning && scanSawWindow)
				{
					journal.Reset();
					CancelScan("图鉴已关闭，扫描已取消。");
				}
				else
				{
					Status = (scanning ? "正在打开魔物图鉴…" : "显示已保存的图鉴记录");
				}
				return;
			}
			scanSawWindow = true;
			NotebookPage notebookPage = NotebookPageDecoder.Decode(notebookSnapshot);
			journal.Apply(notebookPage);
			lastReadError = "";
			int num = Enumerable.Range(1, 50).Count((int n) => GetFresh(n) != CaptureState.Unknown);
			if (num == 50)
			{
				Dictionary<int, CaptureState> dictionary = Enumerable.Range(1, 50).ToDictionary((int n) => n, GetFresh);
				NotebookCache old = config.NotebookCaches.FirstOrDefault((NotebookCache c) => c.ContentId == character && c.GameVersion == GameVersion);
				if (old == null || dictionary.Any((KeyValuePair<int, CaptureState> s) => old.Get(s.Key, character, GameVersion) != s.Value))
				{
					config.NotebookCaches.RemoveAll((NotebookCache c) => c.ContentId == character);
					config.NotebookCaches.Add(new NotebookCache(character, GameVersion, DateTimeOffset.UtcNow, dictionary));
					Services.PluginInterface.SavePluginConfig((IPluginConfiguration)(object)config);
				}
			}
			Status = ((num == 50) ? $"已确认全部 50 项：已捕获 {notebookPage.CapturedCount} / 未捕获 {50 - notebookPage.CapturedCount}（{DateTime.Now:HH:mm:ss}）。" : $"已读取第 {notebookPage.PageIndex + 1} 页，已确认 {num}/50 项。");
			if (scanning && num < 50)
			{
				if (paging.TryFlip(notebookPage.PageIndex))
				{
					Status = "正在自动读取另一页图鉴…";
				}
				else
				{
					Status = "等待图鉴页码更新…";
				}
				return;
			}
			if (scanning && num == 50)
			{
				CompletedScans++;
			}
			scanning = false;
			paging.Reset();
		}
		catch (TimeoutException ex)
		{
			journal.Reset();
			CancelScan(ex.Message);
		}
		catch (Exception ex2)
		{
			lastReadError = ex2.Message;
			Status = (scanning ? ("等待图鉴数据刷新：" + ex2.Message) : ("图鉴读取未完成：" + ex2.Message));
		}
	}

	public string Export(object? runtime = null)
	{
		NotebookSnapshot notebookSnapshot = Read();
		string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
		Directory.CreateDirectory(text);
		string text2 = Path.Combine(text, $"xbm-notebook-{DateTime.Now:yyyyMMdd-HHmmss-fff}.json");
		File.WriteAllText(text2, JsonSerializer.Serialize(((object)notebookSnapshot) ?? ((object)new
		{
			NotebookClosed = true,
			Cache = config.NotebookCaches.FirstOrDefault((NotebookCache c) => c.ContentId == Services.PlayerState.ContentId)
		}), new JsonSerializerOptions
		{
			WriteIndented = true,
			Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
		}));
		File.WriteAllText(Path.ChangeExtension(text2, ".paging.json"), JsonSerializer.Serialize(paging.Diagnostics(), new JsonSerializerOptions
		{
			WriteIndented = true
		}));
		File.WriteAllText(Path.ChangeExtension(text2, ".runtime.json"), JsonSerializer.Serialize(new
		{
			Status = Status,
			IsScanning = IsScanning,
			Runtime = runtime
		}, new JsonSerializerOptions
		{
			WriteIndented = true,
			Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
		}));
		return text2;
	}

	public bool TryReadRoster(out NotebookPage? page)
	{
		page = null;
		NotebookSnapshot notebookSnapshot = null;
		try
		{
			notebookSnapshot = Read();
			if (notebookSnapshot == null)
			{
				throw new InvalidOperationException("等待编组图鉴打开");
			}
			page = ArenaRosterNotebookDecoder.Decode(notebookSnapshot);
			lastRosterError = null;
			return true;
		}
		catch (InvalidOperationException ex)
		{
			string text = $"{ex.Message}; values={(((object)notebookSnapshot != null) ? notebookSnapshot.Values.Length : 0)}";
			if (lastRosterError != text)
			{
				lastRosterError = text;
				Services.Log.Warning("Arena roster notebook waiting for data: " + text, Array.Empty<object>());
				try
				{
					string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
					Directory.CreateDirectory(text2);
					File.WriteAllText(Path.Combine(text2, "arena-roster-notebook-latest.json"), JsonSerializer.Serialize(new
					{
						At = DateTimeOffset.Now,
						Error = text,
						Snapshot = notebookSnapshot
					}, new JsonSerializerOptions
					{
						WriteIndented = true,
						Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
					}));
				}
				catch (Exception ex2)
				{
					Services.Log.Warning(ex2, "Arena roster notebook diagnostic failed", Array.Empty<object>());
				}
			}
			return false;
		}
	}

	private unsafe NotebookSnapshot? Read()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Expected I4, but got Unknown
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0107: Invalid comparison between Unknown and I4
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Invalid comparison between Unknown and I4
		if (!Services.ClientState.IsLoggedIn || Services.PlayerState.ContentId == 0L)
		{
			return null;
		}
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName("XBMMonsterNotebook", 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible || ((AtkUnitBase)address).AtkValues == null || ((AtkUnitBase)address).AtkValuesCount == 0)
		{
			return null;
		}
		if (((AtkUnitBase)address).AtkValuesCount > 4096)
		{
			throw new InvalidOperationException("图鉴字段数量超出校验范围");
		}
		List<NotebookValue> list = new List<NotebookValue>();
		for (int i = 0; i < ((AtkUnitBase)address).AtkValuesCount; i++)
		{
			AtkValue val = ((AtkValue*)((AtkUnitBase)address).AtkValues)[i];
			AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
			long? number = (val2 - 2) switch
			{
				0 => val.Bool ? 1 : 0, 
				1 => val.Int, 
				3 => val.UInt, 
				2 => val.Int64, 
				_ => null, 
			};
			bool flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
			string text = (flag ? ((object)(*(CStringPointer*)(&val.String))/*cast due to .constrained prefix*/).ToString() : null);
			if (text != null && text.Length > 2048)
			{
				text = text.Substring(0, 2048);
			}
			list.Add(new NotebookValue(i, ((object)(*(AtkValueType*)(&val.Type))/*cast due to .constrained prefix*/).ToString(), number, text));
		}
		return new NotebookSnapshot(GameVersion, Services.PlayerState.ContentId, DateTimeOffset.UtcNow, list.ToArray());
	}

	private static string ReadGameVersion()
	{
		try
		{
			return File.ReadAllText(Path.Combine(Path.GetDirectoryName(Environment.ProcessPath), "ffxivgame.ver")).Trim();
		}
		catch
		{
			return "unknown";
		}
	}

	public void Dispose()
	{
		paging.Dispose();
	}
}
