using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using Beastmaster.Arena;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Beastmaster.Hunting;
using Beastmaster.Integrations;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Interface.Textures.TextureWraps;
using Dalamud.Interface.Windowing;

namespace Beastmaster.Windows;

internal sealed class MainWindow(Plugin plugin, Configuration config, WorkflowRunner runner, IntegrationHub integrations) : Window("Pawprint###BeastmasterMain")
{
	private sealed class PriorityView
	{
		public string Search = "";

		public int Category;

		public Dictionary<uint, int> Ranks = new Dictionary<uint, int>();

		public IReadOnlyList<uint>? Source;

		public List<uint> Full = new List<uint>();
	}

	private readonly Dictionary<string, PriorityView> priorityViews = new Dictionary<string, PriorityView>();

	private string? priorityDragScope;

	private int arenaNode = -1;

	private string? arenaEditorPreset;

	private string presetShareText = "";

	private string presetShareNotice = "";

	private const string NodeWindow = "节点设置###ArenaNodeEditor";

	private bool nodeEditorOpen;

	private int arenaEditorStage = -1;

	private int arenaRandomOutcome = -1;

	private bool routeInitialScroll = true;

	private string arenaExpandedRule = "";

	private const string RuleAddPopup = "###ArenaRuleAdd";

	private const string RuleResetPopup = "###ArenaRuleReset";

	private readonly Dictionary<string, string> ruleSearch = new Dictionary<string, string>();

	private static readonly string[] RuleTriggerLabels = new string[8] { "进入战斗", "开战经过", "敌人HP低于", "敌人存活超过", "敌人数量达到", "当前目标是", "重新召唤后", "玩家HP低于" };

	private static readonly string[] RuleTargetLabels = new string[6] { "无", "玩家自己", "当前目标", "触发的敌人", "指定敌人", "已召唤魔兽" };

	private static readonly string[] RuleActionLabels = new string[6] { "使用道具", "使用职责技", "目标优先", "倒计时", "PR最后一击", "背后接近" };

	private static readonly string[] PetSlotLabels = new string[4] { "任意魔兽", "1 号魔兽", "2 号魔兽", "3 号魔兽" };

	private static readonly string[] RuleOnceLabels = new string[4] { "不限次数", "每场一次", "每个目标一次", "每次召唤一次" };

	private bool onlyMissing;

	private string monsterQuery = "";

	private MonsterNameSearch? monsterMatches;

	private string monsterQueryError = "";

	private readonly PluginConfigurationPanel pluginConfiguration = new PluginConfigurationPanel(plugin, config, integrations);

	private string? requestedMainTab;

	private bool titleButtonsReady;

	private bool supportRequested;

	private Vector2 supportPosition;

	private void DrawPresetSelector(ArenaStage stage)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		ArenaPresetCollection arenaPresetCollection = plugin.PresetsFor(stage.Id);
		if (arenaPresetCollection == null)
		{
			return;
		}
		ImGui.SetNextItemWidth(220f);
		if (!ImGui.BeginCombo(ImU8String.op_Implicit("预设"), ImU8String.op_Implicit(arenaPresetCollection.Selected.Name), (ImGuiComboFlags)0))
		{
			return;
		}
		foreach (ArenaPreset item in arenaPresetCollection.Presets.Where((ArenaPreset p) => p.StageId == stage.Id))
		{
			ImU8String val = new ImU8String(2, 2);
			((ImU8String)(ref val)).AppendFormatted<string>(item.Name);
			((ImU8String)(ref val)).AppendLiteral("##");
			((ImU8String)(ref val)).AppendFormatted<string>(item.Id);
			if (ImGui.Selectable(val, item.Id == arenaPresetCollection.Selected.Id, (ImGuiSelectableFlags)0, default(Vector2)))
			{
				arenaPresetCollection.SelectedId = item.Id;
				plugin.Save();
			}
		}
		ImGui.EndCombo();
	}

	private void DrawPresetEditor(ArenaStage stage)
	{
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_0173: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_025e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_027e: Unknown result type (might be due to invalid IL or missing references)
		ArenaPresetCollection arenaPresetCollection = plugin.PresetsFor(stage.Id);
		if (arenaPresetCollection == null)
		{
			ImGui.TextUnformatted(ImU8String.op_Implicit("登录后设置预设"));
			return;
		}
		ArenaPreset selected = arenaPresetCollection.Selected;
		if (arenaEditorStage != stage.Id || arenaEditorPreset != selected.Id)
		{
			arenaEditorStage = stage.Id;
			arenaEditorPreset = selected.Id;
			arenaNode = -1;
			arenaRandomOutcome = -1;
			nodeEditorOpen = false;
			routeInitialScroll = true;
			priorityViews.Clear();
			priorityDragScope = null;
		}
		ImGui.PushID(ImU8String.op_Implicit("ArenaPresetEditor"));
		if (ImGui.BeginTabBar(ImU8String.op_Implicit("ArenaPresetTabs_v4"), (ImGuiTabBarFlags)128))
		{
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("预设设置"), (ImGuiTabItemFlags)32))
			{
				DrawPresetManagement(arenaPresetCollection, selected);
				DrawResourceGoals(selected, arenaPresetCollection);
				bool useFood = selected.UseFood;
				if (ImGui.Checkbox(ImU8String.op_Implicit("使用食物"), ref useFood))
				{
					selected.UseFood = useFood;
					plugin.Save();
				}
				if (ImGui.IsItemHovered())
				{
					ImGui.SetTooltip(ImU8String.op_Implicit("每局开始前在局外检查：食物增益剩余不足 15 分钟时自动吃 炖剑山芋 或 焦糖爆米花"));
				}
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("入场编组"), (ImGuiTabItemFlags)32))
			{
				DrawArenaRoster(selected.Roster, stage.RosterCapacity);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("路线图"), (ImGuiTabItemFlags)32))
			{
				DrawArenaRoute(selected);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("优先级"), (ImGuiTabItemFlags)32))
			{
				DrawAcquisitionPriorities(selected);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("其他设置"), (ImGuiTabItemFlags)32))
			{
				int effectiveOpeningMode = (int)selected.EffectiveOpeningMode;
				string[] array = new string[4] { "进入战斗后10s自动开怪", "进入战斗后调用ACR起手", "不自动开怪", "进入战斗后调用驯兽师助手ACR起手" };
				ImGui.SetNextItemWidth(Math.Min(330f, ImGui.GetContentRegionAvail().X));
				if (ImGui.Combo(ImU8String.op_Implicit("开怪方式"), ref effectiveOpeningMode, (ReadOnlySpan<string>)array, array.Length))
				{
					selected.OpeningMode = (ArenaOpeningMode)effectiveOpeningMode;
					selected.AutoPullAfterTenSeconds = selected.OpeningMode == ArenaOpeningMode.TenSecondAttack;
					plugin.Save();
				}
				DrawHealSection(selected, inBattle: false);
				DrawHealSection(selected, inBattle: true);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("预设分享"), (ImGuiTabItemFlags)32))
			{
				DrawPresetSharing(arenaPresetCollection, selected);
				ImGui.EndTabItem();
			}
			if (ImGui.BeginTabItem(ImU8String.op_Implicit("统计"), (ImGuiTabItemFlags)32))
			{
				DrawArenaStatistics();
				ImGui.EndTabItem();
			}
			ImGui.EndTabBar();
		}
		ImGui.PopID();
	}

	private void DrawHealSection(ArenaPreset preset, bool inBattle)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011b: Unknown result type (might be due to invalid IL or missing references)
		if (!ImGui.CollapsingHeader(ImU8String.op_Implicit(inBattle ? "战斗内补血" : "战斗外补血"), (ImGuiTreeNodeFlags)0))
		{
			return;
		}
		ImGui.PushID(ImU8String.op_Implicit(inBattle ? "battleHeal" : "boardHeal"));
		ImGui.BeginDisabled(preset.Resources.NoItems);
		bool flag = (inBattle ? preset.HealDuringBattle : preset.HealBeforeBattle);
		if (ImGui.Checkbox(ImU8String.op_Implicit("启用"), ref flag))
		{
			if (inBattle)
			{
				preset.HealDuringBattle = flag;
			}
			else
			{
				preset.HealBeforeBattle = flag;
			}
			plugin.Save();
		}
		ImGui.BeginDisabled(!flag);
		int value = (inBattle ? preset.BattleHealBelowPercent : preset.HealBelowPercent);
		ImGui.SetNextItemWidth(130f);
		if (ImGui.InputInt(ImU8String.op_Implicit("玩家体力低于 (%)"), ref value, 0, 0, default(ImU8String), (ImGuiInputTextFlags)0))
		{
			if (inBattle)
			{
				preset.BattleHealBelowPercent = Math.Clamp(value, 1, 100);
			}
			else
			{
				preset.HealBelowPercent = Math.Clamp(value, 1, 100);
			}
			plugin.Save();
		}
		DrawItemPriority(inBattle ? "battleHeal" : "heal", inBattle ? preset.BattleHealingPriority : preset.HealingPriority, ArenaPriorityKind.Healing, delegate(List<uint> order)
		{
			if (inBattle)
			{
				preset.BattleHealingPriority = order;
			}
			else
			{
				preset.HealingPriority = order;
			}
			plugin.Save();
		}, 210f);
		ImGui.EndDisabled();
		ImGui.EndDisabled();
		ImGui.PopID();
	}

	private void DrawPresetManagement(ArenaPresetCollection collection, ArenaPreset preset)
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		string name = preset.Name;
		ImGui.SetNextItemWidth(240f);
		if (ImGui.InputText(ImU8String.op_Implicit("名称"), ref name, 64, (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null))
		{
			preset.Name = name;
			plugin.Save();
		}
		if (ImGui.Button(ImU8String.op_Implicit("复制为新预设"), default(Vector2)))
		{
			ArenaPreset arenaPreset = preset.Duplicate();
			collection.Presets.Add(arenaPreset);
			collection.SelectedId = arenaPreset.Id;
			plugin.Save();
		}
		SameLineIfFits(ButtonWidth("删除预设"));
		ImGui.BeginDisabled(collection.Presets.Count <= 1);
		if (ImGui.Button(ImU8String.op_Implicit("删除预设"), default(Vector2)))
		{
			collection.Presets.Remove(preset);
			collection.SelectedId = collection.Presets[0].Id;
			plugin.Save();
		}
		ImGui.EndDisabled();
		SameLineIfFits(ButtonWidth("恢复默认预设"));
		if (ImGui.Button(ImU8String.op_Implicit("恢复默认预设"), default(Vector2)))
		{
			collection.ResetDefault();
			arenaEditorPreset = null;
			nodeEditorOpen = false;
			plugin.Save();
			presetShareNotice = "已切回默认预设";
		}
	}

	private void DrawPresetSharing(ArenaPresetCollection collection, ArenaPreset preset)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0230: Unknown result type (might be due to invalid IL or missing references)
		if (ImGui.Button(ImU8String.op_Implicit("导出并复制"), default(Vector2)))
		{
			try
			{
				presetShareText = ArenaPresetShare.Export(preset);
				ImGui.SetClipboardText(ImU8String.op_Implicit(presetShareText));
				presetShareNotice = "已复制：" + preset.Name;
			}
			catch (FormatException ex)
			{
				presetShareNotice = ex.Message;
			}
		}
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("粘贴字符串"), default(Vector2)))
		{
			string clipboardText = ImGui.GetClipboardText();
			if (clipboardText.Length > 65536)
			{
				presetShareNotice = "预设字符串过长";
			}
			else
			{
				presetShareText = clipboardText;
				presetShareNotice = "";
			}
		}
		ImGui.InputTextMultiline(ImU8String.op_Implicit("##PresetShare"), ref presetShareText, 65537, new Vector2(-1f, 110f), (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null);
		if (ImGui.Button(ImU8String.op_Implicit("导入为新预设"), default(Vector2)))
		{
			try
			{
				ArenaPreset imported = ArenaPresetShare.Import(presetShareText, collection.StageId);
				imported.Resources.MigratePriorities(imported);
				string name = imported.Name;
				int num = 2;
				while (collection.Presets.Any((ArenaPreset p) => p.Name == imported.Name))
				{
					imported.Name = $"{((name.Length > 48) ? name.Substring(0, 48) : name)} ({num++})";
				}
				collection.Presets.Add(imported);
				collection.SelectedId = imported.Id;
				plugin.Save();
				presetShareNotice = "已导入：" + imported.Name;
			}
			catch (FormatException ex2)
			{
				presetShareNotice = "导入失败：" + ex2.Message;
			}
		}
		if (presetShareNotice.Length > 0)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(presetShareNotice));
		}
	}

	private void DrawArenaStatistics()
	{
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0318: Unknown result type (might be due to invalid IL or missing references)
		ArenaStatistics arenaStats = plugin.ArenaStats;
		if (arenaStats == null)
		{
			return;
		}
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(24, 3);
		((ImU8String)(ref val)).AppendLiteral("全局：累计 ");
		((ImU8String)(ref val)).AppendFormatted<ulong>(arenaStats.Runs);
		((ImU8String)(ref val)).AppendLiteral(" 局 · 失败 ");
		((ImU8String)(ref val)).AppendFormatted<ulong>(arenaStats.Failures);
		((ImU8String)(ref val)).AppendLiteral(" 局 · 最高 ");
		((ImU8String)(ref val)).AppendFormatted<uint>(arenaStats.BestScore, "N0");
		((ImU8String)(ref val)).AppendLiteral(" 分");
		ImGui.TextUnformatted(val);
		ImU8String val2 = default(ImU8String);
		((ImU8String)(ref val2))._002Ector(17, 2);
		((ImU8String)(ref val2)).AppendLiteral("低纯度兽核晶 ");
		((ImU8String)(ref val2)).AppendFormatted<ulong>(arenaStats.LowCrystals, "N0");
		((ImU8String)(ref val2)).AppendLiteral(" · 高纯度兽核晶 ");
		((ImU8String)(ref val2)).AppendFormatted<ulong>(arenaStats.HighCrystals, "N0");
		ImGui.TextUnformatted(val2);
		if (arenaStats.Ratings.Count > 0)
		{
			ImGui.TextUnformatted(ImU8String.op_Implicit("称号\u3000" + string.Join(" · ", arenaStats.Ratings.Select<KeyValuePair<string, ulong>, string>((KeyValuePair<string, ulong> kv) => $"{kv.Key} ×{kv.Value:N0}"))));
		}
		ArenaStatistics arenaSession = plugin.ArenaSession;
		if (arenaSession != null && arenaSession.Runs != 0)
		{
			ImU8String val3 = default(ImU8String);
			((ImU8String)(ref val3))._002Ector(21, 3);
			((ImU8String)(ref val3)).AppendLiteral("本轮：");
			((ImU8String)(ref val3)).AppendFormatted<ulong>(arenaSession.Runs);
			((ImU8String)(ref val3)).AppendLiteral(" 局 · 失败 ");
			((ImU8String)(ref val3)).AppendFormatted<ulong>(arenaSession.Failures);
			((ImU8String)(ref val3)).AppendLiteral(" 局 · 最高 ");
			((ImU8String)(ref val3)).AppendFormatted<uint>(arenaSession.BestScore, "N0");
			((ImU8String)(ref val3)).AppendLiteral(" 分");
			ImGui.TextUnformatted(val3);
			ImU8String val4 = default(ImU8String);
			((ImU8String)(ref val4))._002Ector(17, 2);
			((ImU8String)(ref val4)).AppendLiteral("低纯度兽核晶 ");
			((ImU8String)(ref val4)).AppendFormatted<ulong>(arenaSession.LowCrystals, "N0");
			((ImU8String)(ref val4)).AppendLiteral(" · 高纯度兽核晶 ");
			((ImU8String)(ref val4)).AppendFormatted<ulong>(arenaSession.HighCrystals, "N0");
			ImGui.TextUnformatted(val4);
			if (arenaSession.Ratings.Count > 0)
			{
				ImGui.TextUnformatted(ImU8String.op_Implicit("称号\u3000" + string.Join(" · ", arenaSession.Ratings.Select<KeyValuePair<string, ulong>, string>((KeyValuePair<string, ulong> kv) => $"{kv.Key} ×{kv.Value:N0}"))));
			}
		}
		ArenaRunResult lastResult = arenaStats.LastResult;
		if ((object)lastResult != null)
		{
			ImU8String val5 = default(ImU8String);
			((ImU8String)(ref val5))._002Ector(16, 5);
			((ImU8String)(ref val5)).AppendLiteral("上局 ");
			((ImU8String)(ref val5)).AppendFormatted<string>(ArenaStage.Get(lastResult.StageId).Name);
			((ImU8String)(ref val5)).AppendFormatted<string>(lastResult.Failed ? "（失败）" : "");
			((ImU8String)(ref val5)).AppendLiteral(" · ");
			((ImU8String)(ref val5)).AppendFormatted<uint>(lastResult.Score, "N0");
			((ImU8String)(ref val5)).AppendLiteral(" 分");
			((ImU8String)(ref val5)).AppendFormatted<string>(string.IsNullOrWhiteSpace(lastResult.Rating) ? "" : (" · " + lastResult.Rating));
			((ImU8String)(ref val5)).AppendLiteral(" · 兽核晶 +");
			((ImU8String)(ref val5)).AppendFormatted<uint>(lastResult.LowCrystals + lastResult.HighCrystals);
			ImGui.TextUnformatted(val5);
		}
	}

	private string ArenaPetName(uint id)
	{
		if (id == 0)
		{
			return "—";
		}
		MonsterEntry monsterEntry = plugin.Catalog.Monsters.FirstOrDefault((MonsterEntry m) => m.Number == id);
		return monsterEntry?.SpeciesName ?? monsterEntry?.Name ?? id.ToString();
	}

	private bool PetChoice(string label, ref uint value, IReadOnlyList<uint> roster)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		bool result = false;
		if (ImGui.BeginCombo(ImU8String.op_Implicit(label), ImU8String.op_Implicit((value == 0) ? "未指定" : ArenaPetName(value)), (ImGuiComboFlags)0))
		{
			if (ImGui.Selectable(ImU8String.op_Implicit("未指定"), value == 0, (ImGuiSelectableFlags)0, default(Vector2)))
			{
				value = 0u;
				result = true;
			}
			foreach (MonsterEntry item in from m in plugin.Catalog.Monsters
				orderby roster.Contains((uint)m.Number) descending, m.Number
				select m)
			{
				uint number = (uint)item.Number;
				ImU8String val = new ImU8String(1, 3);
				((ImU8String)(ref val)).AppendFormatted<int>(item.Number, "00");
				((ImU8String)(ref val)).AppendLiteral(" ");
				((ImU8String)(ref val)).AppendFormatted<string>(ArenaPetName(number));
				((ImU8String)(ref val)).AppendFormatted<string>((roster.Count > 0 && !roster.Contains(number)) ? "（未编入）" : "");
				if (ImGui.Selectable(val, value == number, (ImGuiSelectableFlags)0, default(Vector2)))
				{
					value = number;
					result = true;
				}
			}
			ImGui.EndCombo();
		}
		return result;
	}

	private void DrawBattleFlutes(ArenaPreset preset, int node)
	{
		DrawBattleFlutes(preset, preset.Battle(node));
	}

	private void DrawBattleFlutes(ArenaPreset preset, ArenaBattlePreset battle)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		float cursorPosX = ImGui.GetCursorPosX();
		float num = Math.Max(260f, ImGui.GetContentRegionAvail().X);
		float num2 = 60f;
		ImGuiStylePtr style = ImGui.GetStyle();
		float x = ((ImGuiStylePtr)(ref style)).ItemInnerSpacing.X;
		float num3 = Math.Max(70f, (num - num2 - x * 2f) / 2f);
		ImGui.TextUnformatted(ImU8String.op_Implicit("兽角"));
		ImGui.SameLine(cursorPosX + num2);
		ImGui.TextUnformatted(ImU8String.op_Implicit("A · 优先"));
		ImGui.SameLine(cursorPosX + num2 + num3 + x);
		ImGui.TextUnformatted(ImU8String.op_Implicit("B · 替补"));
		ImGui.Separator();
		ImU8String val = default(ImU8String);
		for (int i = 0; i < 3; i++)
		{
			ArenaFluteChoice arenaFluteChoice = battle.Flutes[i];
			ImGui.PushID((IntPtr)i);
			((ImU8String)(ref val))._002Ector(2, 1);
			((ImU8String)(ref val)).AppendFormatted<int>(i + 1);
			((ImU8String)(ref val)).AppendLiteral(" 号");
			ImGui.TextUnformatted(val);
			ImGui.SameLine(cursorPosX + num2);
			ImGui.SetNextItemWidth(num3);
			uint value = arenaFluteChoice.A;
			if (PetChoice("##A", ref value, preset.Roster))
			{
				arenaFluteChoice.A = value;
				plugin.Save();
			}
			ImGui.SameLine(cursorPosX + num2 + num3 + x);
			ImGui.SetNextItemWidth(num3);
			uint value2 = arenaFluteChoice.B;
			if (PetChoice("##B", ref value2, preset.Roster))
			{
				arenaFluteChoice.B = value2;
				plugin.Save();
			}
			ImGui.PopID();
		}
	}

	private unsafe void DrawItemPriority(string id, IReadOnlyList<uint> saved, ArenaPriorityKind kind, Action<List<uint>> save, float? fixedHeight = null, ArenaResources? resources = null, ArenaAcquisitionPriority? acquisition = null)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_04f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_038f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0422: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0530: Unknown result type (might be due to invalid IL or missing references)
		//IL_04af: Unknown result type (might be due to invalid IL or missing references)
		//IL_0562: Unknown result type (might be due to invalid IL or missing references)
		//IL_0578: Unknown result type (might be due to invalid IL or missing references)
		//IL_058e: Unknown result type (might be due to invalid IL or missing references)
		//IL_05a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_05be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0643: Unknown result type (might be due to invalid IL or missing references)
		//IL_064e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0654: Unknown result type (might be due to invalid IL or missing references)
		//IL_06be: Unknown result type (might be due to invalid IL or missing references)
		//IL_06ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_072e: Unknown result type (might be due to invalid IL or missing references)
		//IL_07b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_07d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0746: Unknown result type (might be due to invalid IL or missing references)
		//IL_074c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0751: Unknown result type (might be due to invalid IL or missing references)
		//IL_07ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0888: Unknown result type (might be due to invalid IL or missing references)
		//IL_0934: Unknown result type (might be due to invalid IL or missing references)
		ImGui.PushID(ImU8String.op_Implicit(id));
		string text = arenaEditorPreset + "/" + id;
		if (!priorityViews.TryGetValue(text, out PriorityView view))
		{
			priorityViews[text] = (view = new PriorityView());
		}
		if (view.Source != saved)
		{
			view.Source = saved;
			view.Full = ArenaPriorityOrder.Complete(saved, kind);
		}
		List<uint> list = view.Full;
		ImGui.SetNextItemWidth(240f);
		ImGui.InputTextWithHint(ImU8String.op_Implicit("##search"), ImU8String.op_Implicit("搜索名称、效果或物品 ID"), ref view.Search, 100, (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null);
		string[] array = null;
		ArenaPriorityKind arenaPriorityKind = kind;
		if ((uint)(arenaPriorityKind - 2) > 1u)
		{
			SameLineIfFits(130f);
			ImGui.SetNextItemWidth(150f);
			string[] array2 = (from i in ArenaItemCatalog.Items.Values
				where i.Category == 2 && i.Sub != null
				select "道具/" + i.Sub).Distinct().ToArray();
			string[] array3;
			if (kind != ArenaPriorityKind.Rewards)
			{
				if (kind != ArenaPriorityKind.Supplies)
				{
					List<string> list2 = new List<string>();
					list2.Add("全部");
					list2.Add("装备");
					list2.Add("食料");
					list2.AddRange(array2);
					array3 = list2.ToArray();
				}
				else
				{
					string text2 = "全部";
					string text3 = "食料";
					string[] array4 = array2;
					int num = 0;
					string[] array5 = new string[2 + array4.Length];
					array5[num] = text2;
					num++;
					array5[num] = text3;
					num++;
					ReadOnlySpan<string> readOnlySpan = new ReadOnlySpan<string>(array4);
					readOnlySpan.CopyTo(new Span<string>(array5).Slice(num, readOnlySpan.Length));
					num += readOnlySpan.Length;
					array3 = array5;
				}
			}
			else
			{
				string text3 = "全部";
				string text2 = "装备";
				string[] array5 = array2;
				int num = 0;
				string[] array4 = new string[2 + array5.Length];
				array4[num] = text3;
				num++;
				array4[num] = text2;
				num++;
				ReadOnlySpan<string> readOnlySpan = new ReadOnlySpan<string>(array5);
				readOnlySpan.CopyTo(new Span<string>(array4).Slice(num, readOnlySpan.Length));
				num += readOnlySpan.Length;
				array3 = array4;
			}
			array = array3;
			if (view.Category >= array.Length)
			{
				view.Category = 0;
			}
			ImGui.Combo(ImU8String.op_Implicit("##category"), ref view.Category, (ReadOnlySpan<string>)array, array.Length);
		}
		SameLineIfFits(ButtonWidth("恢复默认"));
		if (ImGui.Button(ImU8String.op_Implicit("恢复默认"), default(Vector2)))
		{
			save(new List<uint>());
			list = (view.Full = ArenaPriorityOrder.Complete(Array.Empty<uint>(), kind));
			view.Ranks.Clear();
		}
		string selected = ((array == null || view.Category == 0) ? null : array[view.Category]);
		uint[] array6 = list.Where(delegate(uint itemId)
		{
			ArenaItem arenaItem2 = ArenaItemCatalog.Items[itemId];
			if (kind != ArenaPriorityKind.Healing && selected != null)
			{
				bool num4;
				if (!(selected == "装备"))
				{
					if (!(selected == "食料"))
					{
						if (arenaItem2.Category != 2)
						{
							goto IL_00e0;
						}
						num4 = arenaItem2.CategoryLabel == selected;
					}
					else
					{
						num4 = arenaItem2.Category == 3;
					}
				}
				else
				{
					num4 = arenaItem2.Category == 1;
				}
				if (!num4)
				{
					goto IL_00e0;
				}
			}
			if (!string.IsNullOrWhiteSpace(view.Search) && !arenaItem2.Name.Contains(view.Search, StringComparison.OrdinalIgnoreCase) && !arenaItem2.Description.Contains(view.Search, StringComparison.OrdinalIgnoreCase))
			{
				return arenaItem2.Id.ToString() == view.Search.Trim();
			}
			return true;
			IL_00e0:
			return false;
		}).ToArray();
		if (resources != null)
		{
			SameLineIfFits(ButtonWidth("全部启用"));
			if (ImGui.Button(ImU8String.op_Implicit("全部启用"), default(Vector2)))
			{
				uint[] array7 = array6;
				foreach (uint item in array7)
				{
					resources.Disabled.Remove(item);
					resources.DisabledAcquisition.Remove(item);
					resources.DisabledUse.Remove(item);
					acquisition?.Disabled.Remove(item);
				}
				plugin.Save();
			}
			SameLineIfFits(ButtonWidth("全部禁用"));
			if (ImGui.Button(ImU8String.op_Implicit("全部禁用"), default(Vector2)))
			{
				uint[] array7 = array6;
				foreach (uint item2 in array7)
				{
					if (acquisition != null)
					{
						if (!acquisition.Disabled.Contains(item2))
						{
							acquisition.Disabled.Add(item2);
						}
					}
					else if (!resources.Disabled.Contains(item2))
					{
						resources.Disabled.Add(item2);
					}
				}
				plugin.Save();
			}
			if (ImGui.IsItemHovered())
			{
				ImGui.SetTooltip(ImU8String.op_Implicit("按当前搜索与筛选结果批量启用/禁用"));
			}
		}
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(5, 2);
		((ImU8String)(ref val)).AppendFormatted<int>(array6.Length);
		((ImU8String)(ref val)).AppendLiteral(" / ");
		((ImU8String)(ref val)).AppendFormatted<int>(list.Count);
		((ImU8String)(ref val)).AppendLiteral(" 件");
		ImGui.TextUnformatted(val);
		float y = fixedHeight ?? Math.Max(200f, ImGui.GetContentRegionAvail().Y - 40f);
		if (ImGui.BeginTable(ImU8String.op_Implicit("priority"), (resources == null) ? 4 : 5, (ImGuiTableFlags)33579201, new Vector2(0f, y), 0f))
		{
			ImGui.TableSetupColumn(ImU8String.op_Implicit("排名"), (ImGuiTableColumnFlags)8, 48f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("物品"), (ImGuiTableColumnFlags)4, 0.35f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("类别"), (ImGuiTableColumnFlags)8, 110f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("效果"), (ImGuiTableColumnFlags)4, 0.65f, 0u);
			if (resources != null)
			{
				ImGui.TableSetupColumn(ImU8String.op_Implicit("启用"), (ImGuiTableColumnFlags)8, 48f, 0u);
			}
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			List<uint> list3 = null;
			uint[] array7 = array6;
			ImU8String val4 = default(ImU8String);
			foreach (uint num2 in array7)
			{
				ArenaItem arenaItem = ArenaItemCatalog.Items[num2];
				int num3 = list.IndexOf(num2) + 1;
				ImGui.PushID((IntPtr)(int)num2);
				ImGui.TableNextRow();
				ImGui.TableNextColumn();
				ImGui.SetNextItemWidth(-1f);
				int valueOrDefault = view.Ranks.GetValueOrDefault(num2, num3);
				ImU8String val2 = ImU8String.op_Implicit("##rank");
				ImU8String val3 = default(ImU8String);
				if (ImGui.InputInt(val2, ref valueOrDefault, 0, 0, val3, (ImGuiInputTextFlags)0))
				{
					view.Ranks[num2] = valueOrDefault;
				}
				if (ImGui.IsItemDeactivatedAfterEdit())
				{
					list3 = ArenaPriorityOrder.Move(list, num2, valueOrDefault);
					view.Ranks.Clear();
				}
				ImGui.TableNextColumn();
				((ImU8String)(ref val3))._002Ector(2, 1);
				((ImU8String)(ref val3)).AppendLiteral("≡ ");
				((ImU8String)(ref val3)).AppendFormatted<string>(arenaItem.Name);
				ImGui.Selectable(val3, false, (ImGuiSelectableFlags)0, new Vector2(0f, ImGui.GetTextLineHeight()));
				if (ImGui.BeginDragDropSource())
				{
					priorityDragScope = text;
					ImGui.SetDragDropPayload(ImU8String.op_Implicit("PP_PRIORITY"), (ReadOnlySpan<byte>)BitConverter.GetBytes(num2), (ImGuiCond)0);
					((ImU8String)(ref val4))._002Ector(2, 2);
					((ImU8String)(ref val4)).AppendFormatted<int>(num3);
					((ImU8String)(ref val4)).AppendLiteral(". ");
					((ImU8String)(ref val4)).AppendFormatted<string>(arenaItem.Name);
					ImGui.TextUnformatted(val4);
					ImGui.EndDragDropSource();
				}
				if (ImGui.BeginDragDropTarget())
				{
					ImGuiPayloadPtr val5 = ImGui.AcceptDragDropPayload(ImU8String.op_Implicit("PP_PRIORITY"), (ImGuiDragDropFlags)0);
					if (!((ImGuiPayloadPtr)(ref val5)).IsNull && ((ImGuiPayloadPtr)(ref val5)).Delivery && ((ImGuiPayloadPtr)(ref val5)).DataSize == 4 && priorityDragScope == text)
					{
						uint data = *(uint*)((ImGuiPayloadPtr)(ref val5)).Data;
						if (list.Contains(data))
						{
							list3 = ArenaPriorityOrder.Move(list, data, num3);
						}
					}
					ImGui.EndDragDropTarget();
				}
				ImGui.TableNextColumn();
				ImGui.TextUnformatted(ImU8String.op_Implicit(arenaItem.CategoryLabel));
				ImGui.TableNextColumn();
				ImGui.TextWrapped(ImU8String.op_Implicit(arenaItem.Description.Replace("\r", "")));
				if (ImGui.IsItemHovered())
				{
					ImGui.SetTooltip(ImU8String.op_Implicit(arenaItem.Description));
				}
				if (resources != null)
				{
					ImGui.TableNextColumn();
					List<uint> list4 = acquisition?.Disabled;
					bool flag = (arenaItem.Category == 1 && resources.NoEquipment) || (arenaItem.Category == 2 && resources.NoItems) || (arenaItem.Category == 3 && resources.NoFeeding);
					bool flag2 = !flag && !resources.IsDisabled(num2) && (list4 == null || !list4.Contains(num2));
					ImGui.BeginDisabled(flag);
					if (ImGui.Checkbox(ImU8String.op_Implicit("##enabled"), ref flag2))
					{
						if (flag2)
						{
							list4?.Remove(num2);
							resources.Disabled.Remove(num2);
							resources.DisabledAcquisition.Remove(num2);
							resources.DisabledUse.Remove(num2);
						}
						else if (list4 != null)
						{
							if (!list4.Contains(num2))
							{
								list4.Add(num2);
							}
						}
						else if (!resources.Disabled.Contains(num2))
						{
							resources.Disabled.Add(num2);
						}
						plugin.Save();
					}
					if (ImGui.IsItemHovered())
					{
						ImGui.SetTooltip(ImU8String.op_Implicit(flag ? "本盘全局限制中已禁用此类别" : "不勾选 = 仅本来源不购买、不获取，其他来源不受影响"));
					}
					ImGui.EndDisabled();
				}
				ImGui.PopID();
				if (list3 != null)
				{
					break;
				}
			}
			ImGui.EndTable();
			if (list3 != null)
			{
				view.Ranks.Clear();
				save(list3);
			}
		}
		ImGui.PopID();
	}

	private void ResourceCheck(string label, bool value, Action<bool> save, bool disabled = false)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		ImGui.BeginDisabled(disabled);
		if (ImGui.Checkbox(ImU8String.op_Implicit(label), ref value))
		{
			save(value);
			plugin.Save();
		}
		ImGui.EndDisabled();
	}

	private void ResourceNumber(string label, int value, Action<int> save, int max = 10)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		ImGui.SetNextItemWidth(105f);
		if (ImGui.InputInt(ImU8String.op_Implicit(label), ref value, 0, 0, default(ImU8String), (ImGuiInputTextFlags)0))
		{
			save(Math.Clamp(value, 0, max));
			plugin.Save();
		}
	}

	private void DrawResourceGoals(ArenaPreset preset, ArenaPresetCollection collection)
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0225: Unknown result type (might be due to invalid IL or missing references)
		//IL_0239: Unknown result type (might be due to invalid IL or missing references)
		//IL_0266: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e8: Unknown result type (might be due to invalid IL or missing references)
		ArenaResources r = preset.Resources;
		ImGui.Separator();
		ImGui.TextUnformatted(ImU8String.op_Implicit("全程限制"));
		ResourceCheck("不获得装备", r.NoEquipment, delegate(bool v)
		{
			r.NoEquipment = v;
			if (v)
			{
				r.TargetEquipment = 0;
			}
		});
		SameLineIfFits(150f);
		ResourceCheck("不花费斗兽币", r.NoSpending, delegate(bool v)
		{
			r.NoSpending = v;
		});
		ResourceCheck("不使用道具", r.NoItems, delegate(bool v)
		{
			r.NoItems = v;
		});
		SameLineIfFits(110f);
		ResourceCheck("不喂食", r.NoFeeding, delegate(bool v)
		{
			r.NoFeeding = v;
		});
		SameLineIfFits(150f);
		ResourceCheck("不在帐篷休息", r.NoRest, delegate(bool v)
		{
			r.NoRest = v;
		});
		ImGui.TextUnformatted(ImU8String.op_Implicit("库存目标（0 不限制）"));
		ImGui.BeginDisabled(r.NoEquipment);
		ResourceNumber("装备件数", r.TargetEquipment, delegate(int v)
		{
			r.TargetEquipment = v;
		});
		ImGui.EndDisabled();
		ResourceNumber("道具个数", r.TargetItems, delegate(int v)
		{
			r.TargetItems = v;
		});
		ResourceCheck("为达成个数目标预留道具（背包≤目标时不用药）", r.ReserveTargetItems, delegate(bool v)
		{
			r.ReserveTargetItems = v;
		}, r.TargetItems == 0 || r.NoItems);
		ResourceNumber("至少保留斗兽币", (int)r.ReserveCoins, delegate(int v)
		{
			r.ReserveCoins = (uint)v;
		}, 999999);
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("节点默认行为"), (ImGuiTreeNodeFlags)0))
		{
			ImGui.PushID(ImU8String.op_Implicit("defaultsReward"));
			ImGui.TextUnformatted(ImU8String.op_Implicit("免费奖励"));
			DrawResourceRules(r, r.Rewards, ArenaTileKind.Battle, defaults: true);
			ImGui.PopID();
			ImGui.PushID(ImU8String.op_Implicit("defaultsCamp"));
			ImGui.Separator();
			ImGui.TextUnformatted(ImU8String.op_Implicit("帐篷"));
			DrawResourceRules(r, r.Rewards, ArenaTileKind.Camp, defaults: true);
			ImGui.PopID();
			ImGui.PushID(ImU8String.op_Implicit("defaultsShop"));
			ImGui.Separator();
			ImGui.TextUnformatted(ImU8String.op_Implicit("商店"));
			DrawResourceRules(r, r.Shop, ArenaTileKind.Shop, defaults: true);
			ImGui.PopID();
		}
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("策略模板"), (ImGuiTreeNodeFlags)0))
		{
			string[] array = new string[4] { "零装备 · 零消费", "满装备 · 零消费", "10道具 · 不使用", "低价凑齐装备／道具" };
			for (int num = 0; num < array.Length; num++)
			{
				if (!ImGui.Button(ImU8String.op_Implicit(array[num]), default(Vector2)))
				{
					continue;
				}
				ArenaPreset arenaPreset = preset.Duplicate();
				arenaPreset.Name = array[num];
				arenaPreset.Resources = new ArenaResources
				{
					UnifiedPriorities = true,
					SourcePriorities = true
				};
				ArenaResources resources = arenaPreset.Resources;
				if (num == 0)
				{
					bool noEquipment = (resources.NoSpending = true);
					resources.NoEquipment = noEquipment;
				}
				if (num == 1)
				{
					resources.NoSpending = true;
					resources.TargetEquipment = 10;
					ArenaAcquisitionPriority battleRewards = resources.BattleRewards;
					int num2 = 1;
					List<uint> list = new List<uint>(num2);
					CollectionsMarshal.SetCount(list, num2);
					CollectionsMarshal.AsSpan(list)[0] = 3u;
					battleRewards.Order = list;
					ArenaAcquisitionPriority treasureRewards = resources.TreasureRewards;
					num2 = 1;
					List<uint> list2 = new List<uint>(num2);
					CollectionsMarshal.SetCount(list2, num2);
					CollectionsMarshal.AsSpan(list2)[0] = 3u;
					treasureRewards.Order = list2;
					ArenaAcquisitionPriority purchases = resources.Purchases;
					num2 = 1;
					List<uint> list3 = new List<uint>(num2);
					CollectionsMarshal.SetCount(list3, num2);
					CollectionsMarshal.AsSpan(list3)[0] = 3u;
					purchases.Order = list3;
				}
				if (num == 2)
				{
					resources.TargetItems = 10;
					resources.NoItems = true;
				}
				if (num == 3)
				{
					int num2 = (resources.TargetItems = 10);
					resources.TargetEquipment = num2;
					ArenaNodeResources shop = resources.Shop;
					ArenaPurchaseSort equipmentSort = (resources.Shop.ItemSort = ArenaPurchaseSort.FillThenPriority);
					shop.EquipmentSort = equipmentSort;
					resources.Shop.Food = false;
				}
				foreach (ArenaRandomOutcomePreset randomOutcome in arenaPreset.RandomOutcomes)
				{
					randomOutcome.Resources = null;
				}
				collection.Presets.Add(arenaPreset);
				collection.SelectedId = arenaPreset.Id;
				plugin.Save();
			}
		}
		ImGui.Separator();
		ResourceCheck("死亡后自动重开", preset.RetryAfterDeath, delegate(bool v)
		{
			preset.RetryAfterDeath = v;
		});
	}

	private void DrawAcquisitionPriorities(ArenaPreset preset)
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		ArenaResources r = preset.Resources;
		if (ImGui.BeginTabBar(ImU8String.op_Implicit("AcquisitionSources"), (ImGuiTabBarFlags)128))
		{
			Source("战斗结束", "battleRewards", r.BattleRewards, shop: false);
			Source("宝箱", "treasureRewards", r.TreasureRewards, shop: false);
			Source("商店", "purchases", r.Purchases, shop: true);
			ImGui.EndTabBar();
		}
		void Source(string label, string id, ArenaAcquisitionPriority source, bool shop)
		{
			//IL_0015: Unknown result type (might be due to invalid IL or missing references)
			if (ImGui.BeginTabItem(ImU8String.op_Implicit(label), (ImGuiTabItemFlags)32))
			{
				MainWindow mainWindow = this;
				List<uint> order = source.Order;
				int kind = ((!shop) ? 5 : 0);
				Action<List<uint>> save = delegate(List<uint> order2)
				{
					source.Order = order2;
					plugin.Save();
				};
				ArenaResources resources = r;
				ArenaAcquisitionPriority acquisition = source;
				mainWindow.DrawItemPriority(id, order, (ArenaPriorityKind)kind, save, null, resources, acquisition);
				ImGui.EndTabItem();
			}
		}
	}

	private void DrawNodeResources(ArenaPreset preset, int node, ArenaTileKind kind, int? outcome = null)
	{
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_015e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0282: Unknown result type (might be due to invalid IL or missing references)
		//IL_028d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		ArenaResources resources = preset.Resources;
		object obj;
		if (outcome.HasValue)
		{
			int valueOrDefault = outcome.GetValueOrDefault();
			obj = preset.RandomOutcome(node, valueOrDefault);
		}
		else
		{
			obj = null;
		}
		ArenaRandomOutcomePreset arenaRandomOutcomePreset = (ArenaRandomOutcomePreset)obj;
		ArenaNodeResources rules = (outcome.HasValue ? arenaRandomOutcomePreset.Resources : resources.Nodes.GetValueOrDefault(node));
		bool flag = rules != null;
		if (ImGui.Checkbox(ImU8String.op_Implicit("此节点单独设置"), ref flag))
		{
			rules = (flag ? ((kind == ArenaTileKind.Shop) ? resources.Shop : resources.Rewards).Copy() : null);
			if (arenaRandomOutcomePreset != null)
			{
				arenaRandomOutcomePreset.Resources = rules;
			}
			else if (rules == null)
			{
				resources.Nodes.Remove(node);
			}
			else
			{
				resources.Nodes[node] = rules;
			}
			if (kind == ArenaTileKind.Battle)
			{
				ArenaBattlePreset? arenaBattlePreset;
				if (outcome.HasValue)
				{
					int valueOrDefault2 = outcome.GetValueOrDefault();
					arenaBattlePreset = preset.RandomOutcome(node, valueOrDefault2).Battle;
				}
				else
				{
					arenaBattlePreset = preset.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == node);
				}
				ArenaBattlePreset arenaBattlePreset2 = arenaBattlePreset;
				if (arenaBattlePreset2 != null)
				{
					arenaBattlePreset2.HealOverride = flag;
				}
			}
			plugin.Save();
		}
		if (ImGui.IsItemHovered() && !flag)
		{
			ImGui.SetTooltip(ImU8String.op_Implicit("勾选后可针对本节点单独调整，未勾选时跟随本盘默认"));
		}
		ArenaNodeResources rules2 = rules ?? ((kind == ArenaTileKind.Shop) ? resources.Shop : resources.Rewards);
		ImGui.BeginDisabled(!flag);
		if (flag && rules?.Priority != null && ImGui.Button(ImU8String.op_Implicit("改用本盘物品优先级"), default(Vector2)))
		{
			rules.Priority = null;
			plugin.Save();
		}
		DrawResourceRules(resources, rules2, kind);
		if (kind == ArenaTileKind.Battle)
		{
			ArenaBattlePreset? arenaBattlePreset3;
			if (outcome.HasValue)
			{
				int valueOrDefault3 = outcome.GetValueOrDefault();
				arenaBattlePreset3 = preset.RandomOutcome(node, valueOrDefault3).Battle;
			}
			else
			{
				arenaBattlePreset3 = preset.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == node);
			}
			ArenaBattlePreset arenaBattlePreset4 = arenaBattlePreset3;
			if (arenaBattlePreset4 != null)
			{
				bool healEnabled = arenaBattlePreset4.HealEnabled;
				if (ImGui.Checkbox(ImU8String.op_Implicit("战斗内补血"), ref healEnabled))
				{
					arenaBattlePreset4.HealEnabled = healEnabled;
					plugin.Save();
				}
				ImGui.SameLine();
				ImGui.SetNextItemWidth(90f);
				int healBelowPercent = arenaBattlePreset4.HealBelowPercent;
				if (ImGui.InputInt(ImU8String.op_Implicit("玩家体力低于 (%)##nodeheal"), ref healBelowPercent, 0, 0, default(ImU8String), (ImGuiInputTextFlags)0))
				{
					arenaBattlePreset4.HealBelowPercent = Math.Clamp(healBelowPercent, 1, 100);
					plugin.Save();
				}
			}
		}
		if (kind == ArenaTileKind.Shop)
		{
			ImGui.Separator();
			List<uint> saved = rules?.Priority ?? resources.Purchases.Order;
			DrawItemPriority($"nodeShop/{preset.StageId}/{node}/{outcome}", saved, ArenaPriorityKind.Shop, delegate(List<uint> order)
			{
				if (rules != null)
				{
					rules.Priority = order;
					plugin.Save();
				}
			}, 230f, resources, resources.Purchases);
		}
		ImGui.EndDisabled();
	}

	private void DrawResourceRules(ArenaResources r, ArenaNodeResources rules, ArenaTileKind kind, bool defaults = false)
	{
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0307: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_0378: Unknown result type (might be due to invalid IL or missing references)
		//IL_0383: Unknown result type (might be due to invalid IL or missing references)
		//IL_0389: Unknown result type (might be due to invalid IL or missing references)
		//IL_0429: Unknown result type (might be due to invalid IL or missing references)
		//IL_0434: Unknown result type (might be due to invalid IL or missing references)
		//IL_043a: Unknown result type (might be due to invalid IL or missing references)
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		bool flag = kind == ArenaTileKind.Shop;
		if (kind == ArenaTileKind.Camp)
		{
			ResourceCheck("在帐篷休息", rules.Rest && !r.NoRest, delegate(bool v)
			{
				rules.Rest = v;
			}, r.NoRest);
			if (r.NoRest)
			{
				ImGui.TextUnformatted(ImU8String.op_Implicit("本盘禁止休息"));
			}
			ImGui.BeginDisabled(r.NoRest || !rules.Rest);
			ResourceNumber("魔兽体力低于（%）", rules.RestBelowPercent, delegate(int v)
			{
				rules.RestBelowPercent = Math.Max(1, v);
			}, 100);
			ImGui.EndDisabled();
			return;
		}
		ResourceCheck(flag ? "购买装备" : "获得装备", rules.Equipment && !r.NoEquipment && (!flag || !r.NoSpending), delegate(bool v)
		{
			rules.Equipment = v;
		}, r.NoEquipment || (flag && r.NoSpending));
		ResourceCheck(flag ? "购买道具" : "获得道具", rules.Items && (!flag || !r.NoSpending), delegate(bool v)
		{
			rules.Items = v;
		}, flag && r.NoSpending);
		if (flag)
		{
			ResourceCheck("购买食料", rules.Food && !r.NoFeeding && !r.NoSpending, delegate(bool v)
			{
				rules.Food = v;
			}, r.NoFeeding || r.NoSpending);
		}
		if (r.NoEquipment)
		{
			ImGui.TextUnformatted(ImU8String.op_Implicit("本盘禁止获得装备"));
		}
		if (flag && r.NoSpending)
		{
			ImGui.TextUnformatted(ImU8String.op_Implicit("本盘禁止消费"));
		}
		if (!flag)
		{
			return;
		}
		Sort("装备购买", rules.EquipmentSort, delegate(ArenaPurchaseSort v)
		{
			rules.EquipmentSort = v;
		}, r.NoEquipment || r.NoSpending || !rules.Equipment);
		Sort("道具购买", rules.ItemSort, delegate(ArenaPurchaseSort v)
		{
			rules.ItemSort = v;
		}, r.NoSpending || !rules.Items);
		Sort("食料购买", rules.FoodSort, delegate(ArenaPurchaseSort v)
		{
			rules.FoodSort = v;
		}, r.NoSpending || r.NoFeeding || !rules.Food);
		int num = ((rules.Budget != 0) ? 1 : ((rules.ReserveCoins != 0) ? 2 : 0));
		if (ImGui.RadioButton<int>(ImU8String.op_Implicit("不限制##shoplimit"), ref num, 0))
		{
			rules.Budget = 0u;
			rules.ReserveCoins = 0u;
			plugin.Save();
		}
		ImGui.SameLine();
		if (ImGui.RadioButton<int>(ImU8String.op_Implicit("本店预算##shoplimit"), ref num, 1))
		{
			rules.ReserveCoins = 0u;
			if (rules.Budget == 0)
			{
				rules.Budget = 500u;
			}
			plugin.Save();
		}
		if (rules.Budget != 0)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			int budget = (int)rules.Budget;
			if (ImGui.InputInt(ImU8String.op_Implicit("斗兽币##shopbudget"), ref budget, 0, 0, default(ImU8String), (ImGuiInputTextFlags)0))
			{
				rules.Budget = (uint)Math.Clamp(budget, 0, 999999);
				plugin.Save();
			}
		}
		if (ImGui.RadioButton<int>(ImU8String.op_Implicit("至少保留##shoplimit"), ref num, 2))
		{
			rules.Budget = 0u;
			if (rules.ReserveCoins == 0)
			{
				rules.ReserveCoins = 100u;
			}
			plugin.Save();
		}
		if (rules.ReserveCoins != 0)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(90f);
			int reserveCoins = (int)rules.ReserveCoins;
			if (ImGui.InputInt(ImU8String.op_Implicit("斗兽币##shopreserve"), ref reserveCoins, 0, 0, default(ImU8String), (ImGuiInputTextFlags)0))
			{
				rules.ReserveCoins = (uint)Math.Clamp(reserveCoins, 0, 999999);
				plugin.Save();
			}
		}
		if (!defaults)
		{
			ResourceCheck("出售未勾选的物品", rules.SellDisabled, delegate(bool v)
			{
				rules.SellDisabled = v;
			});
			if (ImGui.IsItemHovered())
			{
				ImGui.SetTooltip(ImU8String.op_Implicit("进入本商店时自动卖掉优先级列表中未勾选（禁用）的持有装备/道具"));
			}
		}
		void Sort(string label, ArenaPurchaseSort value, Action<ArenaPurchaseSort> save, bool disabled)
		{
			//IL_0067: Unknown result type (might be due to invalid IL or missing references)
			ImGui.BeginDisabled(disabled);
			ImGui.SetNextItemWidth(Math.Min(300f, ImGui.GetContentRegionAvail().X));
			int obj = (int)value;
			string[] array = ((!(label == "食料购买")) ? new string[3] { "按预设优先级", "按低价优先", "未满目标按低价，满后按预设" } : new string[2] { "按预设优先级", "按低价优先" });
			if (ImGui.Combo(ImU8String.op_Implicit(label), ref obj, (ReadOnlySpan<string>)array, array.Length))
			{
				save((ArenaPurchaseSort)obj);
				plugin.Save();
			}
			ImGui.EndDisabled();
		}
	}

	private static uint RouteColor(float r, float g, float b, float a = 1f)
	{
		return ImGui.ColorConvertFloat4ToU32(new Vector4(r, g, b, a));
	}

	private void DrawArenaRoute(ArenaPreset preset)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f08: Unknown result type (might be due to invalid IL or missing references)
		//IL_0275: Unknown result type (might be due to invalid IL or missing references)
		//IL_027a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0f48: Unknown result type (might be due to invalid IL or missing references)
		//IL_0fbc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0691: Unknown result type (might be due to invalid IL or missing references)
		//IL_0719: Unknown result type (might be due to invalid IL or missing references)
		//IL_07fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_09b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_08e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0931: Unknown result type (might be due to invalid IL or missing references)
		//IL_0aef: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a77: Unknown result type (might be due to invalid IL or missing references)
		//IL_0cc9: Unknown result type (might be due to invalid IL or missing references)
		ArenaStageMap map = ArenaMaps.Get(preset.StageId);
		IReadOnlyList<Vector2> positions = map.Positions;
		int num = -1;
		Vector2 windowPos = ImGui.GetWindowPos();
		Vector2 windowSize = ImGui.GetWindowSize();
		ImGuiViewportPtr windowViewport = ImGui.GetWindowViewport();
		float width;
		float scale;
		float radius;
		float spread;
		float textSize;
		if (ImGui.BeginChild(ImU8String.op_Implicit("RouteCanvas"), new Vector2(0f, Math.Max(140f, ImGui.GetContentRegionAvail().Y)), false, (ImGuiWindowFlags)2048))
		{
			Vector2 origin = ImGui.GetCursorScreenPos();
			width = ImGui.GetContentRegionAvail().X;
			scale = ImGui.GetFontSize() / 17f * 0.82f;
			radius = 28f * scale;
			float num2 = Math.Max(1f, positions.Max((Vector2 p) => Math.Abs(p.X)));
			if (num2 > 1f)
			{
				width = Math.Max(width, 620f * scale);
			}
			spread = Math.Min(145f * scale, width / (2f * (num2 + 1.1f)));
			textSize = 15f * scale;
			Dictionary<int, string[]> dictionary = (from b in preset.Battles
				where b.Flutes.Any((ArenaFluteChoice f) => f.A != 0 || f.B != 0)
				group b by b.Node).ToDictionary((IGrouping<int, ArenaBattlePreset> g) => g.Key, (IGrouping<int, ArenaBattlePreset> g) => RouteRosterLines(g.First(), RosterWidth(g.Key), textSize));
			float num3 = dictionary.Values.Select((string[] lines) => (float)lines.Length * (textSize + 3f * scale)).DefaultIfEmpty(0f).Max();
			float pitch = Math.Max(108f * scale, num3 + 30f * scale);
			Vector2[] array = positions.Select((Vector2 p) => origin + new Vector2(width / 2f + p.X * spread, 38f * scale + ((float)map.Depth - p.Y) * pitch)).ToArray();
			ImDrawListPtr windowDrawList = ImGui.GetWindowDrawList();
			uint num4 = RouteColor(0.27f, 0.83f, 0.52f);
			uint num5 = RouteColor(0.37f, 0.42f, 0.47f);
			HashSet<(int, int)> hashSet = ArenaRouteDiagram.SelectedEdges(preset);
			ArenaMapNode[] nodes = map.Nodes;
			foreach (ArenaMapNode arenaMapNode in nodes)
			{
				int[] next = arenaMapNode.Next;
				foreach (int num8 in next)
				{
					Vector2 vector = Vector2.Normalize(array[num8] - array[arenaMapNode.Node]);
					Vector2 vector2 = array[arenaMapNode.Node] + vector * ((arenaMapNode.Node == 0) ? (radius * 0.72f) : (radius + 6f * scale));
					Vector2 vector3 = array[num8];
					Vector2 vector4 = vector;
					float num9 = radius * ((map.Nodes[num8].BattleTier == ArenaBattleTier.Boss) ? 1.18f : 1f);
					ArenaBattleTier battleTier = map.Nodes[num8].BattleTier;
					bool flag = (uint)(battleTier - 2) <= 1u;
					Vector2 vector5 = vector3 - vector4 * (num9 + (float)(flag ? 24 : 6) * scale);
					Vector2 vector6 = vector5 - vector2;
					Vector2 mousePos = ImGui.GetMousePos();
					float num10 = Math.Clamp(Vector2.Dot(mousePos - vector2, vector6) / vector6.LengthSquared(), 0f, 1f);
					bool flag2 = ArenaRouteDiagram.CanChooseEdge(preset.StageId, arenaMapNode.Node, num8) && ImGui.IsWindowHovered() && Vector2.Distance(mousePos, vector2 + num10 * vector6) < 8f * scale && Vector2.Distance(mousePos, array[arenaMapNode.Node]) > radius + 2f && Vector2.Distance(mousePos, array[num8]) > radius + 2f;
					((ImDrawListPtr)(ref windowDrawList)).AddLine(vector2, vector5, hashSet.Contains((arenaMapNode.Node, num8)) ? num4 : num5, (float)(flag2 ? 7 : 4) * scale);
					if (flag2)
					{
						ImGui.SetMouseCursor((ImGuiMouseCursor)7);
						if (ImGui.IsMouseClicked((ImGuiMouseButton)0) && ArenaRouteDiagram.ChooseEdge(preset, arenaMapNode.Node, num8))
						{
							plugin.Save();
						}
					}
				}
			}
			nodes = map.Nodes;
			ImU8String tooltip = default(ImU8String);
			ImU8String val = default(ImU8String);
			foreach (ArenaMapNode node in nodes)
			{
				Vector2 vector7 = array[node.Node];
				float num11 = ((node.Kind == ArenaTileKind.Start) ? (radius * 0.72f) : ((node.BattleTier == ArenaBattleTier.Boss) ? (radius * 1.18f) : radius));
				ArenaBattlePreset arenaBattlePreset = preset.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == node.Node);
				bool flag3 = arenaBattlePreset?.Flutes.Any((ArenaFluteChoice f) => f.A != 0 || f.B != 0) ?? false;
				IReadOnlyList<int> readOnlyList2;
				if (node.Kind != ArenaTileKind.Battle || (arenaBattlePreset != null && arenaBattlePreset.RuleMode))
				{
					IReadOnlyList<int> readOnlyList = Array.Empty<int>();
					readOnlyList2 = readOnlyList;
				}
				else
				{
					readOnlyList2 = ArenaBattleLogicStatus.Slots(preset.StageId, node.Node);
				}
				IReadOnlyList<int> readOnlyList3 = readOnlyList2;
				bool flag4 = false;
				int slot = 0;
				Vector2 vector8 = vector7;
				if (arenaBattlePreset != null && arenaBattlePreset.RuleMode)
				{
					vector8 = vector7 + new Vector2((0f - num11) * 0.8f, (0f - num11) * 0.85f);
					CanvasText(windowDrawList, vector8, "规则", 11f * scale);
					if (Vector2.Distance(ImGui.GetMousePos(), vector8) <= 14f * scale)
					{
						ImGui.SetMouseCursor((ImGuiMouseCursor)7);
						if (ImGui.IsMouseClicked((ImGuiMouseButton)0))
						{
							num = node.Node;
						}
					}
				}
				for (int num12 = 0; num12 < readOnlyList3.Count; num12++)
				{
					vector8 = vector7 + new Vector2((0f - num11) * 0.8f - (float)(num12 * 15) * scale, (0f - num11) * 0.85f);
					DrawCompletionStar(windowDrawList, vector8, 10f * scale, arenaBattlePreset?.LogicEnabled(readOnlyList3[num12]) ?? true);
					if (Vector2.Distance(ImGui.GetMousePos(), vector8) <= 12f * scale)
					{
						flag4 = true;
						slot = readOnlyList3[num12];
					}
				}
				Vector2 vector9 = vector7 - new Vector2(num11);
				Vector2 vector10 = vector7 + new Vector2(num11);
				Vector2 mousePos2 = ImGui.GetMousePos();
				bool hovered = ImGui.IsWindowHovered() && mousePos2.X >= vector9.X && mousePos2.X <= vector10.X && mousePos2.Y >= vector9.Y && mousePos2.Y <= vector10.Y && !flag4;
				DrawRouteIcon(windowDrawList, vector7, node, num11, hovered);
				if (node.Kind == ArenaTileKind.Battle && flag3)
				{
					string[] array2 = dictionary[node.Node];
					float num13 = RosterWidth(node.Node);
					float num14 = ((positions[node.Node].X < 0f) ? (vector7.X - num11 - 10f * scale - num13) : (vector7.X + num11 + 10f * scale));
					float num15 = vector7.Y - (float)array2.Length * (textSize + 3f * scale) / 2f;
					for (int num16 = 0; num16 < array2.Length; num16++)
					{
						((ImDrawListPtr)(ref windowDrawList)).AddText(ImGui.GetFont(), textSize, new Vector2(num14, num15 + (float)num16 * (textSize + 3f * scale)), RouteColor(0.81f, 0.89f, 0.96f), ImU8String.op_Implicit(array2[num16]), 0f);
					}
					vector9 = Vector2.Min(vector9, new Vector2(num14, num15));
					vector10 = Vector2.Max(vector10, new Vector2(num14 + num13, num15 + (float)array2.Length * (textSize + 3f * scale)));
				}
				ArenaBattleTier battleTier = node.BattleTier;
				if ((uint)(battleTier - 2) <= 1u)
				{
					CanvasText(windowDrawList, vector7 + new Vector2(0f, num11 + 11f * scale), (node.BattleTier == ArenaBattleTier.Elite) ? "精英" : "首领", 12f * scale);
				}
				if (flag4 && ImGui.IsWindowHovered())
				{
					bool flag5 = arenaBattlePreset?.LogicEnabled(slot) ?? true;
					ImGui.SetMouseCursor((ImGuiMouseCursor)7);
					((ImU8String)(ref tooltip))._002Ector(1, 2);
					((ImU8String)(ref tooltip)).AppendFormatted<string>(ArenaBattleLogicStatus.Note(preset.StageId, node.Node, slot));
					((ImU8String)(ref tooltip)).AppendLiteral("\n");
					((ImU8String)(ref tooltip)).AppendFormatted<string>(flag5 ? "已启用 · 点击停用" : "已停用 · 点击启用");
					ImGui.SetTooltip(tooltip);
					if (ImGui.IsMouseClicked((ImGuiMouseButton)0))
					{
						preset.Battle(node.Node).SetLogicEnabled(slot, !flag5);
						plugin.Save();
					}
				}
				if (node.Kind == ArenaTileKind.Start)
				{
					continue;
				}
				ImGui.SetCursorScreenPos(vector9);
				((ImU8String)(ref val))._002Ector(4, 1);
				((ImU8String)(ref val)).AppendLiteral("node");
				((ImU8String)(ref val)).AppendFormatted<int>(node.Node);
				if (ImGui.InvisibleButton(val, vector10 - vector9, (ImGuiButtonFlags)0) && !flag4)
				{
					num = node.Node;
				}
				if (!ImGui.IsItemHovered() || flag4)
				{
					continue;
				}
				ImGui.SetMouseCursor((ImGuiMouseCursor)7);
				string text = NodeLabel(node);
				foreach (int item in readOnlyList3)
				{
					text += $"\n★ {ArenaBattleLogicStatus.Note(preset.StageId, node.Node, item)}（{((arenaBattlePreset == null || arenaBattlePreset.LogicEnabled(item)) ? "启用" : "停用")}）";
				}
				if (arenaBattlePreset != null && arenaBattlePreset.RuleMode)
				{
					text = text + "\n自定义规则：" + string.Join("；", arenaBattlePreset.Rules.Select((ArenaBattleRule r) => (r.Enabled ? "" : "（停用）") + ArenaRuleSummary.Describe(r)));
				}
				if (arenaBattlePreset != null && flag3)
				{
					text = text + "\n" + string.Join("\n", arenaBattlePreset.Flutes.Select((ArenaFluteChoice f, int num17) => $"{num17 + 1}：A {ArenaPetName(f.A)} / B {ArenaPetName(f.B)}"));
				}
				if (arenaBattlePreset != null && arenaBattlePreset.HealOverride)
				{
					text += (arenaBattlePreset.HealEnabled ? "\n战斗内补血已单独启用" : "\n战斗内补血已单独禁用");
				}
				ImGui.SetTooltip(ImU8String.op_Implicit(text));
			}
			ImGui.SetCursorScreenPos(origin + new Vector2(0f, (float)map.Depth * pitch + 80f * scale));
			ImGui.Dummy(new Vector2(width, 1f));
			if (routeInitialScroll)
			{
				ImGui.SetScrollHereY(1f);
				routeInitialScroll = false;
			}
		}
		ImGui.EndChild();
		if (num >= 0)
		{
			arenaNode = num;
			arenaRandomOutcome = -1;
			nodeEditorOpen = true;
		}
		if (arenaNode < 0 || !nodeEditorOpen)
		{
			return;
		}
		ArenaMapNode arenaMapNode2 = map.Nodes.Single((ArenaMapNode n) => n.Node == arenaNode);
		bool flag6 = arenaMapNode2.BattleTier != ArenaBattleTier.Boss;
		if (num >= 0)
		{
			Vector2 value = Vector2.Max(new Vector2(300f, 220f), ((ImGuiViewportPtr)(ref windowViewport)).WorkSize - new Vector2(32f));
			Vector2 vector11 = Vector2.Min(new Vector2(flag6 ? 560 : 480, flag6 ? 530 : 250), value);
			Vector2 value2 = windowPos + new Vector2(windowSize.X + 12f, 0f);
			if (value2.X + vector11.X > ((ImGuiViewportPtr)(ref windowViewport)).WorkPos.X + ((ImGuiViewportPtr)(ref windowViewport)).WorkSize.X)
			{
				value2.X = windowPos.X - vector11.X - 12f;
			}
			value2 = Vector2.Clamp(value2, ((ImGuiViewportPtr)(ref windowViewport)).WorkPos + new Vector2(8f), Vector2.Max(((ImGuiViewportPtr)(ref windowViewport)).WorkPos + new Vector2(8f), ((ImGuiViewportPtr)(ref windowViewport)).WorkPos + ((ImGuiViewportPtr)(ref windowViewport)).WorkSize - vector11 - new Vector2(8f)));
			ImGui.SetNextWindowPos(value2);
			ImGui.SetNextWindowSize(vector11);
		}
		if (ImGui.Begin(ImU8String.op_Implicit("节点设置###ArenaNodeEditor"), ref nodeEditorOpen, (ImGuiWindowFlags)256))
		{
			if (arenaMapNode2.Kind == ArenaTileKind.Battle)
			{
				DrawBattleRules(preset, arenaMapNode2, preset.Battle(arenaNode));
			}
			ImGui.TextWrapped(ImU8String.op_Implicit(NodeLabel(arenaMapNode2)));
			ImGui.Separator();
			if (arenaMapNode2.Kind == ArenaTileKind.Battle)
			{
				DrawBattleFlutes(preset, arenaNode);
			}
			if (arenaMapNode2.BattleTier != ArenaBattleTier.Boss && arenaMapNode2.Kind != ArenaTileKind.Random)
			{
				DrawNodeResources(preset, arenaNode, arenaMapNode2.Kind);
			}
			if (arenaMapNode2.Kind == ArenaTileKind.Random)
			{
				DrawRandomNodeEditor(preset, arenaNode);
			}
			if (ImGui.Button(ImU8String.op_Implicit("完成"), default(Vector2)))
			{
				nodeEditorOpen = false;
			}
		}
		ImGui.End();
		float RosterWidth(int index)
		{
			Vector2 position = positions[index];
			bool left = position.X < 0f;
			float num17 = width / 2f + position.X * spread;
			IEnumerable<Vector2> source = positions.Where((Vector2 p) => p.Y == position.Y && ((!left) ? (p.X > position.X) : (p.X < position.X)));
			float num18 = (left ? source.Select((Vector2 p) => width / 2f + p.X * spread + radius + 10f * scale).DefaultIfEmpty(8f * scale).Max() : source.Select((Vector2 p) => width / 2f + p.X * spread - radius - 10f * scale).DefaultIfEmpty(width - 8f * scale).Min());
			return Math.Max(textSize * 2f, Math.Abs(num18 - num17) - radius * 1.18f - 18f * scale);
		}
	}

	private void DrawRandomNodeEditor(ArenaPreset preset, int node)
	{
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		IReadOnlyList<ArenaRandomOutcome> readOnlyList = ArenaRandomEvents.Outcomes(preset.StageId, node);
		ArenaRandomOutcome arenaRandomOutcome = readOnlyList.FirstOrDefault((ArenaRandomOutcome o) => o.PoolSubrow == this.arenaRandomOutcome);
		if (arenaRandomOutcome == null)
		{
			foreach (ArenaRandomOutcome item in readOnlyList)
			{
				ImGui.PushID((IntPtr)item.PoolSubrow);
				if (ImGui.Button(ImU8String.op_Implicit(item.Label), new Vector2(-1f, ImGui.GetFrameHeight())))
				{
					this.arenaRandomOutcome = item.PoolSubrow;
				}
				if (item.Enemies.Length != 0)
				{
					ImGui.TextWrapped(ImU8String.op_Implicit(string.Join(" / ", item.Enemies.Select((ArenaRandomEnemy e) => e.Name))));
				}
				ImGui.Spacing();
				ImGui.PopID();
			}
			return;
		}
		if (ImGui.Button(ImU8String.op_Implicit("返回可能结果"), default(Vector2)))
		{
			this.arenaRandomOutcome = -1;
			return;
		}
		ImGui.SameLine();
		ImGui.TextUnformatted(ImU8String.op_Implicit(arenaRandomOutcome.Label));
		if (arenaRandomOutcome.Enemies.Length != 0)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(string.Join(" / ", arenaRandomOutcome.Enemies.Select((ArenaRandomEnemy e) => e.Name))));
		}
		ImGui.Separator();
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(9, 3);
		((ImU8String)(ref val)).AppendLiteral("random/");
		((ImU8String)(ref val)).AppendFormatted<int>(preset.StageId);
		((ImU8String)(ref val)).AppendLiteral("/");
		((ImU8String)(ref val)).AppendFormatted<int>(node);
		((ImU8String)(ref val)).AppendLiteral("/");
		((ImU8String)(ref val)).AppendFormatted<int>(arenaRandomOutcome.PoolSubrow);
		ImGui.PushID(val);
		ArenaRandomOutcomePreset arenaRandomOutcomePreset = preset.RandomOutcome(node, arenaRandomOutcome.PoolSubrow);
		if (arenaRandomOutcome.TileKind == ArenaTileKind.Battle)
		{
			DrawBattleFlutes(preset, arenaRandomOutcomePreset.Battle);
		}
		if (arenaRandomOutcome.EventType != 4)
		{
			DrawNodeResources(preset, node, arenaRandomOutcome.TileKind, arenaRandomOutcome.PoolSubrow);
		}
		ImGui.PopID();
	}

	private static void DrawCompletionStar(ImDrawListPtr draw, Vector2 center, float radius, bool enabled = true)
	{
		Span<Vector2> span = stackalloc Vector2[10];
		for (int i = 0; i < span.Length; i++)
		{
			float x = -(float)Math.PI / 2f + (float)i * (float)Math.PI / 5f;
			span[i] = center + new Vector2(MathF.Cos(x), MathF.Sin(x)) * radius * ((i % 2 == 0) ? 1f : 0.45f);
		}
		uint num = (enabled ? RouteColor(1f, 0.81f, 0.25f) : RouteColor(0.4f, 0.43f, 0.47f));
		uint num2 = (enabled ? RouteColor(0.3f, 0.2f, 0.04f) : RouteColor(0.18f, 0.2f, 0.22f));
		for (int j = 0; j < span.Length; j++)
		{
			((ImDrawListPtr)(ref draw)).AddTriangleFilled(center, span[j], span[(j + 1) % span.Length], num);
		}
		for (int k = 0; k < span.Length; k++)
		{
			((ImDrawListPtr)(ref draw)).AddLine(span[k], span[(k + 1) % span.Length], num2, 1f);
		}
	}

	private static string NodeLabel(ArenaMapNode node)
	{
		string text = $"第 {node.Node} 格 · ";
		return text + node.Kind switch
		{
			ArenaTileKind.Battle => string.Join(" / ", node.Enemies), 
			ArenaTileKind.Treasure => "宝箱", 
			ArenaTileKind.Shop => "商店", 
			ArenaTileKind.Camp => "帐篷", 
			ArenaTileKind.Random => "随机事件", 
			_ => "起点", 
		};
	}

	private static void CanvasText(ImDrawListPtr draw, Vector2 center, string text, float size)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		Vector2 vector = ImGui.CalcTextSize(ImU8String.op_Implicit(text), false, -1f) * (size / ImGui.GetFontSize());
		((ImDrawListPtr)(ref draw)).AddText(ImGui.GetFont(), size, center - vector / 2f, RouteColor(0.97f, 0.98f, 1f), ImU8String.op_Implicit(text), 0f);
	}

	private string[] RouteRosterLines(ArenaBattlePreset battle, float width, float size)
	{
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		List<string> list = new List<string>();
		for (int i = 0; i < 3; i++)
		{
			string obj = $"{i + 1}  {ArenaPetName(battle.Flutes[i].A)}";
			string text = "";
			string text2 = obj;
			foreach (char c in text2)
			{
				if (text.Length > 0 && ImGui.CalcTextSize(ImU8String.op_Implicit(text + c), false, -1f).X * size / ImGui.GetFontSize() > width)
				{
					list.Add(text);
					text = "  ";
				}
				text += c;
			}
			if (text.Length > 0)
			{
				list.Add(text);
			}
		}
		return list.ToArray();
	}

	private static void DrawRouteIcon(ImDrawListPtr draw, Vector2 p, ArenaMapNode node, float radius, bool hovered)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_02bb: Unknown result type (might be due to invalid IL or missing references)
		if (node.Kind == ArenaTileKind.Start)
		{
			CanvasText(draw, p, "起点", radius * 0.6f);
			return;
		}
		string text = node.Kind switch
		{
			ArenaTileKind.Battle => node.BattleTier switch
			{
				ArenaBattleTier.Elite => "elite", 
				ArenaBattleTier.Boss => "boss", 
				_ => "monster", 
			}, 
			ArenaTileKind.Treasure => "chest", 
			ArenaTileKind.Shop => "shop", 
			ArenaTileKind.Camp => "rest", 
			ArenaTileKind.Random => "unknown", 
			_ => "monster", 
		};
		string directoryName = Services.PluginInterface.AssemblyLocation.DirectoryName;
		IDalamudTextureWrap val = (string.IsNullOrWhiteSpace(directoryName) ? null : Services.Textures.GetFromFile(Path.Combine(directoryName, "images", "route", text + ".png")).GetWrapOrDefault((IDalamudTextureWrap)null));
		if (val == null)
		{
			CanvasText(draw, p, (node.Kind == ArenaTileKind.Battle) ? "战斗" : NodeLabel(node), radius * 0.5f);
			return;
		}
		Vector2 vector = new Vector2(val.Width, val.Height);
		vector *= radius * 2f / Math.Max(vector.X, vector.Y) * (hovered ? 1.08f : 1f);
		if (text == "monster")
		{
			vector *= 0.78f;
		}
		Vector4 vector2 = text switch
		{
			"monster" => new Vector4(1f, 0.43f, 0.39f, 1f), 
			"elite" => new Vector4(0.78f, 0.53f, 1f, 1f), 
			"boss" => new Vector4(1f, 0.8f, 0.32f, 1f), 
			"chest" => new Vector4(0.44f, 0.77f, 1f, 1f), 
			"shop" => new Vector4(0.48f, 0.94f, 0.57f, 1f), 
			"unknown" => new Vector4(0.47f, 0.86f, 0.92f, 1f), 
			_ => new Vector4(1f, 0.6f, 0.3f, 1f), 
		};
		if (hovered)
		{
			vector2 = Vector4.Lerp(vector2, Vector4.One, 0.22f);
		}
		((ImDrawListPtr)(ref draw)).AddImage(val.Handle, p - vector / 2f, p + vector / 2f, Vector2.Zero, Vector2.One, ImGui.ColorConvertFloat4ToU32(vector2));
	}

	private void DrawBattleRules(ArenaPreset preset, ArenaMapNode info, ArenaBattlePreset battle)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_0127: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0174: Unknown result type (might be due to invalid IL or missing references)
		//IL_0160: Unknown result type (might be due to invalid IL or missing references)
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		ImGui.TextUnformatted(ImU8String.op_Implicit("战斗逻辑"));
		if (battle.RuleMode)
		{
			DrawCustomRules(preset, info, battle);
			return;
		}
		foreach (int item in ArenaBattleLogicStatus.Slots(preset.StageId, info.Node))
		{
			float textLineHeight = ImGui.GetTextLineHeight();
			bool flag = battle.LogicEnabled(item);
			DrawCompletionStar(ImGui.GetWindowDrawList(), ImGui.GetCursorScreenPos() + new Vector2(textLineHeight / 2f), textLineHeight / 2f, flag);
			ImU8String val = new ImU8String(17, 1);
			((ImU8String)(ref val)).AppendLiteral("toggleCustomLogic");
			((ImU8String)(ref val)).AppendFormatted<int>(item);
			if (ImGui.InvisibleButton(val, new Vector2(textLineHeight), (ImGuiButtonFlags)0))
			{
				battle.SetLogicEnabled(item, !flag);
				plugin.Save();
			}
			if (ImGui.IsItemHovered())
			{
				ImU8String tooltip = new ImU8String(1, 2);
				((ImU8String)(ref tooltip)).AppendFormatted<string>(ArenaBattleLogicStatus.Note(preset.StageId, info.Node, item));
				((ImU8String)(ref tooltip)).AppendLiteral("\n");
				((ImU8String)(ref tooltip)).AppendFormatted<string>(flag ? "已启用 · 点击停用" : "已停用 · 点击启用");
				ImGui.SetTooltip(tooltip);
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit(ArenaBattleLogicStatus.Note(preset.StageId, info.Node, item)));
		}
		if (!ArenaBattleLogicStatus.IsComplete(preset.StageId, info.Node))
		{
			ImGui.TextDisabled(ImU8String.op_Implicit("此战斗格暂无内置定制逻辑"));
		}
		ImGui.Spacing();
		if (ImGui.Button(ImU8String.op_Implicit("自定义规则…"), default(Vector2)))
		{
			if (battle.Rules == null)
			{
				List<ArenaBattleRule> list = (battle.Rules = new List<ArenaBattleRule>());
			}
			ImGui.OpenPopup(ImU8String.op_Implicit("###ArenaRuleAdd"), (ImGuiPopupFlags)0);
		}
		DrawRuleAddPopup(preset, info, battle, copyTemplates: false);
	}

	private void DrawRuleAddPopup(ArenaPreset preset, ArenaMapNode info, ArenaBattlePreset battle, bool copyTemplates)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		if (!ImGui.BeginPopup(ImU8String.op_Implicit("###ArenaRuleAdd"), (ImGuiWindowFlags)0))
		{
			return;
		}
		if (battle.Rules == null)
		{
			List<ArenaBattleRule> list = (battle.Rules = new List<ArenaBattleRule>());
		}
		foreach (ArenaBattleRule item in ArenaBattleRuleTemplates.BuiltIn(preset.StageId, info.Node))
		{
			ArenaBattleRule arenaBattleRule = (copyTemplates ? item.Copy() : item);
			if (!copyTemplates)
			{
				arenaBattleRule.Enabled = battle.LogicEnabled(arenaBattleRule.LegacySlot ?? 1);
			}
			if (ImGui.Selectable(ImU8String.op_Implicit((copyTemplates ? "内置：" : "") + ArenaRuleSummary.Describe(arenaBattleRule)), false, (ImGuiSelectableFlags)0, default(Vector2)))
			{
				battle.Rules.Add(arenaBattleRule);
				arenaExpandedRule = arenaBattleRule.Id;
				plugin.Save();
			}
		}
		if (ImGui.Selectable(ImU8String.op_Implicit("（空白规则）"), false, (ImGuiSelectableFlags)0, default(Vector2)))
		{
			ArenaBattleRule arenaBattleRule2 = new ArenaBattleRule
			{
				Name = "新规则"
			};
			battle.Rules.Add(arenaBattleRule2);
			arenaExpandedRule = arenaBattleRule2.Id;
			plugin.Save();
		}
		ImGui.EndPopup();
	}

	private void DrawCustomRules(ArenaPreset preset, ArenaMapNode info, ArenaBattlePreset battle)
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0208: Unknown result type (might be due to invalid IL or missing references)
		//IL_0265: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c9: Unknown result type (might be due to invalid IL or missing references)
		List<ArenaBattleRule> list = battle.Rules ?? (battle.Rules = new List<ArenaBattleRule>());
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("添加规则"), default(Vector2)))
		{
			ImGui.OpenPopup(ImU8String.op_Implicit("###ArenaRuleAdd"), (ImGuiPopupFlags)0);
		}
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("恢复内置"), default(Vector2)))
		{
			ImGui.OpenPopup(ImU8String.op_Implicit("###ArenaRuleReset"), (ImGuiPopupFlags)0);
		}
		if (ImGui.BeginPopup(ImU8String.op_Implicit("###ArenaRuleReset"), (ImGuiWindowFlags)0))
		{
			ImGui.TextUnformatted(ImU8String.op_Implicit("放弃全部自定义规则，恢复内置逻辑？"));
			if (ImGui.Button(ImU8String.op_Implicit("确定"), default(Vector2)))
			{
				list.Clear();
				arenaExpandedRule = "";
				plugin.Save();
				ImGui.CloseCurrentPopup();
			}
			ImGui.SameLine();
			if (ImGui.Button(ImU8String.op_Implicit("取消"), default(Vector2)))
			{
				ImGui.CloseCurrentPopup();
			}
			ImGui.EndPopup();
		}
		DrawRuleAddPopup(preset, info, battle, copyTemplates: true);
		ImGui.BeginChild(ImU8String.op_Implicit("###ArenaRuleList"), new Vector2(0f, Math.Min(150f, ImGui.GetContentRegionAvail().Y)), true, (ImGuiWindowFlags)0);
		for (int i = 0; i < list.Count; i++)
		{
			ArenaBattleRule arenaBattleRule = list[i];
			ImGui.PushID(ImU8String.op_Implicit(arenaBattleRule.Id));
			bool enabled = arenaBattleRule.Enabled;
			if (ImGui.Checkbox(ImU8String.op_Implicit("##enabled"), ref enabled))
			{
				arenaBattleRule.Enabled = enabled;
				plugin.Save();
			}
			ImGui.SameLine();
			bool flag = arenaExpandedRule == arenaBattleRule.Id;
			float x = Math.Max(60f, ImGui.GetContentRegionAvail().X - 68f);
			if (ImGui.Selectable(ImU8String.op_Implicit(ArenaRuleSummary.Describe(arenaBattleRule)), flag, (ImGuiSelectableFlags)0, new Vector2(x, 0f)))
			{
				arenaExpandedRule = (flag ? "" : arenaBattleRule.Id);
			}
			ImGui.SameLine();
			if (ImGui.ArrowButton(ImU8String.op_Implicit("up"), (ImGuiDir)2) && i > 0)
			{
				List<ArenaBattleRule> list3 = list;
				int index = i - 1;
				int index2 = i;
				ArenaBattleRule value = list[i];
				ArenaBattleRule value2 = list[i - 1];
				list3[index] = value;
				list[index2] = value2;
				plugin.Save();
			}
			ImGui.SameLine();
			if (ImGui.ArrowButton(ImU8String.op_Implicit("down"), (ImGuiDir)3) && i < list.Count - 1)
			{
				List<ArenaBattleRule> list3 = list;
				int index2 = i + 1;
				int index = i;
				ArenaBattleRule value2 = list[i];
				ArenaBattleRule value = list[i + 1];
				list3[index2] = value2;
				list[index] = value;
				plugin.Save();
			}
			ImGui.SameLine();
			if (ImGui.Button(ImU8String.op_Implicit("✕"), default(Vector2)))
			{
				list.RemoveAt(i);
				if (arenaExpandedRule == arenaBattleRule.Id)
				{
					arenaExpandedRule = "";
				}
				plugin.Save();
				ImGui.PopID();
				break;
			}
			ImGui.PopID();
		}
		ImGui.EndChild();
		ArenaBattleRule arenaBattleRule2 = list.FirstOrDefault((ArenaBattleRule r) => r.Id == arenaExpandedRule);
		if (arenaBattleRule2 != null)
		{
			ImGui.Separator();
			DrawRuleEditor(info, arenaBattleRule2);
		}
	}

	private static float StepperIntWidth(float field)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		float frameHeight = ImGui.GetFrameHeight();
		ImGuiStylePtr style = ImGui.GetStyle();
		return field + (frameHeight + ((ImGuiStylePtr)(ref style)).ItemInnerSpacing.X) * 2f;
	}

	private static float ComboWidth(params string[] labels)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		float num = labels.Max((string l) => ImGui.CalcTextSize(ImU8String.op_Implicit(l), false, -1f).X) + ImGui.GetFrameHeight();
		ImGuiStylePtr style = ImGui.GetStyle();
		return num + ((ImGuiStylePtr)(ref style)).FramePadding.X * 4f;
	}

	private void DrawRuleEditor(ArenaMapNode info, ArenaBattleRule rule)
	{
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0154: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0209: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_034f: Unknown result type (might be due to invalid IL or missing references)
		//IL_035a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0360: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_0394: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0513: Unknown result type (might be due to invalid IL or missing references)
		//IL_04da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0645: Unknown result type (might be due to invalid IL or missing references)
		//IL_0670: Unknown result type (might be due to invalid IL or missing references)
		//IL_05d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_080e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0819: Unknown result type (might be due to invalid IL or missing references)
		//IL_081f: Unknown result type (might be due to invalid IL or missing references)
		//IL_088c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0897: Unknown result type (might be due to invalid IL or missing references)
		//IL_089d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0733: Unknown result type (might be due to invalid IL or missing references)
		//IL_084e: Unknown result type (might be due to invalid IL or missing references)
		//IL_08dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_090c: Unknown result type (might be due to invalid IL or missing references)
		//IL_08cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0782: Unknown result type (might be due to invalid IL or missing references)
		//IL_078d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0793: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a37: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a42: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a48: Unknown result type (might be due to invalid IL or missing references)
		//IL_07c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0a81: Unknown result type (might be due to invalid IL or missing references)
		//IL_0af6: Unknown result type (might be due to invalid IL or missing references)
		ImGui.PushID(ImU8String.op_Implicit(rule.Id));
		ImGui.SetNextItemWidth(-1f);
		string name = rule.Name;
		if (ImGui.InputTextWithHint(ImU8String.op_Implicit("##rulename"), ImU8String.op_Implicit("规则名称（留空按内容生成摘要）"), ref name, 80, (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null))
		{
			rule.Name = name;
			plugin.Save();
		}
		ImGui.Spacing();
		ImGui.TextUnformatted(ImU8String.op_Implicit("触发"));
		int kind = (int)rule.Trigger.Kind;
		ImGui.SetNextItemWidth(150f);
		if (ImGui.Combo(ImU8String.op_Implicit("##trigger"), ref kind, (ReadOnlySpan<string>)RuleTriggerLabels, RuleTriggerLabels.Length))
		{
			rule.Trigger.Kind = (ArenaRuleTriggerKind)kind;
			plugin.Save();
		}
		ArenaRuleTrigger t = rule.Trigger;
		ImU8String val2;
		switch (t.Kind)
		{
		case ArenaRuleTriggerKind.BattleElapsed:
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(36f));
			int seconds = t.Seconds;
			ImU8String val3 = ImU8String.op_Implicit("##tsec");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val3, ref seconds, 1, 5, val2, (ImGuiInputTextFlags)0))
			{
				t.Seconds = Math.Clamp(seconds, 0, 600);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("秒后"));
			break;
		}
		case ArenaRuleTriggerKind.EnemyHpBelow:
		{
			ImGui.SameLine();
			EnemyIdSelector("##tenemy", info.Enemies, t.EnemyNameId, delegate(uint v)
			{
				t.EnemyNameId = v;
				plugin.Save();
			});
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(28f));
			int percent2 = t.Percent;
			ImU8String val4 = ImU8String.op_Implicit("##tpct");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val4, ref percent2, 1, 5, val2, (ImGuiInputTextFlags)0))
			{
				t.Percent = Math.Clamp(percent2, 1, 99);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("% 以下"));
			break;
		}
		case ArenaRuleTriggerKind.EnemyAliveFor:
		{
			ImGui.SameLine();
			EnemyIdSelector("##tenemy", info.Enemies, t.EnemyNameId, delegate(uint v)
			{
				t.EnemyNameId = v;
				plugin.Save();
			});
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(36f));
			int seconds2 = t.Seconds;
			ImU8String val6 = ImU8String.op_Implicit("##tsec");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val6, ref seconds2, 1, 5, val2, (ImGuiInputTextFlags)0))
			{
				t.Seconds = Math.Clamp(seconds2, 0, 600);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("秒"));
			break;
		}
		case ArenaRuleTriggerKind.EnemyCount:
		{
			ImGui.SameLine();
			EnemyIdSelector("##tenemy", info.Enemies, t.EnemyNameId, delegate(uint v)
			{
				t.EnemyNameId = v;
				plugin.Save();
			});
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(28f));
			int count = t.Count;
			ImU8String val7 = ImU8String.op_Implicit("##tcount");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val7, ref count, 1, 1, val2, (ImGuiInputTextFlags)0))
			{
				t.Count = Math.Clamp(count, 1, 20);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("只"));
			break;
		}
		case ArenaRuleTriggerKind.TargetIs:
			ImGui.SameLine();
			EnemyIdSelector("##tenemy", info.Enemies, t.EnemyNameId, delegate(uint v)
			{
				t.EnemyNameId = v;
				plugin.Save();
			});
			break;
		case ArenaRuleTriggerKind.PetSummoned:
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(ComboWidth(PetSlotLabels));
			int petSlot = t.PetSlot;
			ImU8String val5 = ImU8String.op_Implicit("##tpet");
			InlineArray4<string> buffer = default(InlineArray4<string>);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer, 0) = "任意魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer, 1) = "1 号魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer, 2) = "2 号魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer, 3) = "3 号魔兽";
			if (ImGui.Combo(val5, ref petSlot, global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<InlineArray4<string>, string>(in buffer, 4), 4))
			{
				t.PetSlot = petSlot;
				plugin.Save();
			}
			break;
		}
		case ArenaRuleTriggerKind.PlayerHpBelow:
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(28f));
			int percent = t.Percent;
			ImU8String val = ImU8String.op_Implicit("##tpct");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val, ref percent, 1, 5, val2, (ImGuiInputTextFlags)0))
			{
				t.Percent = Math.Clamp(percent, 1, 99);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("% 以下"));
			break;
		}
		}
		ImGui.TextUnformatted(ImU8String.op_Implicit("目标"));
		int kind2 = (int)rule.Target.Kind;
		ImGui.SetNextItemWidth(150f);
		if (ImGui.Combo(ImU8String.op_Implicit("##target"), ref kind2, (ReadOnlySpan<string>)RuleTargetLabels, RuleTargetLabels.Length))
		{
			rule.Target.Kind = (ArenaRuleTargetKind)kind2;
			plugin.Save();
		}
		ArenaRuleTarget g = rule.Target;
		if (g.Kind == ArenaRuleTargetKind.Enemy)
		{
			ImGui.SameLine();
			EnemyIdSelector("##genemy", info.Enemies, g.EnemyNameId, delegate(uint v)
			{
				g.EnemyNameId = v;
				plugin.Save();
			});
		}
		if (g.Kind == ArenaRuleTargetKind.Pet)
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(ComboWidth(PetSlotLabels));
			int petSlot2 = g.PetSlot;
			ImU8String val8 = ImU8String.op_Implicit("##gpet");
			InlineArray4<string> buffer2 = default(InlineArray4<string>);
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer2, 0) = "任意魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer2, 1) = "1 号魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer2, 2) = "2 号魔兽";
			global::_003CPrivateImplementationDetails_003E.InlineArrayElementRef<InlineArray4<string>, string>(ref buffer2, 3) = "3 号魔兽";
			if (ImGui.Combo(val8, ref petSlot2, global::_003CPrivateImplementationDetails_003E.InlineArrayAsReadOnlySpan<InlineArray4<string>, string>(in buffer2, 4), 4))
			{
				g.PetSlot = petSlot2;
				plugin.Save();
			}
		}
		ImGui.TextUnformatted(ImU8String.op_Implicit("动作"));
		int kind3 = (int)rule.Action.Kind;
		ImGui.SetNextItemWidth(150f);
		if (ImGui.Combo(ImU8String.op_Implicit("##action"), ref kind3, (ReadOnlySpan<string>)RuleActionLabels, RuleActionLabels.Length))
		{
			rule.Action.Kind = (ArenaRuleActionKind)kind3;
			plugin.Save();
		}
		ArenaRuleAction action = rule.Action;
		switch (action.Kind)
		{
		case ArenaRuleActionKind.UseItems:
		{
			int itemFilter = (int)action.ItemFilter;
			string[] array = Enum.GetValues<ArenaRuleItemFilter>().Select(ArenaRuleItemFilters.Label).ToArray();
			ImGui.SameLine();
			ImGui.SetNextItemWidth(Math.Min(280f, ComboWidth(array)));
			if (ImGui.Combo(ImU8String.op_Implicit("##afilter"), ref itemFilter, (ReadOnlySpan<string>)array, array.Length))
			{
				action.ItemFilter = (ArenaRuleItemFilter)itemFilter;
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(28f));
			int itemLimit = action.ItemLimit;
			ImU8String val10 = ImU8String.op_Implicit("##alimit");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val10, ref itemLimit, 1, 1, val2, (ImGuiInputTextFlags)0))
			{
				action.ItemLimit = Math.Clamp(itemLimit, 0, 10);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("件（0=全部）"));
			if (action.ItemFilter == ArenaRuleItemFilter.ExplicitList)
			{
				DrawExplicitItemsEditor(action);
			}
			DrawItemMatchSummary(action);
			break;
		}
		case ArenaRuleActionKind.UseDutyAction:
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(24f));
			int dutyActionSlot = action.DutyActionSlot;
			ImU8String val11 = ImU8String.op_Implicit("##aduty");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val11, ref dutyActionSlot, 1, 1, val2, (ImGuiInputTextFlags)0))
			{
				action.DutyActionSlot = Math.Clamp(dutyActionSlot, 1, 2);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("号职责技槽"));
			break;
		}
		case ArenaRuleActionKind.SetTargetPriority:
			DrawPriorityIdsEditor(info, action.PriorityEnemyIds);
			break;
		case ArenaRuleActionKind.Countdown:
		{
			ImGui.SameLine();
			ImGui.SetNextItemWidth(StepperIntWidth(24f));
			int countdownSeconds = action.CountdownSeconds;
			ImU8String val9 = ImU8String.op_Implicit("##acd");
			val2 = default(ImU8String);
			if (ImGui.InputInt(val9, ref countdownSeconds, 1, 5, val2, (ImGuiInputTextFlags)0))
			{
				action.CountdownSeconds = Math.Clamp(countdownSeconds, 1, 30);
				plugin.Save();
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit("秒"));
			break;
		}
		}
		ImGui.TextUnformatted(ImU8String.op_Implicit("限制"));
		int once = (int)rule.Limit.Once;
		ImGui.SetNextItemWidth(ComboWidth(RuleOnceLabels));
		if (ImGui.Combo(ImU8String.op_Implicit("##lonce"), ref once, (ReadOnlySpan<string>)RuleOnceLabels, RuleOnceLabels.Length))
		{
			rule.Limit.Once = (ArenaRuleOnce)once;
			plugin.Save();
		}
		LimitSeconds("窗口", "##lwin", rule.Limit.WindowSeconds, delegate(int v)
		{
			rule.Limit.WindowSeconds = v;
		}, "秒");
		LimitSeconds("冷却", "##lcd", rule.Limit.CooldownSeconds, delegate(int v)
		{
			rule.Limit.CooldownSeconds = v;
		});
		LimitSeconds("确认", "##lretry", rule.Limit.RetrySeconds, delegate(int v)
		{
			rule.Limit.RetrySeconds = Math.Clamp(v, 1, 60);
		});
		LimitSeconds("防抖", "##ldeb", rule.Limit.DebounceSeconds, delegate(int v)
		{
			rule.Limit.DebounceSeconds = v;
		});
		ImGui.SameLine();
		ImGui.SetNextItemWidth(StepperIntWidth(28f));
		int maxAttemptsPerItem = rule.Limit.MaxAttemptsPerItem;
		ImU8String val12 = ImU8String.op_Implicit("##latt");
		val2 = default(ImU8String);
		if (ImGui.InputInt(val12, ref maxAttemptsPerItem, 1, 1, val2, (ImGuiInputTextFlags)0))
		{
			rule.Limit.MaxAttemptsPerItem = Math.Clamp(maxAttemptsPerItem, 1, 10);
			plugin.Save();
		}
		ImGui.SameLine();
		ImGui.TextUnformatted(ImU8String.op_Implicit("次/件"));
		if (rule.Limit.WindowSeconds > 0)
		{
			ImGui.PushStyleColor((ImGuiCol)0, new Vector4(0.95f, 0.78f, 0.3f, 1f));
			((ImU8String)(ref val2))._002Ector(27, 1);
			((ImU8String)(ref val2)).AppendLiteral("仅开战后前 ");
			((ImU8String)(ref val2)).AppendFormatted<int>(rule.Limit.WindowSeconds);
			((ImU8String)(ref val2)).AppendLiteral(" 秒内可触发：超时后本场战斗本规则不再执行");
			ImGui.TextUnformatted(val2);
			ImGui.PopStyleColor();
		}
		ImGui.PopID();
	}

	private void LimitSeconds(string label, string id, int value, Action<int> set, string suffix = "")
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		ImGui.SameLine();
		ImGui.TextUnformatted(ImU8String.op_Implicit(label));
		ImGui.SameLine();
		ImGui.SetNextItemWidth(StepperIntWidth(24f));
		int value2 = value;
		if (ImGui.InputInt(ImU8String.op_Implicit(id), ref value2, 1, 5, default(ImU8String), (ImGuiInputTextFlags)0))
		{
			set(Math.Clamp(value2, 0, 600));
			plugin.Save();
		}
		if (suffix.Length > 0)
		{
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit(suffix));
		}
	}

	private void EnemyIdSelector(string id, IReadOnlyList<string> nodeEnemies, uint value, Action<uint> apply)
	{
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_017c: Unknown result type (might be due to invalid IL or missing references)
		string text = ((value == 0) ? "0 ·（最强敌人/全部敌人）" : $"{ArenaEnemyCatalog.Name(value)}（{value}）");
		ImGui.SetNextItemWidth(Math.Min(240f, Math.Max(140f, ImGui.GetContentRegionAvail().X - 8f)));
		if (!ImGui.BeginCombo(ImU8String.op_Implicit(id), ImU8String.op_Implicit(text), (ImGuiComboFlags)0))
		{
			return;
		}
		if (!ruleSearch.TryGetValue(id, out string value2))
		{
			value2 = "";
		}
		ImGui.SetNextItemWidth(-1f);
		if (ImGui.InputTextWithHint(ImU8String.op_Implicit("##filter"), ImU8String.op_Implicit("搜索敌人名称"), ref value2, 40, (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null))
		{
			ruleSearch[id] = value2;
		}
		if (ImGui.Selectable(ImU8String.op_Implicit("0 ·（最强敌人/全部敌人）"), value == 0, (ImGuiSelectableFlags)0, default(Vector2)))
		{
			apply(0u);
			ImGui.EndCombo();
			return;
		}
		int num = 0;
		foreach (uint item in ArenaEnemyCatalog.Search(value2, 120))
		{
			if (nodeEnemies.Count <= 0 || nodeEnemies.Contains(ArenaEnemyCatalog.Name(item)))
			{
				if (num++ >= 40)
				{
					break;
				}
				ImU8String val = new ImU8String(2, 2);
				((ImU8String)(ref val)).AppendFormatted<string>(ArenaEnemyCatalog.Name(item));
				((ImU8String)(ref val)).AppendLiteral("（");
				((ImU8String)(ref val)).AppendFormatted<uint>(item);
				((ImU8String)(ref val)).AppendLiteral("）");
				if (ImGui.Selectable(val, item == value, (ImGuiSelectableFlags)0, default(Vector2)))
				{
					apply(item);
					ImGui.EndCombo();
					return;
				}
			}
		}
		ImGui.EndCombo();
	}

	private void DrawPriorityIdsEditor(ArenaMapNode info, List<uint> ids)
	{
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_012c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c0: Unknown result type (might be due to invalid IL or missing references)
		ImGui.Spacing();
		ImU8String val = default(ImU8String);
		ImU8String val2 = default(ImU8String);
		for (int i = 0; i < ids.Count; i++)
		{
			((ImU8String)(ref val))._002Ector(4, 1);
			((ImU8String)(ref val)).AppendLiteral("prio");
			((ImU8String)(ref val)).AppendFormatted<int>(i);
			ImGui.PushID(val);
			if (ImGui.ArrowButton(ImU8String.op_Implicit("up"), (ImGuiDir)2) && i > 0)
			{
				List<uint> list = ids;
				int index = i - 1;
				List<uint> list2 = ids;
				int index2 = i;
				uint value = ids[i];
				uint value2 = ids[i - 1];
				list[index] = value;
				list2[index2] = value2;
				plugin.Save();
			}
			ImGui.SameLine();
			if (ImGui.ArrowButton(ImU8String.op_Implicit("down"), (ImGuiDir)3) && i < ids.Count - 1)
			{
				List<uint> list = ids;
				int index2 = i + 1;
				List<uint> list3 = ids;
				int index = i;
				uint value2 = ids[i];
				uint value = ids[i + 1];
				list[index2] = value2;
				list3[index] = value;
				plugin.Save();
			}
			ImGui.SameLine();
			if (ImGui.SmallButton(ImU8String.op_Implicit("✕")))
			{
				ids.RemoveAt(i);
				plugin.Save();
				ImGui.PopID();
				break;
			}
			ImGui.SameLine();
			((ImU8String)(ref val2))._002Ector(4, 3);
			((ImU8String)(ref val2)).AppendFormatted<int>(i + 1);
			((ImU8String)(ref val2)).AppendLiteral(". ");
			((ImU8String)(ref val2)).AppendFormatted<string>(ArenaEnemyCatalog.Name(ids[i]));
			((ImU8String)(ref val2)).AppendLiteral("（");
			((ImU8String)(ref val2)).AppendFormatted<uint>(ids[i]);
			((ImU8String)(ref val2)).AppendLiteral("）");
			ImGui.TextUnformatted(val2);
			ImGui.PopID();
		}
		if (ids.Count == 0)
		{
			ImGui.TextDisabled(ImU8String.op_Implicit("从下方选择要优先攻击的敌人"));
		}
		EnemyIdSelector("##prioadd", info.Enemies, 0u, delegate(uint v)
		{
			if (v != 0 && !ids.Contains(v))
			{
				ids.Add(v);
			}
			plugin.Save();
		});
	}

	private void DrawExplicitItemsEditor(ArenaRuleAction action)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0133: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ee: Unknown result type (might be due to invalid IL or missing references)
		ImGui.Spacing();
		List<uint> itemIds = action.ItemIds;
		ImU8String val = default(ImU8String);
		for (int i = 0; i < itemIds.Count; i++)
		{
			((ImU8String)(ref val))._002Ector(4, 1);
			((ImU8String)(ref val)).AppendLiteral("item");
			((ImU8String)(ref val)).AppendFormatted<int>(i);
			ImGui.PushID(val);
			if (ImGui.SmallButton(ImU8String.op_Implicit("✕")))
			{
				itemIds.RemoveAt(i);
				plugin.Save();
				ImGui.PopID();
				break;
			}
			ImGui.SameLine();
			ImGui.TextUnformatted(ImU8String.op_Implicit(ArenaItemCatalog.Items.TryGetValue(itemIds[i], out ArenaItem value) ? value.Name : $"#{itemIds[i]}"));
			ImGui.PopID();
		}
		string value2;
		string text = (ruleSearch.TryGetValue("explicititem", out value2) ? value2 : "");
		ImGui.SetNextItemWidth(200f);
		if (ImGui.InputTextWithHint(ImU8String.op_Implicit("##itemfilter"), ImU8String.op_Implicit("搜索道具名称或 ID"), ref text, 40, (ImGuiInputTextFlags)0, (ImGuiInputTextCallbackDelegate)null))
		{
			ruleSearch["explicititem"] = text;
		}
		ImGui.BeginChild(ImU8String.op_Implicit("###ExplicitItemPick"), new Vector2(0f, 90f), true, (ImGuiWindowFlags)0);
		string text2 = text.Trim();
		uint.TryParse(text2, out var result);
		foreach (ArenaItem value3 in ArenaItemCatalog.Items.Values)
		{
			if ((text2.Length <= 0 || value3.Id == result || value3.Name.Contains(text2, StringComparison.Ordinal)) && !itemIds.Contains(value3.Id))
			{
				ImU8String val2 = new ImU8String(2, 2);
				((ImU8String)(ref val2)).AppendFormatted<string>(value3.Name);
				((ImU8String)(ref val2)).AppendLiteral("（");
				((ImU8String)(ref val2)).AppendFormatted<uint>(value3.Id);
				((ImU8String)(ref val2)).AppendLiteral("）");
				if (ImGui.Selectable(val2, false, (ImGuiSelectableFlags)0, default(Vector2)))
				{
					itemIds.Add(value3.Id);
					plugin.Save();
				}
			}
		}
		ImGui.EndChild();
	}

	private void DrawItemMatchSummary(ArenaRuleAction a)
	{
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		List<uint> list = ArenaItemDispatch.ReadOwnedItems();
		if (list == null)
		{
			return;
		}
		List<uint> list2 = list.Where((uint id) => ArenaRuleItemFilters.Match(a.ItemFilter, a.ItemIds, id)).ToList();
		if (list2.Count > 0)
		{
			ImGui.PushStyleColor((ImGuiCol)0, new Vector4(0.45f, 0.85f, 0.45f, 1f));
			ImU8String val = default(ImU8String);
			((ImU8String)(ref val))._002Ector(8, 1);
			((ImU8String)(ref val)).AppendLiteral("本场可匹配 ");
			((ImU8String)(ref val)).AppendFormatted<int>(list2.Count);
			((ImU8String)(ref val)).AppendLiteral(" 件");
			ImGui.TextUnformatted(val);
			if (ImGui.IsItemHovered())
			{
				ImGui.SetTooltip(ImU8String.op_Implicit(string.Join("\n", list2.Select((uint id) => ArenaItemCatalog.Items.TryGetValue(id, out ArenaItem value) ? $"{value.Name}（{id}）" : $"#{id}"))));
			}
		}
		else
		{
			ImGui.PushStyleColor((ImGuiCol)0, new Vector4(0.9f, 0.45f, 0.45f, 1f));
			ImGui.TextUnformatted(ImU8String.op_Implicit("本场没有匹配的道具（该规则不会使用任何道具）"));
		}
		ImGui.PopStyleColor();
	}

	internal void ShowPluginConfiguration()
	{
		((Window)this).IsOpen = true;
		requestedMainTab = "插件配置";
	}

	private static ImGuiTabItemFlags MainTabFlags(string tab, string? requested)
	{
		if (requested == tab)
		{
			return (ImGuiTabItemFlags)2;
		}
		return (ImGuiTabItemFlags)0;
	}

	public override void PreDraw()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Expected O, but got Unknown
		WindowSizeConstraints value = default(WindowSizeConstraints);
		((WindowSizeConstraints)(ref value))._002Ector();
		((WindowSizeConstraints)(ref value)).MinimumSize = new Vector2(420f, 400f);
		((WindowSizeConstraints)(ref value)).MaximumSize = new Vector2(float.MaxValue);
		((Window)this).SizeConstraints = value;
		if (titleButtonsReady)
		{
			return;
		}
		titleButtonsReady = true;
		((Window)this).TitleBarButtons.Add(new TitleBarButton
		{
			Icon = (FontAwesomeIcon)61444,
			IconOffset = new Vector2(1f, 1f),
			ShowTooltip = delegate
			{
				//IL_0005: Unknown result type (might be due to invalid IL or missing references)
				ImGui.SetTooltip(ImU8String.op_Implicit("支持 Pawprint"));
			},
			Click = delegate(ImGuiMouseButton button)
			{
				//IL_0000: Unknown result type (might be due to invalid IL or missing references)
				if ((int)button == 0)
				{
					supportRequested = true;
					supportPosition = ImGui.GetMousePos();
				}
			}
		});
	}

	public override void OnClose()
	{
		plugin.Activation.Clear();
	}

	private void DrawSupport()
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		if (supportRequested)
		{
			supportRequested = false;
			ImGui.SetNextWindowPos(supportPosition);
			ImGui.OpenPopup(ImU8String.op_Implicit("PawprintSupport"), (ImGuiPopupFlags)0);
		}
		if (!ImGui.BeginPopup(ImU8String.op_Implicit("PawprintSupport"), (ImGuiWindowFlags)0))
		{
			return;
		}
		if (ImGui.Button(ImU8String.op_Implicit("前往爱发电赞助"), default(Vector2)))
		{
			try
			{
				Process.Start(new ProcessStartInfo("https://afdian.com/a/a16239438")
				{
					UseShellExecute = true
				});
			}
			catch (Exception ex)
			{
				Services.Log.Warning(ex, "Unable to open Pawprint support link", Array.Empty<object>());
			}
			ImGui.CloseCurrentPopup();
		}
		ImGui.EndPopup();
	}

	private static void SameLineIfFits(float nextWidth)
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		float num = ImGui.GetCursorScreenPos().X + ImGui.GetContentRegionAvail().X;
		float x = ImGui.GetItemRectMax().X;
		ImGuiStylePtr style = ImGui.GetStyle();
		if (x + ((ImGuiStylePtr)(ref style)).ItemSpacing.X + nextWidth <= num)
		{
			ImGui.SameLine();
		}
	}

	private static float ButtonWidth(string label)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		float x = ImGui.CalcTextSize(ImU8String.op_Implicit(label), false, -1f).X;
		ImGuiStylePtr style = ImGui.GetStyle();
		return x + ((ImGuiStylePtr)(ref style)).FramePadding.X * 2f;
	}

	public override void Draw()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		DrawSupport();
		if (!ImGui.BeginTabBar(ImU8String.op_Implicit("MainTabs"), (ImGuiTabBarFlags)0))
		{
			plugin.Activation.Clear();
			return;
		}
		string requested = requestedMainTab;
		requestedMainTab = null;
		if (ImGui.BeginTabItem(ImU8String.op_Implicit("插件配置"), MainTabFlags("插件配置", requested)))
		{
			try
			{
				pluginConfiguration.Draw();
			}
			catch (Exception e)
			{
				plugin.ReportDrawError(e);
			}
			ImGui.EndTabItem();
		}
		else
		{
			plugin.Activation.Clear();
		}
		if (ImGui.BeginTabItem(ImU8String.op_Implicit("捕猎"), MainTabFlags("捕猎", requested)))
		{
			try
			{
				DrawHunting();
			}
			catch (Exception e2)
			{
				plugin.ReportDrawError(e2);
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem(ImU8String.op_Implicit("斗兽奇弈"), MainTabFlags("斗兽奇弈", requested)))
		{
			try
			{
				DrawArena();
			}
			catch (Exception e3)
			{
				plugin.ReportDrawError(e3);
			}
			ImGui.EndTabItem();
		}
		if (ImGui.BeginTabItem(ImU8String.op_Implicit("设置"), MainTabFlags("设置", requested)))
		{
			try
			{
				DrawSettings();
			}
			catch (Exception e4)
			{
				plugin.ReportDrawError(e4);
			}
			ImGui.EndTabItem();
		}
		ImGui.EndTabBar();
	}

	private void DrawHunting()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0216: Unknown result type (might be due to invalid IL or missing references)
		//IL_0226: Unknown result type (might be due to invalid IL or missing references)
		//IL_023c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0508: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_0296: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_052b: Unknown result type (might be due to invalid IL or missing references)
		//IL_051c: Unknown result type (might be due to invalid IL or missing references)
		//IL_036f: Unknown result type (might be due to invalid IL or missing references)
		//IL_055e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0588: Unknown result type (might be due to invalid IL or missing references)
		//IL_05c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_05f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_061b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0486: Unknown result type (might be due to invalid IL or missing references)
		ImGui.BeginDisabled(plugin.HasTask);
		if (ImGui.Button(ImU8String.op_Implicit("自动捕获"), new Vector2(120f, 0f)))
		{
			plugin.AutoCapture();
		}
		ImGui.EndDisabled();
		ImGui.SameLine();
		ImGui.BeginDisabled(runner.State != RunState.Running);
		if (ImGui.Button(ImU8String.op_Implicit("暂停"), default(Vector2)))
		{
			runner.Pause();
		}
		ImGui.EndDisabled();
		ImGui.SameLine();
		ImGui.BeginDisabled(runner.State != RunState.Paused);
		if (ImGui.Button(ImU8String.op_Implicit("继续"), default(Vector2)))
		{
			plugin.ResumeTask();
		}
		ImGui.EndDisabled();
		ImGui.SameLine();
		ImGui.BeginDisabled(!plugin.HasTask && !plugin.CaptureIntentHeld && !plugin.HasAttackTarget);
		if (ImGui.Button(ImU8String.op_Implicit("停止"), default(Vector2)))
		{
			plugin.StopTask();
		}
		ImGui.EndDisabled();
		ImGui.TextWrapped(ImU8String.op_Implicit((runner.State == RunState.Paused) ? "已暂停" : plugin.Notice));
		Dictionary<CaptureState, int> dictionary = (from m in plugin.Catalog.Monsters
			group m by plugin.Notebook.Get(m.Number)).ToDictionary((IGrouping<CaptureState, MonsterEntry> g) => g.Key, (IGrouping<CaptureState, MonsterEntry> g) => g.Count());
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(17, 3);
		((ImU8String)(ref val)).AppendLiteral("已捕获 ");
		((ImU8String)(ref val)).AppendFormatted<int>(dictionary.GetValueOrDefault(CaptureState.Captured));
		((ImU8String)(ref val)).AppendLiteral(" / 未捕获 ");
		((ImU8String)(ref val)).AppendFormatted<int>(dictionary.GetValueOrDefault(CaptureState.Missing));
		((ImU8String)(ref val)).AppendLiteral(" / 未知 ");
		((ImU8String)(ref val)).AppendFormatted<int>(dictionary.GetValueOrDefault(CaptureState.Unknown));
		ImGui.TextUnformatted(val);
		ImGui.SameLine();
		ImGui.Checkbox(ImU8String.op_Implicit("只看未捕获"), ref onlyMissing);
		if (ImGui.BeginTable(ImU8String.op_Implicit("MonsterCatalog"), 4, (ImGuiTableFlags)33556417, new Vector2(0f, 280f), 0f))
		{
			ImGui.TableSetupColumn(ImU8String.op_Implicit("编号 / 魔物"), (ImGuiTableColumnFlags)0, 0f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("收录"), (ImGuiTableColumnFlags)0, 0f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("区域 / 副本"), (ImGuiTableColumnFlags)0, 0f, 0u);
			ImGui.TableSetupColumn(ImU8String.op_Implicit("位置"), (ImGuiTableColumnFlags)0, 0f, 0u);
			ImGui.TableSetupScrollFreeze(0, 1);
			ImGui.TableHeadersRow();
			MonsterEntry[] monsters = plugin.Catalog.Monsters;
			ImU8String val2 = default(ImU8String);
			foreach (MonsterEntry monsterEntry in monsters)
			{
				CaptureState captureState = plugin.Notebook.Get(monsterEntry.Number);
				if (!onlyMissing || captureState == CaptureState.Missing)
				{
					ImGui.TableNextRow();
					ImGui.TableNextColumn();
					((ImU8String)(ref val2))._002Ector(10, 3);
					((ImU8String)(ref val2)).AppendFormatted<int>(monsterEntry.Number, "00");
					((ImU8String)(ref val2)).AppendLiteral(" ");
					((ImU8String)(ref val2)).AppendFormatted<string>(monsterEntry.Name);
					((ImU8String)(ref val2)).AppendLiteral("##monster");
					((ImU8String)(ref val2)).AppendFormatted<int>(monsterEntry.Number);
					if (ImGui.Selectable(val2, plugin.SelectedMonster == monsterEntry.Number, (ImGuiSelectableFlags)0, default(Vector2)))
					{
						plugin.SelectedMonster = monsterEntry.Number;
					}
					ImGui.TableNextColumn();
					ImGui.TextUnformatted(ImU8String.op_Implicit(captureState switch
					{
						CaptureState.Captured => "已捕获", 
						CaptureState.Missing => "未捕获", 
						_ => "未知", 
					}));
					ImGui.TableNextColumn();
					ImGui.TextUnformatted(ImU8String.op_Implicit(monsterEntry.LocationName));
					ImGui.TableNextColumn();
					ImGui.TextUnformatted(ImU8String.op_Implicit(monsterEntry.UnsupportedDuty ? "多人本 · 不支持" : (monsterEntry.MapX.HasValue ? $"{monsterEntry.MapX:0.0}, {monsterEntry.MapY:0.0}" : ((monsterEntry.Kind == MonsterLocationKind.Duty) ? "位于副本内" : ((monsterEntry.Kind == MonsterLocationKind.Starter) ? "初始伙伴" : "待补充")))));
				}
			}
			ImGui.EndTable();
		}
		MonsterEntry monsterEntry2 = plugin.Catalog.Monsters.Single((MonsterEntry m) => m.Number == plugin.SelectedMonster);
		ImU8String val3 = default(ImU8String);
		((ImU8String)(ref val3))._002Ector(2, 2);
		((ImU8String)(ref val3)).AppendLiteral("#");
		((ImU8String)(ref val3)).AppendFormatted<int>(monsterEntry2.Number, "00");
		((ImU8String)(ref val3)).AppendLiteral(" ");
		((ImU8String)(ref val3)).AppendFormatted<string>(monsterEntry2.Name);
		ImGui.TextUnformatted(val3);
		if (monsterEntry2.UnsupportedDuty)
		{
			ImGui.TextDisabled(ImU8String.op_Implicit("多人副本，暂不支持"));
		}
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("手动操作"), (ImGuiTreeNodeFlags)0))
		{
			ImGui.BeginDisabled(plugin.HasTask || !monsterEntry2.CanHunt);
			if (ImGui.Button(ImU8String.op_Implicit("捕获选中"), default(Vector2)))
			{
				plugin.CaptureSelected();
			}
			ImGui.SameLine();
			if (ImGui.Button(ImU8String.op_Implicit("仅寻找选中"), default(Vector2)))
			{
				plugin.LocateSelected();
			}
			ImGui.EndDisabled();
			ImGui.SameLine();
			ImGui.BeginDisabled(plugin.HasTask);
			if (ImGui.Button(ImU8String.op_Implicit("练级提升一级"), default(Vector2)))
			{
				plugin.LevelOnce();
			}
			ImGui.SameLine();
			if (ImGui.Button(ImU8String.op_Implicit("刷新图鉴"), default(Vector2)))
			{
				plugin.ScanNotebook();
			}
			ImGui.SameLine();
			if (ImGui.Button(ImU8String.op_Implicit("打开图鉴"), default(Vector2)))
			{
				plugin.OpenNotebook();
			}
			ImGui.EndDisabled();
		}
	}

	private void DrawArena()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_018c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0243: Unknown result type (might be due to invalid IL or missing references)
		//IL_0293: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_037c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03bf: Unknown result type (might be due to invalid IL or missing references)
		float num = ImGui.CalcTextSize(ImU8String.op_Implicit("高段第二盘"), false, -1f).X + ImGui.GetFrameHeight();
		ImGuiStylePtr style = ImGui.GetStyle();
		float num2 = num + ((ImGuiStylePtr)(ref style)).ItemInnerSpacing.X;
		style = ImGui.GetStyle();
		float num3 = num2 + ((ImGuiStylePtr)(ref style)).CellPadding.X * 2f + 8f;
		int num4 = Math.Clamp((int)(ImGui.GetContentRegionAvail().X / num3), 1, 5);
		ImGui.BeginDisabled(plugin.HasTask);
		if (ImGui.BeginTable(ImU8String.op_Implicit("ArenaMaps"), num4, (ImGuiTableFlags)32768, default(Vector2), 0f))
		{
			foreach (ArenaStage item in ArenaStage.All)
			{
				ImGui.TableNextColumn();
				string text = ((item.Id <= 3) ? ("低段" + item.Name) : item.Name);
				if (!item.HasNavigationRoute)
				{
					text += "（暂不支持）";
				}
				if (ImGui.RadioButton(ImU8String.op_Implicit(text), config.ArenaStageId == item.Id))
				{
					config.ArenaStageId = item.Id;
					plugin.Save();
				}
			}
			ImGui.EndTable();
		}
		ImGui.EndDisabled();
		ArenaStage arenaStage = ArenaStage.Get(config.ArenaStageId);
		DrawPresetSelector(arenaStage);
		if (Services.PlayerState.ContentId != 0L)
		{
			style = ImGui.GetStyle();
			SameLineIfFits(180f + ((ImGuiStylePtr)(ref style)).ItemInnerSpacing.X + ImGui.CalcTextSize(ImU8String.op_Implicit("次数 (1–999)"), false, -1f).X);
		}
		int value = Math.Clamp(config.ArenaRepeatCount, 1, 999);
		ImGui.SetNextItemWidth(180f);
		ImU8String val = ImU8String.op_Implicit("次数 (1–999)");
		ImU8String val2 = default(ImU8String);
		if (ImGui.InputInt(val, ref value, 0, 0, val2, (ImGuiInputTextFlags)0))
		{
			config.ArenaRepeatCount = Math.Clamp(value, 1, 999);
			plugin.Save();
		}
		ImGui.BeginDisabled(!arenaStage.HasNavigationRoute || plugin.HasTask);
		if (ImGui.Button(ImU8String.op_Implicit("自动完成斗兽奇弈(WIP)"), default(Vector2)))
		{
			plugin.StartArenaRun();
		}
		ImGui.EndDisabled();
		SameLineIfFits(ButtonWidth("暂停"));
		ImGui.BeginDisabled(runner.State != RunState.Running);
		if (ImGui.Button(ImU8String.op_Implicit("暂停##arena"), default(Vector2)))
		{
			runner.Pause();
		}
		ImGui.EndDisabled();
		SameLineIfFits(ButtonWidth("继续"));
		ImGui.BeginDisabled(runner.State != RunState.Paused);
		if (ImGui.Button(ImU8String.op_Implicit("继续##arena"), default(Vector2)))
		{
			plugin.ResumeTask();
		}
		ImGui.EndDisabled();
		SameLineIfFits(ButtonWidth("停止"));
		ImGui.BeginDisabled(!plugin.HasTask);
		if (ImGui.Button(ImU8String.op_Implicit("停止##arena"), default(Vector2)))
		{
			plugin.StopTask();
		}
		ImGui.EndDisabled();
		ImGui.TextWrapped(ImU8String.op_Implicit((runner.State == RunState.Paused) ? "已暂停" : plugin.Notice));
		string arenaBattleStatus = plugin.ArenaBattleStatus;
		if (arenaBattleStatus != null && arenaBattleStatus.Length > 0)
		{
			((ImU8String)(ref val2))._002Ector(7, 1);
			((ImU8String)(ref val2)).AppendLiteral("战斗辅助 · ");
			((ImU8String)(ref val2)).AppendFormatted<string>(arenaBattleStatus);
			ImGui.TextWrapped(val2);
		}
		DrawPresetEditor(arenaStage);
	}

	private void DrawArenaRoster(List<uint> roster, int capacity)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_0188: Unknown result type (might be due to invalid IL or missing references)
		//IL_01dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0362: Unknown result type (might be due to invalid IL or missing references)
		//IL_04aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_04bb: Unknown result type (might be due to invalid IL or missing references)
		ImGui.Separator();
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(6, 2);
		((ImU8String)(ref val)).AppendLiteral("入场编组 ");
		((ImU8String)(ref val)).AppendFormatted<int>(roster.Count);
		((ImU8String)(ref val)).AppendLiteral("/");
		((ImU8String)(ref val)).AppendFormatted<int>(capacity);
		ImGui.TextUnformatted(val);
		ImGui.SameLine();
		ImGui.BeginDisabled(Services.PlayerState.ContentId == 0L || plugin.HasTask);
		if (ImGui.SmallButton(ImU8String.op_Implicit("读取已解锁魔兽")))
		{
			plugin.ScanNotebook();
		}
		ImGui.EndDisabled();
		if (!ImGui.BeginTable(ImU8String.op_Implicit("ArenaRoster"), 2, (ImGuiTableFlags)33554945, new Vector2(0f, 310f), 0f))
		{
			return;
		}
		ImGui.TableSetupColumn(ImU8String.op_Implicit("已解锁魔兽"), (ImGuiTableColumnFlags)0, 0f, 0u);
		ImGui.TableSetupColumn(ImU8String.op_Implicit("入场顺序／补位顺序"), (ImGuiTableColumnFlags)0, 0f, 0u);
		ImGui.TableHeadersRow();
		ImGui.TableNextRow();
		ImGui.TableNextColumn();
		foreach (MonsterEntry item in plugin.Catalog.Monsters.Where((MonsterEntry m) => plugin.Notebook.Get(m.Number) == CaptureState.Captured))
		{
			bool flag = roster.Contains((uint)item.Number);
			ImGui.BeginDisabled(!flag && roster.Count >= capacity);
			ImU8String val2 = new ImU8String(8, 3);
			((ImU8String)(ref val2)).AppendFormatted<int>(item.Number, "00");
			((ImU8String)(ref val2)).AppendLiteral(" ");
			((ImU8String)(ref val2)).AppendFormatted<string>(item.SpeciesName ?? item.Name);
			((ImU8String)(ref val2)).AppendLiteral("##arena");
			((ImU8String)(ref val2)).AppendFormatted<int>(item.Number);
			if (ImGui.Checkbox(val2, ref flag))
			{
				if (flag)
				{
					roster.Add((uint)item.Number);
				}
				else
				{
					roster.Remove((uint)item.Number);
				}
				plugin.Save();
			}
			ImGui.EndDisabled();
		}
		ImGui.TableNextColumn();
		int i;
		ImU8String val3 = default(ImU8String);
		for (i = 0; i < roster.Count; i++)
		{
			MonsterEntry monsterEntry = plugin.Catalog.Monsters.FirstOrDefault((MonsterEntry m) => m.Number == roster[i]);
			ImGui.PushID((IntPtr)i);
			ImGui.BeginDisabled(i == 0);
			if (ImGui.SmallButton(ImU8String.op_Implicit("上移")))
			{
				List<uint> list = roster;
				int index = i - 1;
				List<uint> list2 = roster;
				int index2 = i;
				uint value = roster[i];
				uint value2 = roster[i - 1];
				list[index] = value;
				list2[index2] = value2;
				plugin.Save();
			}
			ImGui.EndDisabled();
			ImGui.SameLine();
			ImGui.BeginDisabled(i == roster.Count - 1);
			if (ImGui.SmallButton(ImU8String.op_Implicit("下移")))
			{
				List<uint> list = roster;
				int index2 = i + 1;
				List<uint> list3 = roster;
				int index = i;
				uint value2 = roster[i];
				uint value = roster[i + 1];
				list[index2] = value2;
				list3[index] = value;
				plugin.Save();
			}
			ImGui.EndDisabled();
			ImGui.SameLine();
			string text = ((monsterEntry != null && plugin.Notebook.Get(monsterEntry.Number) != CaptureState.Captured) ? "（未解锁）" : "");
			((ImU8String)(ref val3))._002Ector(2, 3);
			((ImU8String)(ref val3)).AppendFormatted<int>(i + 1);
			((ImU8String)(ref val3)).AppendLiteral(". ");
			((ImU8String)(ref val3)).AppendFormatted<string>(monsterEntry?.SpeciesName ?? monsterEntry?.Name ?? roster[i].ToString());
			((ImU8String)(ref val3)).AppendFormatted<string>(text);
			ImGui.TextUnformatted(val3);
			ImGui.SameLine();
			if (ImGui.SmallButton(ImU8String.op_Implicit("移除")))
			{
				roster.RemoveAt(i);
				plugin.Save();
				ImGui.PopID();
				break;
			}
			ImGui.PopID();
		}
		ImGui.EndTable();
	}

	private void DrawSettings()
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0123: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_0325: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0301: Unknown result type (might be due to invalid IL or missing references)
		//IL_0316: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0380: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0411: Unknown result type (might be due to invalid IL or missing references)
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(9, 1);
		((ImU8String)(ref val)).AppendLiteral("Pawprint ");
		((ImU8String)(ref val)).AppendFormatted<string>(typeof(Plugin).Assembly.GetName().Version?.ToString(3));
		ImGui.TextDisabled(val);
		bool openOnLoad = config.OpenOnLoad;
		if (ImGui.Checkbox(ImU8String.op_Implicit("加载时打开窗口"), ref openOnLoad))
		{
			config.OpenOnLoad = openOnLoad;
			plugin.Save();
		}
		bool preferFlight = config.PreferFlight;
		if (ImGui.Checkbox(ImU8String.op_Implicit("优先飞行"), ref preferFlight))
		{
			config.PreferFlight = preferFlight;
			plugin.Save();
		}
		ImGui.Separator();
		if (ImGui.Button(ImU8String.op_Implicit("导出图鉴诊断"), default(Vector2)))
		{
			plugin.ExportNotebook();
		}
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("导出捕获诊断"), default(Vector2)))
		{
			plugin.ExportNotebook();
		}
		ImGui.SameLine();
		ImGui.BeginDisabled(plugin.HasTask);
		if (ImGui.Button(ImU8String.op_Implicit("出售测试"), default(Vector2)))
		{
			plugin.DebugShopTrade();
		}
		ImGui.EndDisabled();
		if (!plugin.ArenaRecording.IsRecording)
		{
			ImGui.BeginDisabled(plugin.HasTask);
			if (ImGui.Button(ImU8String.op_Implicit("记录斗兽流程"), default(Vector2)))
			{
				plugin.StartArenaRecording();
			}
			ImGui.EndDisabled();
		}
		else if (ImGui.Button(ImU8String.op_Implicit("停止并保存斗兽记录"), default(Vector2)))
		{
			plugin.ArenaRecording.Stop();
		}
		ImGui.TextWrapped(ImU8String.op_Implicit(plugin.ArenaRecording.Status));
		ImGui.TextWrapped(ImU8String.op_Implicit(plugin.Notice));
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("怪物 ID 查询"), (ImGuiTreeNodeFlags)0))
		{
			DrawMonsterLookup();
		}
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("目标数据"), (ImGuiTreeNodeFlags)0))
		{
			MonsterEntry monsterEntry = plugin.Catalog.Monsters.Single((MonsterEntry m) => m.Number == plugin.SelectedMonster);
			ImU8String val2 = default(ImU8String);
			((ImU8String)(ref val2))._002Ector(15, 4);
			((ImU8String)(ref val2)).AppendLiteral("#");
			((ImU8String)(ref val2)).AppendFormatted<int>(monsterEntry.Number, "00");
			((ImU8String)(ref val2)).AppendLiteral(" ");
			((ImU8String)(ref val2)).AppendFormatted<string>(monsterEntry.SpeciesName ?? monsterEntry.Name);
			((ImU8String)(ref val2)).AppendLiteral(" → ");
			((ImU8String)(ref val2)).AppendFormatted<string>(monsterEntry.Name);
			((ImU8String)(ref val2)).AppendLiteral(" · NameId ");
			((ImU8String)(ref val2)).AppendFormatted<string>(string.Join(", ", monsterEntry.NameIds));
			ImGui.TextWrapped(val2);
			if (monsterEntry.Note != null)
			{
				ImGui.TextWrapped(ImU8String.op_Implicit(monsterEntry.Note));
			}
			ImGui.TextWrapped(ImU8String.op_Implicit(plugin.Notebook.Status));
			ImGui.TextWrapped(ImU8String.op_Implicit(plugin.CombatStatus));
		}
		if (ImGui.CollapsingHeader(ImU8String.op_Implicit("插件状态"), (ImGuiTreeNodeFlags)0))
		{
			foreach (IntegrationStatus status in integrations.Statuses)
			{
				ImU8String val3 = new ImU8String(3, 2);
				((ImU8String)(ref val3)).AppendFormatted<string>(status.Name);
				((ImU8String)(ref val3)).AppendLiteral(" · ");
				((ImU8String)(ref val3)).AppendFormatted<string>(status.Detail);
				ImGui.TextWrapped(val3);
			}
		}
		if (!ImGui.CollapsingHeader(ImU8String.op_Implicit("运行日志"), (ImGuiTreeNodeFlags)0))
		{
			return;
		}
		foreach (RunEvent item in runner.History.Reverse())
		{
			ImU8String val4 = new ImU8String(1, 2);
			((ImU8String)(ref val4)).AppendFormatted<DateTimeOffset>(item.At.ToLocalTime(), "HH:mm:ss");
			((ImU8String)(ref val4)).AppendLiteral(" ");
			((ImU8String)(ref val4)).AppendFormatted<string>(item.Message);
			ImGui.TextWrapped(val4);
		}
	}

	private void DrawMonsterLookup()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_020f: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_02f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0324: Unknown result type (might be due to invalid IL or missing references)
		//IL_033a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0350: Unknown result type (might be due to invalid IL or missing references)
		//IL_03b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_044a: Unknown result type (might be due to invalid IL or missing references)
		ImGui.SetNextItemWidth(230f);
		bool flag = ImGui.InputTextWithHint(ImU8String.op_Implicit("##monsterQuery"), ImU8String.op_Implicit("名称或 NameId"), ref monsterQuery, 100, (ImGuiInputTextFlags)32, (ImGuiInputTextCallbackDelegate)null);
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("查询"), default(Vector2)) || flag)
		{
			SearchMonsters();
		}
		ImGui.SameLine();
		if (ImGui.Button(ImU8String.op_Implicit("查图鉴名称"), default(Vector2)))
		{
			MonsterEntry monsterEntry = plugin.Catalog.Monsters.Single((MonsterEntry m) => m.Number == plugin.SelectedMonster);
			monsterQuery = monsterEntry.SpeciesName ?? monsterEntry.Name;
			SearchMonsters();
		}
		LiveMonsterIdentity liveMonsterIdentity = plugin.MonsterData.ReadCurrentTarget();
		if ((object)liveMonsterIdentity != null)
		{
			ImU8String val = default(ImU8String);
			((ImU8String)(ref val))._002Ector(29, 4);
			((ImU8String)(ref val)).AppendLiteral("游戏目标：");
			((ImU8String)(ref val)).AppendFormatted<string>(liveMonsterIdentity.Name);
			((ImU8String)(ref val)).AppendLiteral(" Lv.");
			((ImU8String)(ref val)).AppendFormatted<byte>(liveMonsterIdentity.Level);
			((ImU8String)(ref val)).AppendLiteral(" · NameId ");
			((ImU8String)(ref val)).AppendFormatted<uint>(liveMonsterIdentity.NameId);
			((ImU8String)(ref val)).AppendLiteral(" · BaseId ");
			((ImU8String)(ref val)).AppendFormatted<uint>(liveMonsterIdentity.BaseId);
			ImGui.TextUnformatted(val);
			if (ImGui.SmallButton(ImU8String.op_Implicit("复制目标 ID")))
			{
				ImU8String clipboardText = default(ImU8String);
				((ImU8String)(ref clipboardText))._002Ector(51, 7);
				((ImU8String)(ref clipboardText)).AppendFormatted<string>(liveMonsterIdentity.Name);
				((ImU8String)(ref clipboardText)).AppendLiteral(" | BNpcName=");
				((ImU8String)(ref clipboardText)).AppendFormatted<uint>(liveMonsterIdentity.NameId);
				((ImU8String)(ref clipboardText)).AppendLiteral(" | BNpcBase=");
				((ImU8String)(ref clipboardText)).AppendFormatted<uint>(liveMonsterIdentity.BaseId);
				((ImU8String)(ref clipboardText)).AppendLiteral(" | Territory=");
				((ImU8String)(ref clipboardText)).AppendFormatted<uint>(liveMonsterIdentity.TerritoryId);
				((ImU8String)(ref clipboardText)).AppendLiteral(" | Position=");
				((ImU8String)(ref clipboardText)).AppendFormatted<float>(liveMonsterIdentity.X, "F2");
				((ImU8String)(ref clipboardText)).AppendLiteral(",");
				((ImU8String)(ref clipboardText)).AppendFormatted<float>(liveMonsterIdentity.Y, "F2");
				((ImU8String)(ref clipboardText)).AppendLiteral(",");
				((ImU8String)(ref clipboardText)).AppendFormatted<float>(liveMonsterIdentity.Z, "F2");
				ImGui.SetClipboardText(clipboardText);
			}
		}
		else
		{
			ImGui.TextDisabled(ImU8String.op_Implicit("未选中魔物"));
		}
		if (monsterQueryError.Length > 0)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(monsterQueryError));
		}
		if (monsterMatches == null)
		{
			return;
		}
		ImU8String val2 = default(ImU8String);
		((ImU8String)(ref val2))._002Ector(13, 2);
		((ImU8String)(ref val2)).AppendLiteral("BNpcName · ");
		((ImU8String)(ref val2)).AppendFormatted<int>(monsterMatches.Total);
		((ImU8String)(ref val2)).AppendLiteral(" 项");
		((ImU8String)(ref val2)).AppendFormatted<string>((monsterMatches.Total > monsterMatches.Rows.Length) ? $"，显示前 {monsterMatches.Rows.Length} 项" : "");
		ImGui.TextDisabled(val2);
		if (!ImGui.BeginTable(ImU8String.op_Implicit("MonsterNameLookup"), 3, (ImGuiTableFlags)33556416, new Vector2(0f, 180f), 0f))
		{
			return;
		}
		ImGui.TableSetupColumn(ImU8String.op_Implicit("NameId"), (ImGuiTableColumnFlags)0, 0f, 0u);
		ImGui.TableSetupColumn(ImU8String.op_Implicit("游戏名称"), (ImGuiTableColumnFlags)0, 0f, 0u);
		ImGui.TableSetupColumn(ImU8String.op_Implicit("目录引用"), (ImGuiTableColumnFlags)0, 0f, 0u);
		ImGui.TableSetupScrollFreeze(0, 1);
		ImGui.TableHeadersRow();
		MonsterNameRow[] rows = monsterMatches.Rows;
		foreach (MonsterNameRow row in rows)
		{
			ImGui.TableNextRow();
			ImGui.TableNextColumn();
			ImGui.TextUnformatted(ImU8String.op_Implicit(row.NameId.ToString()));
			ImGui.TableNextColumn();
			ImGui.TextUnformatted(ImU8String.op_Implicit(row.Name));
			ImGui.TableNextColumn();
			IEnumerable<string> values = from m in plugin.Catalog.Monsters
				where ((ReadOnlySpan<uint>)m.NameIds).Contains(row.NameId)
				select $"#{m.Number:00}";
			ImGui.TextUnformatted(ImU8String.op_Implicit(row.IsNotebookCompanion ? "图鉴伙伴行" : string.Join(", ", values)));
		}
		ImGui.EndTable();
	}

	private void SearchMonsters()
	{
		try
		{
			monsterMatches = plugin.MonsterData.Search(monsterQuery);
			monsterQueryError = "";
		}
		catch (Exception ex)
		{
			monsterMatches = null;
			monsterQueryError = "游戏表读取失败：" + ex.Message;
		}
	}
}
