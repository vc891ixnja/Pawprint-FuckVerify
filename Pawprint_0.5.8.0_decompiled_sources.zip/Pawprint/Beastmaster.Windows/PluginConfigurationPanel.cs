using System;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Security;
using Beastmaster.Integrations;
using Dalamud.Bindings.ImGui;
using Dalamud.Interface;
using Dalamud.Plugin;
using Dalamud.Utility;

namespace Beastmaster.Windows;

internal sealed class PluginConfigurationPanel(Plugin plugin, Configuration config, IntegrationHub integrations)
{
	private string notice = "";

	public void Draw()
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_03be: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_041c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0493: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0176: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0250: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_030b: Unknown result type (might be due to invalid IL or missing references)
		if (ImGui.Button(ImU8String.op_Implicit("重新检测"), default(Vector2)))
		{
			integrations.Refresh();
		}
		if (notice.Length > 0)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(notice));
		}
		foreach (DependencyStatus item in integrations.Dependencies.Where(delegate(DependencyStatus d)
		{
			string name = d.Name;
			return (name == "Lifestream" || name == "vnavmesh") ? true : false;
		}))
		{
			ImGui.Separator();
			DrawDependency(item);
		}
		ImGui.Separator();
		int num = config.CombatBackend switch
		{
			CombatBackend.BuiltIn => 1, 
			CombatBackend.PromeRotation => 2, 
			_ => 0, 
		};
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo(ImU8String.op_Implicit("战斗插件"), ref num, ImU8String.op_Implicit("无\0内置简单战斗\0PR · XSZYYS ACR\0"), -1))
		{
			Plugin plugin = plugin;
			plugin.SetCombatBackend(num switch
			{
				1 => CombatBackend.BuiltIn, 
				2 => CombatBackend.PromeRotation, 
				_ => CombatBackend.None, 
			});
			integrations.Refresh();
		}
		if (config.CombatBackend == CombatBackend.PromeRotation)
		{
			DrawSelectedDependency("PromeRotation");
		}
		ImGui.Separator();
		int fieldDodge = (int)config.FieldDodge;
		ImGui.SetNextItemWidth(230f);
		if (ImGui.Combo(ImU8String.op_Implicit("野外躲避"), ref fieldDodge, ImU8String.op_Implicit("无\0BossMod\0BossModReborn\0"), -1))
		{
			plugin.StopTask("野外躲避设置已变更");
			config.FieldDodge = (FieldDodgeBackend)fieldDodge;
			plugin.Save();
			integrations.Refresh();
		}
		if (config.FieldDodge != FieldDodgeBackend.None)
		{
			DrawSelectedDependency(config.FieldDodge.ToString());
		}
		ImGui.Separator();
		bool enableAutoDuty = config.EnableAutoDuty;
		if (ImGui.Checkbox(ImU8String.op_Implicit("副本捕获（AutoDuty）"), ref enableAutoDuty))
		{
			plugin.StopTask("副本捕猎设置已变更");
			config.EnableAutoDuty = enableAutoDuty;
			plugin.Save();
		}
		DrawSelectedDependency("AutoDuty");
		ImGui.Separator();
		bool autoLevelWhenNeeded = config.AutoLevelWhenNeeded;
		if (ImGui.Checkbox(ImU8String.op_Implicit("单只捕获时自动练级"), ref autoLevelWhenNeeded))
		{
			plugin.StopTask("练级设置已变更");
			config.AutoLevelWhenNeeded = autoLevelWhenNeeded;
			plugin.Save();
		}
		if (!config.SetupCompleted && integrations.RequiredReady)
		{
			config.SetupCompleted = true;
			plugin.Save();
		}
		ImGui.Separator();
		ImGui.TextUnformatted(ImU8String.op_Implicit("斗兽奇弈需要 Omni Verification"));
		ImGui.TextWrapped(ImU8String.op_Implicit(plugin.ArenaAuthorizationStatus));
		if (ImGui.Button(ImU8String.op_Implicit("认证 / 重新认证 OMNI"), default(Vector2)))
		{
			plugin.RefreshArenaAuthorization();
		}
		if (ImGui.Button(ImU8String.op_Implicit("打开 Omni Discord"), default(Vector2)))
		{
			try
			{
				Util.OpenLink("https://discord.gg/DFhmp7zzrz");
				notice = "";
			}
			catch (Exception ex)
			{
				notice = "打开 Omni Discord 失败：" + ex.Message;
			}
		}
		plugin.UpdateActivation(delegate(string ticket)
		{
			//IL_0001: Unknown result type (might be due to invalid IL or missing references)
			ImGui.SetClipboardText(ImU8String.op_Implicit(ticket));
		});
		ImGui.BeginDisabled(plugin.Activation.Busy);
		if (ImGui.Button(ImU8String.op_Implicit("生成并复制机器凭证"), default(Vector2)))
		{
			plugin.BeginActivation(ArenaCredentialKind.Machine);
		}
		if (ImGui.Button(ImU8String.op_Implicit("生成并复制账号凭证"), default(Vector2)))
		{
			plugin.BeginActivation(ArenaCredentialKind.Account);
		}
		ImGui.EndDisabled();
		ImGui.TextUnformatted(ImU8String.op_Implicit("一次性凭证 · 签发后 30 秒有效"));
		if (plugin.Activation.Message.Length > 0)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(plugin.Activation.Message));
		}
		DateTimeOffset? expiresAt = plugin.Activation.ExpiresAt;
		if (expiresAt.HasValue)
		{
			DateTimeOffset valueOrDefault = expiresAt.GetValueOrDefault();
			ImU8String val = default(ImU8String);
			((ImU8String)(ref val))._002Ector(5, 1);
			((ImU8String)(ref val)).AppendLiteral("剩余 ");
			((ImU8String)(ref val)).AppendFormatted<int>(Math.Max(0, (int)Math.Ceiling((valueOrDefault - DateTimeOffset.UtcNow).TotalSeconds)));
			((ImU8String)(ref val)).AppendLiteral(" 秒");
			ImGui.TextUnformatted(val);
		}
	}

	private void DrawSelectedDependency(string name)
	{
		DependencyStatus dependencyStatus = integrations.Dependencies.FirstOrDefault((DependencyStatus d) => d.Name == name);
		if (dependencyStatus != null)
		{
			DrawDependency(dependencyStatus);
		}
	}

	private void DrawDependency(DependencyStatus dependency)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0149: Unknown result type (might be due to invalid IL or missing references)
		ImGui.PushID(ImU8String.op_Implicit(dependency.Name));
		Vector4 vector = (dependency.Ready ? new Vector4(0.4f, 0.85f, 0.55f, 1f) : new Vector4(1f, 0.7f, 0.35f, 1f));
		ImU8String val = default(ImU8String);
		((ImU8String)(ref val))._002Ector(6, 3);
		((ImU8String)(ref val)).AppendFormatted<string>(dependency.Name);
		((ImU8String)(ref val)).AppendLiteral(" · ");
		((ImU8String)(ref val)).AppendFormatted<string>(dependency.Required ? "必需" : "按需");
		((ImU8String)(ref val)).AppendLiteral(" · ");
		((ImU8String)(ref val)).AppendFormatted<string>(dependency.Ready ? "已就绪" : (dependency.ProbeFailed ? "检测失败" : "待配置"));
		ImGui.TextColored(ref vector, val);
		if (!dependency.Ready)
		{
			ImGui.TextWrapped(ImU8String.op_Implicit(dependency.Detail));
		}
		if (ImGui.Button(ImU8String.op_Implicit("打开插件安装器"), default(Vector2)))
		{
			Services.PluginInterface.OpenPluginInstallerTo((PluginInstallerOpenKind)1, dependency.Name);
		}
		ImGui.SameLine();
		IExposedPlugin val2 = IntegrationHub.FindInstalledPlugin(dependency.Name);
		ImGui.BeginDisabled(val2 == null || !val2.IsLoaded || (!val2.HasConfigUi && !val2.HasMainUi));
		if (ImGui.Button(ImU8String.op_Implicit("打开设置"), default(Vector2)))
		{
			try
			{
				if (val2.HasConfigUi)
				{
					val2.OpenConfigUi();
				}
				else
				{
					val2.OpenMainUi();
				}
				notice = "";
			}
			catch (Exception ex)
			{
				notice = "打开 " + dependency.Name + " 设置失败：" + ex.Message;
			}
		}
		ImGui.EndDisabled();
		ImGui.PopID();
	}
}
