using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.Event;
using FFXIVClientStructs.FFXIV.Client.Game.InstanceContent;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Client.UI.Misc;

namespace Beastmaster.Arena;

internal static class ArenaItemDispatch
{
	private const string UseStatusSignature = "48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 41 8B F8 48 8B D9 83 FA 0A 0F 83 ?? ?? ?? ?? 8B C2 48 8D 14 40 48 8D 34 91 0F B7 86 84 23 00 00";

	private const string RefreshMappingSignature = "48 89 5C 24 18 57 48 83 EC 30 48 8B D9 E8 ?? ?? ?? ?? 48 8B C8 E8 ?? ?? ?? ?? 48 8B F8 48 85 C0 0F 84 ?? ?? ?? ?? 48 89 6C 24 40 33 ED";

	private static readonly object Gate = new object();

	private static bool scanned;

	private static string? fault;

	private unsafe static delegate* unmanaged<byte*, uint, byte, uint> getUseStatus;

	private unsafe static delegate* unmanaged<byte*, void> refreshMapping;

	private static long nextLogAt;

	private static long nextRuleLogAt;

	internal static string? LastDeny { get; private set; }

	public static uint TargetCheckAction(uint itemId)
	{
		switch (itemId)
		{
		case 76u:
		case 77u:
		case 78u:
		case 79u:
		case 80u:
		case 81u:
		case 82u:
		case 83u:
		case 84u:
		case 85u:
		case 86u:
		case 87u:
		case 88u:
		case 89u:
		case 90u:
		case 91u:
		case 92u:
		case 93u:
		case 94u:
		case 95u:
		case 96u:
		case 97u:
		case 98u:
		case 99u:
		case 100u:
		case 101u:
		case 102u:
		case 103u:
		case 104u:
			return 46959 + itemId - 76;
		case 105u:
		case 106u:
		case 107u:
		case 108u:
		case 109u:
		case 110u:
		case 111u:
		case 112u:
		case 113u:
			return 46987 + (itemId - 104) / 2;
		case 114u:
		case 115u:
		case 116u:
		case 117u:
		case 118u:
		case 119u:
		case 120u:
		case 121u:
		case 122u:
		case 123u:
		case 124u:
		case 125u:
		case 126u:
		case 127u:
		case 128u:
		case 129u:
		case 130u:
		case 131u:
		case 132u:
		case 133u:
		case 134u:
		case 135u:
		case 136u:
		case 137u:
		case 138u:
		case 139u:
		case 140u:
		case 141u:
			return 46992 + itemId - 114;
		default:
			return 0u;
		}
	}

	private unsafe static bool Initialize()
	{
		lock (Gate)
		{
			if (scanned)
			{
				return fault == null;
			}
			scanned = true;
			try
			{
				getUseStatus = (delegate* unmanaged<byte*, uint, byte, uint>)Services.SigScanner.ScanText("48 89 5C 24 08 48 89 74 24 10 57 48 83 EC 20 41 8B F8 48 8B D9 83 FA 0A 0F 83 ?? ?? ?? ?? 8B C2 48 8D 14 40 48 8D 34 91 0F B7 86 84 23 00 00");
				refreshMapping = (delegate* unmanaged<byte*, void>)Services.SigScanner.ScanText("48 89 5C 24 18 57 48 83 EC 30 48 8B D9 E8 ?? ?? ?? ?? 48 8B C8 E8 ?? ?? ?? ?? 48 8B F8 48 85 C0 0F 84 ?? ?? ?? ?? 48 89 6C 24 40 33 ED");
			}
			catch (Exception ex)
			{
				fault = ex.Message;
			}
			if (fault != null)
			{
				Services.Log.Warning("Arena item native init failed: " + fault, Array.Empty<object>());
			}
			return fault == null;
		}
	}

	private static void Diagnose(string gate)
	{
		LastDeny = gate;
		if (Environment.TickCount64 >= nextLogAt)
		{
			nextLogAt = Environment.TickCount64 + 2000;
			Services.Log.Information("Arena item gate: " + gate, Array.Empty<object>());
			Trace("gate: " + gate);
		}
	}

	internal static void Trace(string message)
	{
		if (message.StartsWith("rule ", StringComparison.Ordinal) && Environment.TickCount64 >= nextRuleLogAt)
		{
			nextRuleLogAt = Environment.TickCount64 + 5000;
			Services.Log.Information("Arena rule: " + message, Array.Empty<object>());
		}
		try
		{
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			File.AppendAllText(Path.Combine(text, "arena-item-gates.jsonl"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Message = message
			}) + "\n");
		}
		catch
		{
		}
	}

	private unsafe static byte* GetDirector()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Invalid comparison between Unknown and I4
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null || ((IGameObject)localPlayer).IsDead || ((ICharacter)localPlayer).ClassJob.RowId != 43)
		{
			return null;
		}
		ICondition condition = Services.Condition;
		if (condition[(ConditionFlag)45] || condition[(ConditionFlag)51])
		{
			return null;
		}
		EventFramework* ptr = EventFramework.Instance();
		if (ptr == null)
		{
			return null;
		}
		InstanceContentDirector* instanceContentDirector = ((EventFramework)ptr).GetInstanceContentDirector();
		if (instanceContentDirector != null && (int)((InstanceContentDirector)instanceContentDirector).InstanceContentType == 22)
		{
			return (byte*)instanceContentDirector;
		}
		return null;
	}

	private unsafe static byte* GetAgent()
	{
		AgentModule* ptr = AgentModule.Instance();
		if (ptr != null)
		{
			return (byte*)((AgentModule)ptr).GetAgentByInternalId((AgentId)497);
		}
		return null;
	}

	private unsafe static bool TryReadDisplaySlot(byte* agent, byte* director, int display, out uint inventory, out ushort itemId)
	{
		inventory = 10u;
		itemId = 0;
		if (agent == null || director == null || (uint)display >= 10u)
		{
			return false;
		}
		byte* ptr = agent + 80 + display * 8;
		inventory = *(uint*)ptr;
		itemId = ((ushort*)ptr)[2];
		if (inventory >= 10 || itemId == 0)
		{
			return false;
		}
		return *(ushort*)(director + 9092 + inventory * 12) == itemId;
	}

	internal unsafe static List<uint>? ReadOwnedItems()
	{
		byte* director = GetDirector();
		if (director == null)
		{
			return null;
		}
		List<uint> list = new List<uint>(10);
		for (int i = 0; i < 10; i++)
		{
			ushort num = *(ushort*)(director + 9092 + i * 12);
			if (num != 0)
			{
				list.Add(num);
			}
		}
		return list;
	}

	public unsafe static bool TryUse(int displaySlot, uint itemId, ulong targetGameObjectId, bool fallbackToSelf, bool selfOnly)
	{
		//IL_0326: Unknown result type (might be due to invalid IL or missing references)
		//IL_0330: Unknown result type (might be due to invalid IL or missing references)
		//IL_033d: Unknown result type (might be due to invalid IL or missing references)
		//IL_033f: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a9: Unknown result type (might be due to invalid IL or missing references)
		LastDeny = null;
		if ((uint)displaySlot >= 10u)
		{
			return false;
		}
		if (!Initialize())
		{
			Diagnose("native init failed: " + fault);
			return false;
		}
		byte* director = GetDirector();
		byte* agent = GetAgent();
		if (director == null || agent == null)
		{
			Diagnose("no director/agent (not in crucible?)");
			return false;
		}
		if (!TryReadDisplaySlot(agent, director, displaySlot, out var inventory, out var itemId2) || itemId2 != itemId)
		{
			refreshMapping(agent);
			if (!TryReadDisplaySlot(agent, director, displaySlot, out inventory, out itemId2) || itemId2 != itemId)
			{
				Diagnose($"mapping mismatch slot={displaySlot} expected={itemId} mapped={itemId2}");
				return false;
			}
		}
		if (getUseStatus(director, inventory, 0) != 0)
		{
			Diagnose($"use status denied item={itemId} inventory={inventory}");
			return false;
		}
		ActionManager* ptr = ActionManager.Instance();
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		RaptureHotbarModule* ptr2 = RaptureHotbarModule.Instance();
		TargetSystem* ptr3 = TargetSystem.Instance();
		if (ptr == null || ptr2 == null || ptr3 == null || localPlayer == null)
		{
			Diagnose("null manager/hotbar/targets/local");
			return false;
		}
		if (((ActionManager)ptr).AnimationLock > 0f)
		{
			Diagnose("animation lock");
			return false;
		}
		GameObject* address = (GameObject*)((IGameObject)localPlayer).Address;
		GameObject* ptr4 = null;
		if (targetGameObjectId != 0L)
		{
			foreach (IGameObject item in (IEnumerable<IGameObject>)Services.Objects)
			{
				if (item.GameObjectId == targetGameObjectId)
				{
					ptr4 = (GameObject*)item.Address;
					break;
				}
			}
		}
		GameObject* ptr5;
		if (itemId - 142 <= 1)
		{
			ptr5 = (selfOnly ? address : null);
		}
		else
		{
			uint num = TargetCheckAction(itemId);
			bool num2 = num != 0 && ptr4 != null && ActionManager.CanUseActionOnTarget(num, ptr4) && ActionManager.GetActionInRangeOrLoS(num, address, ptr4) == 0;
			bool flag = fallbackToSelf && num != 0 && ActionManager.CanUseActionOnTarget(num, address) && ActionManager.GetActionInRangeOrLoS(num, address, address) == 0;
			ptr5 = (num2 ? ptr4 : (flag ? address : null));
		}
		if (ptr5 == null)
		{
			string value = ((ptr4 != null) ? $", name={((GameObject)ptr4).NameString}, kind={((GameObject)ptr4).ObjectKind}" : "");
			Diagnose($"no valid target item={itemId} action={TargetCheckAction(itemId)} requested={ptr4:X}{value}");
			return false;
		}
		HotbarSlot val = new HotbarSlot
		{
			CommandType = (HotbarSlotType)36,
			CommandId = (uint)displaySlot
		};
		GameObject* softTarget = ((TargetSystem)ptr3).SoftTarget;
		try
		{
			((TargetSystem)ptr3).SoftTarget = ptr5;
			((RaptureHotbarModule)ptr2).ExecuteSlot(&val);
			Services.Log.Information($"Arena item: dispatched slot {displaySlot}, item {itemId}, target {ptr5:X}, inventory {inventory}", Array.Empty<object>());
			Trace($"dispatched slot {displaySlot}, item {itemId}, target {ptr5:X}, inventory {inventory}");
			return true;
		}
		finally
		{
			((TargetSystem)ptr3).SoftTarget = softTarget;
		}
	}
}
