using System;
using Beastmaster.Core.Arena;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal static class ArenaUtilityUi
{
	internal unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	internal unsafe static ArenaValue[] Values(AtkUnitBase* a)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Expected I4, but got Unknown
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Invalid comparison between Unknown and I4
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e4: Invalid comparison between Unknown and I4
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		bool flag = a == null || !((AtkUnitBase)a).IsReady || ((AtkUnitBase)a).AtkValues == null;
		if (!flag)
		{
			ushort atkValuesCount = ((AtkUnitBase)a).AtkValuesCount;
			bool flag2 = ((atkValuesCount < 1 || atkValuesCount > 4096) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return Array.Empty<ArenaValue>();
		}
		ArenaValue[] array = new ArenaValue[((AtkUnitBase)a).AtkValuesCount];
		for (int i = 0; i < array.Length; i++)
		{
			AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[i];
			AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
			long? number = (val2 - 2) switch
			{
				3 => val.UInt, 
				1 => val.Int, 
				0 => val.Bool ? 1 : 0, 
				_ => null, 
			};
			flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
			object obj;
			if (!flag || val.String.Value == null)
			{
				obj = null;
			}
			else
			{
				ReadOnlySeStringSpan val3 = new ReadOnlySeStringSpan(val.String.Value);
				obj = ((ReadOnlySeStringSpan)(ref val3)).ExtractText();
			}
			string text = (string)obj;
			array[i] = new ArenaValue(i, number, text);
		}
		return array;
	}

	internal unsafe static bool ClickButton(AtkUnitBase* a, uint node, uint parameter)
	{
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0111: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Invalid comparison between Unknown and I4
		if (a == null || !((AtkUnitBase)a).IsReady)
		{
			return false;
		}
		AtkComponentButton* componentButtonById = ((AtkUnitBase)a).GetComponentButtonById(node);
		if (componentButtonById == null || !((AtkComponentButton)componentButtonById).IsEnabled || ((AtkComponentButton)componentButtonById).OwnerNode == null || !((AtkComponentNode)((AtkComponentButton)componentButtonById).OwnerNode).IsVisible())
		{
			return false;
		}
		AtkEvent* ptr = null;
		AtkEvent* ptr2 = ((AtkEventManager)(&((AtkComponentNode)((AtkComponentButton)componentButtonById).OwnerNode).AtkEventManager)).Event;
		int num = 0;
		while (ptr2 != null && num < 64)
		{
			if (((AtkEvent)ptr2).Listener == a && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 25 && ((AtkEvent)ptr2).Param == parameter)
			{
				if (ptr != null)
				{
					throw new InvalidOperationException("斗兽按钮事件不唯一");
				}
				ptr = ptr2;
			}
			num++;
			ptr2 = ((AtkEvent)ptr2).NextEvent;
		}
		if (ptr == null)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"arena/button/{a}/{node}/{parameter}"))
		{
			return false;
		}
		AtkEvent val = *ptr;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr).Listener).ReceiveEvent((AtkEventType)25, (int)parameter, &val, &val2);
		return true;
	}

	internal unsafe static bool ClickButtonText(AtkUnitBase* a, string text)
	{
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || !((AtkUnitBase)a).IsReady)
		{
			return false;
		}
		AtkComponentButton* ptr = FindButtonByText(a, &((AtkUnitBase)a).UldManager, text, 0);
		if (ptr == null || !((AtkComponentButton)ptr).IsEnabled || ((AtkComponentButton)ptr).OwnerNode == null || !((AtkComponentNode)((AtkComponentButton)ptr).OwnerNode).IsVisible())
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"arena/text/{a}/{text}"))
		{
			return false;
		}
		AtkEvent val = default(AtkEvent);
		AtkEventData val2 = default(AtkEventData);
		((AtkComponentButton)ptr).ReceiveEvent((AtkEventType)25, 0, &val, &val2);
		return true;
	}

	private unsafe static AtkComponentButton* FindButtonByText(AtkUnitBase* a, AtkUldManager* manager, string text, int depth)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Invalid comparison between Unknown and I4
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Invalid comparison between Unknown and I4
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return null;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !((AtkResNode)ptr).IsVisible())
			{
				continue;
			}
			if ((int)((AtkResNode)ptr).Type == 10000 && (int)((AtkComponentBase)((AtkComponentNode)ptr).Component).GetComponentType() == 1)
			{
				AtkComponentButton* component = (AtkComponentButton*)((AtkComponentNode)ptr).Component;
				if (component != null && ((AtkComponentButton)component).ButtonTextNode != null)
				{
					ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)((AtkComponentButton)component).ButtonTextNode).NodeText)).StringPtr));
					if (((ReadOnlySeStringSpan)(ref val)).ExtractText().Trim() == text)
					{
						return component;
					}
				}
			}
			if ((int)((AtkResNode)ptr).Type < 1000)
			{
				continue;
			}
			AtkComponentBase* component2 = ((AtkComponentNode)ptr).Component;
			if (component2 != null)
			{
				AtkComponentButton* ptr2 = FindButtonByText(a, &((AtkComponentBase)component2).UldManager, text, depth + 1);
				if (ptr2 != null)
				{
					return ptr2;
				}
			}
		}
		return null;
	}

	internal unsafe static bool ClickRegistered(AtkUnitBase* a, uint parameter)
	{
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || !((AtkUnitBase)a).IsReady)
		{
			return false;
		}
		AtkEvent* ptr = FindRegistered(a, &((AtkUnitBase)a).UldManager, parameter, null, 0);
		if (ptr == null || !UiInteractionDelay.Ready($"arena/registered/{a}/{parameter}"))
		{
			return false;
		}
		AtkEvent val = *ptr;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr).Listener).ReceiveEvent((AtkEventType)25, (int)parameter, &val, &val2);
		return true;
	}

	private unsafe static AtkEvent* FindRegistered(AtkUnitBase* a, AtkUldManager* manager, uint parameter, AtkEvent* found, int depth)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Invalid comparison between Unknown and I4
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Invalid comparison between Unknown and I4
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return found;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !((AtkResNode)ptr).IsVisible() || !((Enum)((AtkResNode)ptr).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32))
			{
				continue;
			}
			AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)ptr).AtkEventManager)).Event;
			int num = 0;
			while (ptr2 != null && num < 64)
			{
				if (((AtkEvent)ptr2).Listener == a && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 25 && ((AtkEvent)ptr2).Param == parameter)
				{
					if (found != null)
					{
						throw new InvalidOperationException("奖励按钮事件不唯一");
					}
					found = ptr2;
				}
				num++;
				ptr2 = ((AtkEvent)ptr2).NextEvent;
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
				if (component != null)
				{
					found = FindRegistered(a, &((AtkComponentBase)component).UldManager, parameter, found, depth + 1);
				}
			}
		}
		return found;
	}
}
