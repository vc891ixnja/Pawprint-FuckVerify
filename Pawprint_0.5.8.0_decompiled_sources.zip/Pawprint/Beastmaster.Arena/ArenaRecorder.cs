using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using Beastmaster.Core.Diagnostics;
using Dalamud.Game.Addon.Lifecycle;
using Dalamud.Game.Addon.Lifecycle.AddonArgTypes;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Enums;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.ClientState.Statuses;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;

namespace Beastmaster.Arena;

internal sealed class ArenaRecorder : IDisposable
{
	private sealed record EventPacket(string Kind, DateTimeOffset At, string Addon, object? Input, object[] Values);

	private ArenaTraceWriter? writer;

	private long nextSnapshot;

	private long droppedEvents;

	private ulong character;

	private readonly Queue<EventPacket> events = new Queue<EventPacket>();

	private readonly HashSet<string> observedAddons = new HashSet<string>();

	private ArenaProtocolRecorder? protocol;

	private readonly ConcurrentQueue<(string Kind, DateTimeOffset At, object Data)> protocolEvents = new ConcurrentQueue<(string, DateTimeOffset, object)>();

	private long droppedProtocolEvents;

	public bool IsRecording => writer != null;

	public string Status { get; private set; } = "尚未记录斗兽流程";

	public string? FilePath { get; private set; }

	public ArenaRecorder()
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Expected O, but got Unknown
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Expected O, but got Unknown
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Expected O, but got Unknown
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Expected O, but got Unknown
		Services.AddonLifecycle.RegisterListener((AddonEvent)11, new AddonEventDelegate(OnEvent));
		Services.AddonLifecycle.RegisterListener((AddonEvent)12, new AddonEventDelegate(OnEvent));
		Services.AddonLifecycle.RegisterListener((AddonEvent)1, new AddonEventDelegate(OnEvent));
		Services.AddonLifecycle.RegisterListener((AddonEvent)6, new AddonEventDelegate(OnEvent));
	}

	public void Start(string gameVersion)
	{
		if (!IsRecording)
		{
			if (!Services.ClientState.IsLoggedIn || Services.PlayerState.ContentId == 0L)
			{
				throw new InvalidOperationException("请先登录角色");
			}
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			FilePath = Path.Combine(text, $"xbm-arena-{DateTime.Now:yyyyMMdd-HHmmss-fff}-{Guid.NewGuid():N}");
			writer = new ArenaTraceWriter(FilePath, 67108864L);
			character = Services.PlayerState.ContentId;
			nextSnapshot = 0L;
			droppedEvents = 0L;
			events.Clear();
			observedAddons.Clear();
			writer.Record("Session", new
			{
				Schema = 2,
				GameVersion = gameVersion,
				FFCS = typeof(AtkUnitBase).Assembly.GetName().Version?.ToString(),
				Plugin = typeof(ArenaRecorder).Assembly.GetName().Version?.ToString()
			});
			protocolEvents.Clear();
			droppedProtocolEvents = 0L;
			protocol = new ArenaProtocolRecorder(RecordProtocol);
			protocol.Start();
			writer.Flush();
			Status = "正在记录斗兽流程";
		}
	}

	public void Stop(string reason = "记录已保存")
	{
		if (writer != null)
		{
			ArenaTraceWriter arenaTraceWriter = writer;
			protocol?.Dispose();
			protocol = null;
			try
			{
				DrainEvents();
				arenaTraceWriter.Record("End", new
				{
					Reason = reason
				});
				arenaTraceWriter.Flush();
			}
			finally
			{
				writer = null;
				arenaTraceWriter.Dispose();
				events.Clear();
			}
			Status = reason + "：" + FilePath;
		}
	}

	private void DrainEvents()
	{
		if (writer != null)
		{
			EventPacket result;
			while (events.TryDequeue(out result))
			{
				long valuesState = writer.State(result.Addon + "/values", result.Values);
				writer.Record("Event", new
				{
					Kind = result.Kind,
					ObservedAt = result.At,
					Addon = result.Addon,
					Input = result.Input,
					ValuesState = valuesState
				});
			}
			if (droppedEvents > 0)
			{
				writer.Record("Gap", new
				{
					DroppedEvents = droppedEvents,
					Reason = "Event queue overflow; following snapshots resynchronize state"
				});
				droppedEvents = 0L;
			}
			(string, DateTimeOffset, object) result2;
			while (protocolEvents.TryDequeue(out result2))
			{
				writer.Record(result2.Item1, new
				{
					ObservedAt = result2.Item2,
					Payload = result2.Item3
				});
			}
			long num = Interlocked.Exchange(ref droppedProtocolEvents, 0L);
			if (num > 0)
			{
				writer.Record("Gap", new
				{
					DroppedEvents = num,
					Reason = "Protocol queue overflow"
				});
			}
		}
	}

	private void RecordProtocol(string kind, object data)
	{
		if (protocolEvents.Count >= 512)
		{
			Interlocked.Increment(ref droppedProtocolEvents);
		}
		else
		{
			protocolEvents.Enqueue((kind, DateTimeOffset.UtcNow, data));
		}
	}

	private unsafe void OnEvent(AddonEvent kind, AddonArgs args)
	{
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Expected I4, but got Unknown
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Expected I4, but got Unknown
		if (!IsRecording || Services.PlayerState.ContentId != character || !Relevant(args.AddonName))
		{
			return;
		}
		try
		{
			observedAddons.Add(args.AddonName);
			object input = null;
			AddonReceiveEventArgs e = (AddonReceiveEventArgs)(object)((args is AddonReceiveEventArgs) ? args : null);
			if (e != null)
			{
				AtkEvent* atkEvent = (AtkEvent*)e.AtkEvent;
				AtkEventData* atkEventData = (AtkEventData*)e.AtkEventData;
				bool flag = atkEventData != null;
				if (flag)
				{
					byte b = (byte)(int)e.AtkEventType;
					bool flag2 = (((uint)(b - 35) <= 1u || b == 38) ? true : false);
					flag = flag2;
				}
				int? selectedIndex = (flag ? new int?(((AtkListItemData)(&((AtkEventData)atkEventData).ListItemData)).SelectedIndex) : ((int?)null));
				input = new
				{
					Type = (byte)(int)e.AtkEventType,
					Parameter = e.EventParam,
					NodeId = ((atkEvent != null && ((AtkEvent)atkEvent).Node != null) ? ((AtkResNode)((AtkEvent)atkEvent).Node).NodeId : 0u),
					SelectedIndex = selectedIndex,
					MouseButton = ((selectedIndex.HasValue && atkEventData != null) ? new byte?(((AtkListItemData)(&((AtkEventData)atkEventData).ListItemData)).MouseButtonId) : ((byte?)null))
				};
			}
			if (events.Count >= 512)
			{
				droppedEvents++;
			}
			else
			{
				events.Enqueue(new EventPacket(((object)(*(AddonEvent*)(&kind))/*cast due to .constrained prefix*/).ToString(), DateTimeOffset.UtcNow, args.AddonName, input, ReadValues((AtkUnitBase*)args.Addon.Address)));
			}
		}
		catch (Exception error)
		{
			Abort(error);
		}
	}

	internal static bool Relevant(string name)
	{
		bool flag = name.StartsWith("XBM", StringComparison.Ordinal);
		if (!flag)
		{
			bool flag2;
			switch (name)
			{
			case "SelectYesno":
			case "SelectString":
			case "SelectIconString":
			case "Talk":
			case "ContextMenu":
				flag2 = true;
				break;
			default:
				flag2 = false;
				break;
			}
			flag = flag2;
		}
		return flag;
	}

	public unsafe void Update()
	{
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_021c: Unknown result type (might be due to invalid IL or missing references)
		if (!IsRecording)
		{
			return;
		}
		try
		{
			if (!Services.ClientState.IsLoggedIn || Services.PlayerState.ContentId != character)
			{
				Stop("角色变化，记录已保存");
				return;
			}
			ArenaProtocolRecorder? arenaProtocolRecorder = protocol;
			if (arenaProtocolRecorder != null)
			{
				int inArena;
				if (GameMain.Instance() != null)
				{
					ushort currentContentFinderConditionId = ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId;
					inArena = ((currentContentFinderConditionId >= 1088 && currentContentFinderConditionId <= 1092) ? 1 : 0);
				}
				else
				{
					inArena = 0;
				}
				arenaProtocolRecorder.SetInArena((byte)inArena != 0);
			}
			DrainEvents();
			ArenaTraceWriter arenaTraceWriter = writer;
			if (arenaTraceWriter == null || Environment.TickCount64 < nextSnapshot)
			{
				return;
			}
			nextSnapshot = Environment.TickCount64 + 1000;
			List<object> list = new List<object>();
			RaptureAtkUnitManager* ptr = RaptureAtkUnitManager.Instance();
			if (ptr != null)
			{
				AtkUnitList* ptr2 = &((RaptureAtkUnitManager)ptr).AllLoadedUnitsList;
				for (int i = 0; i < Math.Min((int)((AtkUnitList)ptr2).Count, 256); i++)
				{
					AtkUnitBase* value = ((AtkUnitList)ptr2).Entries[i].Value;
					if (value != null)
					{
						string nameString = ((AtkUnitBase)value).NameString;
						if (Relevant(nameString) && ((AtkUnitBase)value).IsVisible)
						{
							observedAddons.Add(nameString);
							List<object> list2 = new List<object>();
							ReadNodes(&((AtkUnitBase)value).UldManager, list2, 0, new HashSet<nint>());
							list.Add(new
							{
								Name = nameString,
								ValuesState = arenaTraceWriter.State(nameString + "/values", ReadValues(value)),
								NodesState = arenaTraceWriter.State(nameString + "/nodes", list2)
							});
						}
					}
				}
			}
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			uint territoryType = Services.ClientState.TerritoryType;
			int contentId = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
			string?[] conditions = (from c in Services.Condition.AsReadOnlySet()
				select ((object)(*(ConditionFlag*)(&c))/*cast due to .constrained prefix*/).ToString()).ToArray();
			var player = ((localPlayer == null) ? null : new
			{
				EntityId = ((IGameObject)localPlayer).EntityId,
				GameObjectId = ((IGameObject)localPlayer).GameObjectId,
				CurrentHp = ((ICharacter)localPlayer).CurrentHp,
				MaxHp = ((ICharacter)localPlayer).MaxHp,
				Level = ((ICharacter)localPlayer).Level,
				Job = ((ICharacter)localPlayer).ClassJob.RowId,
				X = ((IGameObject)localPlayer).Position.X,
				Y = ((IGameObject)localPlayer).Position.Y,
				Z = ((IGameObject)localPlayer).Position.Z,
				Statuses = ((IEnumerable<IStatus>)((IBattleChara)localPlayer).StatusList).Select((IStatus s) => new { s.StatusId, s.Param, s.RemainingTime }).ToArray()
			});
			IGameObject target = Services.Targets.Target;
			ulong? target2 = ((target != null) ? new ulong?(target.GameObjectId) : ((ulong?)null));
			IGameObject softTarget = Services.Targets.SoftTarget;
			arenaTraceWriter.State("world", new
			{
				Territory = territoryType,
				ContentId = contentId,
				Conditions = conditions,
				Player = player,
				Target = target2,
				SoftTarget = ((softTarget != null) ? new ulong?(softTarget.GameObjectId) : ((ulong?)null)),
				EventObjects = (from o in ((IEnumerable<IGameObject>)Services.Objects).Where(delegate(IGameObject o)
					{
						//IL_0001: Unknown result type (might be due to invalid IL or missing references)
						//IL_0006: Unknown result type (might be due to invalid IL or missing references)
						//IL_0007: Unknown result type (might be due to invalid IL or missing references)
						//IL_0009: Invalid comparison between Unknown and I4
						//IL_000b: Unknown result type (might be due to invalid IL or missing references)
						//IL_000d: Invalid comparison between Unknown and I4
						ObjectKind objectKind = o.ObjectKind;
						return ((int)objectKind == 3 || (int)objectKind == 7) ? true : false;
					}).Take(128)
					select new
					{
						GameObjectId = o.GameObjectId,
						DataId = o.BaseId,
						Kind = ((object)o.ObjectKind/*cast due to .constrained prefix*/).ToString(),
						Name = o.Name.TextValue,
						IsTargetable = o.IsTargetable,
						X = o.Position.X,
						Y = o.Position.Y,
						Z = o.Position.Z
					}).ToArray(),
				Monsters = (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Take(128)
					select new
					{
						GameObjectId = ((IGameObject)n).GameObjectId,
						NameId = ((ICharacter)n).NameId,
						BaseId = ((IGameObject)n).BaseId,
						Name = ((IGameObject)n).Name.TextValue,
						CurrentHp = ((ICharacter)n).CurrentHp,
						MaxHp = ((ICharacter)n).MaxHp,
						Level = ((ICharacter)n).Level,
						IsTargetable = ((IGameObject)n).IsTargetable,
						IsDead = ((IGameObject)n).IsDead,
						TargetObjectId = ((IGameObject)n).TargetObjectId,
						IsCasting = ((IBattleChara)n).IsCasting,
						CastActionId = ((IBattleChara)n).CastActionId,
						CurrentCastTime = ((IBattleChara)n).CurrentCastTime,
						TotalCastTime = ((IBattleChara)n).TotalCastTime,
						EntityId = ((IGameObject)n).EntityId,
						OwnerId = ((IGameObject)n).OwnerId,
						Rotation = ((IGameObject)n).Rotation,
						X = ((IGameObject)n).Position.X,
						Y = ((IGameObject)n).Position.Y,
						Z = ((IGameObject)n).Position.Z,
						Statuses = ((IEnumerable<IStatus>)((IBattleChara)n).StatusList).Select((IStatus s) => new { s.StatusId, s.Param, s.RemainingTime }).ToArray()
					}).ToArray()
			});
			arenaTraceWriter.State("visible-addons", list);
			arenaTraceWriter.Record("Tick", new { });
			arenaTraceWriter.Flush();
			Status = $"正在记录斗兽流程 · {observedAddons.Count} 个界面 · 第 {arenaTraceWriter.PartCount} 卷";
		}
		catch (Exception error)
		{
			Abort(error);
		}
	}

	private void Abort(Exception error)
	{
		protocol?.Dispose();
		protocol = null;
		ArenaTraceWriter arenaTraceWriter = writer;
		writer = null;
		events.Clear();
		try
		{
			arenaTraceWriter?.Dispose();
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Arena trace close failed", Array.Empty<object>());
		}
		Status = "记录中断：" + error.Message + " · 已写入文件位于 " + FilePath;
		Services.Log.Warning(error, "Arena recorder stopped", Array.Empty<object>());
	}

	private unsafe static object[] ReadValues(AtkUnitBase* addon)
	{
		if (addon == null || ((AtkUnitBase)addon).AtkValues == null || ((AtkUnitBase)addon).AtkValuesCount > 4096)
		{
			return Array.Empty<object>();
		}
		return ReadValues(((AtkUnitBase)addon).AtkValues, ((AtkUnitBase)addon).AtkValuesCount);
	}

	internal unsafe static object[] ReadValues(AtkValue* source, int count)
	{
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Expected I4, but got Unknown
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Invalid comparison between Unknown and I4
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Invalid comparison between Unknown and I4
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Invalid comparison between Unknown and I4
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		bool flag = source == null;
		if (!flag)
		{
			bool flag2 = ((count < 0 || count > 4096) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return Array.Empty<object>();
		}
		List<object> list = new List<object>();
		for (int i = 0; i < count; i++)
		{
			AtkValue val = ((AtkValue*)source)[i];
			AtkValueType val2 = (AtkValueType)(val.Type & -33);
			long? number = (val2 - 2) switch
			{
				0 => val.Bool ? 1 : 0, 
				1 => val.Int, 
				3 => val.UInt, 
				2 => val.Int64, 
				_ => null, 
			};
			flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
			string text = (flag ? ((object)(*(CStringPointer*)(&val.String))/*cast due to .constrained prefix*/).ToString() : null);
			float? num = (((int)val2 == 7 && float.IsFinite(val.Float)) ? new float?(val.Float) : ((float?)null));
			list.Add(new
			{
				Index = i,
				Type = ((object)(*(AtkValueType*)(&val.Type))/*cast due to .constrained prefix*/).ToString(),
				Number = number,
				Float = num,
				Text = ((text != null && text.Length > 2048) ? text.Substring(0, 2048) : text)
			});
		}
		return list.ToArray();
	}

	private unsafe static void ReadNodes(AtkUldManager* manager, List<object> result, int depth, HashSet<nint> visited)
	{
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Invalid comparison between Unknown and I4
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Expected I4, but got Unknown
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Expected I4, but got Unknown
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0120: Invalid comparison between Unknown and I4
		//IL_0138: Unknown result type (might be due to invalid IL or missing references)
		//IL_013f: Invalid comparison between Unknown and I4
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0252: Invalid comparison between Unknown and I4
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01da: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e1: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 5 || result.Count >= 2048 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			if (result.Count >= 2048)
			{
				break;
			}
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !visited.Add((nint)ptr))
			{
				continue;
			}
			List<object> list = new List<object>();
			AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)ptr).AtkEventManager)).Event;
			while (ptr2 != null && list.Count < 32)
			{
				list.Add(new
				{
					Type = (byte)(int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType,
					Parameter = ((AtkEvent)ptr2).Param
				});
				ptr2 = ((AtkEvent)ptr2).NextEvent;
			}
			string text = (((int)((AtkResNode)ptr).Type == 3) ? ((object)(*(Utf8String*)(&((AtkTextNode)ptr).NodeText))/*cast due to .constrained prefix*/).ToString() : null);
			result.Add(new
			{
				NodeId = ((AtkResNode)ptr).NodeId,
				Type = (ushort)(int)((AtkResNode)ptr).Type,
				Depth = depth,
				Visible = ((AtkResNode)ptr).IsVisible(),
				Enabled = ((Enum)((AtkResNode)ptr).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32),
				Text = ((text != null && text.Length > 2048) ? text.Substring(0, 2048) : text),
				Events = list
			});
			if ((int)((AtkResNode)ptr).Type < 1000)
			{
				continue;
			}
			AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
			if (component == null)
			{
				continue;
			}
			if ((int)((AtkComponentBase)component).GetComponentType() == 27)
			{
				AtkComponentXBMContentStageEventMap* ptr3 = (AtkComponentXBMContentStageEventMap*)component;
				List<object> list2 = new List<object>();
				bool flag = ((AtkComponentXBMContentStageEventMap)ptr3).IsEventMapLoaded && !((AtkComponentXBMContentStageEventMap)ptr3).IsEventMapLoading && ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCount <= 128 && ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCount <= ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCapacity && ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntries != null;
				if (flag)
				{
					for (int j = 0; j < ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCount; j++)
					{
						EventMapRowEntry val = ((EventMapRowEntry*)((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntries)[j];
						list2.Add(new { val.X, val.Y, val.Type, val.EventIndex, val.LinkedEventIndex, val.State, val.IsStateLoaded });
					}
				}
				result.Add(new
				{
					Kind = "EventMap",
					NodeId = ((AtkResNode)ptr).NodeId,
					RowId = ((AtkComponentXBMContentStageEventMap)ptr3).XBMContentStageEventMapRowId,
					CurrentEventIndex = ((AtkComponentXBMContentStageEventMap)ptr3).CurrentEventIndex,
					Loaded = ((AtkComponentXBMContentStageEventMap)ptr3).IsEventMapLoaded,
					Loading = ((AtkComponentXBMContentStageEventMap)ptr3).IsEventMapLoading,
					Count = ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCount,
					Capacity = ((AtkComponentXBMContentStageEventMap)ptr3).EventMapEntryCapacity,
					Valid = flag,
					Entries = list2
				});
			}
			else if ((int)((AtkComponentBase)component).GetComponentType() == 26)
			{
				AtkComponentXBMItem* ptr4 = (AtkComponentXBMItem*)component;
				result.Add(new
				{
					Kind = "Item",
					NodeId = ((AtkResNode)ptr).NodeId,
					ItemId = ((AtkComponentXBMItem)ptr4).XBMItemId,
					Loaded = ((AtkComponentXBMItem)ptr4).IsItemLoaded,
					ShowPossessionCount = ((AtkComponentXBMItem)ptr4).ShowPossessionCount
				});
			}
			ReadNodes(&((AtkComponentBase)component).UldManager, result, depth + 1, visited);
		}
	}

	public void Dispose()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Expected O, but got Unknown
		Services.AddonLifecycle.UnregisterListener((AddonEventDelegate[])(object)new AddonEventDelegate[1] { OnEvent });
		Stop("插件卸载，记录已保存");
	}
}
