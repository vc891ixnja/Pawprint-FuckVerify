using System;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaResultWorld(Func<bool> authorized, ArenaStage stage, Func<bool>? recordedFailure = null) : IArenaResultWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private string? lastObservation;

	internal unsafe static bool IsOutside
	{
		get
		{
			ICondition condition = Services.Condition;
			if (Services.ClientState.IsLoggedIn && Services.Objects.LocalPlayer != null && Services.ClientState.TerritoryType != 0 && !ArenaStage.All.Any((ArenaStage s) => s.Territory == Services.ClientState.TerritoryType) && GameMain.Instance() != null && ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId == 0 && !condition[(ConditionFlag)45] && !condition[(ConditionFlag)51] && !condition[(ConditionFlag)34] && !condition[(ConditionFlag)56])
			{
				return ArenaUtilityUi.Addon("XBMResult") == null;
			}
			return false;
		}
	}

	public unsafe ArenaResultView Read()
	{
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		ICondition condition = Services.Condition;
		bool flag = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		if (!authorized() || character == 0L || !Services.ClientState.IsLoggedIn || (Services.PlayerState.ContentId != character && (!flag || Services.PlayerState.ContentId != 0L)))
		{
			throw new InvalidOperationException("结算任务或角色已变化");
		}
		if (flag || Services.Objects.LocalPlayer == null)
		{
			return new ArenaResultView(ArenaResultPhase.Loading);
		}
		if (IsOutside)
		{
			return new ArenaResultView(ArenaResultPhase.Outside);
		}
		if (Services.ClientState.TerritoryType != stage.Territory || GameMain.Instance() == null || ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId != stage.Content)
		{
			return new ArenaResultView(ArenaResultPhase.Blocked);
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMResult");
		ArenaValue[] array = ArenaUtilityUi.Values(ptr);
		if (array.Length == 0)
		{
			return new ArenaResultView(ArenaResultPhase.Loading);
		}
		AtkComponentButton* componentButtonById = ((AtkUnitBase)ptr).GetComponentButtonById(61u);
		if (componentButtonById == null || ((AtkComponentButton)componentButtonById).ButtonTextNode == null)
		{
			return new ArenaResultView(ArenaResultPhase.Loading);
		}
		ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)((AtkComponentButton)componentButtonById).ButtonTextNode).NodeText)).StringPtr));
		string text = ((ReadOnlySeStringSpan)(ref val)).ExtractText().Trim();
		Trace(text, array);
		if (string.IsNullOrWhiteSpace(text))
		{
			return new ArenaResultView(ArenaResultPhase.Loading);
		}
		ArenaResultPhase arenaResultPhase = ArenaResultUiPolicy.ButtonPhase(text);
		if (arenaResultPhase == ArenaResultPhase.Loading)
		{
			return new ArenaResultView(arenaResultPhase);
		}
		ArenaRunResult result = null;
		try
		{
			result = ArenaResultDecoder.Decode(array, stage)with
			{
				Failed = (recordedFailure?.Invoke() ?? false)
			};
		}
		catch (InvalidOperationException ex) when (ex.Message.Contains("未就绪"))
		{
		}
		return new ArenaResultView(arenaResultPhase, result);
	}

	private void Trace(string label, ArenaValue[] values)
	{
		bool flag = Services.Condition[(ConditionFlag)26];
		string text = $"{label}/{flag}";
		if (text == lastObservation)
		{
			return;
		}
		lastObservation = text;
		Services.Log.Information($"Arena result: button '{label}', InCombat={flag}", Array.Empty<object>());
		try
		{
			string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text2);
			File.WriteAllText(Path.Combine(text2, "arena-result-latest.json"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Version = typeof(ArenaResultWorld).Assembly.GetName().Version?.ToString(),
				Stage = stage.Id,
				ButtonLabel = label,
				InCombat = flag,
				Values = values
			}, new JsonSerializerOptions
			{
				WriteIndented = true,
				Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
			}));
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Arena result diagnostic failed", Array.Empty<object>());
		}
	}

	private unsafe bool Click(ArenaResultPhase expected)
	{
		ArenaResultView arenaResultView = Read();
		if (arenaResultView.Phase == ArenaResultPhase.Loading)
		{
			return false;
		}
		if (arenaResultView.Phase != expected)
		{
			return false;
		}
		return ArenaUtilityUi.ClickButton(ArenaUtilityUi.Addon("XBMResult"), 61u, 0u);
	}

	public bool TryNext()
	{
		return Click(ArenaResultPhase.NextPage);
	}

	public bool TryExit()
	{
		return Click(ArenaResultPhase.ExitPage);
	}
}
