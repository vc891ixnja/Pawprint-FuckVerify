using System.Numerics;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Arena;

internal static class ArenaBoardReader
{
	private unsafe static bool Visible(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address != null)
		{
			return ((AtkUnitBase)address).IsVisible;
		}
		return false;
	}

	public unsafe static ArenaBoardObservation Read()
	{
		ICondition condition = Services.Condition;
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		uint num = (uint)((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		bool flag = Visible("XBMResult");
		bool flag2 = Visible("XBMStageDetailList");
		bool flag3 = Visible("XBMPetParty");
		bool flag4 = Visible("XBMContentsBooty");
		bool flag5 = Visible("XBMContentsTreasure");
		bool flag6 = Visible("XBMContentsItemShop");
		bool flag7 = Visible("SelectYesno");
		bool flag8 = condition[(ConditionFlag)33] || condition[(ConditionFlag)31];
		bool flag9 = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		bool nodeEvent = flag8 && (flag2 || flag3 || flag4 || flag5 || flag6);
		bool flag10 = localPlayer != null && !ArenaBoardRoute.IsOnBoard(ArenaStage.FromContent(num)?.Id ?? 0, ((IGameObject)localPlayer).Position);
		bool blocked = flag9 || flag8 || condition[(ConditionFlag)26] || condition[(ConditionFlag)29] || condition[(ConditionFlag)63] || flag2 || flag3 || flag4 || flag5 || flag6 || flag7 || !Visible("XBMContentsMainHUD");
		string phase = (flag ? "已到达结算" : (flag9 ? "等待过场或场地切换" : (flag4 ? "请领取战利品" : (flag5 ? "请选择宝箱奖励" : (flag6 ? "请处理商店" : ((flag2 && flag8) ? "请编队并开始战斗" : ((flag3 && flag8) ? "请处理魔兽或休息选项" : ((flag10 || condition[(ConditionFlag)26]) ? "请完成战斗" : (flag7 ? "请处理确认窗口" : ((flag2 || flag3) ? "请关闭查看窗口" : "等待棋盘就绪"))))))))));
		return new ArenaBoardObservation(Services.ClientState.TerritoryType, num, (localPlayer != null) ? new Vector3?(((IGameObject)localPlayer).Position) : ((Vector3?)null), blocked, nodeEvent, flag, phase, flag4, flag9, flag2 && flag3 && flag8, condition[(ConditionFlag)26], flag8 && ArenaRestWorld.HasRestUi, flag8 && flag5, flag8 && flag6);
	}
}
