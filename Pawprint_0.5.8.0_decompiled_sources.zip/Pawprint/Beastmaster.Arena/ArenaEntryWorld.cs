using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.I18N;
using Beastmaster.Core.Models;
using Beastmaster.Hunting;
using Beastmaster.Integrations;
using Dalamud.Game;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;
using Lumina.Excel.Sheets;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaEntryWorld(NotebookReader notebook, DalamudHuntingWorld movement, VnavmeshClient nav, Func<bool> authorized, ArenaStage stage) : IArenaEntryWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private NavigationStep? approach;

	private LandAndDismountStep? landing;

	private TimeSpan landingAt;

	private bool ownsNotebook;

	private TimeSpan? pageSent;

	private int pageAttempts;

	private ulong npcId;

	private string? lastListWait;

	private string? lastEntryUiError;

	private string? lastClearMenuState;

	private bool contextRequested;

	private bool clearMenuSelected;

	private bool clearConfirmed;

	public static readonly LevelingLocation Entrance = new LevelingLocation(-1, "劳妲", 148u, 4u, "黑衣森林中央林区", 0, 22f, 22.8f, 0f, 0f);

	private static long nextCommenceDiagnoseAt;

	private static long nextStructureDumpAt;

	public unsafe static bool HasOpenEntryUi
	{
		get
		{
			if (Addon("SelectString") == null && Addon("SelectIconString") == null && Addon("XBMStageList") == null)
			{
				if (Addon("XBMStageDetailList") != null)
				{
					return Addon("XBMPetParty") != null;
				}
				return false;
			}
			return true;
		}
	}

	public bool NotebookBusy => notebook.IsScanning;

	public bool NotebookClosed
	{
		get
		{
			if (!notebook.IsVisibleNow)
			{
				return !Services.Condition[(ConditionFlag)31];
			}
			return false;
		}
	}

	private unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	public void Validate()
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		if (authorized() && Services.ClientState.IsLoggedIn && character != 0L && (Services.PlayerState.ContentId == 0L || Services.PlayerState.ContentId == character))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || !((IGameObject)localPlayer).IsDead)
			{
				IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
				if (localPlayer2 == null || ((ICharacter)localPlayer2).ClassJob.RowId == 43)
				{
					return;
				}
			}
		}
		throw new InvalidOperationException("斗兽任务或角色状态已变化");
	}

	private void AtEntrance()
	{
		Validate();
		if (Services.Objects.LocalPlayer == null || Services.PlayerState.ContentId != character || Services.ClientState.TerritoryType != 148 || movement.IsTransitioning || movement.IsInCutscene || Services.Condition[(ConditionFlag)26])
		{
			throw new InvalidOperationException("当前不能与劳妲交互");
		}
	}

	private unsafe static long Number(AtkUnitBase* a, int index)
	{
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Expected I4, but got Unknown
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || ((AtkUnitBase)a).AtkValues == null || index < 0 || index >= ((AtkUnitBase)a).AtkValuesCount)
		{
			return -1L;
		}
		AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[index];
		AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
		return (val2 - 2) switch
		{
			3 => val.UInt, 
			1 => val.Int, 
			0 => val.Bool ? 1 : 0, 
			_ => -1L, 
		};
	}

	private unsafe static string Text(AtkUnitBase* a, int index)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Invalid comparison between Unknown and I4
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Invalid comparison between Unknown and I4
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || ((AtkUnitBase)a).AtkValues == null || index < 0 || index >= ((AtkUnitBase)a).AtkValuesCount)
		{
			return "";
		}
		AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[index];
		AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
		bool flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
		if (!flag || val.String.Value == null)
		{
			return "";
		}
		ReadOnlySeStringSpan val3 = new ReadOnlySeStringSpan(val.String.Value);
		return ((ReadOnlySeStringSpan)(ref val3)).ExtractText();
	}

	private unsafe static string PromptText(AtkUnitBase* a)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Invalid comparison between Unknown and I4
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Invalid comparison between Unknown and I4
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || ((AtkUnitBase)a).AtkValues == null || ((AtkUnitBase)a).AtkValuesCount == 0)
		{
			return "";
		}
		AtkValue atkValues = *((AtkUnitBase)a).AtkValues;
		AtkValueType val = (AtkValueType)(atkValues.Type & 0xF);
		bool flag = (((int)val == 8 || (int)val == 10) ? true : false);
		if (!flag || atkValues.String.Value == null)
		{
			return "";
		}
		ReadOnlySeStringSpan val2 = new ReadOnlySeStringSpan(atkValues.String.Value);
		return ((ReadOnlySeStringSpan)(ref val2)).ExtractText();
	}

	private unsafe ArenaEntryView BlockedUi(string reason)
	{
		AtkUnitBase* a = Addon("SelectYesno");
		string text = PromptText(a);
		string text2 = reason + ": " + text;
		if (text2 != lastEntryUiError)
		{
			lastEntryUiError = text2;
			Services.Log.Warning("Arena entry blocked: " + text2, Array.Empty<object>());
			try
			{
				string text3 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
				Directory.CreateDirectory(text3);
				File.WriteAllText(Path.Combine(text3, "arena-entry-ui-latest.json"), JsonSerializer.Serialize(new
				{
					At = DateTimeOffset.Now,
					Version = typeof(ArenaEntryWorld).Assembly.GetName().Version?.ToString(),
					Reason = reason,
					Prompt = text,
					RawPrompt = Text(a, 0),
					SelectedStage = stage.Id,
					VisibleStage = ReadStageMap(),
					PartyCount = Number(Addon("XBMPetParty"), 5),
					NotebookOpen = (Addon("XBMMonsterNotebook") != null),
					TalkOpen = (Addon("Talk") != null)
				}, new JsonSerializerOptions
				{
					WriteIndented = true,
					Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
				}));
			}
			catch (Exception ex)
			{
				Services.Log.Warning(ex, "Arena entry UI diagnostic failed", Array.Empty<object>());
			}
		}
		return new ArenaEntryView(ArenaEntryPhase.Blocked, Array.Empty<uint>());
	}

	private unsafe static ArenaPet[] ReadParty()
	{
		if (!ArenaPartyReader.TryRead(Addon("XBMPetParty"), allowEmpty: true, out ArenaPet[] pets))
		{
			throw new InvalidOperationException("入场编组尚未加载");
		}
		return pets;
	}

	private unsafe static int? ReadStageMap()
	{
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Invalid comparison between Unknown and I4
		AtkUnitBase* ptr = Addon("XBMStageDetailList");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return null;
		}
		AtkComponentBase* componentByNodeId = ((AtkUnitBase)ptr).GetComponentByNodeId(36u);
		if (componentByNodeId == null || (int)((AtkComponentBase)componentByNodeId).GetComponentType() != 27)
		{
			return null;
		}
		AtkComponentXBMContentStageEventMap* ptr2 = (AtkComponentXBMContentStageEventMap*)componentByNodeId;
		if (((AtkComponentXBMContentStageEventMap)ptr2).IsEventMapLoaded && !((AtkComponentXBMContentStageEventMap)ptr2).IsEventMapLoading)
		{
			uint xBMContentStageEventMapRowId = ((AtkComponentXBMContentStageEventMap)ptr2).XBMContentStageEventMapRowId;
			if (xBMContentStageEventMapRowId >= 1 && xBMContentStageEventMapRowId <= 5)
			{
				return (int)((AtkComponentXBMContentStageEventMap)ptr2).XBMContentStageEventMapRowId;
			}
		}
		return null;
	}

	public unsafe ArenaEntryView Read()
	{
		Validate();
		if (movement.IsTransitioning || movement.IsInCutscene || Services.Objects.LocalPlayer == null)
		{
			return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
		}
		if (Services.ClientState.TerritoryType == stage.Territory && GameMain.Instance() != null && ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId == stage.Content)
		{
			return new ArenaEntryView(ArenaEntryPhase.Board, Array.Empty<uint>());
		}
		if (Services.ClientState.TerritoryType != 148)
		{
			return new ArenaEntryView(ArenaEntryPhase.Blocked, Array.Empty<uint>());
		}
		if (Addon("Talk") != null)
		{
			return BlockedUi("对话窗口仍打开");
		}
		AtkUnitBase* ptr = Addon("SelectYesno");
		if (ptr != null)
		{
			string text = PromptText(ptr);
			if (!((AtkUnitBase)ptr).IsReady || string.IsNullOrWhiteSpace(text))
			{
				return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
			}
			if (!ArenaClearMenu.IsPrompt(text))
			{
				if (!ArenaEntryConfirmation.Matches(text))
				{
					return BlockedUi("确认文字不匹配");
				}
				if (Addon("XBMMonsterNotebook") != null)
				{
					return BlockedUi("入场确认时编组图鉴仍打开");
				}
				if (ArenaPartyReader.TryRead(Addon("XBMPetParty"), allowEmpty: true, out ArenaPet[] pets))
				{
					int? num = ReadStageMap();
					if (num.HasValue)
					{
						int valueOrDefault = num.GetValueOrDefault();
						return new ArenaEntryView(ArenaEntryPhase.EntryConfirmation, pets.Select((ArenaPet p) => p.PetId).ToArray(), valueOrDefault, ArenaEntryConfirmation.IsUnderleveled(text));
					}
				}
				return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
			}
		}
		string[] array = new string[6] { "SelectString", "SelectIconString", "XBMStageList", "XBMPetParty", "XBMStageDetailList", "XBMMonsterNotebook" };
		for (int num2 = 0; num2 < array.Length; num2++)
		{
			AtkUnitBase* ptr2 = Addon(array[num2]);
			if (ptr2 != null && !((AtkUnitBase)ptr2).IsReady)
			{
				return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
			}
		}
		if (Addon("XBMPetParty") != null && Addon("XBMStageDetailList") != null)
		{
			if (!ArenaPartyReader.TryRead(Addon("XBMPetParty"), allowEmpty: true, out ArenaPet[] pets2))
			{
				return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
			}
			return new ArenaEntryView((Addon("XBMMonsterNotebook") != null) ? ArenaEntryPhase.RosterEditor : ArenaEntryPhase.Party, pets2.Select((ArenaPet p) => p.PetId).ToArray(), ReadStageMap());
		}
		if (Addon("XBMStageList") != null)
		{
			return new ArenaEntryView(ArenaEntryPhase.StageList, Array.Empty<uint>());
		}
		if (Addon("SelectString") != null || Addon("SelectIconString") != null)
		{
			if (!ReadEntranceMenu(out AtkUnitBase* _, out PopupMenu* _, out string _, out string[] entries))
			{
				return new ArenaEntryView(ArenaEntryPhase.Loading, Array.Empty<uint>());
			}
			if (ArenaEntranceMenu.ActivityRow(entries) >= 0)
			{
				return new ArenaEntryView(ArenaEntryPhase.NpcMenu, Array.Empty<uint>());
			}
			if (ArenaEntranceMenu.ChallengeRow(entries) >= 0)
			{
				return new ArenaEntryView(ArenaEntryPhase.Menu, Array.Empty<uint>());
			}
			return BlockedUi("劳妲菜单未找到斗兽选项：" + string.Join(" / ", entries));
		}
		return new ArenaEntryView(ArenaEntryPhase.Outside, Array.Empty<uint>());
	}

	public bool StartNotebook()
	{
		Validate();
		notebook.RequestScan();
		ownsNotebook = true;
		return true;
	}

	public uint[] ReadUnlocked()
	{
		Validate();
		if (Enumerable.Range(1, 50).Any((int n) => notebook.GetFresh(n) == CaptureState.Unknown))
		{
			throw new InvalidOperationException("未能读取完整图鉴，未执行斗兽编组");
		}
		return (from n in Enumerable.Range(1, 50)
			where notebook.GetFresh(n) == CaptureState.Captured
			select (uint)n).ToArray();
	}

	public bool CloseNotebook()
	{
		Validate();
		if (!notebook.TryClose())
		{
			return false;
		}
		ownsNotebook = false;
		return true;
	}

	private IGameObject? Npc()
	{
		return ((IEnumerable<IGameObject>)Services.Objects).FirstOrDefault((Func<IGameObject, bool>)((IGameObject n) => (int)n.ObjectKind == 3 && n.IsTargetable && GameText.MatchesAnyLanguage("Entry.NpcName", n.Name.TextValue)));
	}

	public bool ApproachNpc(TimeSpan elapsed)
	{
		AtEntrance();
		if (elapsed > TimeSpan.FromSeconds(60L))
		{
			throw new TimeoutException("未能接近劳妲");
		}
		IGameObject val = Npc();
		if (val == null)
		{
			if (elapsed > TimeSpan.FromSeconds(10L))
			{
				throw new InvalidOperationException("劳妲坐标附近没有找到 NPC");
			}
			return false;
		}
		npcId = val.GameObjectId;
		if (movement.IsMounted || movement.IsFlying || movement.IsMountTransition || landing != null)
		{
			if (landing == null)
			{
				landing = new LandAndDismountStep(movement, nav);
				landingAt = elapsed;
			}
			if (landing.Tick(elapsed - landingAt) != StepResult.Completed)
			{
				return false;
			}
			landing.Cancel();
			landing = null;
		}
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null)
		{
			return false;
		}
		if (Vector3.Distance(((IGameObject)localPlayer).Position, val.Position) <= 3f)
		{
			approach?.Cancel();
			approach = null;
			return true;
		}
		if (approach == null)
		{
			approach = new NavigationStep(nav, new WorldPoint(148u, val.Position.X, val.Position.Y, val.Position.Z), () => movement.Player);
		}
		approach.Tick(elapsed);
		return false;
	}

	public unsafe bool Interact()
	{
		AtEntrance();
		IGameObject val = Npc();
		if (val != null && val.GameObjectId == npcId)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && !(Vector3.Distance(((IGameObject)localPlayer).Position, val.Position) > 3f))
			{
				if (Read().Phase != ArenaEntryPhase.Outside)
				{
					throw new InvalidOperationException("请先关闭其他交互窗口");
				}
				TargetSystem* ptr = TargetSystem.Instance();
				if (ptr == null)
				{
					throw new InvalidOperationException("目标系统尚未就绪");
				}
				if (!UiInteractionDelay.Ready($"entry/interact/{val.GameObjectId}"))
				{
					return false;
				}
				Services.Targets.Target = val;
				((TargetSystem)ptr).InteractWithObject((GameObject*)val.Address, true);
				return true;
			}
		}
		throw new InvalidOperationException("劳妲不在交互范围内");
	}

	private unsafe bool WaitForList(string context, AtkComponentList* list, int row, string reason)
	{
		string text = $"{context}: {reason}; row={row}, count={((list == null) ? (-1) : ((AtkComponentList)list).ListLength)}, owner={((list == null || ((AtkComponentList)list).OwnerNode == null) ? "null" : ((object)(*(NodeFlags*)(&((AtkComponentNode)((AtkComponentList)list).OwnerNode).NodeFlags))/*cast due to .constrained prefix*/).ToString())}";
		if (text != lastListWait)
		{
			Services.Log.Warning("Arena entry waiting for UI: " + text, Array.Empty<object>());
			lastListWait = text;
		}
		return false;
	}

	private unsafe bool TryListClick(AtkUnitBase* addon, AtkComponentList* list, int row, string context)
	{
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		if (addon == null || !((AtkUnitBase)addon).IsReady || list == null || ((AtkComponentList)list).OwnerNode == null)
		{
			return WaitForList(context, list, row, "list not loaded");
		}
		if (!Visible((AtkResNode*)((AtkComponentList)list).OwnerNode) || !((Enum)((AtkComponentNode)((AtkComponentList)list).OwnerNode).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32))
		{
			return WaitForList(context, list, row, "list not interactive");
		}
		if (row < 0 || row >= ((AtkComponentList)list).ListLength || ((AtkComponentList)list).ListLength > 100)
		{
			return WaitForList(context, list, row, "row not populated");
		}
		if (((AtkComponentList)list).GetItemDisabledState(row))
		{
			return WaitForList(context, list, row, "row disabled");
		}
		if (!UiInteractionDelay.Ready($"entry/list/{addon}/{row}/{context}"))
		{
			return false;
		}
		lastListWait = null;
		Services.Log.Information($"Arena entry selecting {context}, row={row}, count={((AtkComponentList)list).ListLength}", Array.Empty<object>());
		((AtkComponentList)list).SelectItem(row, false);
		((AtkComponentList)list).DispatchItemEvent(row, (AtkEventType)35);
		return true;
	}

	private unsafe static bool ReadEntranceMenu(out AtkUnitBase* addon, out PopupMenu* popup, out string name, out string[] entries)
	{
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* ptr = Addon("SelectIconString");
		AtkUnitBase* ptr2 = Addon("SelectString");
		addon = ((ptr != null) ? ptr : ptr2);
		popup = null;
		entries = Array.Empty<string>();
		name = ((ptr != null) ? "SelectIconString" : "SelectString");
		if (addon == null || !((AtkUnitBase)addon).IsReady || (ptr != null && ptr2 != null))
		{
			return false;
		}
		popup = ((ptr != null) ? ((PopupMenu*)(&((AddonSelectIconString)addon).PopupMenu)) : ((PopupMenu*)(&((AddonSelectString)addon).PopupMenu)));
		bool flag = ((PopupMenu)popup).EntryNames == null;
		if (!flag)
		{
			int entryCount = ((PopupMenu)popup).EntryCount;
			bool flag2 = ((entryCount < 1 || entryCount > 64) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return false;
		}
		entries = new string[((PopupMenu)popup).EntryCount];
		for (int i = 0; i < entries.Length; i++)
		{
			if (((CStringPointer)((byte*)((PopupMenu)popup).EntryNames + (nint)i * (nint)Unsafe.SizeOf<CStringPointer>())).Value == null)
			{
				return false;
			}
			string[] obj = entries;
			int num = i;
			ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(((CStringPointer)((byte*)((PopupMenu)popup).EntryNames + (nint)i * (nint)Unsafe.SizeOf<CStringPointer>())).Value);
			obj[num] = ((ReadOnlySeStringSpan)(ref val)).ExtractText();
			if (string.IsNullOrWhiteSpace(entries[i]))
			{
				return false;
			}
		}
		return true;
	}

	public bool TryChooseActivity()
	{
		return TryChooseMenu(activity: true);
	}

	public bool TryChooseChallenge()
	{
		return TryChooseMenu(activity: false);
	}

	private unsafe bool TryChooseMenu(bool activity)
	{
		AtEntrance();
		if (!ReadEntranceMenu(out AtkUnitBase* addon, out PopupMenu* popup, out string name, out string[] entries))
		{
			return WaitForList(name, null, -1, "menu entries not populated");
		}
		int num = (activity ? ArenaEntranceMenu.ActivityRow(entries) : ArenaEntranceMenu.ChallengeRow(entries));
		if (num < 0)
		{
			throw new InvalidOperationException("当前菜单未找到所需斗兽选项");
		}
		return TryListClick(addon, ((PopupMenu)popup).List, num, name + "/" + entries[num]);
	}

	public unsafe bool TryChooseBoard()
	{
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		AtEntrance();
		AtkUnitBase* ptr = Addon("XBMStageList");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return WaitForList("XBMStageList", null, 0, "stage list not ready");
		}
		AtkComponentList* componentListById = ((AtkUnitBase)ptr).GetComponentListById(2u);
		bool flag = componentListById == null;
		if (!flag)
		{
			int listLength = ((AtkComponentList)componentListById).ListLength;
			bool flag2 = ((listLength < 1 || listLength > 5) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return WaitForList("XBMStageList", componentListById, -1, "rows not populated");
		}
		ContentFinderCondition row = Services.Data.GetExcelSheet<ContentFinderCondition>((ClientLanguage?)null, (string)null).GetRow(stage.Content);
		ReadOnlySeString name = ((ContentFinderCondition)(ref row)).Name;
		string text = ((ReadOnlySeString)(ref name)).ExtractText();
		List<string[]> list = new List<string[]>();
		for (int i = 0; i < ((AtkComponentList)componentListById).ListLength; i++)
		{
			List<string> list2 = new List<string>();
			CStringPointer itemLabel = ((AtkComponentList)componentListById).GetItemLabel(i);
			if (itemLabel.Value != null)
			{
				ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(itemLabel.Value);
				list2.Add(((ReadOnlySeStringSpan)(ref val)).ExtractText());
			}
			AtkComponentListItemRenderer* itemRenderer = ((AtkComponentList)componentListById).GetItemRenderer(i);
			if (itemRenderer != null && ((AtkComponentListItemRenderer)itemRenderer).ListItemIndex == i)
			{
				ReadRowTexts((AtkComponentBase*)itemRenderer, list2);
			}
			list.Add(list2.Where((string t) => !string.IsNullOrWhiteSpace(t)).Distinct().ToArray());
		}
		int num = ArenaEntranceMenu.FindRow(list, text);
		if (num < 0 && ((AtkComponentList)componentListById).ListLength == 1 && Text(ptr, 2) == text && Number(ptr, 0) == 1)
		{
			num = 0;
		}
		if (num < 0 && list.Any((string[] r) => r.Length == 0))
		{
			return WaitForList("XBMStageList/" + stage.Name, componentListById, -1, "labels not populated: " + JsonSerializer.Serialize(list));
		}
		if (num < 0)
		{
			throw new InvalidOperationException(stage.Name + "尚未解锁或未出现在当前列表中：" + JsonSerializer.Serialize(list));
		}
		return TryListClick(ptr, componentListById, num, "XBMStageList/" + stage.Name);
	}

	private unsafe static void ReadRowTexts(AtkComponentBase* component, List<string> texts, int depth = 0)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Invalid comparison between Unknown and I4
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Invalid comparison between Unknown and I4
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		if (component == null || depth > 4 || ((AtkUldManager)(&((AtkComponentBase)component).UldManager)).NodeList == null || ((AtkUldManager)(&((AtkComponentBase)component).UldManager)).NodeListCount > 256)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)(&((AtkComponentBase)component).UldManager)).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)(&((AtkComponentBase)component).UldManager)).NodeList[i];
			if (ptr == null || !Visible(ptr))
			{
				continue;
			}
			if ((int)((AtkResNode)ptr).Type == 3)
			{
				CStringPointer stringPtr = ((Utf8String)(&((AtkTextNode)ptr).NodeText)).StringPtr;
				if (stringPtr.Value != null)
				{
					ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(stringPtr.Value);
					texts.Add(((ReadOnlySeStringSpan)(ref val)).ExtractText());
				}
			}
			else if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				ReadRowTexts(((AtkComponentNode)ptr).Component, texts, depth + 1);
			}
		}
	}

	public unsafe bool TryClearRoster()
	{
		//IL_0193: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		AtEntrance();
		AtkUnitBase* ptr = Addon("XBMPetParty");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady || Addon("XBMStageDetailList") == null || Addon("XBMMonsterNotebook") != null)
		{
			return false;
		}
		AtkUnitBase* ptr2 = Addon("SelectYesno");
		if (ptr2 != null)
		{
			if (!ArenaClearMenu.IsPrompt(Text(ptr2, 0)))
			{
				throw new InvalidOperationException("当前不是本次清空队伍的确认窗口");
			}
			clearMenuSelected = true;
			if (!((AtkUnitBase)ptr2).IsReady)
			{
				return false;
			}
			if (!clearConfirmed)
			{
				if (!UiInteractionDelay.Ready($"entry/clear/yes/{ptr2}"))
				{
					return false;
				}
				Fire(ptr2, default(int));
				clearConfirmed = true;
			}
			return true;
		}
		if (clearConfirmed)
		{
			return true;
		}
		if (clearMenuSelected)
		{
			return false;
		}
		AtkUnitBase* ptr3 = Addon("ContextMenu");
		if (ptr3 != null)
		{
			AgentContext* ptr4 = AgentContext.Instance();
			if (ptr4 == null || ((AgentContext)ptr4).OwnerAddon != ((AtkUnitBase)ptr).Id)
			{
				throw new InvalidOperationException("当前右键菜单不属于魔兽编队");
			}
			if (!((AtkUnitBase)ptr3).IsReady)
			{
				return false;
			}
			AtkComponentList* ptr5 = FindContextList(ptr3);
			bool flag = ptr5 == null;
			if (!flag)
			{
				int listLength = ((AtkComponentList)ptr5).ListLength;
				bool flag2 = ((listLength < 1 || listLength > 32) ? true : false);
				flag = flag2;
			}
			if (flag || ((AtkComponentList)ptr5).IsUpdatePending)
			{
				TraceClearMenu(ptr3, ptr5, Array.Empty<ArenaClearMenuRow>(), "waiting for menu list");
				return false;
			}
			List<ArenaClearMenuRow> list = new List<ArenaClearMenuRow>();
			for (int i = 0; i < ((AtkComponentList)ptr5).ListLength; i++)
			{
				List<string> list2 = new List<string>();
				CStringPointer itemLabel = ((AtkComponentList)ptr5).GetItemLabel(i);
				if (itemLabel.Value != null)
				{
					ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(itemLabel.Value);
					list2.Add(((ReadOnlySeStringSpan)(ref val)).ExtractText());
				}
				AtkComponentListItemRenderer* itemRenderer = ((AtkComponentList)ptr5).GetItemRenderer(i);
				if (itemRenderer != null && ((AtkComponentListItemRenderer)itemRenderer).ListItemIndex == i)
				{
					ReadRowTexts((AtkComponentBase*)itemRenderer, list2);
				}
				if (list2.All(string.IsNullOrWhiteSpace) && Number(ptr3, 0) == ((AtkComponentList)ptr5).ListLength)
				{
					list2.Add(Text(ptr3, 8 + i));
				}
				list.Add(new ArenaClearMenuRow(i, list2.Where((string t) => !string.IsNullOrWhiteSpace(t)).Distinct().ToArray(), !((AtkComponentList)ptr5).GetItemDisabledState(i)));
			}
			int? num = ArenaClearMenu.FindDisplayedRow(list);
			if (num.HasValue)
			{
				int valueOrDefault = num.GetValueOrDefault();
				TraceClearMenu(ptr3, ptr5, list, $"selecting row {valueOrDefault}");
				if (!TryListClick(ptr3, ptr5, valueOrDefault, "ContextMenu/清空整个队伍"))
				{
					TraceClearMenu(ptr3, ptr5, list, "menu list not interactive");
					return false;
				}
				clearMenuSelected = true;
				return false;
			}
			TraceClearMenu(ptr3, ptr5, list, "clear entry unavailable");
			return false;
		}
		if (contextRequested)
		{
			return false;
		}
		if (!ArenaPartyReader.TryRead(ptr, allowEmpty: true, out ArenaPet[] pets) || pets.Length == 0)
		{
			return false;
		}
		ArenaPet arenaPet = pets[^1];
		if (!UiInteractionDelay.Ready($"entry/context/{ptr}/{arenaPet.PetId}/{arenaPet.Row}"))
		{
			return false;
		}
		Services.Log.Information($"Arena entry opening pet context menu: row={arenaPet.Row}, notebook={arenaPet.PetId}", Array.Empty<object>());
		Fire(ptr, 2, arenaPet.Row);
		contextRequested = true;
		return false;
	}

	private unsafe static AtkComponentList* FindContextList(AtkUnitBase* menu)
	{
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Invalid comparison between Unknown and I4
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Invalid comparison between Unknown and I4
		if (menu == null || ((AtkUldManager)(&((AtkUnitBase)menu).UldManager)).NodeList == null || ((AtkUldManager)(&((AtkUnitBase)menu).UldManager)).NodeListCount > 256)
		{
			return null;
		}
		AtkComponentList* ptr = null;
		for (int i = 0; i < ((AtkUldManager)(&((AtkUnitBase)menu).UldManager)).NodeListCount; i++)
		{
			AtkResNode* ptr2 = ((AtkUldManager)(&((AtkUnitBase)menu).UldManager)).NodeList[i];
			if (ptr2 == null || (int)((AtkResNode)ptr2).Type < 1000 || !Visible(ptr2))
			{
				continue;
			}
			AtkComponentBase* component = ((AtkComponentNode)ptr2).Component;
			if (component != null && (int)((AtkComponentBase)component).GetComponentType() == 9)
			{
				if (ptr != null)
				{
					return null;
				}
				ptr = (AtkComponentList*)component;
			}
		}
		return ptr;
	}

	private unsafe void TraceClearMenu(AtkUnitBase* menu, AtkComponentList* list, IReadOnlyList<ArenaClearMenuRow> rows, string state)
	{
		var anon = new
		{
			State = state,
			Rows = rows,
			Territory = Services.ClientState.TerritoryType,
			MenuReady = ((AtkUnitBase)menu).IsReady,
			ValueCount = ((AtkUnitBase)menu).AtkValuesCount,
			DeclaredRows = Number(menu, 0),
			ListCount = ((list == null) ? (-1) : ((AtkComponentList)list).ListLength),
			ListFlags = ((list == null || ((AtkComponentList)list).OwnerNode == null) ? "" : ((object)(*(NodeFlags*)(&((AtkComponentNode)((AtkComponentList)list).OwnerNode).NodeFlags))/*cast due to .constrained prefix*/).ToString()),
			InteractionEnabled = (list != null && ((AtkComponentList)list).IsItemInteractionEnabled),
			contextRequested = contextRequested,
			clearMenuSelected = clearMenuSelected,
			clearConfirmed = clearConfirmed
		};
		string text = JsonSerializer.Serialize(anon);
		if (lastClearMenuState == text)
		{
			return;
		}
		lastClearMenuState = text;
		try
		{
			string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text2);
			File.WriteAllText(Path.Combine(text2, "arena-clear-menu-latest.json"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Version = typeof(ArenaEntryWorld).Assembly.GetName().Version?.ToString(),
				Diagnostic = anon
			}, new JsonSerializerOptions
			{
				WriteIndented = true,
				Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
			}));
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Arena clear menu diagnostic failed", Array.Empty<object>());
		}
	}

	private unsafe static void Fire(AtkUnitBase* addon, params int[] request)
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		AtkValue* ptr = (AtkValue*)stackalloc AtkValue[request.Length];
		AtkValue val = default(AtkValue);
		for (int i = 0; i < request.Length; i++)
		{
			byte* num = (byte*)ptr + (nint)i * (nint)Unsafe.SizeOf<AtkValue>();
			((AtkValue)(ref val))._002Ector();
			val.Type = (AtkValueType)3;
			val.Int = request[i];
			Unsafe.Write(num, val);
		}
		((AtkUnitBase)addon).FireCallback((uint)request.Length, ptr, true);
	}

	public bool TryOpenRoster()
	{
		if (!TrySendRegisteredEvent("XBMPetParty", (AtkEventType)25, 5u))
		{
			return false;
		}
		ownsNotebook = true;
		return true;
	}

	public unsafe bool AddPet(uint id, TimeSpan elapsed)
	{
		//IL_0180: Unknown result type (might be due to invalid IL or missing references)
		//IL_018d: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b6: Unknown result type (might be due to invalid IL or missing references)
		AtEntrance();
		AtkUnitBase* ptr = Addon("XBMMonsterNotebook");
		if ((id < 1 || id > 50) ? true : false)
		{
			throw new InvalidOperationException("魔兽图鉴编号无效");
		}
		if (!notebook.TryReadRoster(out NotebookPage page) || page == null || ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		uint num = (id - 1) / 25;
		if (page.PageIndex != num)
		{
			if (pageSent.HasValue)
			{
				TimeSpan? timeSpan = pageSent;
				if (elapsed - timeSpan < TimeSpan.FromSeconds(1.5))
				{
					return false;
				}
			}
			if (!UiInteractionDelay.Ready($"entry/notebook/{ptr}/page/{num}"))
			{
				return false;
			}
			if (++pageAttempts > 3)
			{
				throw new TimeoutException("编组图鉴翻页未生效");
			}
			AtkValue* ptr2 = (AtkValue*)stackalloc AtkValue[2];
			AtkValue val = default(AtkValue);
			((AtkValue)(ref val))._002Ector();
			val.Type = (AtkValueType)3;
			val.Int = 3;
			Unsafe.Write(ptr2, val);
			byte* num2 = (byte*)ptr2 + Unsafe.SizeOf<AtkValue>();
			((AtkValue)(ref val))._002Ector();
			val.Type = (AtkValueType)5;
			val.UInt = num;
			Unsafe.Write(num2, val);
			((AtkUnitBase)ptr).FireCallback(2u, ptr2, true);
			pageSent = elapsed;
			return false;
		}
		pageAttempts = 0;
		pageSent = null;
		int num3 = (int)((id - 1) % 25);
		if (page.States.GetValueOrDefault((int)id) != CaptureState.Captured)
		{
			throw new InvalidOperationException($"图鉴 {id:00} 尚未解锁，无法编组");
		}
		if (!ArenaPartyReader.TryRead(Addon("XBMPetParty"), allowEmpty: true, out ArenaPet[] pets))
		{
			return false;
		}
		if (pets.Length >= stage.RosterCapacity || pets.Any((ArenaPet p) => p.PetId == id))
		{
			throw new InvalidOperationException("编组已满或魔兽已在队伍中");
		}
		return TrySendRegisteredEvent("XBMMonsterNotebook", (AtkEventType)3, (uint)(num3 + 4));
	}

	public bool Enter()
	{
		AtEntrance();
		ArenaPet[] array = ReadParty();
		if (array.Length < 1 || array.Length > stage.RosterCapacity)
		{
			throw new InvalidOperationException("斗兽编组数量无效");
		}
		return TrySendRegisteredEvent("XBMStageDetailList", (AtkEventType)25, 9u);
	}

	public unsafe bool TryCommenceEntry()
	{
		RaptureAtkUnitManager* ptr = RaptureAtkUnitManager.Instance();
		if (ptr == null)
		{
			return false;
		}
		AtkUnitList* ptr2 = &((RaptureAtkUnitManager)ptr).AllLoadedUnitsList;
		for (int i = 0; i < Math.Min((int)((AtkUnitList)ptr2).Count, 256); i++)
		{
			AtkUnitBase* value = ((AtkUnitList)ptr2).Entries[i].Value;
			if (value == null || !((AtkUnitBase)value).IsVisible || !((AtkUnitBase)value).IsReady || (!((AtkUnitBase)value).NameString.Contains("ContentsFinder", StringComparison.Ordinal) && !ContainsText(&((AtkUnitBase)value).UldManager, "出发准备", 0)))
			{
				continue;
			}
			AtkResNode* ptr3 = FindTextButton(&((AtkUnitBase)value).UldManager, "Entry.DepartButton", 0);
			if (ptr3 != null)
			{
				DumpCommenceStructure(value);
				if (!UiInteractionDelay.Ready($"entry/commence/{value}/{((AtkResNode)ptr3).NodeId}"))
				{
					return false;
				}
				return ClickButton(value, ptr3);
			}
		}
		DiagnoseCommenceMiss();
		return false;
	}

	private unsafe static AtkResNode* FindTextButton(AtkUldManager* manager, string textKey, int depth)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Invalid comparison between Unknown and I4
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return null;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !Visible(ptr) || (int)((AtkResNode)ptr).Type < 1000)
			{
				continue;
			}
			AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
			if (component == null)
			{
				continue;
			}
			if ((int)((AtkComponentBase)component).GetComponentType() == 1)
			{
				AtkComponentButton* ptr2 = (AtkComponentButton*)component;
				object obj;
				if (((AtkComponentButton)ptr2).ButtonTextNode == null)
				{
					obj = null;
				}
				else
				{
					ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)((AtkComponentButton)ptr2).ButtonTextNode).NodeText)).StringPtr));
					obj = ((ReadOnlySeStringSpan)(ref val)).ExtractText().Trim();
				}
				string text = (string)obj;
				if (GameText.Matches(textKey, text) || FindChildText(&((AtkComponentBase)component).UldManager, textKey, depth + 1))
				{
					return ptr;
				}
			}
			else
			{
				AtkResNode* ptr3 = FindTextButton(&((AtkComponentBase)component).UldManager, textKey, depth + 1);
				if (ptr3 != null)
				{
					return ptr3;
				}
			}
		}
		return null;
	}

	private unsafe static bool FindChildText(AtkUldManager* manager, string textKey, int depth)
	{
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Invalid comparison between Unknown and I4
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return false;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr != null && Visible(ptr) && (int)((AtkResNode)ptr).Type == 3)
			{
				ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)ptr).NodeText)).StringPtr));
				if (GameText.Matches(textKey, ((ReadOnlySeStringSpan)(ref val)).ExtractText()))
				{
					return true;
				}
			}
		}
		return false;
	}

	private unsafe static bool ClickButton(AtkUnitBase* addon, AtkResNode* buttonNode)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		List<(nint, uint, bool)> list = new List<(nint, uint, bool)>();
		CollectClicks(&((AtkUnitBase)addon).UldManager, ((AtkResNode)buttonNode).NodeId, inside: false, list, 0);
		AtkEventData val = default(AtkEventData);
		(nint, uint, bool) tuple = list.FirstOrDefault<(nint, uint, bool)>(((nint evt, uint owner, bool direct) f) => f.direct);
		if (tuple.Item1 == 0 && list.Count > 0)
		{
			tuple = list[0];
		}
		if (tuple.Item1 != 0)
		{
			AtkEvent* item = (AtkEvent*)tuple.Item1;
			AtkEvent val2 = *item;
			((AtkEventListener)((AtkEvent)item).Listener).ReceiveEvent((AtkEventType)25, (int)((AtkEvent)item).Param, &val2, &val);
			TraceCommence($"{((AtkUnitBase)addon).NameString} node={((AtkResNode)buttonNode).NodeId} owner={tuple.Item2} param={((AtkEvent)item).Param} clicks={list.Count} via registered");
			return true;
		}
		AtkEvent val3 = default(AtkEvent);
		((AtkUnitBase)addon).ReceiveEvent((AtkEventType)25, (int)((AtkResNode)buttonNode).NodeId, &val3, &val);
		((AtkComponentBase)((AtkComponentNode)buttonNode).Component).ReceiveEvent((AtkEventType)25, 0, &val3, &val);
		TraceCommence($"{((AtkUnitBase)addon).NameString} node={((AtkResNode)buttonNode).NodeId} no registered click, fallback");
		return true;
	}

	private unsafe static void CollectClicks(AtkUldManager* manager, uint targetId, bool inside, List<(nint evt, uint owner, bool direct)> found, int depth)
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Invalid comparison between Unknown and I4
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Invalid comparison between Unknown and I4
		if (depth > 8 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null)
			{
				continue;
			}
			bool flag = inside || ((AtkResNode)ptr).NodeId == targetId;
			AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)ptr).AtkEventManager)).Event;
			int num = 0;
			while (ptr2 != null && num < 64)
			{
				if (flag && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 25 && ((AtkEvent)ptr2).Listener != null)
				{
					found.Add(((nint)ptr2, ((AtkResNode)ptr).NodeId, ((AtkResNode)ptr).NodeId == targetId));
				}
				num++;
				ptr2 = ((AtkEvent)ptr2).NextEvent;
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
				if (component != null)
				{
					CollectClicks(&((AtkComponentBase)component).UldManager, targetId, flag, found, depth + 1);
				}
			}
		}
	}

	private static void TraceCommence(string message)
	{
		try
		{
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			File.AppendAllText(Path.Combine(text, "arena-commence.jsonl"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Message = message
			}) + "\n");
		}
		catch
		{
		}
	}

	private unsafe static void DiagnoseCommenceMiss()
	{
		if (Environment.TickCount64 < nextCommenceDiagnoseAt)
		{
			return;
		}
		nextCommenceDiagnoseAt = Environment.TickCount64 + 2000;
		try
		{
			RaptureAtkUnitManager* ptr = RaptureAtkUnitManager.Instance();
			if (ptr == null)
			{
				return;
			}
			AtkUnitList* ptr2 = &((RaptureAtkUnitManager)ptr).AllLoadedUnitsList;
			List<string> list = new List<string>();
			for (int i = 0; i < Math.Min((int)((AtkUnitList)ptr2).Count, 256); i++)
			{
				AtkUnitBase* value = ((AtkUnitList)ptr2).Entries[i].Value;
				if (value != null && ((AtkUnitBase)value).IsVisible)
				{
					list.Add(((AtkUnitBase)value).NameString);
				}
			}
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			File.AppendAllText(Path.Combine(text, "arena-commence.jsonl"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Addons = list
			}) + "\n");
		}
		catch
		{
		}
	}

	private unsafe static AtkComponentButton* FindCommenceButton(AtkUnitBase* addon, AtkUldManager* manager, int depth)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Invalid comparison between Unknown and I4
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bc: Invalid comparison between Unknown and I4
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Invalid comparison between Unknown and I4
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return null;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !Visible(ptr))
			{
				continue;
			}
			if ((int)((AtkResNode)ptr).Type == 10000 && (int)((AtkComponentBase)((AtkComponentNode)ptr).Component).GetComponentType() == 1)
			{
				AtkComponentButton* component = (AtkComponentButton*)((AtkComponentNode)ptr).Component;
				if (component != null && ((AtkComponentButton)component).ButtonTextNode != null)
				{
					ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)((AtkComponentButton)component).ButtonTextNode).NodeText)).StringPtr));
					if (GameText.Matches("Entry.DepartButton", ((ReadOnlySeStringSpan)(ref val)).ExtractText()))
					{
						return component;
					}
				}
			}
			if ((int)((AtkResNode)ptr).Type < 1000)
			{
				continue;
			}
			AtkComponentBase* component2 = ((AtkComponentNode)ptr).Component;
			if (component2 != null)
			{
				AtkComponentButton* ptr2 = FindCommenceButton(addon, &((AtkComponentBase)component2).UldManager, depth + 1);
				if (ptr2 != null)
				{
					return ptr2;
				}
			}
		}
		return null;
	}

	private unsafe static void DumpCommenceStructure(AtkUnitBase* addon)
	{
		if (Environment.TickCount64 < nextStructureDumpAt)
		{
			return;
		}
		nextStructureDumpAt = Environment.TickCount64 + 2000;
		try
		{
			List<object> list = new List<object>();
			DumpNodes(&((AtkUnitBase)addon).UldManager, 0, list);
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			File.AppendAllText(Path.Combine(text, "arena-commence-structure.jsonl"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Addon = ((AtkUnitBase)addon).NameString,
				Ready = ((AtkUnitBase)addon).IsReady,
				Visible = ((AtkUnitBase)addon).IsVisible,
				Nodes = list
			}) + "\n");
		}
		catch
		{
		}
	}

	private unsafe static void DumpNodes(AtkUldManager* manager, int depth, List<object> output)
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Invalid comparison between Unknown and I4
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Invalid comparison between Unknown and I4
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e9: Expected I4, but got Unknown
		//IL_0109: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Invalid comparison between Unknown and I4
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Invalid comparison between Unknown and I4
		//IL_00c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 8 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null)
			{
				continue;
			}
			string text = null;
			string component = null;
			ReadOnlySeStringSpan val;
			if ((int)((AtkResNode)ptr).Type == 3)
			{
				val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)ptr).NodeText)).StringPtr));
				text = ((ReadOnlySeStringSpan)(ref val)).ExtractText();
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component2 = ((AtkComponentNode)ptr).Component;
				if (component2 != null)
				{
					component = ((object)((AtkComponentBase)component2).GetComponentType()/*cast due to .constrained prefix*/).ToString();
					if ((int)((AtkComponentBase)component2).GetComponentType() == 1)
					{
						AtkComponentButton* ptr2 = (AtkComponentButton*)component2;
						if (((AtkComponentButton)ptr2).ButtonTextNode != null)
						{
							val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)((AtkComponentButton)ptr2).ButtonTextNode).NodeText)).StringPtr));
							text = ((ReadOnlySeStringSpan)(ref val)).ExtractText();
						}
					}
				}
			}
			output.Add(new
			{
				Depth = depth,
				Id = (int)((AtkResNode)ptr).NodeId,
				Type = ((ushort)(int)((AtkResNode)ptr).Type).ToString(),
				Component = component,
				Text = text,
				Visible = ((AtkResNode)ptr).IsVisible(),
				Chain = Visible(ptr)
			});
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component3 = ((AtkComponentNode)ptr).Component;
				if (component3 != null)
				{
					DumpNodes(&((AtkComponentBase)component3).UldManager, depth + 1, output);
				}
			}
		}
	}

	private unsafe static bool ContainsText(AtkUldManager* manager, string text, int depth)
	{
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Invalid comparison between Unknown and I4
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Invalid comparison between Unknown and I4
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return false;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !Visible(ptr))
			{
				continue;
			}
			if ((int)((AtkResNode)ptr).Type == 3)
			{
				ReadOnlySeStringSpan val = new ReadOnlySeStringSpan(CStringPointer.op_Implicit(((Utf8String)(&((AtkTextNode)ptr).NodeText)).StringPtr));
				if (((ReadOnlySeStringSpan)(ref val)).ExtractText().Contains(text, StringComparison.Ordinal))
				{
					return true;
				}
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
				if (component != null && ContainsText(&((AtkComponentBase)component).UldManager, text, depth + 1))
				{
					return true;
				}
			}
		}
		return false;
	}

	public unsafe bool TryConfirmEntry()
	{
		AtEntrance();
		ArenaEntryView arenaEntryView = Read();
		if (arenaEntryView.Phase == ArenaEntryPhase.Loading)
		{
			return false;
		}
		if (arenaEntryView.Phase != ArenaEntryPhase.EntryConfirmation || arenaEntryView.StageId != stage.Id || arenaEntryView.Roster.Length < 1 || arenaEntryView.Roster.Length > stage.RosterCapacity)
		{
			throw new InvalidOperationException("当前不是斗兽入场警告确认");
		}
		AtkUnitBase* ptr = Addon("SelectYesno");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		AtkComponentButton* yesButton = ((AddonSelectYesno)ptr).YesButton;
		if (yesButton == null || ((AtkComponentButton)yesButton).OwnerNode == null || !Visible((AtkResNode*)((AtkComponentButton)yesButton).OwnerNode) || !((AtkComponentButton)yesButton).IsEnabled)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"entry/confirm/{ptr}"))
		{
			return false;
		}
		Fire(ptr, default(int));
		return true;
	}

	private unsafe bool TrySendRegisteredEvent(string name, AtkEventType type, uint parameter)
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Expected I4, but got Unknown
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Expected I4, but got Unknown
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0169: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0178: Unknown result type (might be due to invalid IL or missing references)
		AtEntrance();
		AtkUnitBase* ptr = Addon(name);
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return WaitForList(name, null, -1, "addon not ready");
		}
		HashSet<nint> hashSet = new HashSet<nint>();
		FindEvents(&((AtkUnitBase)ptr).UldManager, (AtkEventListener*)ptr, type, parameter, hashSet, 0);
		if (hashSet.Count == 0)
		{
			return WaitForList(name, null, -1, $"control not ready ({(int)type}/{parameter})");
		}
		if (hashSet.Count != 1)
		{
			throw new InvalidOperationException($"{name} 的操作控件不唯一（{(int)type}/{parameter}）");
		}
		if (!UiInteractionDelay.Ready($"entry/event/{ptr}/{type}/{parameter}"))
		{
			return false;
		}
		lastListWait = null;
		AtkEvent* ptr2 = (AtkEvent*)hashSet.Single();
		AtkEvent val = *ptr2;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr2).Listener).ReceiveEvent(type, (int)parameter, &val, &val2);
		return true;
	}

	internal unsafe static void FindEvents(AtkUldManager* manager, AtkEventListener* listener, AtkEventType type, uint parameter, HashSet<nint> found, int depth)
	{
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Invalid comparison between Unknown and I4
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		if (depth > 6 || ((AtkUldManager)manager).NodeList == null || ((AtkUldManager)manager).NodeListCount > 2048)
		{
			return;
		}
		for (int i = 0; i < ((AtkUldManager)manager).NodeListCount; i++)
		{
			AtkResNode* ptr = ((AtkUldManager)manager).NodeList[i];
			if (ptr == null || !Visible(ptr))
			{
				continue;
			}
			AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)ptr).AtkEventManager)).Event;
			int num = 0;
			while (ptr2 != null && num < 64)
			{
				if (((Enum)((AtkResNode)ptr).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32) && ((AtkEvent)ptr2).Listener == listener && ((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == type && ((AtkEvent)ptr2).Param == parameter)
				{
					found.Add((nint)ptr2);
				}
				num++;
				ptr2 = ((AtkEvent)ptr2).NextEvent;
			}
			if ((int)((AtkResNode)ptr).Type >= 1000)
			{
				AtkComponentBase* component = ((AtkComponentNode)ptr).Component;
				if (component != null)
				{
					FindEvents(&((AtkComponentBase)component).UldManager, listener, type, parameter, found, depth + 1);
				}
			}
		}
	}

	private unsafe static bool Visible(AtkResNode* node)
	{
		int num = 0;
		while (node != null && num < 32)
		{
			if (!((AtkResNode)node).IsVisible())
			{
				return false;
			}
			num++;
			node = ((AtkResNode)node).ParentNode;
		}
		return node == null;
	}

	public void Cancel()
	{
		approach?.Cancel();
		approach = null;
		landing?.Cancel();
		landing = null;
		pageSent = null;
		pageAttempts = 0;
		if (ownsNotebook)
		{
			notebook.CancelScan("斗兽已暂停或停止");
			notebook.Close();
			ownsNotebook = false;
		}
	}
}
