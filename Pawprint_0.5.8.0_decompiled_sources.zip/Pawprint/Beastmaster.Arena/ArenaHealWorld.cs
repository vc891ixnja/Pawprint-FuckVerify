using System;
using System.Linq;
using System.Runtime.CompilerServices;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Arena;

internal sealed class ArenaHealWorld(Func<bool> authorized, ArenaStage stage, bool duringBattle = false, bool allItems = false, bool selfTarget = false) : IArenaHealWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private ArenaHealItem? requested;

	private long nextUiActionAt;

	public bool DuringBattle => duringBattle;

	public bool DirectDispatch => true;

	public unsafe ArenaHealView Read()
	{
		//IL_019e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		if (!authorized() || !Services.ClientState.IsLoggedIn || character == 0L || character != Services.PlayerState.ContentId || Services.ClientState.TerritoryType != stage.Territory || GameMain.Instance() == null || ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId != stage.Content)
		{
			throw new InvalidOperationException("回血任务、角色或奇盘已变化");
		}
		ICondition condition = Services.Condition;
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null || condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35])
		{
			return new ArenaHealView(ArenaHealPhase.Loading, 0u, 0u, Array.Empty<ArenaHealItem>());
		}
		if (duringBattle && (!condition[(ConditionFlag)26] || ArenaBoardRoute.IsOnBoard(stage.Id, ((IGameObject)localPlayer).Position) || ArenaUtilityUi.Addon("XBMResult") != null || ArenaUtilityUi.Addon("XBMContentsBooty") != null || ArenaUtilityUi.Addon("XBMContentsTreasure") != null || ArenaUtilityUi.Addon("XBMStageDetailList") != null))
		{
			return new ArenaHealView(ArenaHealPhase.Ended, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, Array.Empty<ArenaHealItem>());
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsMainHUD");
		AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("ContextMenu");
		AgentContext* ptr3 = AgentContext.Instance();
		bool flag = requested != null && ptr != null && ptr2 != null && ptr3 != null && ((AgentContext)ptr3).OwnerAddon == ((AtkUnitBase)ptr).Id;
		if (((IGameObject)localPlayer).IsDead || ((ICharacter)localPlayer).ClassJob.RowId != 43 || (!duringBattle && condition[(ConditionFlag)26]) || (!flag && (condition[(ConditionFlag)33] || condition[(ConditionFlag)31])) || !stage.HasNavigationRoute || (duringBattle ? ArenaBoardRoute.IsOnBoard(stage.Id, ((IGameObject)localPlayer).Position) : (!ArenaBoardRoute.IsOnBoard(stage.Id, ((IGameObject)localPlayer).Position))) || ArenaUtilityUi.Addon("XBMPetParty") != null || ArenaUtilityUi.Addon("XBMStageDetailList") != null || ArenaUtilityUi.Addon("XBMContentsBooty") != null || ArenaUtilityUi.Addon("XBMContentsTreasure") != null || ArenaUtilityUi.Addon("XBMContentsItemShop") != null || ArenaUtilityUi.Addon("SelectYesno") != null || ArenaUtilityUi.Addon("SelectOk") != null || ArenaUtilityUi.Addon("XBMResult") != null)
		{
			return new ArenaHealView(ArenaHealPhase.Blocked, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, Array.Empty<ArenaHealItem>());
		}
		ArenaValue[] array = ArenaUtilityUi.Values(ptr);
		if (array.Length == 0)
		{
			return new ArenaHealView(ArenaHealPhase.Loading, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, Array.Empty<ArenaHealItem>());
		}
		ArenaHealItem[] items;
		try
		{
			items = ArenaHealPolicy.Decode(array);
		}
		catch (InvalidOperationException)
		{
			return new ArenaHealView(ArenaHealPhase.Blocked, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, Array.Empty<ArenaHealItem>());
		}
		if (ptr2 == null)
		{
			return new ArenaHealView(ArenaHealPhase.Board, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, items);
		}
		if (!flag)
		{
			return new ArenaHealView(ArenaHealPhase.Blocked, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, items);
		}
		return new ArenaHealView(((AtkUnitBase)ptr2).IsReady ? ArenaHealPhase.Menu : ArenaHealPhase.Loading, ((ICharacter)localPlayer).CurrentHp, ((ICharacter)localPlayer).MaxHp, items);
	}

	private bool HasItem(ArenaHealView view, ArenaHealItem item)
	{
		if (view.Items.Any((ArenaHealItem i) => i.Slot == item.Slot && i.ItemId == item.ItemId && i.Usable))
		{
			if (!allItems)
			{
				return ArenaHealPolicy.Healing(item.ItemId) > 0;
			}
			return true;
		}
		return false;
	}

	public bool TryDispatch(ArenaHealItem item)
	{
		ArenaHealView arenaHealView = Read();
		if (arenaHealView.Phase == ArenaHealPhase.Loading)
		{
			return false;
		}
		if (arenaHealView.Phase != ArenaHealPhase.Board || !HasItem(arenaHealView, item))
		{
			return false;
		}
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null)
		{
			return false;
		}
		if (Environment.TickCount64 < nextUiActionAt)
		{
			return false;
		}
		nextUiActionAt = Environment.TickCount64 + 500;
		requested = item;
		long num;
		if (!allItems || selfTarget)
		{
			num = (long)((IGameObject)localPlayer).GameObjectId;
		}
		else
		{
			IGameObject target = Services.Targets.Target;
			num = (long)((target != null) ? target.GameObjectId : ((IGameObject)localPlayer).GameObjectId);
		}
		ulong num2 = (ulong)num;
		int slot = item.Slot;
		uint itemId = item.ItemId;
		ulong targetGameObjectId = num2;
		uint itemId2 = item.ItemId;
		bool selfOnly = itemId2 - 142 <= 1;
		bool flag = ArenaItemDispatch.TryUse(slot, itemId, targetGameObjectId, fallbackToSelf: true, selfOnly);
		Services.Log.Information($"Arena item: dispatched slot {item.Slot}, item {item.ItemId}, target {num2:X}, sent={flag}, allItems={allItems}", Array.Empty<object>());
		return flag;
	}

	public unsafe bool TryOpen(ArenaHealItem item)
	{
		ArenaHealView arenaHealView = Read();
		if (arenaHealView.Phase == ArenaHealPhase.Loading)
		{
			return false;
		}
		if (arenaHealView.Phase != ArenaHealPhase.Board || !HasItem(arenaHealView, item))
		{
			return false;
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsMainHUD");
		if (ptr == null)
		{
			return false;
		}
		if (Environment.TickCount64 < nextUiActionAt)
		{
			return false;
		}
		nextUiActionAt = Environment.TickCount64 + ArenaHealPolicy.UiIntervalMilliseconds(duringBattle);
		requested = item;
		Submit(ptr, ArenaMedicineProtocol.Open(item.Slot));
		Services.Log.Information($"Arena heal: opened slot {item.Slot}, item {item.ItemId}", Array.Empty<object>());
		return true;
	}

	public unsafe bool TryUse(ArenaHealItem item)
	{
		ArenaHealView arenaHealView = Read();
		if (arenaHealView.Phase == ArenaHealPhase.Loading)
		{
			return false;
		}
		if (arenaHealView.Phase != ArenaHealPhase.Menu || requested != item || !HasItem(arenaHealView, item))
		{
			return false;
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("ContextMenu");
		ArenaValue[] values = ArenaUtilityUi.Values(ptr);
		if (ptr == null)
		{
			return false;
		}
		int? num = ArenaMedicineProtocol.UseRow(values);
		if (num.HasValue)
		{
			int valueOrDefault = num.GetValueOrDefault();
			if (Environment.TickCount64 < nextUiActionAt)
			{
				return false;
			}
			nextUiActionAt = Environment.TickCount64 + ArenaHealPolicy.UiIntervalMilliseconds(duringBattle);
			Submit(ptr, ArenaMedicineProtocol.Use(valueOrDefault));
			Services.Log.Information($"Arena item: using item {item.ItemId} from slot {item.Slot}, allItems={allItems}", Array.Empty<object>());
			return true;
		}
		return false;
	}

	private unsafe static void Submit(AtkUnitBase* addon, ArenaMedicineArgument[] payload)
	{
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		AtkValue* ptr = (AtkValue*)stackalloc AtkValue[payload.Length];
		AtkValue val = default(AtkValue);
		for (int i = 0; i < payload.Length; i++)
		{
			byte* num = (byte*)ptr + (nint)i * (nint)Unsafe.SizeOf<AtkValue>();
			((AtkValue)(ref val))._002Ector();
			val.Type = (AtkValueType)payload[i].Type;
			val.Int = payload[i].Value;
			Unsafe.Write(num, val);
		}
		((AtkUnitBase)addon).FireCallback((uint)payload.Length, ptr, true);
	}

	public unsafe void RestoreTarget()
	{
		if (requested != null && Services.PlayerState.ContentId == character && Services.ClientState.TerritoryType == stage.Territory)
		{
			AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsMainHUD");
			AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("ContextMenu");
			AgentContext* ptr3 = AgentContext.Instance();
			if (ptr != null && ptr2 != null && ptr3 != null && ((AgentContext)ptr3).OwnerAddon == ((AtkUnitBase)ptr).Id)
			{
				((AtkUnitBase)ptr2).Close(true);
			}
			requested = null;
		}
	}
}
