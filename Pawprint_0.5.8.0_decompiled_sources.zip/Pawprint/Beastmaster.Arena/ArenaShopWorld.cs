using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaShopWorld(Func<bool> authorized, ArenaStage stage) : IArenaShopWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private string? lastError;

	public IArenaEquipmentWorld Equipment { get; } = new ArenaEquipmentWorld(authorized, stage);

	private unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	private unsafe static ArenaValue[] Snapshot(AtkUnitBase* a)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Expected I4, but got Unknown
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_00da: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Invalid comparison between Unknown and I4
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Invalid comparison between Unknown and I4
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		bool flag = a == null || !((AtkUnitBase)a).IsReady || ((AtkUnitBase)a).AtkValues == null;
		if (!flag)
		{
			ushort atkValuesCount = ((AtkUnitBase)a).AtkValuesCount;
			bool flag2 = ((atkValuesCount > 4096 || atkValuesCount == 0) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return Array.Empty<ArenaValue>();
		}
		ArenaValue[] array = new ArenaValue[((AtkUnitBase)a).AtkValuesCount];
		for (int i = 0; i < array.Length; i++)
		{
			AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[i];
			AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
			long? number = (val2 - 2) switch
			{
				3 => val.UInt, 
				1 => val.Int, 
				0 => val.Bool ? 1 : 0, 
				_ => null, 
			};
			flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
			object obj;
			if (!flag || val.String.Value == null)
			{
				obj = null;
			}
			else
			{
				ReadOnlySeStringSpan val3 = new ReadOnlySeStringSpan(val.String.Value);
				obj = ((ReadOnlySeStringSpan)(ref val3)).ExtractText();
			}
			string text = (string)obj;
			array[i] = new ArenaValue(i, number, text);
		}
		return array;
	}

	public unsafe ArenaShopView Read()
	{
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		ICondition condition = Services.Condition;
		bool flag = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		int num = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		if (authorized() && Services.ClientState.IsLoggedIn && character != 0L && (Services.PlayerState.ContentId == character || (flag && Services.PlayerState.ContentId == 0L)) && (Services.ClientState.TerritoryType == stage.Territory || (flag && Services.ClientState.TerritoryType == 0)) && (num == stage.Content || (flag && num == 0)))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || !((IGameObject)localPlayer).IsDead)
			{
				IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
				if (localPlayer2 == null || ((ICharacter)localPlayer2).ClassJob.RowId == 43)
				{
					ArenaShopContents contents = new ArenaShopContents(0u, Array.Empty<ArenaShopOffer>(), Array.Empty<uint>(), 0, 0);
					if (flag || Services.Objects.LocalPlayer == null)
					{
						return new ArenaShopView(ArenaShopPhase.Loading, contents);
					}
					if (condition[(ConditionFlag)26] || Addon("XBMStageDetailList") != null || Addon("XBMContentsTreasure") != null || Addon("XBMContentsBooty") != null)
					{
						return new ArenaShopView(ArenaShopPhase.Blocked, contents);
					}
					AtkUnitBase* ptr = Addon("XBMContentsItemShop");
					AtkUnitBase* ptr2 = Addon("SelectYesno");
					AtkUnitBase* ptr3 = Addon("SelectOk");
					AtkUnitBase* ptr4 = Addon("XBMPetParty");
					if (ptr == null)
					{
						return new ArenaShopView((ptr2 != null || ptr3 != null || ptr4 != null) ? ArenaShopPhase.Blocked : ((!condition[(ConditionFlag)33] && !condition[(ConditionFlag)31] && Addon("XBMContentsMainHUD") != null) ? ArenaShopPhase.Returned : ArenaShopPhase.Loading), contents);
					}
					ArenaValue[] values = Snapshot(ptr);
					ArenaValue[] array = Snapshot(ptr4);
					ArenaShopPet[] pets = null;
					uint foodId = 0u;
					ArenaShopContents contents2;
					try
					{
						contents2 = ArenaShopDecoder.Decode(values);
						if (ptr4 != null)
						{
							(foodId, pets) = ArenaShopDecoder.Feeding(array);
						}
						lastError = null;
					}
					catch (InvalidOperationException ex)
					{
						if (lastError != ex.Message)
						{
							lastError = ex.Message;
							Services.Log.Warning("Arena shop waiting: " + ex.Message, Array.Empty<object>());
							try
							{
								string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
								Directory.CreateDirectory(text);
								File.WriteAllText(Path.Combine(text, "arena-shop-latest.json"), JsonSerializer.Serialize(new
								{
									At = DateTimeOffset.Now,
									Error = ex.Message,
									Values = values,
									Party = array
								}));
							}
							catch (Exception ex2)
							{
								Services.Log.Warning(ex2, "Shop diagnostic failed", Array.Empty<object>());
							}
						}
						return new ArenaShopView(ArenaShopPhase.Loading, contents);
					}
					if (ptr2 != null || ptr3 != null)
					{
						string text2 = Snapshot((ptr2 != null) ? ptr2 : ptr3).FirstOrDefault()?.Text;
						return new ArenaShopView((!string.IsNullOrWhiteSpace(text2)) ? ((ptr3 != null) ? ArenaShopPhase.Duplicate : ArenaShopPhase.Confirmation) : ArenaShopPhase.Loading, contents2, pets, foodId, text2 ?? "");
					}
					return new ArenaShopView((ptr4 == null) ? ArenaShopPhase.Selection : ArenaShopPhase.Feeding, contents2, pets, foodId);
				}
			}
		}
		throw new InvalidOperationException("商店任务、角色或奇盘已变化");
	}

	private unsafe static bool ListClick(AtkUnitBase* a, uint nodeId, int row, uint parameter)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Invalid comparison between Unknown and I4
		AtkComponentList* componentListById = ((AtkUnitBase)a).GetComponentListById(nodeId);
		if (componentListById == null || ((AtkComponentList)componentListById).OwnerNode == null || !((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).IsVisible() || !((Enum)((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32) || !((AtkComponentList)componentListById).IsItemInteractionEnabled || ((AtkComponentList)componentListById).IsUpdatePending || row < 0 || row >= ((AtkComponentList)componentListById).ListLength || ((AtkComponentList)componentListById).GetItemDisabledState(row))
		{
			return false;
		}
		int num = 0;
		AtkEvent* ptr = ((AtkEventManager)(&((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).AtkEventManager)).Event;
		int num2 = 0;
		while (ptr != null && num2 < 64)
		{
			if (((AtkEvent)ptr).Listener == a && (int)((AtkEventState)(&((AtkEvent)ptr).State)).EventType == 35 && ((AtkEvent)ptr).Param == parameter)
			{
				num++;
			}
			num2++;
			ptr = ((AtkEvent)ptr).NextEvent;
		}
		switch (num)
		{
		case 0:
			return false;
		default:
			throw new InvalidOperationException("商店列表事件不唯一");
		case 1:
			if (row < ((AtkComponentList)componentListById).FirstVisibleItemIndex || row >= ((AtkComponentList)componentListById).FirstVisibleItemIndex + ((AtkComponentList)componentListById).NumVisibleItems)
			{
				if (UiInteractionDelay.Ready($"shop/scroll/{a}/{row}"))
				{
					((AtkComponentList)componentListById).ScrollToItem((short)row);
				}
				return false;
			}
			if (!UiInteractionDelay.Ready($"shop/list/{a}/{row}/{parameter}"))
			{
				return false;
			}
			((AtkComponentList)componentListById).SelectItem(row, false);
			((AtkComponentList)componentListById).DispatchItemEvent(row, (AtkEventType)35);
			return true;
		}
	}

	public unsafe bool TryOpen(ArenaShopOffer offer)
	{
		//IL_0181: Unknown result type (might be due to invalid IL or missing references)
		//IL_0186: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01af: Unknown result type (might be due to invalid IL or missing references)
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Selection)
		{
			return false;
		}
		ArenaShopOffer arenaShopOffer = arenaShopView.Contents.Offers.FirstOrDefault((ArenaShopOffer o) => o.ItemId == offer.ItemId);
		if (arenaShopOffer == null || arenaShopOffer.Sold || arenaShopView.Contents.Balance < arenaShopOffer.Price)
		{
			return false;
		}
		if (ArenaItemCatalog.Items[arenaShopOffer.ItemId].Category != 2 && ((ReadOnlySpan<uint>)arenaShopView.Contents.Owned).Contains(arenaShopOffer.ItemId))
		{
			return false;
		}
		AtkUnitBase* ptr = Addon("XBMContentsItemShop");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		HashSet<nint> hashSet = new HashSet<nint>();
		ArenaEntryWorld.FindEvents(&((AtkUnitBase)ptr).UldManager, (AtkEventListener*)ptr, (AtkEventType)35, 2u, hashSet, 0);
		if (hashSet.Count == 0)
		{
			return false;
		}
		if (hashSet.Count != 1)
		{
			throw new InvalidOperationException("商店商品点击事件不唯一");
		}
		if (!UiInteractionDelay.Ready($"shop/offer/{ptr}/{arenaShopOffer.Row}/{arenaShopOffer.ItemId}/{arenaShopOffer.Price}"))
		{
			return false;
		}
		AtkEvent val = Unsafe.Read<AtkEvent>((void*)hashSet.Single());
		AtkEventData val2 = new AtkEventData
		{
			ListItemData = 
			{
				SelectedIndex = arenaShopOffer.Row
			},
			ListItemData = 
			{
				MouseButtonId = 0
			}
		};
		((AtkEventListener)val.Listener).ReceiveEvent((AtkEventType)35, 2, &val, &val2);
		Services.Log.Information($"Arena shop choose row={arenaShopOffer.Row}, item={arenaShopOffer.ItemId}, price={arenaShopOffer.Price}, balance={arenaShopView.Contents.Balance}", Array.Empty<object>());
		return true;
	}

	public unsafe bool TrySell(uint itemId)
	{
		//IL_0156: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_016c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a9: Unknown result type (might be due to invalid IL or missing references)
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Selection || !((ReadOnlySpan<uint>)arenaShopView.Contents.Owned).Contains(itemId))
		{
			throw new InvalidOperationException("出售目标不在当前持有列表中");
		}
		AtkUnitBase* ptr = Addon("XBMContentsItemShop");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		ArenaValue[] array = Snapshot(ptr);
		int? value = null;
		for (int i = 0; i < 20; i++)
		{
			if (value.HasValue)
			{
				break;
			}
			int num = ((i < 10) ? (154 + i * 5) : (205 + (i - 10) * 5));
			if (array.Length > num + 3 && array[num + 3].Number == itemId)
			{
				value = i;
			}
		}
		if (!value.HasValue)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"shop/sell/{itemId}/{value}"))
		{
			return false;
		}
		bool flag = value.Value < 10;
		AtkValue* ptr2 = (AtkValue*)stackalloc AtkValue[2];
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = (flag ? 3 : 4);
		Unsafe.Write(ptr2, val);
		byte* num2 = (byte*)ptr2 + Unsafe.SizeOf<AtkValue>();
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = (flag ? value.Value : (value.Value - 10));
		Unsafe.Write(num2, val);
		((AtkUnitBase)ptr).FireCallback(2u, ptr2, true);
		Services.Log.Information($"Arena shop sell item={itemId}, slot={value}, callback=[{((AtkValue)ptr2).Int},{((AtkValue)((byte*)ptr2 + Unsafe.SizeOf<AtkValue>())).Int}]", Array.Empty<object>());
		return true;
	}

	public unsafe bool TryFeed(uint number)
	{
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		ArenaShopPet arenaShopPet = arenaShopView.Pets?.SingleOrDefault((ArenaShopPet p) => p.Number == number);
		if (arenaShopView.Phase != ArenaShopPhase.Feeding || arenaShopPet == null || arenaShopPet.Hp == 0 || arenaShopPet.FoodId != 0 || !ArenaFoodPolicy.CanEat(number, arenaShopView.FoodId))
		{
			throw new InvalidOperationException("当前魔兽不能使用该食料");
		}
		return ListClick(Addon("XBMPetParty"), 11u, arenaShopPet.Row, 0u);
	}

	private unsafe static bool ClickButton(AtkUnitBase* a, uint nodeId, uint parameter)
	{
		AtkComponentButton* componentButtonById = ((AtkUnitBase)a).GetComponentButtonById(nodeId);
		if (componentButtonById == null || ((AtkComponentButton)componentButtonById).OwnerNode == null || !((AtkComponentNode)((AtkComponentButton)componentButtonById).OwnerNode).IsVisible() || !((AtkComponentButton)componentButtonById).IsEnabled)
		{
			return false;
		}
		return DispatchButton(a, ((AtkComponentButton)componentButtonById).OwnerNode, parameter);
	}

	private unsafe static bool DispatchButton(AtkUnitBase* a, AtkComponentNode* node, uint? parameter)
	{
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Invalid comparison between Unknown and I4
		AtkEvent* ptr = null;
		AtkEvent* ptr2 = ((AtkEventManager)(&((AtkComponentNode)node).AtkEventManager)).Event;
		int num = 0;
		while (ptr2 != null && num < 64)
		{
			if (((AtkEvent)ptr2).Listener == a && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 25 && (!parameter.HasValue || ((AtkEvent)ptr2).Param == parameter))
			{
				if (ptr != null)
				{
					throw new InvalidOperationException("商店按钮事件不唯一");
				}
				ptr = ptr2;
			}
			num++;
			ptr2 = ((AtkEvent)ptr2).NextEvent;
		}
		if (ptr == null)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"shop/button/{a}/{node}/{parameter}"))
		{
			return false;
		}
		AtkEvent val = *ptr;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr).Listener).ReceiveEvent((AtkEventType)25, (int)((AtkEvent)ptr).Param, &val, &val2);
		return true;
	}

	public unsafe bool TryBack()
	{
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Feeding)
		{
			throw new InvalidOperationException("当前不是食料选择窗口");
		}
		return ClickButton(Addon("XBMPetParty"), 21u, 3u);
	}

	public unsafe bool TryExit()
	{
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Selection)
		{
			throw new InvalidOperationException("当前不是商店窗口");
		}
		return ClickButton(Addon("XBMContentsItemShop"), 40u, 0u);
	}

	public unsafe bool TryAnswer(string prompt, bool yes)
	{
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Confirmation || ArenaShopDecoder.Compact(arenaShopView.Prompt) != ArenaShopDecoder.Compact(prompt))
		{
			throw new InvalidOperationException("商店确认窗口已变化");
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)Addon("SelectYesno");
		AtkComponentButton* ptr2 = (yes ? ((AddonSelectYesno)ptr).YesButton : ((AddonSelectYesno)ptr).NoButton);
		if (ptr2 == null || !((AtkComponentButton)ptr2).IsEnabled)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"shop/answer/{ptr}/{arenaShopView.Prompt}/{yes}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = ((!yes) ? 1 : 0);
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}

	public unsafe bool TryDismissDuplicate(string prompt)
	{
		ArenaShopView arenaShopView = Read();
		if (arenaShopView.Phase == ArenaShopPhase.Loading)
		{
			return false;
		}
		if (arenaShopView.Phase != ArenaShopPhase.Duplicate || arenaShopView.Prompt != prompt || !arenaShopView.Contents.Offers.Any((ArenaShopOffer o) => ArenaShopDecoder.IsDuplicate(prompt, o.ItemId)))
		{
			throw new InvalidOperationException("不是商店重复持有提示");
		}
		AddonSelectOk* ptr = (AddonSelectOk*)Addon("SelectOk");
		AtkComponentButton* okButton = ((AddonSelectOk)ptr).OkButton;
		if (okButton != null && ((AtkComponentButton)okButton).OwnerNode != null && ((AtkComponentButton)okButton).IsEnabled)
		{
			return DispatchButton((AtkUnitBase*)ptr, ((AtkComponentButton)okButton).OwnerNode, null);
		}
		return false;
	}
}
