using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Beastmaster.Core.I18N;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaRestWorld(Func<bool> authorized, ArenaStage stage, int restBelowPercent = 100) : IArenaRestWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private string? lastError;

	private string? lastBlocked;

	private DateTime blockedWrittenAt;

	public IArenaEquipmentWorld Equipment { get; } = new ArenaEquipmentWorld(authorized, stage);

	public IArenaRewardWorld Rewards { get; } = new ArenaRewardWorld(authorized, stage);

	public unsafe static bool HasRestUi => Num(Addon("XBMPetParty"), 2) == 4;

	private unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	private unsafe static long Num(AtkUnitBase* a, int i)
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected I4, but got Unknown
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || ((AtkUnitBase)a).AtkValues == null || i >= ((AtkUnitBase)a).AtkValuesCount)
		{
			return -1L;
		}
		AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[i];
		AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
		return (val2 - 2) switch
		{
			3 => val.UInt, 
			1 => val.Int, 
			0 => val.Bool ? 1 : 0, 
			_ => -1L, 
		};
	}

	private unsafe static string Text(AtkUnitBase* a, int i)
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Invalid comparison between Unknown and I4
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Invalid comparison between Unknown and I4
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (a == null || ((AtkUnitBase)a).AtkValues == null || i >= ((AtkUnitBase)a).AtkValuesCount)
		{
			return "";
		}
		AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[i];
		AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
		bool flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
		if (!flag || val.String.Value == null)
		{
			return "";
		}
		ReadOnlySeStringSpan val3 = new ReadOnlySeStringSpan(val.String.Value);
		return ((ReadOnlySeStringSpan)(ref val3)).ExtractText();
	}

	private unsafe void Validate(bool loading)
	{
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		int num = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		if (authorized() && Services.ClientState.IsLoggedIn && character != 0L && (Services.PlayerState.ContentId == character || (loading && Services.PlayerState.ContentId == 0L)) && (Services.ClientState.TerritoryType == stage.Territory || (loading && Services.ClientState.TerritoryType == 0)) && (num == stage.Content || (loading && num == 0)))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || !((IGameObject)localPlayer).IsDead)
			{
				IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
				if (localPlayer2 == null || ((ICharacter)localPlayer2).ClassJob.RowId == 43)
				{
					return;
				}
			}
		}
		throw new InvalidOperationException("休息任务、角色或奇盘已变化");
	}

	public unsafe ArenaRestView Read()
	{
		ICondition condition = Services.Condition;
		bool flag = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		Validate(flag);
		if (flag || Services.Objects.LocalPlayer == null)
		{
			return new ArenaRestView(ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
		}
		AtkUnitBase* ptr = Addon("XBMPetParty");
		AtkUnitBase* ptr2 = Addon("SelectYesno");
		AtkUnitBase* ptr3 = Addon("XBMContentsBooty");
		if (ptr2 != null && (!((AtkUnitBase)ptr2).IsReady || string.IsNullOrWhiteSpace(Text(ptr2, 0))))
		{
			return new ArenaRestView(ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
		}
		if (ptr3 != null)
		{
			if (!((AtkUnitBase)ptr3).IsReady)
			{
				return new ArenaRestView(ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
			}
			if (ptr2 == null)
			{
				return new ArenaRestView(ArenaRestPhase.Reward, Array.Empty<ArenaRestPet>());
			}
			if (!GameText.Matches("Reward.TakeAllConfirm", Text(ptr2, 0)))
			{
				return Blocked("奖励确认待识别");
			}
			return new ArenaRestView(ArenaRestPhase.RewardConfirmation, Array.Empty<ArenaRestPet>());
		}
		if (ptr != null && Num(ptr, 2) == 4)
		{
			if (ptr2 != null && ArenaRestDecoder.IsLeavePrompt(Text(ptr2, 0)))
			{
				return new ArenaRestView(ArenaRestPhase.LeaveConfirmation, Array.Empty<ArenaRestPet>());
			}
			bool flag2 = !((AtkUnitBase)ptr).IsReady || ((AtkUnitBase)ptr).AtkValues == null;
			if (!flag2)
			{
				ushort atkValuesCount = ((AtkUnitBase)ptr).AtkValuesCount;
				bool flag3 = ((atkValuesCount < 6 || atkValuesCount > 4096) ? true : false);
				flag2 = flag3;
			}
			if (flag2)
			{
				return new ArenaRestView(ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
			}
			ArenaValue[] array = new ArenaValue[((AtkUnitBase)ptr).AtkValuesCount];
			for (int i = 0; i < array.Length; i++)
			{
				array[i] = new ArenaValue(i, Num(ptr, i), Text(ptr, i));
			}
			try
			{
				ArenaRestPet[] array2 = ArenaRestDecoder.Decode(array);
				int capacity = ArenaRestDecoder.Capacity(array);
				lastError = null;
				if (ptr2 != null)
				{
					string text = Text(ptr2, 0);
					if (ArenaRestDecoder.MatchesPrompt(text, array2.Where((ArenaRestPet p) => p.Selected)))
					{
						return new ArenaRestView(ArenaRestPhase.Confirmation, array2, capacity);
					}
					if (ArenaRestDecoder.IsRestPrompt(text))
					{
						return new ArenaRestView(ArenaRestPhase.StaleConfirmation, array2, capacity);
					}
					return Blocked("休息确认待识别");
				}
				return new ArenaRestView(ArenaRestPhase.Selection, array2, capacity);
			}
			catch (InvalidOperationException ex)
			{
				if (lastError != ex.Message)
				{
					lastError = ex.Message;
					Services.Log.Warning("Arena rest waiting: " + ex.Message, Array.Empty<object>());
					try
					{
						string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
						Directory.CreateDirectory(text2);
						File.WriteAllText(Path.Combine(text2, "arena-rest-latest.json"), JsonSerializer.Serialize(new
						{
							At = DateTimeOffset.Now,
							Error = ex.Message,
							Values = array
						}));
					}
					catch (Exception ex2)
					{
						Services.Log.Warning(ex2, "Rest diagnostic failed", Array.Empty<object>());
					}
				}
				return new ArenaRestView(ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
			}
		}
		if (ptr2 != null || Addon("SelectOk") != null)
		{
			return Blocked("等待弹窗交接");
		}
		if (ptr != null || condition[(ConditionFlag)26] || Addon("XBMStageDetailList") != null || Addon("XBMContentsItemShop") != null)
		{
			return Blocked("等待休息窗口");
		}
		lastBlocked = null;
		return new ArenaRestView((!condition[(ConditionFlag)33] && !condition[(ConditionFlag)31] && Addon("XBMContentsMainHUD") != null) ? ArenaRestPhase.Returned : ArenaRestPhase.Loading, Array.Empty<ArenaRestPet>());
	}

	private unsafe ArenaRestView Blocked(string reason)
	{
		AtkUnitBase* a = Addon("XBMPetParty");
		string text = Text(Addon("SelectYesno"), 0);
		string[] array = new string[6] { "XBMPetParty", "SelectYesno", "SelectOk", "XBMContentsBooty", "XBMStageDetailList", "XBMContentsItemShop" }.Where((string name) => Addon(name) != null).ToArray();
		long num = Num(a, 2);
		string text2 = reason + "/" + text + "/" + num + "/" + string.Join(',', array);
		DateTime now = DateTime.Now;
		if (text2 != lastBlocked || now - blockedWrittenAt > TimeSpan.FromSeconds(2L))
		{
			try
			{
				WriteSnapshot(reason, text, array);
				lastBlocked = text2;
				blockedWrittenAt = now;
				Services.Log.Warning("Arena rest waiting: " + text2, Array.Empty<object>());
			}
			catch (Exception ex)
			{
				Services.Log.Warning(ex, "Rest diagnostic failed", Array.Empty<object>());
			}
		}
		return new ArenaRestView(ArenaRestPhase.Blocked, Array.Empty<ArenaRestPet>());
	}

	public void Dump(string reason)
	{
		try
		{
			WriteSnapshot(reason);
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Rest diagnostic failed", Array.Empty<object>());
		}
	}

	private unsafe void WriteSnapshot(string reason, string? prompt = null, string[]? addons = null)
	{
		AtkUnitBase* ptr = Addon("XBMPetParty");
		string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
		Directory.CreateDirectory(text);
		File.WriteAllText(Path.Combine(text, "arena-rest-latest.json"), JsonSerializer.Serialize(new
		{
			At = DateTimeOffset.Now,
			Reason = reason,
			Prompt = (prompt ?? Text(Addon("SelectYesno"), 0)),
			Addons = (addons ?? new string[6] { "XBMPetParty", "SelectYesno", "SelectOk", "XBMContentsBooty", "XBMStageDetailList", "XBMContentsItemShop" }.Where((string name) => Addon(name) != null).ToArray()),
			Stage = stage.Id,
			InCombat = Services.Condition[(ConditionFlag)26],
			Mode = Num(ptr, 2),
			PartyReady = (ptr != null && ((AtkUnitBase)ptr).IsReady),
			PartyValues = ((ptr == null) ? (-1) : ((AtkUnitBase)ptr).AtkValuesCount),
			Values = ArenaUtilityUi.Values(ptr)
		}));
	}

	public unsafe bool TryToggle(uint number)
	{
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_015f: Invalid comparison between Unknown and I4
		ArenaRestView arenaRestView = Read();
		if (arenaRestView.Phase == ArenaRestPhase.Loading)
		{
			return false;
		}
		if (arenaRestView.Phase != ArenaRestPhase.Selection)
		{
			return false;
		}
		ArenaRestPet arenaRestPet = arenaRestView.Pets.SingleOrDefault((ArenaRestPet p) => p.Number == number);
		if (arenaRestPet == null || (arenaRestPet.Hp == 0 && !arenaRestPet.Selected))
		{
			return false;
		}
		if (!arenaRestPet.Selected && arenaRestView.Pets.Count((ArenaRestPet p) => p.Selected) >= arenaRestView.Capacity)
		{
			return false;
		}
		AtkUnitBase* ptr = Addon("XBMPetParty");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		AtkComponentList* componentListById = ((AtkUnitBase)ptr).GetComponentListById(11u);
		if (componentListById == null || ((AtkComponentList)componentListById).OwnerNode == null || !((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).IsVisible() || !((Enum)((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32) || !((AtkComponentList)componentListById).IsItemInteractionEnabled || ((AtkComponentList)componentListById).IsUpdatePending || arenaRestPet.Row >= ((AtkComponentList)componentListById).ListLength || ((AtkComponentList)componentListById).GetItemDisabledState(arenaRestPet.Row))
		{
			return false;
		}
		int num = 0;
		AtkEvent* ptr2 = ((AtkEventManager)(&((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).AtkEventManager)).Event;
		int num2 = 0;
		while (ptr2 != null && num2 < 64)
		{
			if (((AtkEvent)ptr2).Listener == ptr && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 35 && ((AtkEvent)ptr2).Param == 0)
			{
				num++;
			}
			num2++;
			ptr2 = ((AtkEvent)ptr2).NextEvent;
		}
		switch (num)
		{
		case 0:
			return false;
		default:
			throw new InvalidOperationException("休息列表点击事件不唯一");
		case 1:
			if (!UiInteractionDelay.Ready($"rest/pet/{ptr}/{number}/{arenaRestPet.Row}"))
			{
				return false;
			}
			((AtkComponentList)componentListById).SelectItem(arenaRestPet.Row, false);
			((AtkComponentList)componentListById).DispatchItemEvent(arenaRestPet.Row, (AtkEventType)35);
			return true;
		}
	}

	private unsafe bool Button(string addonName, uint node, uint parameter, ArenaRestPhase phase)
	{
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Invalid comparison between Unknown and I4
		ArenaRestView arenaRestView = Read();
		if (arenaRestView.Phase == ArenaRestPhase.Loading)
		{
			return false;
		}
		if (arenaRestView.Phase != phase)
		{
			return false;
		}
		AtkUnitBase* ptr = Addon(addonName);
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		AtkComponentButton* componentButtonById = ((AtkUnitBase)ptr).GetComponentButtonById(node);
		if (componentButtonById == null || ((AtkComponentButton)componentButtonById).OwnerNode == null || !((AtkComponentNode)((AtkComponentButton)componentButtonById).OwnerNode).IsVisible() || !((AtkComponentButton)componentButtonById).IsEnabled)
		{
			return false;
		}
		AtkEvent* ptr2 = null;
		AtkEvent* ptr3 = ((AtkEventManager)(&((AtkComponentNode)((AtkComponentButton)componentButtonById).OwnerNode).AtkEventManager)).Event;
		int num = 0;
		while (ptr3 != null && num < 64)
		{
			if (((AtkEvent)ptr3).Listener == ptr && (int)((AtkEventState)(&((AtkEvent)ptr3).State)).EventType == 25 && ((AtkEvent)ptr3).Param == parameter)
			{
				if (ptr2 != null)
				{
					throw new InvalidOperationException("休息按钮事件不唯一");
				}
				ptr2 = ptr3;
			}
			num++;
			ptr3 = ((AtkEvent)ptr3).NextEvent;
		}
		if (ptr2 == null)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"rest/button/{ptr}/{node}/{parameter}"))
		{
			return false;
		}
		AtkEvent val = *ptr2;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr2).Listener).ReceiveEvent((AtkEventType)25, (int)parameter, &val, &val2);
		return true;
	}

	public bool TryRest()
	{
		ArenaRestView arenaRestView = Read();
		if (arenaRestView.Phase != ArenaRestPhase.Selection)
		{
			return false;
		}
		if (!(from p in arenaRestView.Pets
			where p.Selected
			select p.Number).ToHashSet().SetEquals(ArenaRestPolicy.Select(arenaRestView.Pets, arenaRestView.Capacity, restBelowPercent)))
		{
			return false;
		}
		return Button("XBMPetParty", 21u, 3u, ArenaRestPhase.Selection);
	}

	public bool TryTakeReward()
	{
		return Button("XBMContentsBooty", 46u, 1u, ArenaRestPhase.Reward);
	}

	public unsafe bool TryLeave()
	{
		if (Read().Phase == ArenaRestPhase.Selection)
		{
			return ArenaUtilityUi.ClickRegistered(Addon("XBMPetParty"), 4u);
		}
		return false;
	}

	public bool TryConfirmLeave()
	{
		return Answer(ArenaRestPhase.LeaveConfirmation, yes: true);
	}

	private unsafe bool Answer(ArenaRestPhase expected, bool yes)
	{
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dd: Unknown result type (might be due to invalid IL or missing references)
		ArenaRestView arenaRestView = Read();
		if (arenaRestView.Phase == ArenaRestPhase.Loading)
		{
			return false;
		}
		if (arenaRestView.Phase != expected)
		{
			return false;
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)Addon("SelectYesno");
		if (ptr == null || !((AddonSelectYesno)ptr).IsReady)
		{
			return false;
		}
		AtkComponentButton* ptr2 = (yes ? ((AddonSelectYesno)ptr).YesButton : ((AddonSelectYesno)ptr).NoButton);
		if (ptr2 == null || ((AtkComponentButton)ptr2).OwnerNode == null || !((AtkComponentButton)ptr2).IsEnabled)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"rest/answer/{ptr}/{expected}/{yes}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = ((!yes) ? 1 : 0);
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}

	public bool TryConfirm(uint[] numbers)
	{
		ArenaRestView arenaRestView = Read();
		if (arenaRestView.Phase == ArenaRestPhase.Loading)
		{
			return false;
		}
		if (numbers.Length > arenaRestView.Capacity || arenaRestView.Pets.Any((ArenaRestPet p) => p.Selected && p.Hp == 0))
		{
			return false;
		}
		if (!(from p in arenaRestView.Pets
			where p.Selected
			select p.Number).ToHashSet().SetEquals(numbers))
		{
			return false;
		}
		return Answer(ArenaRestPhase.Confirmation, yes: true);
	}

	public bool TryDismissConfirmation()
	{
		ArenaRestPhase phase = Read().Phase;
		if ((phase == ArenaRestPhase.Confirmation || phase == ArenaRestPhase.StaleConfirmation) ? true : false)
		{
			return Answer(phase, yes: false);
		}
		return false;
	}

	public bool TryConfirmReward()
	{
		return Answer(ArenaRestPhase.RewardConfirmation, yes: true);
	}
}
