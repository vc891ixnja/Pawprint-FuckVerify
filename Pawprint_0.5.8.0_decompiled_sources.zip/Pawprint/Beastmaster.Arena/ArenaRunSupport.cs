using System;
using System.Collections.Generic;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Beastmaster.Integrations;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;

namespace Beastmaster.Arena;

internal sealed class ArenaRunSupport(FieldDodgeBackend backend, PromeRotationClient? pr = null) : IArenaRunSupport
{
	private ArenaRotationSession? rotation;

	private PluginSettingsScope? settings;

	private object? ownedBehavior;

	private long nextCheck;

	private bool wasDead;

	public bool IsDead
	{
		get
		{
			uint territoryType = Services.ClientState.TerritoryType;
			if (territoryType != 0 && !ArenaCombatPolicy.IsArena(territoryType))
			{
				return wasDead = false;
			}
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null)
			{
				wasDead = ((IGameObject)localPlayer).IsDead;
			}
			return wasDead;
		}
	}

	public void Update()
	{
		ICondition condition = Services.Condition;
		if (Services.ClientState.TerritoryType == 0 && (condition[(ConditionFlag)45] || condition[(ConditionFlag)51]))
		{
			return;
		}
		if (!ArenaCombatPolicy.IsArena(Services.ClientState.TerritoryType))
		{
			Cancel();
		}
		else
		{
			if (Services.Objects.LocalPlayer == null || IsDead || Services.PlayerState.ContentId == 0L || condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35])
			{
				return;
			}
			long tickCount = Environment.TickCount64;
			if (tickCount < nextCheck)
			{
				return;
			}
			nextCheck = tickCount + 1000;
			if (pr != null)
			{
				if (rotation == null)
				{
					PromeTaskBackend promeTaskBackend = new PromeTaskBackend(pr);
					promeTaskBackend.RequireReady();
					promeTaskBackend.BindToCurrentSettings();
					rotation = new ArenaRotationSession(promeTaskBackend);
				}
				rotation.Update();
			}
			if (backend == FieldDodgeBackend.None)
			{
				return;
			}
			BossModAiBinding bossModAiBinding = new BossModDodgeSession(backend).Resolve();
			if (settings == null)
			{
				settings = new PluginSettingsScope(BossModDodgeSession.Read, BossModDodgeSession.Write);
				Dictionary<string, string> dictionary = new Dictionary<string, string>
				{
					["ManualTarget"] = "True",
					["ForbidMovement"] = "False",
					["FollowOutOfCombat"] = "False",
					["FocusTargetMaster"] = "False",
					["FollowSlot"] = "0",
					["FollowTarget"] = "True",
					["FollowDuringCombat"] = "True",
					["FollowDuringActiveBossModule"] = "True",
					["AutoAFK"] = "False",
					["ForbidActions"] = "True",
					["Preset"] = "<none>",
					["MinDistance"] = "0"
				};
				foreach (KeyValuePair<string, string> item in BossModDistanceSettings.Resolve(BossModDodgeSession.Query))
				{
					dictionary.Add(item.Key, item.Value);
				}
				settings.Apply(dictionary);
			}
			if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) == null)
			{
				bossModAiBinding.SetEnabled(enabled: true);
				ownedBehavior = bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) ?? throw new InvalidOperationException($"{backend} AI 未启动");
			}
		}
	}

	public void Cancel()
	{
		try
		{
			if (ownedBehavior == null)
			{
				return;
			}
			BossModAiBinding bossModAiBinding = new BossModDodgeSession(backend).Resolve();
			if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) == ownedBehavior)
			{
				bossModAiBinding.SetEnabled(enabled: false);
				if (bossModAiBinding.Behavior.GetValue(bossModAiBinding.Manager) != null)
				{
					throw new InvalidOperationException($"{backend} AI 未停止");
				}
			}
		}
		finally
		{
			ownedBehavior = null;
			nextCheck = 0L;
			PluginSettingsScope pluginSettingsScope = settings;
			settings = null;
			try
			{
				pluginSettingsScope?.Dispose();
			}
			finally
			{
				ArenaRotationSession? arenaRotationSession = rotation;
				rotation = null;
				arenaRotationSession?.Dispose();
			}
		}
	}
}
