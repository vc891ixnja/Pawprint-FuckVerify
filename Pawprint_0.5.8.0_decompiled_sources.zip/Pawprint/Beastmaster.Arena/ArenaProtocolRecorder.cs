using System;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.CompilerServices;
using Dalamud.Hooking;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.Character;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Arena;

internal sealed class ArenaProtocolRecorder(Action<string, object> record) : IDisposable
{
	private Hook<FireCallback>? callbacks;

	private Hook<Receive>? effects;

	private volatile bool inArena;

	public void SetInArena(bool value)
	{
		inArena = value;
	}

	public unsafe void Start()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Expected O, but got Unknown
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Expected O, but got Unknown
		try
		{
			callbacks = Services.Interop.HookFromAddress<FireCallback>((IntPtr)(nint)MemberFunctionPointers.FireCallback, new FireCallback(OnCallback), (HookBackend)0);
			callbacks.Enable();
		}
		catch (Exception ex)
		{
			callbacks?.Dispose();
			callbacks = null;
			record("CapabilityError", new
			{
				Hook = "FireCallback",
				Message = ex.Message
			});
		}
		try
		{
			effects = Services.Interop.HookFromAddress<Receive>((IntPtr)(nint)MemberFunctionPointers.Receive, new Receive(OnEffect), (HookBackend)0);
			effects.Enable();
		}
		catch (Exception ex2)
		{
			effects?.Dispose();
			effects = null;
			record("CapabilityError", new
			{
				Hook = "ActionEffect",
				Message = ex2.Message
			});
		}
		record("Capabilities", new
		{
			Callbacks = (callbacks != null),
			ActionEffects = (effects != null)
		});
	}

	private unsafe bool OnCallback(AtkUnitBase* addon, uint count, AtkValue* values, bool close)
	{
		try
		{
			if (addon != null && ArenaRecorder.Relevant(((AtkUnitBase)addon).NameString) && count <= 4096 && (count == 0 || values != null))
			{
				record("Callback", new
				{
					Addon = ((AtkUnitBase)addon).NameString,
					Close = close,
					Values = ArenaRecorder.ReadValues(values, (int)count)
				});
			}
		}
		catch (Exception ex)
		{
			record("ObservationError", new
			{
				Hook = "FireCallback",
				Message = ex.Message
			});
		}
		return callbacks.Original.Invoke(addon, count, values, close);
	}

	private unsafe void OnEffect(uint casterId, Character* caster, Vector3* position, Header* header, TargetEffects* targetEffects, GameObjectId* targets)
	{
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			if (inArena && header != null && ((Header)header).NumTargets <= 64 && (((Header)header).NumTargets == 0 || (targets != null && targetEffects != null)))
			{
				List<object> list = new List<object>();
				for (int i = 0; i < ((Header)header).NumTargets; i++)
				{
					List<object> list2 = new List<object>();
					for (int j = 0; j < 8; j++)
					{
						Effect val = ((TargetEffects)((byte*)targetEffects + (nint)i * (nint)Unsafe.SizeOf<TargetEffects>())).Effects[j];
						if (val.Type != 0)
						{
							list2.Add(new { val.Type, val.Param0, val.Param1, val.Param2, val.Param3, val.Param4, val.Value });
						}
					}
					list.Add(new
					{
						Target = GameObjectId.op_Implicit(((GameObjectId*)targets)[i]),
						Effects = list2
					});
				}
				record("ActionEffect", new
				{
					Caster = casterId,
					ActionId = ((Header)header).ActionId,
					ActionType = ((Header)header).ActionType,
					GlobalSequence = ((Header)header).GlobalSequence,
					SourceSequence = ((Header)header).SourceSequence,
					Targets = list
				});
			}
		}
		catch (Exception ex)
		{
			record("ObservationError", new
			{
				Hook = "ActionEffect",
				Message = ex.Message
			});
		}
		effects.Original.Invoke(casterId, caster, position, header, targetEffects, targets);
	}

	public void Dispose()
	{
		inArena = false;
		callbacks?.Dispose();
		callbacks = null;
		effects?.Dispose();
		effects = null;
	}
}
