using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using Beastmaster.Core.Arena;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;

namespace Beastmaster.Arena;

internal static class ArenaPartyReader
{
	private static string? lastError;

	public unsafe static bool TryRead(AtkUnitBase* addon, bool allowEmpty, out ArenaPet[] pets)
	{
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Expected I4, but got Unknown
		//IL_00bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0119: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Invalid comparison between Unknown and I4
		//IL_00f2: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Invalid comparison between Unknown and I4
		pets = Array.Empty<ArenaPet>();
		bool flag = addon == null || !((AtkUnitBase)addon).IsReady || ((AtkUnitBase)addon).AtkValues == null;
		if (!flag)
		{
			ushort atkValuesCount = ((AtkUnitBase)addon).AtkValuesCount;
			bool flag2 = ((atkValuesCount < 6 || atkValuesCount > 4096) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return false;
		}
		List<ArenaValue> list = new List<ArenaValue>();
		for (int i = 0; i < ((AtkUnitBase)addon).AtkValuesCount; i++)
		{
			AtkValue val = ((AtkValue*)((AtkUnitBase)addon).AtkValues)[i];
			AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
			AtkValueType val3 = val2;
			long? num;
			switch (val3 - 2)
			{
			case 1:
				num = val.Int;
				break;
			case 3:
				num = val.UInt;
				break;
			case 0:
				num = (val.Bool ? 1 : 0);
				break;
			case 2:
				num = val.Int64;
				break;
			case 4:
				if (val.UInt64 <= long.MaxValue)
				{
					num = (long)val.UInt64;
					break;
				}
				goto default;
			default:
				num = null;
				break;
			}
			long? num2 = num;
			List<ArenaValue> list2 = list;
			int index = i;
			num = num2;
			flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
			list2.Add(new ArenaValue(index, num, flag ? ((object)(*(CStringPointer*)(&val.String))/*cast due to .constrained prefix*/).ToString() : null));
		}
		try
		{
			pets = ArenaPartyDecoder.Decode(list, allowEmpty);
			lastError = null;
			return true;
		}
		catch (InvalidOperationException ex)
		{
			string text = $"{ex.Message}; values={list.Count}, count={list[5].Number}";
			if (lastError != text)
			{
				lastError = text;
				Services.Log.Warning("Arena party waiting for data: " + text, Array.Empty<object>());
				try
				{
					string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
					Directory.CreateDirectory(text2);
					File.WriteAllText(Path.Combine(text2, "arena-party-latest.json"), JsonSerializer.Serialize(new
					{
						At = DateTimeOffset.Now,
						Error = text,
						Values = list
					}, new JsonSerializerOptions
					{
						WriteIndented = true
					}));
				}
				catch (Exception ex2)
				{
					Services.Log.Warning(ex2, "Arena party diagnostic failed", Array.Empty<object>());
				}
			}
			return false;
		}
	}
}
