using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;
using Beastmaster.Hunting;
using Beastmaster.Integrations;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.ClientState.Statuses;
using Dalamud.Plugin;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.Game.Control;
using FFXIVClientStructs.FFXIV.Client.Game.Object;
using FFXIVClientStructs.FFXIV.Client.System.String;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;

namespace Beastmaster.Arena;

internal sealed class ArenaBattleWorld(Func<bool> authorized, ArenaEncounterWorld encounter, ArenaStage stage, int? node, FieldDodgeBackend aiBackend, PromeRotationClient pr, CombatEvents events, INavigationProvider navigation) : IArenaBattleWorld, IArenaRuleWorld, IArenaRuleItems
{
	private PluginSettingsScope? targetSettings;

	private PluginSettingsScope? rearSettings;

	private NavigationStep? rearMove;

	private TimeSpan rearAt;

	private long retryRearAt;

	private readonly ArenaAttentionState attention = new ArenaAttentionState(ArenaSixthBattlePolicy.Applies(stage.Id, node) ? new TimeSpan?(ArenaSixthBattlePolicy.AttentionRetryInterval) : ((TimeSpan?)null));

	private long attentionCursor;

	private long nextAttentionAttempt;

	private long dutyCursor;

	private readonly List<(long Seq, ulong TargetId)> dutyConfirms = new List<(long, ulong)>();

	private readonly ArenaHealWorld ruleHud = new ArenaHealWorld(authorized, stage, duringBattle: true, allItems: true);

	private const string AssistantAcrOpeningCommand = "/驯兽师 倒计时 10";

	private long dutyConfirmSeq;

	private bool CanSelect
	{
		get
		{
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_0029: Unknown result type (might be due to invalid IL or missing references)
			if (authorized())
			{
				IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
				if (localPlayer != null && !((IGameObject)localPlayer).IsDead && ((ICharacter)localPlayer).ClassJob.RowId == 43)
				{
					return encounter.Read().Phase == ArenaEncounterPhase.Battle;
				}
			}
			return false;
		}
	}

	public string LastActionStatus { get; private set; } = "";

	public bool HasCustomTargetRule
	{
		get
		{
			if ((stage.Id != 1 || node != 8) && !ArenaFirstBattlePolicy.Applies(stage.Id, node) && !ArenaHighBossPolicy.Applies(stage.Id, node))
			{
				if (stage.Id == 1 && !node.HasValue)
				{
					return ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Any((IBattleNpc n) => ArenaFirstBattlePolicy.IsBattleActor(((ICharacter)n).NameId, ((IGameObject)n).BaseId));
				}
				return false;
			}
			return true;
		}
	}

	public bool RearLogicEnabled { get; set; }

	public string? LastDeny => ArenaItemDispatch.LastDeny;

	public ArenaCombatView Read()
	{
		if (!authorized())
		{
			throw new InvalidOperationException("斗兽任务未授权开怪");
		}
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		return new ArenaCombatView(encounter.Read().Phase == ArenaEncounterPhase.Battle && localPlayer != null && !((IGameObject)localPlayer).IsDead && !((IBattleChara)localPlayer).IsCasting && !Services.Condition[(ConditionFlag)31] && !Services.Condition[(ConditionFlag)33], Services.Condition[(ConditionFlag)26], (localPlayer == null) ? null : new WorldPoint(stage.Territory, ((IGameObject)localPlayer).Position.X, ((IGameObject)localPlayer).Position.Y, ((IGameObject)localPlayer).Position.Z), aiBackend != FieldDodgeBackend.None && Services.Condition[(ConditionFlag)26]);
	}

	public CombatTarget? FindNearestTarget()
	{
		if (Read().Ready)
		{
			IPlayerCharacter player = Services.Objects.LocalPlayer;
			if (player != null)
			{
				IBattleNpc val = (from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(DalamudCombatWorld.IsAttackable)
					orderby Vector3.DistanceSquared(((IGameObject)player).Position, ((IGameObject)n).Position)
					select n).FirstOrDefault();
				if (val != null)
				{
					return ReadTarget(((IGameObject)val).GameObjectId);
				}
				return null;
			}
		}
		return null;
	}

	public CombatTarget? ReadTarget(ulong id)
	{
		if (!CanSelect)
		{
			return null;
		}
		IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc n) => ((IGameObject)n).GameObjectId == id && DalamudCombatWorld.IsAttackable(n)));
		if (val != null)
		{
			return new CombatTarget(((IGameObject)val).GameObjectId, ((ICharacter)val).NameId, new WorldPoint(stage.Territory, ((IGameObject)val).Position.X, ((IGameObject)val).Position.Y, ((IGameObject)val).Position.Z), ((ICharacter)val).Level, ((ICharacter)val).CurrentHp, ((ICharacter)val).MaxHp, ((IGameObject)val).IsDead, ((IGameObject)val).IsTargetable, ((IGameObject)val).HitboxRadius);
		}
		return null;
	}

	public bool TryOpeningAttack(ulong id)
	{
		return TryAction(44879u, id, 3f);
	}

	public bool TryAcrOpening(ulong id)
	{
		if (!CanSelect || !Services.Commands.Commands.ContainsKey("/pr"))
		{
			LastActionStatus = "PR 命令接口未就绪";
			return false;
		}
		if (!pr.IsRunning || !pr.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			LastActionStatus = "请启用 PR 的 XSZYYS ACR";
			return false;
		}
		if (!TrySelectTarget(id))
		{
			return false;
		}
		bool flag = Services.Commands.ProcessCommand("/pr hotkey 执行起手");
		LastActionStatus = (flag ? "" : "PR 未接受起手命令");
		return flag;
	}

	public bool TryAssistantAcrOpening(ulong id)
	{
		if (!CanSelect || !Services.Commands.Commands.ContainsKey("/pr"))
		{
			LastActionStatus = "PR 命令接口未就绪";
			return false;
		}
		if (!pr.IsRunning)
		{
			LastActionStatus = "PR 未在运行";
			return false;
		}
		if (!TrySelectTarget(id))
		{
			return false;
		}
		bool flag = Services.Commands.ProcessCommand("/驯兽师 倒计时 10");
		LastActionStatus = (flag ? "" : "PR 未接受驯兽师助手起手命令");
		if (flag)
		{
			Services.Log.Information($"Arena assistant ACR opener on target {id:X}", Array.Empty<object>());
		}
		return flag;
	}

	public unsafe bool TryStartCountdown(int seconds)
	{
		if (seconds == 5 && authorized() && encounter.Read().Phase == ArenaEncounterPhase.Battle)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && !((IGameObject)localPlayer).IsDead)
			{
				AgentCountDownSettingDialog* ptr = AgentCountDownSettingDialog.Instance();
				if (ptr != null && ((AgentCountDownSettingDialog)ptr).Active)
				{
					return true;
				}
				UIModule* ptr2 = UIModule.Instance();
				if (ptr2 == null)
				{
					return false;
				}
				Utf8String val = default(Utf8String);
				((Utf8String)(ref val))._002Ector("/countdown 5");
				try
				{
					((UIModule)ptr2).ProcessChatBoxEntry(&val, (IntPtr)0, false);
					Services.Log.Information("Arena opener: requested game countdown 5", Array.Empty<object>());
					return true;
				}
				finally
				{
					((IDisposable)(*(Utf8String*)(&val))/*cast due to .constrained prefix*/).Dispose();
				}
			}
		}
		return false;
	}

	public CombatTarget? FindPriorityTarget(ulong? preferred)
	{
		if (ArenaHighBossPolicy.Applies(stage.Id, node))
		{
			return ArenaHighBossPolicy.Choose((from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(delegate(IBattleNpc n)
				{
					uint nameId = ((ICharacter)n).NameId;
					return nameId - 14628 <= 1;
				})
				select ReadTarget(((IGameObject)n).GameObjectId)).OfType<CombatTarget>(), preferred);
		}
		if (stage.Id == 1 && node == 8)
		{
			return ArenaCustomBattlePolicy.ChooseEighth((from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(delegate(IBattleNpc n)
				{
					uint nameId = ((ICharacter)n).NameId;
					return (nameId - 14538 <= 1 || nameId == 14748) ? true : false;
				})
				select ReadTarget(((IGameObject)n).GameObjectId)).OfType<CombatTarget>(), preferred);
		}
		return ArenaFirstBattlePolicy.Choose(from n in ((IEnumerable)Services.Objects).OfType<IBattleNpc>()
			where ArenaFirstBattlePolicy.IsBattleActor(((ICharacter)n).NameId, ((IGameObject)n).BaseId)
			select new CombatTarget(((IGameObject)n).GameObjectId, ((ICharacter)n).NameId, new WorldPoint(stage.Territory, ((IGameObject)n).Position.X, ((IGameObject)n).Position.Y, ((IGameObject)n).Position.Z), ((ICharacter)n).Level, ((ICharacter)n).CurrentHp, ((ICharacter)n).MaxHp, ((IGameObject)n).IsDead, ((IGameObject)n).IsTargetable, ((IGameObject)n).HitboxRadius, DalamudCombatWorld.IsAttackable(n)), preferred);
	}

	public IReadOnlyList<CombatTarget> AliveEnemies()
	{
		if (!authorized() || encounter.Read().Phase != ArenaEncounterPhase.Battle)
		{
			return Array.Empty<CombatTarget>();
		}
		return ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Where(DalamudCombatWorld.IsAttackable).Select(ToTarget)
			.ToArray();
	}

	public CombatTarget? CurrentTarget()
	{
		IGameObject target = Services.Targets.Target;
		IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
		if (val == null || !DalamudCombatWorld.IsAttackable(val))
		{
			return null;
		}
		return ToTarget(val);
	}

	public (ulong ObjectId, uint BaseId)[] SummonedPets()
	{
		IPlayerCharacter player = Services.Objects.LocalPlayer;
		if (player == null)
		{
			return Array.Empty<(ulong, uint)>();
		}
		return (from p in ((IEnumerable)Services.Objects).OfType<IBattleNpc>()
			where ((IGameObject)p).OwnerId == ((IGameObject)player).EntityId && ((IGameObject)p).EntityId != ((IGameObject)player).EntityId && !((IGameObject)p).IsDead && ((ICharacter)p).CurrentHp != 0
			select (GameObjectId: ((IGameObject)p).GameObjectId, BaseId: ((IGameObject)p).BaseId)).ToArray();
	}

	public (ulong ObjectId, uint CurrentHp, uint MaxHp) PlayerState()
	{
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer != null)
		{
			return (ObjectId: ((IGameObject)localPlayer).GameObjectId, CurrentHp: ((ICharacter)localPlayer).CurrentHp, MaxHp: ((ICharacter)localPlayer).MaxHp);
		}
		return (ObjectId: 0uL, CurrentHp: 0u, MaxHp: 0u);
	}

	public WorldPoint? PlayerPosition()
	{
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer != null)
		{
			return new WorldPoint(stage.Territory, ((IGameObject)localPlayer).Position.X, ((IGameObject)localPlayer).Position.Y, ((IGameObject)localPlayer).Position.Z);
		}
		return null;
	}

	private CombatTarget ToTarget(IBattleNpc npc)
	{
		return new CombatTarget(((IGameObject)npc).GameObjectId, ((ICharacter)npc).NameId, new WorldPoint(stage.Territory, ((IGameObject)npc).Position.X, ((IGameObject)npc).Position.Y, ((IGameObject)npc).Position.Z), ((ICharacter)npc).Level, ((ICharacter)npc).CurrentHp, ((ICharacter)npc).MaxHp, ((IGameObject)npc).IsDead, ((IGameObject)npc).IsTargetable, ((IGameObject)npc).HitboxRadius, DalamudCombatWorld.IsAttackable(npc));
	}

	public unsafe bool TryUseDutyAction(int slot, ulong targetId)
	{
		if (!CanSelect || slot != 1 || targetId == 0L)
		{
			return false;
		}
		CombatTarget combatTarget = ReadTarget(targetId);
		bool controlRotationSelector = (object)combatTarget != null && combatTarget.NameId == 14531;
		if (!TrySelectTarget(targetId, controlRotationSelector))
		{
			return false;
		}
		ActionManager* ptr = ActionManager.Instance();
		if (ptr == null)
		{
			return false;
		}
		if (DutyActionManager.GetDutyActionId((ushort)1) != 46751)
		{
			return false;
		}
		if (((ActionManager)ptr).GetActionStatus((ActionType)5, 27u, targetId, true, true, (uint*)null) != 0)
		{
			return false;
		}
		bool num = ((ActionManager)ptr).UseAction((ActionType)5, 27u, targetId, 0u, (UseActionMode)0, 0u, (bool*)null);
		if (num)
		{
			Services.Log.Information($"Arena rule: duty {27} on target {targetId:X}", Array.Empty<object>());
		}
		return num;
	}

	public long DutyConfirmSequence(int slot)
	{
		if (slot != 1)
		{
			return 0L;
		}
		return dutyConfirmSeq;
	}

	public IReadOnlyList<(ulong TargetId, long Seq)> DutyConfirmations(int slot)
	{
		if (slot != 1)
		{
			return Array.Empty<(ulong, long)>();
		}
		foreach (CombatEvent item in events.After(dutyCursor))
		{
			if (item.ActionId == 46751)
			{
				dutyConfirms.Add((++dutyConfirmSeq, item.TargetId));
			}
		}
		dutyCursor = events.Sequence;
		if (dutyConfirms.Count > 64)
		{
			dutyConfirms.RemoveRange(0, dutyConfirms.Count - 64);
		}
		return dutyConfirms.Select(((long Seq, ulong TargetId) c) => (c.TargetId, Seq: c.Seq)).ToArray();
	}

	public bool TryPrcFinisher()
	{
		if (!Services.Commands.Commands.ContainsKey("/pr"))
		{
			LastActionStatus = "PR 命令接口未就绪";
			return false;
		}
		if (!pr.IsRunning || !pr.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			LastActionStatus = "请启用 PR 的 XSZYYS ACR";
			return false;
		}
		bool num = Services.Commands.ProcessCommand("/pr hotkey 最后一击");
		if (num)
		{
			Services.Log.Information("Arena rule: /pr hotkey 最后一击", Array.Empty<object>());
			return num;
		}
		LastActionStatus = "PR 未接受最后一击命令";
		return num;
	}

	public bool TryCountdown(int seconds)
	{
		return TryStartCountdown(seconds);
	}

	public ArenaHealView ReadHud()
	{
		return ruleHud.Read();
	}

	public bool TryUseItem(int slot, uint itemId, ulong targetId)
	{
		if (!CanSelect || targetId == 0L)
		{
			return false;
		}
		bool selfOnly = itemId - 142 <= 1;
		bool num = ArenaItemDispatch.TryUse(slot, itemId, targetId, fallbackToSelf: true, selfOnly);
		if (num)
		{
			Services.Log.Information($"Arena rule: item {itemId} slot {slot} on target {targetId:X}", Array.Empty<object>());
		}
		return num;
	}

	public bool TrySelectTarget(ulong id)
	{
		return TrySelectTarget(id, controlRotationSelector: true);
	}

	private unsafe bool TrySelectTarget(ulong id, bool controlRotationSelector)
	{
		if (!CanSelect || !ArenaCombatPolicy.IsArena(stage.Territory))
		{
			return false;
		}
		IBattleNpc val = ((IEnumerable)Services.Objects).OfType<IBattleNpc>().FirstOrDefault((Func<IBattleNpc, bool>)((IBattleNpc n) => ((IGameObject)n).GameObjectId == id && DalamudCombatWorld.IsAttackable(n)));
		if (val == null)
		{
			return false;
		}
		if (controlRotationSelector && targetSettings == null)
		{
			IExposedPlugin val2 = IntegrationHub.FindInstalledPlugin("PromeRotation");
			if (val2 != null && val2.IsLoaded && pr.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
			{
				PromeTaskBackend promeTaskBackend = new PromeTaskBackend(pr);
				targetSettings = new PluginSettingsScope(promeTaskBackend.Read, promeTaskBackend.Write);
				targetSettings.Apply(new Dictionary<string, string> { ["TargetSelectorMode"] = "None" });
			}
		}
		TargetSystem* ptr = TargetSystem.Instance();
		if (ptr == null)
		{
			return false;
		}
		GameObject* address = (GameObject*)((IGameObject)val).Address;
		if (((TargetSystem)ptr).GetSoftTarget() != null && !((TargetSystem)ptr).SetSoftTarget((GameObject*)null))
		{
			return false;
		}
		if (((TargetSystem)ptr).GetHardTarget() != address && !((TargetSystem)ptr).SetHardTarget(address, false, false, 0))
		{
			return false;
		}
		if (((TargetSystem)ptr).GetHardTarget() == address && ((TargetSystem)ptr).GetSoftTarget() == null)
		{
			IGameObject target = Services.Targets.Target;
			if (target == null)
			{
				return false;
			}
			return target.GameObjectId == id;
		}
		return false;
	}

	private unsafe bool TryAction(uint action, ulong id, float range)
	{
		if (!TrySelectTarget(id))
		{
			return false;
		}
		CombatTarget combatTarget = ReadTarget(id);
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (combatTarget == null || localPlayer == null || ((IBattleChara)localPlayer).IsCasting || Vector3.Distance(((IGameObject)localPlayer).Position, combatTarget.Location.Position) - combatTarget.HitboxRadius > range)
		{
			return false;
		}
		ActionManager* ptr = ActionManager.Instance();
		if (ptr == null)
		{
			return false;
		}
		uint adjustedActionId = ((ActionManager)ptr).GetAdjustedActionId(action);
		if (adjustedActionId == 0 || !ArenaCombatPolicy.AllowsAction(stage.Territory, adjustedActionId))
		{
			return false;
		}
		uint actionStatus = ((ActionManager)ptr).GetActionStatus((ActionType)1, adjustedActionId, id, true, true, (uint*)null);
		if (actionStatus != 0)
		{
			LastActionStatus = $"技能 {adjustedActionId}，状态 {actionStatus}";
			return false;
		}
		bool flag = ((ActionManager)ptr).UseAction((ActionType)1, adjustedActionId, id, 0u, (UseActionMode)0, 0u, (bool*)null);
		LastActionStatus = (flag ? "" : $"技能 {adjustedActionId} 未提交");
		return flag;
	}

	public void UpdateTargetAction(ulong id)
	{
		if (HasCustomTargetRule)
		{
			UpdateAttention(id, knightOnly: true);
		}
	}

	public void UpdateBattleActions(TimeSpan elapsed)
	{
		if (!RearLogicEnabled)
		{
			SuspendBattleMovement();
		}
		else if (Environment.TickCount64 >= retryRearAt)
		{
			try
			{
				UpdateRear();
			}
			catch (Exception ex) when (((ex is InvalidOperationException || ex is TimeoutException || ex is OperationCanceledException) ? 1 : 0) != 0)
			{
				SuspendBattleMovement();
				retryRearAt = Environment.TickCount64 + 3000;
				Services.Log.Warning(ex, "Arena rear positioning unavailable; retrying without blocking combat", Array.Empty<object>());
			}
		}
	}

	private void UpdateRear()
	{
		IPlayerCharacter player = Services.Objects.LocalPlayer;
		IGameObject target = Services.Targets.Target;
		IBattleNpc val = (IBattleNpc)(object)((target is IBattleNpc) ? target : null);
		if (!CanSelect || player == null || val == null || !DalamudCombatWorld.IsAttackable(val) || !ArenaCustomBattlePolicy.Rear(stage.Id, node, ((ICharacter)val).NameId, ((IEnumerable)Services.Objects).OfType<IBattleNpc>().Any((IBattleNpc p) => ((IGameObject)p).OwnerId == ((IGameObject)player).EntityId && !((IGameObject)p).IsDead && ((ICharacter)p).CurrentHp != 0), ((IEnumerable<IStatus>)((IBattleChara)val).StatusList).Any((IStatus s) => s.StatusId == 680), ((IEnumerable<IStatus>)((IBattleChara)player).StatusList).Any((IStatus s) => s.StatusId == 2413)))
		{
			SuspendBattleMovement();
			return;
		}
		if (aiBackend != FieldDodgeBackend.None)
		{
			if (rearSettings == null)
			{
				new BossModDodgeSession(aiBackend).Resolve();
				rearSettings = new PluginSettingsScope(BossModDodgeSession.Read, BossModDodgeSession.Write);
				Dictionary<string, string> dictionary = new Dictionary<string, string> { ["DesiredPositional"] = "Rear" };
				List<string> list = BossModDodgeSession.Query("FollowRSRDesiredPositional");
				if (list.Count == 1 && bool.TryParse(list[0], out var _))
				{
					dictionary["FollowRSRDesiredPositional"] = "False";
				}
				rearSettings.Apply(dictionary);
			}
			return;
		}
		if (((IBattleChara)player).IsCasting)
		{
			SuspendBattleMovement();
			return;
		}
		float num = ((IGameObject)val).HitboxRadius + 1.5f;
		Vector3 value = ((IGameObject)val).Position - new Vector3(MathF.Sin(((IGameObject)val).Rotation), 0f, MathF.Cos(((IGameObject)val).Rotation)) * num;
		if (Vector3.Distance(((IGameObject)player).Position, value) <= 0.5f)
		{
			SuspendBattleMovement();
			return;
		}
		if (rearMove != null && Vector3.Distance(rearMove.Destination.Position, value) > 1f)
		{
			rearMove.Cancel();
			rearMove = null;
		}
		TimeSpan timeSpan = TimeSpan.FromMilliseconds(Environment.TickCount64);
		if (rearMove == null)
		{
			if (!navigation.IsReady || !navigation.MovementAllowed || navigation.IsRunning || navigation.IsPathfinding)
			{
				return;
			}
			rearMove = new NavigationStep(navigation, new WorldPoint(stage.Territory, value.X, value.Y, value.Z), () => Read().Player, fly: false, 0.5f);
			rearAt = timeSpan;
		}
		if (rearMove.Tick(timeSpan - rearAt) == StepResult.Completed)
		{
			rearMove.Cancel();
			rearMove = null;
		}
	}

	public void SuspendBattleMovement()
	{
		rearMove?.Cancel();
		rearMove = null;
		PluginSettingsScope? pluginSettingsScope = rearSettings;
		rearSettings = null;
		pluginSettingsScope?.Dispose();
	}

	private unsafe void UpdateAttention(ulong id, bool knightOnly)
	{
		IPlayerCharacter player = Services.Objects.LocalPlayer;
		if (!CanSelect || player == null)
		{
			return;
		}
		IBattleNpc[] array = (from p in ((IEnumerable)Services.Objects).OfType<IBattleNpc>()
			where ((IGameObject)p).OwnerId == ((IGameObject)player).EntityId && ((IGameObject)p).EntityId != ((IGameObject)player).EntityId && !((IGameObject)p).IsDead && ((ICharacter)p).CurrentHp != 0
			select p).ToArray();
		IBattleNpc val = ((array.Length == 1) ? array[0] : null);
		attention.ObserveSummon((val != null) ? ((IGameObject)val).GameObjectId : 0, (val != null) ? ((IGameObject)val).BaseId : 0u);
		TimeSpan now = TimeSpan.FromMilliseconds(Environment.TickCount64);
		foreach (CombatEvent item in events.After(attentionCursor))
		{
			if (item.ActionId == 46751)
			{
				attention.Confirm(item.TargetId, now);
			}
		}
		attentionCursor = events.Sequence;
		CombatTarget combatTarget = ReadTarget(id);
		if (combatTarget == null || (knightOnly && combatTarget.NameId != 14531) || !attention.NeedsUse(id, now) || ((IBattleChara)player).IsCasting || Environment.TickCount64 < nextAttentionAttempt)
		{
			return;
		}
		nextAttentionAttempt = Environment.TickCount64 + (long)ArenaSixthBattlePolicy.AttentionRetryInterval.TotalMilliseconds;
		if (!TrySelectTarget(id, knightOnly))
		{
			return;
		}
		ActionManager* ptr = ActionManager.Instance();
		if (ptr != null && DutyActionManager.GetDutyActionId((ushort)1) == 46751)
		{
			uint actionStatus = ((ActionManager)ptr).GetActionStatus((ActionType)5, 27u, id, true, true, (uint*)null);
			if (actionStatus != 0)
			{
				LastActionStatus = $"吸引注意暂不可用（{actionStatus}）";
			}
			else if (((ActionManager)ptr).UseAction((ActionType)5, 27u, id, 0u, (UseActionMode)0, 0u, (bool*)null))
			{
				attention.Submitted(id, now);
				Services.Log.Information($"Arena attention: duty {27}, pet {((IGameObject)val).GameObjectId:X}, target {id:X}", Array.Empty<object>());
			}
		}
	}

	public void ReleaseTargetControl()
	{
		PluginSettingsScope? pluginSettingsScope = targetSettings;
		targetSettings = null;
		pluginSettingsScope?.Dispose();
	}
}
