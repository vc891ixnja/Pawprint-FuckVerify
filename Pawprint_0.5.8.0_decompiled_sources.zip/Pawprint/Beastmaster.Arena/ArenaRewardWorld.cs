using System;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Arena;

internal sealed class ArenaRewardWorld(Func<bool> authorized, ArenaStage stage) : IArenaRewardWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private string? lastTrace;

	public IArenaEquipmentWorld Equipment { get; } = new ArenaEquipmentWorld(authorized, stage);

	public unsafe bool IsOpen => ArenaUtilityUi.Addon("XBMContentsBooty") != null;

	public unsafe ArenaRewardView Read()
	{
		ICondition condition = Services.Condition;
		bool flag = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		int num = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		if (!authorized() || !Services.ClientState.IsLoggedIn || (Services.PlayerState.ContentId != character && (!flag || Services.PlayerState.ContentId != 0L)) || (Services.ClientState.TerritoryType != stage.Territory && (!flag || Services.ClientState.TerritoryType != 0)) || (num != stage.Content && (!flag || num != 0)))
		{
			throw new InvalidOperationException("战利品任务或场地已变化");
		}
		if (flag || Services.Objects.LocalPlayer == null)
		{
			return new ArenaRewardView(ArenaRewardPhase.Loading);
		}
		if (ArenaUtilityUi.Addon("XBMResult") != null)
		{
			return new ArenaRewardView(ArenaRewardPhase.Returned);
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsBooty");
		if (ptr == null)
		{
			bool flag2 = condition[(ConditionFlag)33] || condition[(ConditionFlag)31];
			bool flag3 = new string[7] { "SelectYesno", "SelectOk", "XBMContentsItemDispose", "XBMContentsTreasure", "XBMContentsItemShop", "XBMPetParty", "XBMStageDetailList" }.Any((string name) => ArenaUtilityUi.Addon(name) != null);
			ArenaRewardPhase arenaRewardPhase = ((!flag2 && !flag3 && !condition[(ConditionFlag)26] && ArenaUtilityUi.Addon("XBMContentsMainHUD") != null && (!stage.HasNavigationRoute || ArenaBoardRoute.IsOnBoard(stage.Id, ((IGameObject)Services.Objects.LocalPlayer).Position))) ? ArenaRewardPhase.Returned : ((flag2 || flag3) ? ArenaRewardPhase.Loading : ArenaRewardPhase.Closed));
			Trace(Array.Empty<ArenaValue>(), $"窗口关闭/{arenaRewardPhase}/战斗={condition[(ConditionFlag)26]}/交互={flag2}");
			return new ArenaRewardView(arenaRewardPhase);
		}
		ArenaValue[] array = ArenaUtilityUi.Values(ptr);
		if (array.Length == 0)
		{
			return new ArenaRewardView(ArenaRewardPhase.Loading);
		}
		ArenaRewardContents arenaRewardContents;
		try
		{
			arenaRewardContents = ArenaRewardDecoder.Decode(array);
		}
		catch (InvalidOperationException ex)
		{
			Trace(array, "读取中：" + ex.Message);
			return new ArenaRewardView(ArenaRewardPhase.Loading);
		}
		AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("SelectYesno");
		if (ptr2 == null)
		{
			Trace(array, $"选择/{arenaRewardContents.CoinsAvailable}/{arenaRewardContents.Balance}/{string.Join(',', arenaRewardContents.Options.Select((ArenaTreasureOption o) => o.ItemId))}");
			return new ArenaRewardView(ArenaRewardPhase.Selection, arenaRewardContents);
		}
		string text = ArenaUtilityUi.Values(ptr2).FirstOrDefault((ArenaValue v) => v.Index == 0)?.Text;
		if (text != null)
		{
			Trace(array, text);
		}
		if (!string.IsNullOrEmpty(text))
		{
			return new ArenaRewardView(ArenaRewardPhase.Confirmation, arenaRewardContents, text);
		}
		return new ArenaRewardView(ArenaRewardPhase.Loading);
	}

	private void Trace(ArenaValue[] values, string observation)
	{
		if (lastTrace == observation)
		{
			return;
		}
		lastTrace = observation;
		try
		{
			string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text);
			File.WriteAllText(Path.Combine(text, "arena-rewards-latest.json"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Stage = stage.Id,
				Observation = observation,
				Values = values
			}, new JsonSerializerOptions
			{
				WriteIndented = true,
				Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
			}));
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Reward diagnostic failed", Array.Empty<object>());
		}
	}

	public unsafe bool TryChoose(int row)
	{
		ArenaRewardView arenaRewardView = Read();
		bool flag = arenaRewardView.Phase != ArenaRewardPhase.Selection;
		if (!flag)
		{
			bool flag2 = ((row < -1 || row > 3) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			return false;
		}
		if ((row < 0) ? (!arenaRewardView.Contents.CoinsAvailable) : (!arenaRewardView.Contents.Options.Any((ArenaTreasureOption o) => o.Row == row)))
		{
			return false;
		}
		return ArenaUtilityUi.ClickRegistered(ArenaUtilityUi.Addon("XBMContentsBooty"), (uint)(row + 4));
	}

	public unsafe bool TryTakeAll()
	{
		ArenaRewardView arenaRewardView = Read();
		if (arenaRewardView.Phase == ArenaRewardPhase.Selection)
		{
			ArenaRewardContents contents = arenaRewardView.Contents;
			if ((object)contents != null)
			{
				ArenaTreasureOption[] options = contents.Options;
				if (options != null && options.Length > 0)
				{
					return ArenaUtilityUi.ClickRegistered(ArenaUtilityUi.Addon("XBMContentsBooty"), 1u);
				}
			}
		}
		return false;
	}

	public unsafe bool TryExit()
	{
		if (Read().Phase == ArenaRewardPhase.Selection)
		{
			return ArenaUtilityUi.ClickButton(ArenaUtilityUi.Addon("XBMContentsBooty"), 47u, 0u);
		}
		return false;
	}

	public unsafe bool TryAnswer(string prompt, bool yes)
	{
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		ArenaRewardView arenaRewardView = Read();
		if (arenaRewardView.Phase != ArenaRewardPhase.Confirmation || arenaRewardView.Prompt != prompt)
		{
			return false;
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)ArenaUtilityUi.Addon("SelectYesno");
		AtkComponentButton* ptr2 = (yes ? ((AddonSelectYesno)ptr).YesButton : ((AddonSelectYesno)ptr).NoButton);
		if (ptr2 == null || !((AtkComponentButton)ptr2).IsEnabled || !UiInteractionDelay.Ready($"reward/answer/{ptr}/{yes}/{prompt}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = ((!yes) ? 1 : 0);
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}
}
