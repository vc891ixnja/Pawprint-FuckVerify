using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaTreasureWorld(Func<bool> authorized, ArenaStage stage) : IArenaTreasureWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private string? lastError;

	public IArenaEquipmentWorld Equipment { get; } = new ArenaEquipmentWorld(authorized, stage);

	private unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	private unsafe static ArenaValue Value(AtkUnitBase* a, int i)
	{
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected I4, but got Unknown
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Invalid comparison between Unknown and I4
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Invalid comparison between Unknown and I4
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0092: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		AtkValue val = ((AtkValue*)((AtkUnitBase)a).AtkValues)[i];
		AtkValueType val2 = (AtkValueType)(val.Type & 0xF);
		long? number = (val2 - 2) switch
		{
			3 => val.UInt, 
			1 => val.Int, 
			0 => val.Bool ? 1 : 0, 
			_ => null, 
		};
		bool flag = (((int)val2 == 8 || (int)val2 == 10) ? true : false);
		object obj;
		if (!flag || val.String.Value == null)
		{
			obj = null;
		}
		else
		{
			ReadOnlySeStringSpan val3 = new ReadOnlySeStringSpan(val.String.Value);
			obj = ((ReadOnlySeStringSpan)(ref val3)).ExtractText();
		}
		string text = (string)obj;
		return new ArenaValue(i, number, text);
	}

	public unsafe ArenaTreasureView Read()
	{
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0108: Unknown result type (might be due to invalid IL or missing references)
		ICondition condition = Services.Condition;
		bool flag = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		int num = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		if (authorized() && Services.ClientState.IsLoggedIn && character != 0L && (Services.PlayerState.ContentId == character || (flag && Services.PlayerState.ContentId == 0L)) && (Services.ClientState.TerritoryType == stage.Territory || (flag && Services.ClientState.TerritoryType == 0)) && (num == stage.Content || (flag && num == 0)))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || !((IGameObject)localPlayer).IsDead)
			{
				IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
				if (localPlayer2 == null || ((ICharacter)localPlayer2).ClassJob.RowId == 43)
				{
					ArenaTreasureContents contents = new ArenaTreasureContents(Array.Empty<ArenaTreasureOption>(), Array.Empty<uint>());
					if (flag || Services.Objects.LocalPlayer == null)
					{
						return new ArenaTreasureView(ArenaTreasurePhase.Loading, contents);
					}
					if (condition[(ConditionFlag)26] || Addon("XBMStageDetailList") != null || Addon("XBMPetParty") != null || Addon("XBMContentsBooty") != null || Addon("XBMContentsItemShop") != null)
					{
						return new ArenaTreasureView(ArenaTreasurePhase.Blocked, contents);
					}
					AtkUnitBase* ptr = Addon("XBMContentsTreasure");
					AtkUnitBase* ptr2 = Addon("SelectYesno");
					if (ptr == null)
					{
						return new ArenaTreasureView((ptr2 != null) ? ArenaTreasurePhase.Blocked : ((!condition[(ConditionFlag)33] && !condition[(ConditionFlag)31] && Addon("XBMContentsMainHUD") != null) ? ArenaTreasurePhase.Returned : ArenaTreasurePhase.Loading), contents);
					}
					bool flag2 = !((AtkUnitBase)ptr).IsReady || ((AtkUnitBase)ptr).AtkValues == null;
					if (!flag2)
					{
						ushort atkValuesCount = ((AtkUnitBase)ptr).AtkValuesCount;
						bool flag3 = ((atkValuesCount < 124 || atkValuesCount > 4096) ? true : false);
						flag2 = flag3;
					}
					if (flag2)
					{
						return new ArenaTreasureView(ArenaTreasurePhase.Loading, contents);
					}
					ArenaValue[] array = new ArenaValue[((AtkUnitBase)ptr).AtkValuesCount];
					for (int i = 0; i < array.Length; i++)
					{
						array[i] = Value(ptr, i);
					}
					ArenaTreasureContents contents2;
					try
					{
						contents2 = ArenaTreasureDecoder.Decode(array);
						lastError = null;
					}
					catch (InvalidOperationException ex)
					{
						if (lastError != ex.Message)
						{
							lastError = ex.Message;
							Services.Log.Warning("Arena treasure waiting: " + ex.Message, Array.Empty<object>());
							try
							{
								string text = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
								Directory.CreateDirectory(text);
								File.WriteAllText(Path.Combine(text, "arena-treasure-latest.json"), JsonSerializer.Serialize(new
								{
									At = DateTimeOffset.Now,
									Error = ex.Message,
									Values = array
								}));
							}
							catch (Exception ex2)
							{
								Services.Log.Warning(ex2, "Treasure diagnostic failed", Array.Empty<object>());
							}
						}
						return new ArenaTreasureView(ArenaTreasurePhase.Loading, contents);
					}
					if (ptr2 == null)
					{
						return new ArenaTreasureView(ArenaTreasurePhase.Selection, contents2);
					}
					if (!((AtkUnitBase)ptr2).IsReady || ((AtkUnitBase)ptr2).AtkValues == null || ((AtkUnitBase)ptr2).AtkValuesCount == 0)
					{
						return new ArenaTreasureView(ArenaTreasurePhase.Loading, contents2);
					}
					string text2 = Value(ptr2, 0).Text ?? "";
					return new ArenaTreasureView((!string.IsNullOrWhiteSpace(text2)) ? ArenaTreasurePhase.Confirmation : ArenaTreasurePhase.Loading, contents2, text2);
				}
			}
		}
		throw new InvalidOperationException("宝箱任务、角色或奇盘已变化");
	}

	public unsafe bool TryChoose(ArenaTreasureOption option)
	{
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_0207: Unknown result type (might be due to invalid IL or missing references)
		//IL_020c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Invalid comparison between Unknown and I4
		ArenaTreasureView arenaTreasureView = Read();
		if (arenaTreasureView.Phase == ArenaTreasurePhase.Loading)
		{
			return false;
		}
		if (arenaTreasureView.Phase != ArenaTreasurePhase.Selection || !((ReadOnlySpan<ArenaTreasureOption>)arenaTreasureView.Contents.Options).Contains(option))
		{
			throw new InvalidOperationException("待领取的宝箱奖励已变化");
		}
		AtkUnitBase* ptr = Addon("XBMContentsTreasure");
		AtkResNode* nodeById = ((AtkUnitBase)ptr).GetNodeById((uint)(9 + option.Row));
		if (nodeById == null || !((AtkResNode)nodeById).IsVisible() || !((Enum)((AtkResNode)nodeById).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32))
		{
			return false;
		}
		AtkEvent* ptr2 = ((AtkEventManager)(&((AtkResNode)nodeById).AtkEventManager)).Event;
		AtkEvent* ptr3 = null;
		int num = 0;
		while (ptr2 != null && num < 64)
		{
			if (((AtkEvent)ptr2).Listener == ptr && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 25 && ((AtkEvent)ptr2).Param == option.Row + 2)
			{
				if (ptr3 != null)
				{
					throw new InvalidOperationException("宝箱奖励点击事件不唯一");
				}
				ptr3 = ptr2;
			}
			num++;
			ptr2 = ((AtkEvent)ptr2).NextEvent;
		}
		if (ptr3 == null)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"treasure/choose/{ptr}/{option.Row}/{option.ItemId}"))
		{
			return false;
		}
		Services.Log.Information($"Arena treasure choose row={option.Row}, item={option.ItemId}, name={ArenaItemCatalog.Items[option.ItemId].Name}, priority={ArenaTreasurePolicy.Score(option.ItemId, (IReadOnlyCollection<uint>)(object)arenaTreasureView.Contents.Equipment):F2}", Array.Empty<object>());
		AtkEvent val = *ptr3;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr3).Listener).ReceiveEvent((AtkEventType)25, option.Row + 2, &val, &val2);
		return true;
	}

	public unsafe bool TryExit()
	{
		if (Read().Phase != ArenaTreasurePhase.Selection || ArenaUtilityUi.Addon("XBMContentsItemDispose") != null)
		{
			return false;
		}
		return ArenaUtilityUi.ClickButton(Addon("XBMContentsTreasure"), 44u, 0u);
	}

	public unsafe bool TryConfirmExit(string prompt)
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		ArenaTreasureView arenaTreasureView = Read();
		if (arenaTreasureView.Phase != ArenaTreasurePhase.Confirmation || arenaTreasureView.Prompt != prompt || !ArenaTreasureDecoder.IsExitPrompt(prompt))
		{
			return false;
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)Addon("SelectYesno");
		if (((AddonSelectYesno)ptr).YesButton == null || !((AtkComponentButton)((AddonSelectYesno)ptr).YesButton).IsEnabled || !UiInteractionDelay.Ready($"treasure/exit/{ptr}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = 0;
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}

	public unsafe bool TryAnswer(uint itemId, bool yes)
	{
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_010e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		ArenaTreasureView arenaTreasureView = Read();
		if (arenaTreasureView.Phase == ArenaTreasurePhase.Loading)
		{
			return false;
		}
		if (arenaTreasureView.Phase != ArenaTreasurePhase.Confirmation || !ArenaTreasureDecoder.MatchesPrompt(arenaTreasureView.Prompt, itemId) || !arenaTreasureView.Contents.Options.Any((ArenaTreasureOption o) => o.ItemId == itemId))
		{
			throw new InvalidOperationException("宝箱确认道具不一致");
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)Addon("SelectYesno");
		AtkComponentButton* ptr2 = (yes ? ((AddonSelectYesno)ptr).YesButton : ((AddonSelectYesno)ptr).NoButton);
		if (ptr2 == null || !((AtkComponentButton)ptr2).IsEnabled)
		{
			return false;
		}
		if (!UiInteractionDelay.Ready($"treasure/answer/{ptr}/{itemId}/{yes}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = ((!yes) ? 1 : 0);
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}
}
