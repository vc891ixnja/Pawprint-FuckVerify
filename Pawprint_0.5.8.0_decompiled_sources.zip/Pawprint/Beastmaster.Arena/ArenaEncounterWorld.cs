using System;
using System.IO;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Beastmaster.Core.I18N;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using FFXIVClientStructs.FFXIV.Component.GUI;
using InteropGenerator.Runtime;
using Lumina.Text.ReadOnly;

namespace Beastmaster.Arena;

internal sealed class ArenaEncounterWorld : IArenaEncounterWorld
{
	private readonly ArenaStage stage;

	private string? lastPending;

	private long nextPendingLog;

	private string? lastFlutes;

	private readonly ulong character;

	public IArenaEquipmentWorld Equipment { get; }

	public IArenaRewardWorld Rewards { get; }

	private static bool Transitioning
	{
		get
		{
			if (!Services.Condition[(ConditionFlag)45] && !Services.Condition[(ConditionFlag)51] && !Services.Condition[(ConditionFlag)58] && !Services.Condition[(ConditionFlag)78])
			{
				return Services.Condition[(ConditionFlag)35];
			}
			return true;
		}
	}

	public ArenaEncounterWorld(Func<bool> authorized, int? returnNode = 1, ArenaStage? selectedStage = null)
	{
		_003Cauthorized_003EP = authorized;
		_003CreturnNode_003EP = returnNode;
		stage = selectedStage ?? ArenaStage.Get(1);
		Equipment = new ArenaEquipmentWorld(_003Cauthorized_003EP, selectedStage ?? ArenaStage.Get(1));
		Rewards = new ArenaRewardWorld(_003Cauthorized_003EP, selectedStage ?? ArenaStage.Get(1));
		character = Services.PlayerState.ContentId;
		base._002Ector();
	}

	private unsafe static AtkUnitBase* Addon(string name)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* address = (AtkUnitBase*)Services.GameGui.GetAddonByName(name, 1).Address;
		if (address == null || !((AtkUnitBase)address).IsVisible)
		{
			return null;
		}
		return address;
	}

	private unsafe void Validate()
	{
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		bool transitioning = Transitioning;
		int num = ((GameMain.Instance() != null) ? ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId : 0);
		if (Services.ClientState.IsLoggedIn && character != 0L && (Services.PlayerState.ContentId == character || (transitioning && Services.PlayerState.ContentId == 0L)) && (Services.ClientState.TerritoryType == stage.Territory || (transitioning && Services.ClientState.TerritoryType == 0)) && (num == stage.Content || (transitioning && num == 0)))
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || !((IGameObject)localPlayer).IsDead)
			{
				IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
				if (localPlayer2 == null || ((ICharacter)localPlayer2).ClassJob.RowId == 43)
				{
					return;
				}
			}
		}
		throw new InvalidOperationException($"角色或{stage.Name}场地已变化（区域 {Services.ClientState.TerritoryType} / 副本 {num}）");
	}

	public unsafe ArenaEncounterView Read()
	{
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c0: Invalid comparison between Unknown and I4
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Invalid comparison between Unknown and I4
		Validate();
		if (Transitioning || Services.Objects.LocalPlayer == null)
		{
			return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>());
		}
		if (Addon("XBMResult") != null)
		{
			return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>());
		}
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		AtkUnitBase* ptr = Addon("SelectYesno");
		if (ptr != null)
		{
			if (!((AtkUnitBase)ptr).IsReady)
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>());
			}
			bool flag = ((AtkUnitBase)ptr).AtkValuesCount > 0 && ((AtkUnitBase)ptr).AtkValues != null && ((CStringPointer)(&((AtkValue)((AtkUnitBase)ptr).AtkValues).String)).Value != null;
			if (flag)
			{
				AtkValueType val = (AtkValueType)(((AtkValue)((AtkUnitBase)ptr).AtkValues).Type & -33);
				bool flag2 = (((int)val == 8 || (int)val == 10) ? true : false);
				flag = flag2;
			}
			object obj;
			if (!flag)
			{
				obj = "";
			}
			else
			{
				ReadOnlySeStringSpan val2 = new ReadOnlySeStringSpan(((CStringPointer)(&((AtkValue)((AtkUnitBase)ptr).AtkValues).String)).Value);
				obj = ((ReadOnlySeStringSpan)(ref val2)).ExtractText();
			}
			string text = (string)obj;
			return new ArenaEncounterView(ArenaEncounterPhase.Confirmation, Array.Empty<ArenaPet>(), Addon("XBMContentsBooty") != null && GameText.Matches("Reward.TakeAllConfirm", text), null, ArenaBattleConfirmation.Matches(text));
		}
		AtkUnitBase* ptr2 = Addon("XBMPetParty");
		ArenaBoardRoute arenaBoardRoute = (stage.HasNavigationRoute ? ArenaBoardRoute.Get(stage.Id) : null);
		int? num = arenaBoardRoute?.FindTile(((IGameObject)localPlayer).Position);
		if (Addon("XBMStageDetailList") != null && ptr2 != null)
		{
			if (!stage.HasNavigationRoute)
			{
				goto IL_01ef;
			}
			if (num.HasValue)
			{
				int valueOrDefault = num.GetValueOrDefault();
				if (arenaBoardRoute.CanHaveBattle(valueOrDefault) && (!_003CreturnNode_003EP.HasValue || _003CreturnNode_003EP == valueOrDefault))
				{
					goto IL_01ef;
				}
			}
		}
		goto IL_024c;
		IL_024c:
		if (!stage.HasNavigationRoute)
		{
			if (Addon("XBMContentsBooty") != null)
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Loot, Array.Empty<ArenaPet>());
			}
			if (Services.Condition[(ConditionFlag)26])
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Battle, Array.Empty<ArenaPet>());
			}
			if (Addon("XBMContentsMainHUD") != null && !Services.Condition[(ConditionFlag)33])
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Returned, Array.Empty<ArenaPet>());
			}
			return Pending(((IGameObject)localPlayer).Position, num);
		}
		if (!arenaBoardRoute.IsOnBoard(((IGameObject)localPlayer).Position))
		{
			if (Addon("XBMContentsBooty") != null)
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Loot, Array.Empty<ArenaPet>());
			}
			AtkUnitBase* ptr3 = Addon("XBMContentsMainHUD");
			AgentContext* ptr4 = AgentContext.Instance();
			bool flag3 = ptr3 != null && Addon("ContextMenu") != null && ptr4 != null && ((AgentContext)ptr4).OwnerAddon == ((AtkUnitBase)ptr3).Id;
			if (ptr3 != null && (!Services.Condition[(ConditionFlag)33] || flag3))
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Battle, Array.Empty<ArenaPet>());
			}
			return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>());
		}
		if (num.HasValue && (!_003CreturnNode_003EP.HasValue || num == _003CreturnNode_003EP) && Addon("XBMContentsMainHUD") != null)
		{
			return new ArenaEncounterView(ArenaEncounterPhase.Returned, Array.Empty<ArenaPet>());
		}
		return Pending(((IGameObject)localPlayer).Position, num);
		IL_01ef:
		if (Services.Condition[(ConditionFlag)33] || Services.Condition[(ConditionFlag)31])
		{
			if (!ArenaPartyReader.TryRead(ptr2, allowEmpty: false, out ArenaPet[] pets))
			{
				return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>(), TakeAllPrompt: false, "斗兽 · 等待编队数据加载");
			}
			TraceFlutes("observed", pets);
			return new ArenaEncounterView(ArenaEncounterPhase.Setup, pets);
		}
		goto IL_024c;
	}

	private unsafe ArenaEncounterView Pending(Vector3 position, int? tile)
	{
		string text = $"stage={stage.Id}, tile={tile}, return={_003CreturnNode_003EP}, occupied33={Services.Condition[(ConditionFlag)33]}, event={Services.Condition[(ConditionFlag)31]}, party={Addon("XBMPetParty") != null}, setup={Addon("XBMStageDetailList") != null}, hud={Addon("XBMContentsMainHUD") != null}, position={position}";
		if (text != lastPending && Environment.TickCount64 >= nextPendingLog)
		{
			Services.Log.Information("Arena encounter waiting: " + text, Array.Empty<object>());
			lastPending = text;
			nextPendingLog = Environment.TickCount64 + 1000;
		}
		return new ArenaEncounterView(ArenaEncounterPhase.Loading, Array.Empty<ArenaPet>(), TakeAllPrompt: false, "斗兽 · 等待战斗界面就绪");
	}

	private unsafe bool Callback(string name, ArenaEncounterPhase phase, params int[] request)
	{
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		if (!_003Cauthorized_003EP())
		{
			throw new InvalidOperationException("斗兽任务未运行");
		}
		if (Read().Phase != phase)
		{
			throw new InvalidOperationException("界面状态已变化，取消本次操作");
		}
		AtkUnitBase* ptr = Addon(name);
		if (ptr == null)
		{
			throw new InvalidOperationException("等待的界面已关闭");
		}
		if (!((AtkUnitBase)ptr).IsReady || !UiInteractionDelay.Ready($"encounter/{ptr}/{phase}/{string.Join(',', request)}"))
		{
			return false;
		}
		AtkValue* ptr2 = (AtkValue*)stackalloc AtkValue[request.Length];
		AtkValue val = default(AtkValue);
		for (int i = 0; i < request.Length; i++)
		{
			byte* num = (byte*)ptr2 + (nint)i * (nint)Unsafe.SizeOf<AtkValue>();
			((AtkValue)(ref val))._002Ector();
			val.Type = (AtkValueType)3;
			val.Int = request[i];
			Unsafe.Write(num, val);
		}
		((AtkUnitBase)ptr).FireCallback((uint)request.Length, ptr2, true);
		return true;
	}

	private void TraceFlutes(string state, ArenaPet[] pets, int? attemptedRow = null)
	{
		string text = $"{state}/{attemptedRow}:" + string.Join(",", pets.Select((ArenaPet p) => $"{p.Row}/{p.PetId}/{p.Slot}"));
		if (text == lastFlutes)
		{
			return;
		}
		lastFlutes = text;
		Services.Log.Information("Arena flute setup " + text, Array.Empty<object>());
		try
		{
			string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text2);
			string path = Path.Combine(text2, "arena-flutes-latest.json");
			DateTimeOffset now = DateTimeOffset.Now;
			string version = typeof(ArenaEncounterWorld).Assembly.GetName().Version?.ToString();
			int id = stage.Id;
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			File.WriteAllText(path, JsonSerializer.Serialize(new
			{
				At = now,
				Version = version,
				State = state,
				AttemptedRow = attemptedRow,
				Stage = id,
				Position = ((localPlayer != null) ? ((IGameObject)localPlayer).Position.ToString() : null),
				Pets = pets.Select((ArenaPet p) => new
				{
					Row = p.Row,
					NotebookNumber = p.PetId,
					Name = p.Name,
					Hp = p.Hp,
					Slot = p.Slot,
					Flute = ((p.Slot < 3) ? new int?(p.Slot + 1) : ((int?)null))
				}).ToArray()
			}, new JsonSerializerOptions
			{
				WriteIndented = true,
				Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
			}));
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Arena flute diagnostic failed", Array.Empty<object>());
		}
	}

	public unsafe bool TryAssign(int row)
	{
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Invalid comparison between Unknown and I4
		if (!_003Cauthorized_003EP())
		{
			throw new InvalidOperationException("斗兽任务未运行");
		}
		ArenaEncounterView arenaEncounterView = Read();
		ArenaEncounterPhase phase = arenaEncounterView.Phase;
		if ((phase == ArenaEncounterPhase.Loading || phase == ArenaEncounterPhase.Unknown) ? true : false)
		{
			return false;
		}
		if (arenaEncounterView.Phase != ArenaEncounterPhase.Setup || !arenaEncounterView.Pets.Any((ArenaPet p) => p.Row == row))
		{
			throw new InvalidOperationException("兽笛编队界面或魔兽行已变化");
		}
		AtkUnitBase* ptr = Addon("XBMPetParty");
		if (ptr == null || !((AtkUnitBase)ptr).IsReady)
		{
			return false;
		}
		AtkComponentList* componentListById = ((AtkUnitBase)ptr).GetComponentListById(11u);
		if (componentListById == null || ((AtkComponentList)componentListById).OwnerNode == null || !((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).IsVisible() || !((Enum)((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32) || !((AtkComponentList)componentListById).IsItemInteractionEnabled || ((AtkComponentList)componentListById).IsUpdatePending || row < 0 || row >= ((AtkComponentList)componentListById).ListLength || ((AtkComponentList)componentListById).GetItemDisabledState(row))
		{
			return false;
		}
		int num = 0;
		AtkEvent* ptr2 = ((AtkEventManager)(&((AtkComponentNode)((AtkComponentList)componentListById).OwnerNode).AtkEventManager)).Event;
		int num2 = 0;
		while (ptr2 != null && num2 < 64)
		{
			if (((AtkEvent)ptr2).Listener == ptr && (int)((AtkEventState)(&((AtkEvent)ptr2).State)).EventType == 35 && ((AtkEvent)ptr2).Param == 0)
			{
				num++;
			}
			num2++;
			ptr2 = ((AtkEvent)ptr2).NextEvent;
		}
		switch (num)
		{
		case 0:
			return false;
		default:
			throw new InvalidOperationException("魔兽列表点击事件不唯一");
		case 1:
			if (!UiInteractionDelay.Ready($"encounter/assign/{ptr}/{row}/{string.Join(',', arenaEncounterView.Pets.Select((ArenaPet p) => p.Slot))}"))
			{
				return false;
			}
			TraceFlutes("assign", arenaEncounterView.Pets, row);
			((AtkComponentList)componentListById).SelectItem(row, false);
			((AtkComponentList)componentListById).DispatchItemEvent(row, (AtkEventType)35);
			return true;
		}
	}

	public bool StartBattle()
	{
		return Callback("XBMStageDetailList", ArenaEncounterPhase.Setup, 8);
	}

	public bool ConfirmStartBattle()
	{
		if (!Read().UnderfilledFlutesPrompt)
		{
			throw new InvalidOperationException("当前不是兽笛未满开战确认");
		}
		return Callback("SelectYesno", ArenaEncounterPhase.Confirmation, default(int));
	}

	public bool TakeAll()
	{
		return Callback("XBMContentsBooty", ArenaEncounterPhase.Loot, 1);
	}

	public bool ConfirmTakeAll()
	{
		if (!Read().TakeAllPrompt)
		{
			throw new InvalidOperationException("当前不是全部领取确认");
		}
		return Callback("SelectYesno", ArenaEncounterPhase.Confirmation, default(int));
	}
}
