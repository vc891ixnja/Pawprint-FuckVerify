using System;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using Beastmaster.Core.Arena;
using Beastmaster.Core.I18N;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI;
using FFXIVClientStructs.FFXIV.Component.GUI;

namespace Beastmaster.Arena;

internal sealed class ArenaEquipmentWorld(Func<bool> authorized, ArenaStage stage) : IArenaEquipmentWorld
{
	private readonly ulong character = Services.PlayerState.ContentId;

	private bool wasVisible;

	private string? lastTrace;

	public unsafe ArenaEquipmentView Read()
	{
		//IL_0117: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsItemDispose");
		if (ptr == null && !wasVisible)
		{
			return new ArenaEquipmentView(ArenaEquipmentPhase.Closed, null, "", ReadOwned());
		}
		ICondition condition = Services.Condition;
		bool num = condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35];
		if (!authorized() || !Services.ClientState.IsLoggedIn)
		{
			throw new InvalidOperationException("装备替换任务已结束");
		}
		if (num || Services.Objects.LocalPlayer == null)
		{
			return new ArenaEquipmentView(ArenaEquipmentPhase.Loading);
		}
		if (character != 0L && Services.PlayerState.ContentId == character && Services.ClientState.TerritoryType == stage.Territory && GameMain.Instance() != null && ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId == stage.Content)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if ((localPlayer == null || !((IGameObject)localPlayer).IsDead) && ((ICharacter)Services.Objects.LocalPlayer).ClassJob.RowId == 43)
			{
				if (ptr == null || ArenaUtilityUi.Addon("XBMResult") != null)
				{
					wasVisible = false;
					return new ArenaEquipmentView(ArenaEquipmentPhase.Closed, null, "", ReadOwned());
				}
				wasVisible = true;
				ArenaValue[] array = ArenaUtilityUi.Values(ptr);
				if (array.Length < 56 || array[0].Number == 0)
				{
					return new ArenaEquipmentView(ArenaEquipmentPhase.Loading);
				}
				ArenaEquipmentContents contents;
				try
				{
					contents = ArenaEquipmentPolicy.Decode(array);
				}
				catch (InvalidOperationException ex)
				{
					Trace(array, ex.Message);
					return new ArenaEquipmentView(ArenaEquipmentPhase.Loading);
				}
				AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("SelectYesno");
				if (ptr2 == null)
				{
					return new ArenaEquipmentView(ArenaEquipmentPhase.Selection, contents);
				}
				string text = ArenaUtilityUi.Values(ptr2).FirstOrDefault()?.Text;
				if (!string.IsNullOrWhiteSpace(text))
				{
					Trace(array, text);
				}
				if (text != null && ParentOwnsPrompt(text))
				{
					return new ArenaEquipmentView(ArenaEquipmentPhase.ParentConfirmation, contents, text);
				}
				return new ArenaEquipmentView(string.IsNullOrWhiteSpace(text) ? ArenaEquipmentPhase.Loading : ArenaEquipmentPhase.Confirmation, contents, text ?? "");
			}
		}
		throw new InvalidOperationException("装备替换角色或奇盘已变化");
	}

	private unsafe static bool ParentOwnsPrompt(string prompt)
	{
		if (GameText.Matches("Equip.ReplacePrompt.Main", prompt) || GameText.Matches("Equip.ReplacePrompt.Suit", prompt) || GameText.Matches("Equip.ReplacePrompt.No", prompt))
		{
			return false;
		}
		try
		{
			AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsBooty");
			if (ptr != null)
			{
				ArenaRewardContents arenaRewardContents = ArenaRewardDecoder.Decode(ArenaUtilityUi.Values(ptr));
				if (ArenaRewardDecoder.ExitPrompt(prompt) || arenaRewardContents.Options.Any((ArenaTreasureOption o) => ArenaRewardDecoder.ItemPrompt(prompt, o.ItemId)) || (arenaRewardContents.CoinsAvailable && ArenaRewardDecoder.CoinPrompt(prompt, arenaRewardContents.Coins)) || GameText.Matches("Reward.TakeAllConfirm", prompt) || (GameText.Language == "zhCN" && prompt.StartsWith("确定要全部获取", StringComparison.Ordinal)))
				{
					return true;
				}
			}
			AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("XBMContentsTreasure");
			if (ptr2 != null)
			{
				ArenaTreasureContents arenaTreasureContents = ArenaTreasureDecoder.Decode(ArenaUtilityUi.Values(ptr2));
				if (ArenaTreasureDecoder.IsExitPrompt(prompt) || arenaTreasureContents.Options.Any((ArenaTreasureOption o) => ArenaTreasureDecoder.MatchesPrompt(prompt, o.ItemId)))
				{
					return true;
				}
			}
			AtkUnitBase* ptr3 = ArenaUtilityUi.Addon("XBMContentsItemShop");
			if (ptr3 != null)
			{
				ArenaShopContents arenaShopContents = ArenaShopDecoder.Decode(ArenaUtilityUi.Values(ptr3));
				if (ArenaShopDecoder.IsExitPrompt(prompt) || arenaShopContents.Offers.Where((ArenaShopOffer o) => ArenaItemCatalog.Items[o.ItemId].Category != 3).Any((ArenaShopOffer o) => ArenaShopDecoder.MatchesBuyPrompt(prompt, new ArenaShopPurchase(o), Array.Empty<ArenaShopPet>())))
				{
					return true;
				}
			}
		}
		catch (InvalidOperationException)
		{
		}
		return false;
	}

	private unsafe static uint[]? ReadOwned()
	{
		try
		{
			AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsBooty");
			if (ptr != null)
			{
				return ArenaRewardDecoder.Decode(ArenaUtilityUi.Values(ptr)).Owned;
			}
			AtkUnitBase* ptr2 = ArenaUtilityUi.Addon("XBMContentsTreasure");
			if (ptr2 != null)
			{
				return ArenaTreasureDecoder.Decode(ArenaUtilityUi.Values(ptr2)).Equipment;
			}
			AtkUnitBase* ptr3 = ArenaUtilityUi.Addon("XBMContentsItemShop");
			if (ptr3 != null)
			{
				return ArenaShopDecoder.Decode(ArenaUtilityUi.Values(ptr3)).Owned;
			}
		}
		catch (InvalidOperationException)
		{
		}
		return null;
	}

	private void Trace(ArenaValue[] values, string prompt)
	{
		string text = prompt + "/" + string.Join(',', from v in values
			where v.Number.HasValue
			select v.Number);
		if (text == lastTrace)
		{
			return;
		}
		lastTrace = text;
		try
		{
			string text2 = Path.Combine(Services.PluginInterface.GetPluginConfigDirectory(), "diagnostics");
			Directory.CreateDirectory(text2);
			File.WriteAllText(Path.Combine(text2, "arena-equipment-latest.json"), JsonSerializer.Serialize(new
			{
				At = DateTimeOffset.Now,
				Stage = stage.Id,
				Prompt = prompt,
				Values = values
			}, new JsonSerializerOptions
			{
				WriteIndented = true,
				Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
			}));
		}
		catch (Exception ex)
		{
			Services.Log.Warning(ex, "Equipment diagnostic failed", Array.Empty<object>());
		}
	}

	private bool IsCurrent(ArenaEquipmentContents contents)
	{
		ArenaEquipmentView arenaEquipmentView = Read();
		if ((object)arenaEquipmentView != null && arenaEquipmentView.Phase == ArenaEquipmentPhase.Selection)
		{
			ArenaEquipmentContents contents2 = arenaEquipmentView.Contents;
			if ((object)contents2 != null && contents2.Incoming == contents.Incoming)
			{
				return ((ReadOnlySpan<ArenaEquipmentSlot>)contents2.Slots).SequenceEqual((ReadOnlySpan<ArenaEquipmentSlot>)contents.Slots);
			}
		}
		return false;
	}

	public unsafe bool TryChoose(ArenaEquipmentContents contents, ArenaEquipmentSlot slot)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Invalid comparison between Unknown and I4
		if (!IsCurrent(contents) || !((ReadOnlySpan<ArenaEquipmentSlot>)contents.Slots).Contains(slot))
		{
			return false;
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsItemDispose");
		AtkResNode* nodeById = ((AtkUnitBase)ptr).GetNodeById((uint)(14 + slot.Row * 2));
		if (nodeById == null || !((AtkResNode)nodeById).IsVisible() || !((Enum)((AtkResNode)nodeById).NodeFlags).HasFlag((Enum)(object)(NodeFlags)32))
		{
			return false;
		}
		AtkEvent* ptr2 = null;
		AtkEvent* ptr3 = ((AtkEventManager)(&((AtkResNode)nodeById).AtkEventManager)).Event;
		int num = 0;
		while (ptr3 != null && num < 64)
		{
			if (((AtkEvent)ptr3).Listener == ptr && (int)((AtkEventState)(&((AtkEvent)ptr3).State)).EventType == 9 && ((AtkEvent)ptr3).Param == slot.Row + 1)
			{
				if (ptr2 != null)
				{
					throw new InvalidOperationException("装备替换点击事件不唯一");
				}
				ptr2 = ptr3;
			}
			num++;
			ptr3 = ((AtkEvent)ptr3).NextEvent;
		}
		if (ptr2 == null || !UiInteractionDelay.Ready($"equipment/select/{ptr}/{contents.Incoming}/{slot.Row}"))
		{
			return false;
		}
		AtkEvent val = *ptr2;
		AtkEventData val2 = default(AtkEventData);
		((AtkEventListener)((AtkEvent)ptr2).Listener).ReceiveEvent((AtkEventType)9, slot.Row + 1, &val, &val2);
		Services.Log.Information($"Arena equipment replace: {slot.ItemId} -> {contents.Incoming}, row={slot.Row}", Array.Empty<object>());
		return true;
	}

	public unsafe bool TryAnswer(string prompt, bool yes)
	{
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013a: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		ArenaEquipmentView view = Read();
		if (view.Phase != ArenaEquipmentPhase.Confirmation || view.Prompt != prompt || view.Contents == null || (yes ? (!view.Contents.Slots.Any((ArenaEquipmentSlot s) => ArenaEquipmentPolicy.Matches(prompt, view.Contents.Incoming, s.ItemId))) : (!ArenaEquipmentPolicy.TryReadPrompt(prompt, out var _, out var _))))
		{
			return false;
		}
		AddonSelectYesno* ptr = (AddonSelectYesno*)ArenaUtilityUi.Addon("SelectYesno");
		AtkComponentButton* ptr2 = (yes ? ((AddonSelectYesno)ptr).YesButton : ((AddonSelectYesno)ptr).NoButton);
		if (ptr2 == null || !((AtkComponentButton)ptr2).IsEnabled || !UiInteractionDelay.Ready($"equipment/confirm/{ptr}/{prompt}/{yes}"))
		{
			return false;
		}
		AtkValue val = default(AtkValue);
		((AtkValue)(ref val))._002Ector();
		val.Type = (AtkValueType)3;
		val.Int = ((!yes) ? 1 : 0);
		AtkValue val2 = val;
		((AddonSelectYesno)ptr).FireCallback(1u, &val2, true);
		return true;
	}

	public unsafe bool TryCancel(ArenaEquipmentContents contents)
	{
		if (!IsCurrent(contents))
		{
			return false;
		}
		AtkUnitBase* ptr = ArenaUtilityUi.Addon("XBMContentsItemDispose");
		if (!UiInteractionDelay.Ready($"equipment/cancel/{ptr}/{contents.Incoming}"))
		{
			return false;
		}
		return ((AtkUnitBase)ptr).Close(true);
	}
}
