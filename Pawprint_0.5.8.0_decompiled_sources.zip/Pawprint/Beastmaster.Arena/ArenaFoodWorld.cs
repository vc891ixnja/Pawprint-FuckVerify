using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Arena;
using Dalamud.Game;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.ClientState.Statuses;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Client.UI.Agent;
using Lumina.Excel;
using Lumina.Excel.Sheets;

namespace Beastmaster.Arena;

internal sealed class ArenaFoodWorld(Func<bool> authorized, Func<bool> enabled, ArenaStage stage) : IArenaFoodWorld
{
	private const uint WellFed = 48u;

	private static readonly string[] Foods = new string[2] { "炖剑山芋", "焦糖爆米花" };

	private readonly ulong character = Services.PlayerState.ContentId;

	private long nextEatAttemptAt;

	public bool Enabled => enabled();

	public unsafe ArenaFoodView Read()
	{
		if (!authorized() || !Services.ClientState.IsLoggedIn || character == 0L || character != Services.PlayerState.ContentId)
		{
			throw new InvalidOperationException("食物任务、角色或奇盘已变化");
		}
		ICondition condition = Services.Condition;
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null || condition[(ConditionFlag)45] || condition[(ConditionFlag)51] || condition[(ConditionFlag)58] || condition[(ConditionFlag)78])
		{
			return new ArenaFoodView(InDuty: true, Occupied: true, TimeSpan.Zero, HasFood: false);
		}
		bool inDuty = Services.ClientState.TerritoryType == stage.Territory && GameMain.Instance() != null && ((GameMain)GameMain.Instance()).CurrentContentFinderConditionId == stage.Content;
		IStatus? obj = ((IEnumerable<IStatus>)((IBattleChara)localPlayer).StatusList).FirstOrDefault((Func<IStatus, bool>)((IStatus s) => s.StatusId == 48));
		TimeSpan remaining = TimeSpan.FromSeconds((obj != null) ? obj.RemainingTime : 0f);
		bool occupied = condition[(ConditionFlag)26] || condition[(ConditionFlag)31] || condition[(ConditionFlag)33] || ((IBattleChara)localPlayer).IsCasting || ((IGameObject)localPlayer).IsDead;
		return new ArenaFoodView(inDuty, occupied, remaining, HasFood());
	}

	public unsafe bool TryEat()
	{
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f4: Unknown result type (might be due to invalid IL or missing references)
		if (Environment.TickCount64 < nextEatAttemptAt)
		{
			return false;
		}
		nextEatAttemptAt = Environment.TickCount64 + 1500;
		if (Services.Condition[(ConditionFlag)4])
		{
			ActionManager* ptr = ActionManager.Instance();
			if (ptr != null && ((ActionManager)ptr).GetActionStatus((ActionType)5, 23u, 3758096384uL, true, true, (uint*)null) == 0)
			{
				((ActionManager)ptr).UseAction((ActionType)5, 23u, 3758096384uL, 0u, (UseActionMode)0, 0u, (bool*)null);
				Services.Log.Information("Arena food: dismount before eating", Array.Empty<object>());
			}
			nextEatAttemptAt = Environment.TickCount64 + 2500;
			return true;
		}
		InventoryItem* ptr2 = FindFoodItem();
		if (ptr2 == null)
		{
			return false;
		}
		AgentInventoryContext* ptr3 = AgentInventoryContext.Instance();
		if (ptr3 == null)
		{
			return false;
		}
		uint itemId = ((InventoryItem)ptr2).GetItemId();
		((AgentInventoryContext)ptr3).UseItem(itemId, ((InventoryItem)ptr2).Container, (uint)(ushort)((InventoryItem)ptr2).Slot, (short)0);
		Services.Log.Information($"Arena food: UseItem {itemId} ({((InventoryItem)ptr2).Container}/{((InventoryItem)ptr2).Slot})", Array.Empty<object>());
		return true;
	}

	private unsafe static bool HasFood()
	{
		return FindFoodItem() != null;
	}

	private unsafe static InventoryItem* FindFoodItem()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		InventoryManager* ptr = InventoryManager.Instance();
		if (ptr == null)
		{
			return null;
		}
		ExcelSheet<Item> excelSheet = Services.Data.GetExcelSheet<Item>((ClientLanguage?)null, (string)null);
		if (excelSheet == null)
		{
			return null;
		}
		Item val = default(Item);
		for (int i = 0; i < 4; i++)
		{
			InventoryContainer* inventoryContainer = ((InventoryManager)ptr).GetInventoryContainer((InventoryType)i);
			if (inventoryContainer == null || !((InventoryContainer)inventoryContainer).IsLoaded)
			{
				continue;
			}
			for (int j = 0; j < ((InventoryContainer)inventoryContainer).Size; j++)
			{
				InventoryItem* inventorySlot = ((InventoryContainer)inventoryContainer).GetInventorySlot(j);
				if (inventorySlot == null || ((InventoryItem)inventorySlot).IsSymbolic || ((InventoryItem)inventorySlot).ItemId == 0 || !excelSheet.TryGetRow(((InventoryItem)inventorySlot).GetBaseItemId(), ref val))
				{
					continue;
				}
				string text = ((object)((Item)(ref val)).Name/*cast due to .constrained prefix*/).ToString();
				string[] foods = Foods;
				foreach (string text2 in foods)
				{
					if (text == text2)
					{
						return inventorySlot;
					}
				}
			}
		}
		return null;
	}
}
