using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyCompany("Pawprint")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("驯兽师自动化捕获魔物")]
[assembly: AssemblyFileVersion("0.5.8.0")]
[assembly: AssemblyInformationalVersion("0.5.8.0")]
[assembly: AssemblyProduct("Pawprint")]
[assembly: AssemblyTitle("Pawprint")]
[assembly: AssemblyMetadata("RepositoryUrl", "")]
[assembly: TargetPlatform("Windows7.0")]
[assembly: SupportedOSPlatform("Windows7.0")]
[assembly: AssemblyVersion("0.5.8.0")]
[module: RefSafetyRules(11)]
