using System;
using System.IO;
using System.Threading.Tasks;
using Beastmaster.Core.Security;

namespace Beastmaster.Security;

internal sealed class PublicReleaseGuard
{
	private readonly string? directory;

	private readonly string version;

	private Task<IntegrityResult>? pending;

	private IntegrityResult result = new IntegrityResult(Valid: false, "正在校验自动斗兽文件，请稍后重试");

	private long nextCheck;

	internal bool CanRun
	{
		get
		{
			if (result.Valid)
			{
				return Environment.TickCount64 < nextCheck + 60000;
			}
			return false;
		}
	}

	internal string FailureReason
	{
		get
		{
			if (!result.Valid)
			{
				return result.Message;
			}
			return "自动斗兽文件校验超时，请重新加载插件";
		}
	}

	internal PublicReleaseGuard(string? directory)
	{
		this.directory = directory;
		version = typeof(Plugin).Assembly.GetName().Version?.ToString() ?? "";
		pending = Task.Run((Func<IntegrityResult>)Check);
	}

	internal void Tick()
	{
		Task<IntegrityResult> task = pending;
		if (task != null && task.IsCompleted)
		{
			result = pending.GetAwaiter().GetResult();
			pending = null;
			nextCheck = Environment.TickCount64 + 60000;
		}
		if (pending == null && Environment.TickCount64 >= nextCheck)
		{
			pending = Task.Run((Func<IntegrityResult>)Check);
		}
	}

	internal void RequireValid()
	{
		pending = null;
		result = Check();
		nextCheck = Environment.TickCount64 + 60000;
		if (!result.Valid)
		{
			throw new InvalidOperationException(result.Message);
		}
	}

	private IntegrityResult Check()
	{
		try
		{
			if (string.IsNullOrWhiteSpace(directory))
			{
				return new IntegrityResult(Valid: false, "无法取得插件安装目录，请重新加载插件");
			}
			using Stream stream = typeof(Plugin).Assembly.GetManifestResourceStream("Pawprint.ReleasePublicKey") ?? throw new InvalidOperationException("Missing release key");
			using StreamReader streamReader = new StreamReader(stream);
			return ReleaseIntegrity.Verify(directory, streamReader.ReadToEnd(), version);
		}
		catch (Exception)
		{
			return new IntegrityResult(Valid: false, "自动斗兽文件校验失败，请重新安装完整发布包");
		}
	}
}
