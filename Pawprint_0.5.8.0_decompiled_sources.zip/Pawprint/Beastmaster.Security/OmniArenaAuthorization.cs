using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Beastmaster.Core.Security;
using Omni.Verification;

namespace Beastmaster.Security;

internal static class OmniArenaAuthorization
{
	private sealed class Client(IVerificationClient inner) : IArenaAuthorizationClient, IDisposable, IArenaActivationClient
	{
		public ArenaAuthorizationState Current
		{
			get
			{
				AuthorizationState current = inner.Current;
				return new ArenaAuthorizationState(current.IsAuthorized, current.IsRefreshing, current.ExpiresAt, current.ReasonKey);
			}
		}

		public void UpdateIdentity(ulong accountId, ulong contentId)
		{
			inner.UpdateIdentity(accountId, contentId);
		}

		public async Task RefreshAsync(CancellationToken token)
		{
			await inner.RefreshAsync(token).ConfigureAwait(continueOnCapturedContext: false);
		}

		public async Task<ArenaActivationTicket> CreateTicketAsync(ArenaCredentialKind kind, CancellationToken token)
		{
			ActivationTicketResult activationTicketResult = await inner.CreateActivationTicketAsync((kind != ArenaCredentialKind.Machine) ? VerificationCredentialKind.Account : VerificationCredentialKind.Machine, token).ConfigureAwait(continueOnCapturedContext: false);
			return new ArenaActivationTicket(activationTicketResult.IsSuccess, activationTicketResult.Ticket, activationTicketResult.ExpiresAt, activationTicketResult.ReasonKey);
		}

		public void Dispose()
		{
			inner.Dispose();
		}
	}

	internal static IArenaAuthorizationClient Create(string version)
	{
		using Stream stream = typeof(Plugin).Assembly.GetManifestResourceStream("Pawprint.OfficeConnection") ?? throw new InvalidOperationException("Missing Office connection");
		using MemoryStream memoryStream = new MemoryStream();
		stream.CopyTo(memoryStream);
		byte[] array = memoryStream.ToArray();
		if (array.Length < 61 || array[0] != 1)
		{
			throw new InvalidOperationException("Invalid Office connection");
		}
		byte[] array2 = new byte[array.Length - 61];
		try
		{
			using AesGcm aesGcm = new AesGcm(array.AsSpan(1, 32), 16);
			aesGcm.Decrypt(array.AsSpan(33, 12), array.AsSpan(61), array.AsSpan(45, 16), array2);
			string[] array3 = Encoding.UTF8.GetString(array2).Split('\n', 2);
			Uri uri = new Uri(array3[0]);
			if (uri.Scheme != "https" || uri.AbsolutePath != "/" || uri.Query.Length != 0 || uri.UserInfo.Length != 0)
			{
				throw new InvalidOperationException("Invalid Office endpoint");
			}
			return new Client(VerificationClient.Create(uri, array3[1], "pawprint", version));
		}
		finally
		{
			CryptographicOperations.ZeroMemory(array2);
			CryptographicOperations.ZeroMemory(array);
		}
	}

	internal static string Describe(ArenaAuthorizationState state)
	{
		if (state.Authorized)
		{
			DateTimeOffset? expiresAt = state.ExpiresAt;
			if (expiresAt.HasValue)
			{
				DateTimeOffset valueOrDefault = expiresAt.GetValueOrDefault();
				if (!(valueOrDefault == DateTimeOffset.MaxValue))
				{
					return $"Omni 已授权 · 至 {valueOrDefault.ToLocalTime():yyyy-MM-dd HH:mm}";
				}
				return "Omni 已授权 · 永久";
			}
			return "Omni 已授权";
		}
		switch (state.Reason)
		{
		case "Initializing":
		case "Verification.NotChecked":
			return "Omni 验证中";
		case "Verification.NotLoggedIn":
			return "请登录游戏后验证 Omni 授权";
		case "Verification.NotAuthorized":
			return "自动斗兽需要有效的 Omni 授权";
		case "Verification.Expired":
			return "Omni 授权已到期";
		case "Verification.OfficeBlacklisted":
		case "Verification.NekoBlacklisted":
			return "Omni 授权受限";
		case "Verification.CredentialRevoked":
			return "Omni 授权已撤销";
		case "Verification.PrivateConfigurationMissing":
			return "Omni 连接配置缺失，请联系发布者";
		case "Verification.ClientKeyRejected":
			return "Omni 接口凭据被拒绝，请联系发布者";
		case "Verification.PluginUnsupported":
			return "Omni 尚未允许此版本接入，请联系发布者";
		case "Verification.ProtocolMismatch":
			return "Omni 接口版本不兼容，请联系发布者";
		case "Verification.OfficeUnavailable":
		case "Verification.ServerUnavailable":
			return "Omni 验证服务暂时不可用";
		default:
			return "Omni 验证未完成，请重新加载插件或联系发布者";
		}
	}
}
