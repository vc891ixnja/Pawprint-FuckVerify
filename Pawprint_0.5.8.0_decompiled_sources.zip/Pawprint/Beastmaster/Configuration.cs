using System;
using System.Collections.Generic;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Configuration;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;
using Dalamud.Configuration;
using Dalamud.Plugin;

namespace Beastmaster;

[Serializable]
public sealed class Configuration : IPluginConfiguration
{
	public int Version { get; set; } = 1;

	public bool OpenOnLoad { get; set; } = true;

	public bool SetupCompleted { get; set; }

	public bool PreferFlight { get; set; } = true;

	public bool EnableAutoAttack { get; set; }

	internal bool CombatEnabled => CombatBackend != CombatBackend.None;

	public CombatBackend CombatBackend { get; set; }

	public FieldDodgeBackend FieldDodge { get; set; }

	public bool AutoLevelWhenNeeded { get; set; } = true;

	public bool EnableAutoDuty { get; set; }

	public List<NotebookCache> NotebookCaches { get; set; } = new List<NotebookCache>();

	public List<HuntTarget> HuntTargets { get; set; } = new List<HuntTarget>();

	public int ArenaStageId { get; set; } = 1;

	public int ArenaRepeatCount { get; set; } = 1;

	public List<ArenaStatistics> ArenaStatistics { get; set; } = new List<ArenaStatistics>();

	public List<ArenaPresetCollection> ArenaPresets { get; set; } = new List<ArenaPresetCollection>();

	public List<ArenaRosterSettings> ArenaRosters { get; set; } = new List<ArenaRosterSettings>();

	internal static Configuration Load(IDalamudPluginInterface pluginInterface)
	{
		if (pluginInterface.GetPluginConfig() is Configuration configuration)
		{
			if (configuration.UpgradeCombat())
			{
				pluginInterface.SavePluginConfig((IPluginConfiguration)(object)configuration);
			}
			return configuration;
		}
		Configuration configuration2 = LegacyConfigurationReader.Read<Configuration>(pluginInterface.ConfigFile.FullName);
		if (configuration2 == null)
		{
			Configuration configuration3 = new Configuration();
			configuration3.UpgradeCombat();
			return configuration3;
		}
		configuration2.UpgradeCombat();
		pluginInterface.SavePluginConfig((IPluginConfiguration)(object)configuration2);
		Services.Log.Information("Migrated Beastmaster settings and notebook caches to Pawprint; original configuration retained.", Array.Empty<object>());
		return configuration2;
	}

	private bool UpgradeCombat()
	{
		bool result = Version < 2;
		if (Version < 2 && !EnableAutoAttack)
		{
			CombatBackend = CombatBackend.None;
		}
		if (!Enum.IsDefined(CombatBackend))
		{
			CombatBackend = CombatBackend.None;
			result = true;
		}
		if (!Enum.IsDefined(FieldDodge))
		{
			FieldDodge = FieldDodgeBackend.None;
			result = true;
		}
		if (ArenaRosters == null)
		{
			List<ArenaRosterSettings> list = (ArenaRosters = new List<ArenaRosterSettings>());
		}
		if (ArenaPresets == null)
		{
			List<ArenaPresetCollection> list3 = (ArenaPresets = new List<ArenaPresetCollection>());
		}
		foreach (ArenaPresetCollection arenaPreset in ArenaPresets)
		{
			foreach (ArenaPreset preset in arenaPreset.Presets)
			{
				if (preset.RepairRepeatedLists())
				{
					result = true;
				}
				if (preset.Resources.MigratePriorities(preset))
				{
					result = true;
				}
			}
		}
		foreach (ArenaRosterSettings arenaRoster in ArenaRosters)
		{
			if (arenaRoster.MigrateLegacyIds(MonsterCatalog.Load()))
			{
				result = true;
			}
		}
		EnableAutoAttack = CombatEnabled;
		Version = 2;
		return result;
	}
}
