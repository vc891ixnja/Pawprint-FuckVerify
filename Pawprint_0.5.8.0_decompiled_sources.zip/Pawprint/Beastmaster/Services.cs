using Dalamud.IoC;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;

namespace Beastmaster;

internal sealed class Services
{
	[PluginService]
	public static IDalamudPluginInterface PluginInterface { get; private set; }

	[PluginService]
	public static ICommandManager Commands { get; private set; }

	[PluginService]
	public static IFramework Framework { get; private set; }

	[PluginService]
	public static IClientState ClientState { get; private set; }

	[PluginService]
	public static IObjectTable Objects { get; private set; }

	[PluginService]
	public static ITargetManager Targets { get; private set; }

	[PluginService]
	public static ICondition Condition { get; private set; }

	[PluginService]
	public static IChatGui Chat { get; private set; }

	[PluginService]
	public static IPluginLog Log { get; private set; }

	[PluginService]
	public static IDataManager Data { get; private set; }

	[PluginService]
	public static ITextureProvider Textures { get; private set; }

	[PluginService]
	public static IAetheryteList Aetherytes { get; private set; }

	[PluginService]
	public static IPlayerState PlayerState { get; private set; }

	[PluginService]
	public static IGameGui GameGui { get; private set; }

	[PluginService]
	public static IAddonLifecycle AddonLifecycle { get; private set; }

	[PluginService]
	public static IGameInteropProvider Interop { get; private set; }

	[PluginService]
	public static ISigScanner SigScanner { get; private set; }
}
