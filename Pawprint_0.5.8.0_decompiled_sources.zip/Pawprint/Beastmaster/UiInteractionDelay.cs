using System;
using Beastmaster.Core.Automation;

namespace Beastmaster;

internal static class UiInteractionDelay
{
	private static readonly UiActionDelay Delay = new UiActionDelay();

	internal static bool Ready(string action, int minimumMs = 300, int maximumMs = 900)
	{
		return Delay.Ready($"{Services.PlayerState.ContentId}/{action}", TimeSpan.FromMilliseconds(Environment.TickCount64), minimumMs, maximumMs);
	}

	internal static void Reset()
	{
		Delay.Reset();
	}
}
