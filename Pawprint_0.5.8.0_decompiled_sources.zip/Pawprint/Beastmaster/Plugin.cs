using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Beastmaster.Arena;
using Beastmaster.Core.Arena;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.I18N;
using Beastmaster.Core.Models;
using Beastmaster.Core.Modules;
using Beastmaster.Core.Security;
using Beastmaster.Hunting;
using Beastmaster.Integrations;
using Beastmaster.Security;
using Beastmaster.Windows;
using Dalamud.Configuration;
using Dalamud.Game.ClientState.Conditions;
using Dalamud.Game.ClientState.Objects.SubKinds;
using Dalamud.Game.ClientState.Objects.Types;
using Dalamud.Game.Command;
using Dalamud.Interface.Windowing;
using Dalamud.Plugin;
using Dalamud.Plugin.Services;
using FFXIVClientStructs.FFXIV.Client.Game.Character;

namespace Beastmaster;

public sealed class Plugin : IDalamudPlugin, IDisposable
{
	private delegate nint GetAccountInfoInstanceDelegate();

	private readonly WindowSystem windows = new WindowSystem("Beastmaster");

	private readonly MainWindow mainWindow;

	private readonly WorkflowRunner runner = new WorkflowRunner();

	private RunState? uiDelayRunState;

	private readonly IntegrationHub integrations = new IntegrationHub();

	private readonly Configuration config;

	private readonly PublicReleaseGuard releaseGuard;

	private ArenaAuthorizationSession? arenaAuthorization;

	private readonly GetAccountInfoInstanceDelegate? getAccountInfoInstance;

	private ulong verifiedAccountIdentity;

	private ulong verifiedCharacterIdentity;

	private uint runTerritory;

	private long lastProbe;

	private long? lastArenaModeCheck;

	private long resetNotebookScan;

	private string? lastArenaModeError;

	private ulong pendingHuntCharacter;

	private bool pendingHunt;

	private bool pendingCapture;

	private bool automaticCapture;

	private readonly HashSet<int> skippedHunts = new HashSet<int>();

	private long? notebookClosedAt;

	private HuntSequenceStep? lastHunt;

	private readonly CombatIntent combatIntent = new CombatIntent();

	private readonly DalamudHuntingWorld huntingWorld;

	private readonly CombatEvents combatEvents;

	private readonly DalamudCombatWorld combatWorld;

	private readonly TaskCombatSupport taskCombat;

	private DateTime lastDrawErrorReported;

	internal ArenaActivationFlow Activation { get; } = new ArenaActivationFlow();

	private bool ArenaAccessAllowed
	{
		get
		{
			if (releaseGuard.CanRun)
			{
				return arenaAuthorization?.Current.Authorized ?? false;
			}
			return false;
		}
	}

	internal string ArenaAuthorizationStatus
	{
		get
		{
			if (arenaAuthorization != null)
			{
				return OmniArenaAuthorization.Describe(arenaAuthorization.Current);
			}
			return "OMNI · 未认证";
		}
	}

	internal bool CaptureIntentHeld => combatIntent.CaptureRequested;

	internal bool HasTask
	{
		get
		{
			if (!runner.IsActive && !Notebook.IsScanning)
			{
				return pendingHunt;
			}
			return true;
		}
	}

	internal string CombatStatus => combatEvents.Status;

	internal bool HasAttackTarget => combatWorld.HasAttackTarget;

	internal NotebookReader Notebook { get; }

	internal ArenaRecorder ArenaRecording { get; }

	internal ArenaStatistics? ArenaSession { get; private set; }

	internal ArenaStatistics? ArenaStats
	{
		get
		{
			ulong character = Services.PlayerState.ContentId;
			if (character == 0L)
			{
				return null;
			}
			Configuration configuration = config;
			if (configuration.ArenaStatistics == null)
			{
				List<ArenaStatistics> list = (configuration.ArenaStatistics = new List<ArenaStatistics>());
			}
			ArenaStatistics arenaStatistics = config.ArenaStatistics.FirstOrDefault((ArenaStatistics s) => s.Character == character);
			if (arenaStatistics == null)
			{
				arenaStatistics = new ArenaStatistics
				{
					Character = character
				};
				config.ArenaStatistics.Add(arenaStatistics);
			}
			return arenaStatistics;
		}
	}

	private ArenaRunStep? ActiveArenaRun
	{
		get
		{
			IWorkflowStep activeStep = runner.ActiveStep;
			if (!(activeStep is ArenaRunStep result))
			{
				if (activeStep is ArenaRepeatStep arenaRepeatStep)
				{
					return arenaRepeatStep.Current;
				}
				return null;
			}
			return result;
		}
	}

	internal string ArenaBattleStatus
	{
		get
		{
			if (runner.State != RunState.Running)
			{
				return "";
			}
			return ActiveArenaRun?.BattleStatus ?? "";
		}
	}

	private bool IsArenaAutomation
	{
		get
		{
			bool flag = !runner.IsPreview;
			if (flag)
			{
				IWorkflowStep activeStep = runner.ActiveStep;
				bool flag2 = ((activeStep is ArenaRunStep || activeStep is ArenaRepeatStep || activeStep is ArenaEncounterStep || activeStep is ArenaBoardStep) ? true : false);
				flag = flag2;
			}
			return flag;
		}
	}

	private bool ArenaUiAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.FirstEncounterActive ?? false;
			}
			return false;
		}
	}

	private bool ArenaEntryAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				ArenaRunStep activeArenaRun = ActiveArenaRun;
				if (activeArenaRun != null)
				{
					return !activeArenaRun.BoardActive;
				}
				return false;
			}
			return false;
		}
	}

	private bool ArenaRestAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.RestActive ?? false;
			}
			return false;
		}
	}

	private bool ArenaTreasureAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.TreasureActive ?? false;
			}
			return false;
		}
	}

	private bool ArenaShopAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.ShopActive ?? false;
			}
			return false;
		}
	}

	private bool ArenaResultAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.ResultActive ?? false;
			}
			return false;
		}
	}

	private bool ArenaHealAllowed
	{
		get
		{
			if (ArenaAccessAllowed && runner.State == RunState.Running && !runner.IsPreview)
			{
				return ActiveArenaRun?.HealingActive ?? false;
			}
			return false;
		}
	}

	internal MonsterCatalog Catalog { get; } = MonsterCatalog.Load();

	internal MonsterDataService MonsterData { get; } = new MonsterDataService();

	internal int SelectedMonster { get; set; } = 2;

	internal IReadOnlyList<IFeatureModule> Modules { get; } = new global::_003C_003Ez__ReadOnlyArray<IFeatureModule>(new IFeatureModule[2]
	{
		new HuntingModule(),
		new ArenaModule()
	});

	internal string Notice { get; private set; } = "就绪";

	internal void BeginActivation(ArenaCredentialKind kind)
	{
		EnsureArenaAuthorization();
		UpdateArenaIdentity();
		Activation.Request(kind, Services.PlayerState.ContentId);
	}

	internal void UpdateActivation(Action<string> copy)
	{
		if (Activation.Busy)
		{
			UpdateArenaIdentity();
		}
		Activation.Tick(verifiedAccountIdentity, Services.ClientState.IsLoggedIn ? Services.PlayerState.ContentId : 0, arenaAuthorization?.CanGenerateTicket ?? false, (ArenaCredentialKind kind) => arenaAuthorization.CreateTicketAsync(kind), copy);
	}

	private ArenaAuthorizationSession EnsureArenaAuthorization()
	{
		string version = typeof(Plugin).Assembly.GetName().Version.ToString();
		return arenaAuthorization ?? (arenaAuthorization = new ArenaAuthorizationSession(() => OmniArenaAuthorization.Create(version)));
	}

	internal void RefreshArenaAuthorization()
	{
		EnsureArenaAuthorization().RequestRefresh();
		UpdateArenaIdentity();
	}

	private unsafe void UpdateArenaIdentity()
	{
		if (arenaAuthorization == null)
		{
			return;
		}
		ulong num = 0uL;
		ulong num2 = 0uL;
		ulong contentId = Services.PlayerState.ContentId;
		if (Services.ClientState.IsLoggedIn && contentId != 0L)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && ((IGameObject)localPlayer).Address != (IntPtr)0)
			{
				Character* address = (Character*)((IGameObject)localPlayer).Address;
				if (((Character)address).ContentId == contentId)
				{
					nint num3 = getAccountInfoInstance?.Invoke() ?? IntPtr.Zero;
					if (num3 != IntPtr.Zero)
					{
						num = *(ulong*)(num3 + 8);
						num2 = contentId;
					}
				}
			}
			if (num == 0L && contentId == verifiedCharacterIdentity && (Services.Condition[(ConditionFlag)45] || Services.Condition[(ConditionFlag)51]))
			{
				num = verifiedAccountIdentity;
				num2 = contentId;
			}
		}
		verifiedAccountIdentity = num;
		verifiedCharacterIdentity = ((num != 0L) ? num2 : 0);
		arenaAuthorization.Tick(num, num2);
	}

	private void RequireArenaAccess()
	{
		releaseGuard.RequireValid();
		EnsureArenaAuthorization();
		UpdateArenaIdentity();
		ArenaAuthorizationSession? arenaAuthorizationSession = arenaAuthorization;
		if (arenaAuthorizationSession == null || !arenaAuthorizationSession.Current.Authorized)
		{
			throw new InvalidOperationException(ArenaAuthorizationStatus);
		}
	}

	private void OnLogout(int type, int code)
	{
		Activation.Clear();
		verifiedAccountIdentity = (verifiedCharacterIdentity = 0uL);
		arenaAuthorization?.Tick(0uL, 0uL);
		if (IsArenaAutomation)
		{
			StopTask("已退出登录，自动斗兽已停止");
			UiInteractionDelay.Reset();
		}
	}

	internal ArenaPresetCollection? PresetsFor(int stage)
	{
		ulong character = Services.PlayerState.ContentId;
		if (character == 0L || !ArenaMaps.All.ContainsKey(stage))
		{
			return null;
		}
		Configuration configuration = config;
		if (configuration.ArenaPresets == null)
		{
			List<ArenaPresetCollection> list = (configuration.ArenaPresets = new List<ArenaPresetCollection>());
		}
		ArenaPresetCollection arenaPresetCollection = config.ArenaPresets.FirstOrDefault((ArenaPresetCollection p) => p.Character == character && p.StageId == stage);
		if (arenaPresetCollection != null)
		{
			foreach (ArenaPreset preset in arenaPresetCollection.Presets)
			{
				preset.Resources.FoldLegacy();
				foreach (ArenaBattlePreset battle in preset.Battles)
				{
					battle.FoldLegacyHeal();
				}
			}
			return arenaPresetCollection;
		}
		List<uint> legacyRoster = ((stage != 1) ? new List<uint>() : (config.ArenaRosters?.FirstOrDefault((ArenaRosterSettings r) => r.ContentId == character)?.Numbers ?? new List<uint>()));
		arenaPresetCollection = ArenaPresetCollection.Create(character, stage, legacyRoster);
		config.ArenaPresets.Add(arenaPresetCollection);
		Save();
		return arenaPresetCollection;
	}

	internal void StartArenaRecording()
	{
		TryUiAction(delegate
		{
			RequireIdle();
			ArenaRecording.Start(Notebook.GameVersion);
		});
	}

	internal void DebugShopTrade()
	{
		TryUiAction(delegate
		{
			RequireIdle();
			ArenaBoardObservation board = ArenaBoardReader.Read();
			ArenaStage stage = ArenaStage.All.FirstOrDefault((ArenaStage s) => s.Territory == board.Territory) ?? ArenaStage.FromContent(board.Content) ?? ArenaStage.Get(config.ArenaStageId);
			ArenaShopWorld arenaShopWorld = new ArenaShopWorld(() => true, stage);
			ArenaShopView arenaShopView = arenaShopWorld.Read();
			if (arenaShopView.Phase != ArenaShopPhase.Selection)
			{
				throw new InvalidOperationException("请先打开商店购买页，再开始出售测试");
			}
			ArenaShopContents contents = arenaShopView.Contents;
			ArenaItem value;
			uint num = contents.Owned.LastOrDefault((uint id) => ArenaItemCatalog.Items.TryGetValue(id, out value) && value.Category == 2);
			if (num == 0)
			{
				throw new InvalidOperationException("背包里没有可出售的道具");
			}
			ArenaShopOffer arenaShopOffer = (from o in contents.Offers
				where !o.Sold && !((ReadOnlySpan<uint>)contents.Owned).Contains(o.ItemId) && ArenaItemCatalog.Items[o.ItemId].Category == 1 && contents.EquipmentCount < 10 && o.Price <= contents.Balance
				orderby o.Price
				select o).FirstOrDefault() ?? throw new InvalidOperationException("没有可购买的装备（需要装备未满10件且余额足够）");
			Start(new WorkflowPlan("出售测试：买" + ArenaItemCatalog.Items[arenaShopOffer.ItemId].Name + " 卖" + ArenaItemCatalog.Items[num].Name, IsPreview: false, new global::_003C_003Ez__ReadOnlySingleElementList<IWorkflowStep>(new ArenaShopProbeStep(arenaShopWorld, num, arenaShopOffer.ItemId))));
		});
	}

	internal void StartArenaRun()
	{
		TryUiAction(delegate
		{
			//IL_0154: Unknown result type (might be due to invalid IL or missing references)
			//IL_0159: Unknown result type (might be due to invalid IL or missing references)
			RequireIdle();
			ArenaBoardObservation board = ArenaBoardReader.Read();
			ArenaStage stage = ArenaStage.All.FirstOrDefault((ArenaStage s) => s.Territory == board.Territory) ?? ArenaStage.FromContent(board.Content) ?? ArenaStage.Get(config.ArenaStageId);
			if (!stage.HasNavigationRoute)
			{
				throw new NotSupportedException("高段第二盘暂不支持自动完成");
			}
			ArenaPreset preset = PresetsFor(stage.Id)?.Selected.Snapshot(stage.Id);
			uint[] roster = preset?.Roster.ToArray() ?? Array.Empty<uint>();
			ulong character = Services.PlayerState.ContentId;
			ArenaStatistics stats = ArenaStats ?? throw new InvalidOperationException("角色尚未加载");
			ArenaSession = new ArenaStatistics
			{
				Character = character
			};
			if (Notebook.GameVersion != Catalog.GameVersion)
			{
				throw new InvalidOperationException("游戏版本与棋盘标定版本不一致");
			}
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer == null || ((IGameObject)localPlayer).IsDead || ((ICharacter)localPlayer).ClassJob.RowId != 43)
			{
				throw new InvalidOperationException("请先切换为驯兽师");
			}
			EnsureArenaCaptureOff();
			integrations.Refresh();
			if (!integrations.Navigation.MovementAllowed)
			{
				throw new InvalidOperationException("请启用 vnavmesh 移动");
			}
			if (integrations.Navigation.IsRunning || integrations.Navigation.IsPathfinding)
			{
				throw new InvalidOperationException("vnavmesh 正在执行其他路径");
			}
			ArenaEntryStep runEntry = null;
			if (ArenaStage.All.Any((ArenaStage s) => s.Territory == board.Territory))
			{
				stage = ArenaStage.All.Single((ArenaStage s) => s.Territory == board.Territory);
				if (board.Content != stage.Content && (!board.Loading || board.Content != 0))
				{
					throw new InvalidOperationException("斗兽场地尚未加载");
				}
			}
			else
			{
				if (Services.Condition[(ConditionFlag)34] || Services.Condition[(ConditionFlag)56])
				{
					throw new InvalidOperationException("请先离开当前副本");
				}
				if (integrations.Travel.IsBusy)
				{
					throw new InvalidOperationException("Lifestream 正在执行其他行程");
				}
				if (board.Territory != ArenaEntryWorld.Entrance.TerritoryId && !integrations.Travel.CanTeleport)
				{
					throw new InvalidOperationException("请启用 Lifestream 传送");
				}
				runEntry = new ArenaEntryStep(new ArenaEntryWorld(Notebook, huntingWorld, integrations.Navigation, () => ArenaEntryAllowed, stage), new LevelingTravelStep(ArenaEntryWorld.Entrance, huntingWorld, integrations.Navigation, preferFlight: false), board.Territory == ArenaEntryWorld.Entrance.TerritoryId && ArenaEntryWorld.HasOpenEntryUi, stage, roster);
			}
			Start(new WorkflowPlan("自动完成斗兽奇弈(WIP)", IsPreview: false, new global::_003C_003Ez__ReadOnlySingleElementList<IWorkflowStep>(new ArenaRepeatStep(CreateRun(runEntry), () => Math.Clamp(config.ArenaRepeatCount, 1, 999), NextRun))));
			ArenaEncounterStep CreateEncounter(ArenaEntryStep? arenaEntryStep, int? node, bool attach)
			{
				ArenaResourcePolicy resources = ((preset == null) ? null : new ArenaResourcePolicy(preset, node));
				ArenaEncounterWorld arenaEncounterWorld = new ArenaEncounterWorld(() => ArenaUiAllowed, node, stage);
				object obj;
				if (node.HasValue)
				{
					int knownNode = node.GetValueOrDefault();
					obj = preset?.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == knownNode);
				}
				else
				{
					obj = null;
				}
				ArenaBattlePreset battlePreset = (ArenaBattlePreset)obj;
				preset?.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == 1);
				ArenaBattleWorld arenaBattleWorld = new ArenaBattleWorld(() => ArenaUiAllowed, arenaEncounterWorld, stage, node, config.FieldDodge, integrations.PromeRotation, combatEvents, integrations.Navigation);
				ArenaBattleRuleEngine arenaBattleRuleEngine = new ArenaBattleRuleEngine(arenaBattleWorld, arenaBattleWorld, resources, ArenaItemDispatch.Trace);
				arenaBattleRuleEngine.Reset(ArenaBattleRuleTemplates.Effective(battlePreset, stage.Id, node));
				ArenaBattleAssist battleAssist = new ArenaBattleAssist(arenaBattleWorld, integrations.Navigation, preset?.EffectiveOpeningMode ?? ArenaOpeningMode.Disabled, ArenaBattlePreset.EffectiveBattleHeal(battlePreset, preset?.HealDuringBattle ?? false, preset?.BattleHealBelowPercent ?? 50).Enabled ? ((Func<ArenaHealStep>)delegate
				{
					(bool, int) tuple = ArenaBattlePreset.EffectiveBattleHeal(battlePreset, preset.HealDuringBattle, preset.BattleHealBelowPercent);
					return new ArenaHealStep(new ArenaHealWorld(() => ArenaUiAllowed, stage, duringBattle: true), tuple.Item2, preset.BattleHealingPriority, resources);
				}) : null, null, null, arenaBattleRuleEngine);
				uint[]? rosterOrder = arenaEntryStep?.RosterOrder ?? ((roster.Length != 0) ? roster : null);
				object battlePreset2;
				if (node.HasValue)
				{
					int n = node.GetValueOrDefault();
					battlePreset2 = preset?.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == n);
				}
				else
				{
					battlePreset2 = null;
				}
				return new ArenaEncounterStep(arenaEncounterWorld, attach, rosterOrder, (ArenaBattlePreset?)battlePreset2, battleAssist, preset?.EquipmentPriority, resources);
			}
			ArenaRestStep CreateRest(int? node)
			{
				ArenaResourcePolicy arenaResourcePolicy = ((preset == null) ? null : new ArenaResourcePolicy(preset, node, ArenaTileKind.Camp));
				return new ArenaRestStep(new ArenaRestWorld(() => ArenaRestAllowed, stage, arenaResourcePolicy?.RestBelowPercent ?? 100), preset?.EquipmentPriority, arenaResourcePolicy);
			}
			ArenaRunStep CreateRun(ArenaEntryStep? arenaEntryStep)
			{
				return new ArenaRunStep(arenaEntryStep, new ArenaBoardStep(integrations.Navigation, ArenaBoardReader.Read, null, arenaEntryStep == null, (int? node, bool attach) => CreateEncounter(arenaEntryStep, node, attach), stage, null, null, null, delegate(int next)
				{
					if (preset != null)
					{
						int n2 = next;
						if (ArenaBattlePreset.EffectiveBoardHeal(preset.Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == n2), preset.HealBeforeBattle))
						{
							return new ArenaHealStep(new ArenaHealWorld(() => ArenaHealAllowed, stage), preset.HealBelowPercent, preset.HealingPriority, new ArenaResourcePolicy(preset), untilThreshold: true);
						}
					}
					return (IWorkflowStep?)null;
				}, restAtFactory: CreateRest, chooseNext: (preset == null) ? null : ((Func<int, int?>)((int node) => ArenaPresetPolicy.Next(preset, node))), treasureAtFactory: (int? node) => new ArenaTreasureStep(new ArenaTreasureWorld(() => ArenaTreasureAllowed, stage), preset?.TreasureOrder(node), preset?.EquipmentPriority, (preset == null) ? null : new ArenaResourcePolicy(preset, node, ArenaTileKind.Treasure)), shopAtFactory: (int? node) => new ArenaShopStep(new ArenaShopWorld(() => ArenaShopAllowed, stage), null, preset?.PurchaseOrder(node), preset?.EquipmentPriority, (preset == null) ? null : new ArenaResourcePolicy(preset, node, ArenaTileKind.Shop)))
				{
					JitterRadius = 0.2
				}, new ArenaResultStep(new ArenaResultWorld(() => ArenaResultAllowed, stage, () => stats.PendingResult?.Failed ?? false), delegate(ArenaRunResult result)
				{
					ArenaSession?.Record(result);
					if (stats.Record(result))
					{
						Save();
					}
				}, delegate
				{
					if (stats.ObserveExit())
					{
						Save();
					}
				}), new ArenaRunSupport(config.FieldDodge, (config.CombatBackend == CombatBackend.PromeRotation) ? integrations.PromeRotation : null), preset?.RetryAfterDeath ?? false, new ArenaFoodStep(new ArenaFoodWorld(() => ArenaEntryAllowed, () => preset?.UseFood ?? false, stage)));
			}
			ArenaRunStep NextRun()
			{
				if (character == 0L || Services.PlayerState.ContentId != character || !ArenaResultWorld.IsOutside)
				{
					throw new InvalidOperationException("角色尚未返回入口，无法开始下一局");
				}
				preset = PresetsFor(stage.Id)?.Selected.Snapshot(stage.Id);
				roster = preset?.Roster.ToArray() ?? Array.Empty<uint>();
				return CreateRun(new ArenaEntryStep(new ArenaEntryWorld(Notebook, huntingWorld, integrations.Navigation, () => ArenaEntryAllowed, stage), new LevelingTravelStep(ArenaEntryWorld.Entrance, huntingWorld, integrations.Navigation, preferFlight: false), resumeCurrent: false, stage, roster));
			}
		});
	}

	internal void ReportDrawError(Exception e)
	{
		Notice = "界面绘制出错，已跳过本页内容：" + e.GetType().Name + " · " + e.Message;
		if ((DateTime.UtcNow - lastDrawErrorReported).TotalSeconds >= 5.0)
		{
			lastDrawErrorReported = DateTime.UtcNow;
			Services.Log.Error(e, "Pawprint window draw failed", Array.Empty<object>());
		}
	}

	public Plugin(IDalamudPluginInterface pluginInterface)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Expected O, but got Unknown
		//IL_0100: Unknown result type (might be due to invalid IL or missing references)
		//IL_023f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Expected O, but got Unknown
		//IL_0244: Unknown result type (might be due to invalid IL or missing references)
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Expected O, but got Unknown
		//IL_02ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b5: Expected O, but got Unknown
		//IL_02d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_02e1: Expected O, but got Unknown
		pluginInterface.Create<Services>(Array.Empty<object>());
		nint ptr = default(nint);
		if (Services.SigScanner.TryScanText("48 8B 05 ?? ?? ?? ?? C3 CC CC CC CC CC CC CC CC 83 39", ref ptr))
		{
			getAccountInfoInstance = Marshal.GetDelegateForFunctionPointer<GetAccountInfoInstanceDelegate>(ptr);
		}
		else
		{
			Services.Log.Warning("无法定位 Omni 账号身份读取入口，账号验证保持不可用。", Array.Empty<object>());
		}
		releaseGuard = new PublicReleaseGuard(pluginInterface.AssemblyLocation.DirectoryName);
		config = Configuration.Load(pluginInterface);
		GameText.SelectLanguage(Services.Data.Language);
		integrations.Settings = config;
		Configuration configuration = config;
		if (configuration.HuntTargets == null)
		{
			List<HuntTarget> list = (configuration.HuntTargets = new List<HuntTarget>());
		}
		huntingWorld = new DalamudHuntingWorld(integrations.Navigation, integrations.Travel);
		Notebook = new NotebookReader(config);
		ArenaRecording = new ArenaRecorder();
		combatEvents = new CombatEvents();
		taskCombat = new TaskCombatSupport(config, integrations, () => config.CombatEnabled && CombatIntent.AllowsTaskActions(runner));
		combatWorld = new DalamudCombatWorld(huntingWorld, combatEvents, Notebook, () => config.CombatEnabled && CombatIntent.AllowsTaskActions(runner), taskCombat);
		MainWindow obj = new MainWindow(this, config, runner, integrations);
		((Window)obj).IsOpen = config.OpenOnLoad;
		mainWindow = obj;
		windows.AddWindow((IWindow)(object)mainWindow);
		if (!config.SetupCompleted)
		{
			mainWindow.ShowPluginConfiguration();
		}
		Services.Commands.AddHandler("/pawprint", new CommandInfo(new HandlerDelegate(OnCommand))
		{
			HelpMessage = "打开/关闭 Pawprint；setup 插件配置；stop 停止；pause 暂停；resume 恢复；status 状态"
		});
		pluginInterface.UiBuilder.Draw += Draw;
		pluginInterface.UiBuilder.OpenMainUi += Open;
		pluginInterface.UiBuilder.OpenConfigUi += OpenSetup;
		Services.Framework.Update += new OnUpdateDelegate(Update);
		Services.ClientState.TerritoryChanged += OnTerritoryChanged;
		Services.ClientState.Logout += new LogoutDelegate(OnLogout);
		integrations.Refresh();
	}

	private void Draw()
	{
		windows.Draw();
	}

	private void Open()
	{
		((Window)mainWindow).IsOpen = true;
	}

	internal void Save()
	{
		Services.PluginInterface.SavePluginConfig((IPluginConfiguration)(object)config);
	}

	internal void Preview(IFeatureModule module)
	{
		if (!HasTask)
		{
			Start(module.CreatePreview());
		}
	}

	internal void OpenSetup()
	{
		integrations.Refresh();
		mainWindow.ShowPluginConfiguration();
	}

	internal void ResumeTask()
	{
		TryUiAction(delegate
		{
			if (IsArenaAutomation)
			{
				RequireArenaAccess();
			}
			runner.Resume();
		});
	}

	internal void StopTask(string reason = "手动停止", bool releaseCombatIntent = true)
	{
		if (releaseCombatIntent)
		{
			combatIntent.Reset();
		}
		automaticCapture = false;
		combatWorld.StopAndClearTarget();
		combatWorld.CancelCaptureConfirmation();
		pendingHunt = false;
		notebookClosedAt = null;
		Notebook.CancelScan(reason);
		runner.Stop(reason);
		Notice = reason;
	}

	internal void SetCombatBackend(CombatBackend backend)
	{
		IGameObject target = Services.Targets.Target;
		StopTask("战斗插件已变更");
		config.CombatBackend = backend;
		config.EnableAutoAttack = config.CombatEnabled;
		if (config.CombatEnabled)
		{
			Services.Targets.Target = target;
		}
		Save();
	}

	internal void OpenNotebook()
	{
		TryUiAction(Notebook.Open);
	}

	internal void ExportNotebook()
	{
		TryUiAction(delegate
		{
			NotebookReader notebook = Notebook;
			string notice = Notice;
			RunState state = runner.State;
			string message = runner.Message;
			string currentStep = runner.CurrentStep;
			bool num = pendingHunt;
			bool hasValue = notebookClosedAt.HasValue;
			HashSet<int> hashSet = skippedHunts;
			uint territoryType = Services.ClientState.TerritoryType;
			byte playerLevel = huntingWorld.PlayerLevel;
			string? interruption = GetInterruption();
			bool isMounted = huntingWorld.IsMounted;
			bool isFlying = huntingWorld.IsFlying;
			bool canFlyInTerritory = huntingWorld.CanFlyInTerritory;
			bool canTakeOff = huntingWorld.CanTakeOff;
			bool isMountTransition = huntingWorld.IsMountTransition;
			string combatStatus = CombatStatus;
			IReadOnlyList<CombatEvent> readOnlyList = combatEvents.After(0L);
			object[] recentMessages = combatEvents.RecentMessages;
			IGameObject target = Services.Targets.Target;
			string text = notebook.Export(new
			{
				Notice = notice,
				State = state,
				Message = message,
				CurrentStep = currentStep,
				PendingHunt = num,
				WaitingForClose = hasValue,
				SkippedHunts = hashSet,
				Territory = territoryType,
				Level = playerLevel,
				InterruptedBy = interruption,
				IsMounted = isMounted,
				IsFlying = isFlying,
				CanFlyInTerritory = canFlyInTerritory,
				CanTakeOff = canTakeOff,
				IsMountTransition = isMountTransition,
				CombatStatus = combatStatus,
				CombatEvents = readOnlyList,
				RawMessages = recentMessages,
				Target = ((target != null) ? combatWorld.ReadTarget(target.GameObjectId) : null),
				TargetIdentity = MonsterData.ReadCurrentTarget(),
				Nearby = MonsterData.Nearby(Catalog.Monsters.Single((MonsterEntry m) => m.Number == SelectedMonster)),
				Hunt = lastHunt?.Diagnostics,
				Leveling = (runner.ActiveStep as LevelingStep)?.Diagnostics,
				CaptureIntentHeld = CaptureIntentHeld,
				EnableAutoAttack = config.EnableAutoAttack,
				CombatBackend = config.CombatBackend,
				FieldDodge = config.FieldDodge,
				AutoLevelWhenNeeded = config.AutoLevelWhenNeeded,
				EnableAutoDuty = config.EnableAutoDuty
			});
			Notice = "图鉴诊断已导出：" + text;
		});
	}

	internal void ScanNotebook()
	{
		TryUiAction(delegate
		{
			RequireIdle();
			Notebook.RequestScan();
		});
	}

	internal void LocateSelected()
	{
		TryUiAction(delegate
		{
			Locate(Catalog.Monsters.Single((MonsterEntry m) => m.Number == SelectedMonster));
		});
	}

	internal void CaptureSelected()
	{
		TryUiAction(delegate
		{
			RequireIdle();
			combatIntent.Begin(capture: true);
			combatWorld.StopAutoAttack();
			Locate(Catalog.Monsters.Single((MonsterEntry m) => m.Number == SelectedMonster), capture: true);
		});
	}

	internal void LocateNextMissing()
	{
		BeginNext(capture: false);
	}

	internal void CaptureNextMissing()
	{
		BeginNext(capture: true);
	}

	internal void AutoCapture()
	{
		BeginNext(capture: true, continuous: true);
	}

	private void BeginNext(bool capture, bool continuous = false)
	{
		TryUiAction(delegate
		{
			RequireIdle();
			combatIntent.Begin(capture);
			combatWorld.StopAutoAttack();
			RequireHunting();
			if (capture)
			{
				RequireCombat();
			}
			automaticCapture = continuous;
			skippedHunts.Clear();
			pendingCapture = capture;
			pendingHuntCharacter = Services.PlayerState.ContentId;
			notebookClosedAt = null;
			Notebook.RequestScan();
			pendingHunt = true;
			Notice = "正在读取图鉴";
		});
	}

	private void StartNextMissing()
	{
		MonsterEntry monsterEntry = Catalog.MissingOverworld(Notebook.GetFresh, skippedHunts).FirstOrDefault();
		if (monsterEntry == null)
		{
			automaticCapture = false;
			Notice = ((skippedHunts.Count == 0) ? "野外捕获完成；副本魔物可在下方选择" : $"本轮结束，跳过 {skippedHunts.Count} 项（{string.Join("、", from n in skippedHunts.Order()
				select $"#{n:00}")}）；仍保留未收录状态");
		}
		else
		{
			SelectedMonster = monsterEntry.Number;
			Locate(monsterEntry, pendingCapture);
		}
	}

	private void RequireCombat()
	{
		if (!config.CombatEnabled)
		{
			OpenSetup();
			throw new InvalidOperationException("请先在插件配置选择内置简单战斗或 PR。");
		}
		if (!combatEvents.Ready)
		{
			throw new InvalidOperationException(combatEvents.Status);
		}
		try
		{
			taskCombat.RequireReady();
			taskCombat.StopBeforeTravel();
		}
		catch
		{
			OpenSetup();
			throw;
		}
	}

	private void RequireIdle()
	{
		if (HasTask)
		{
			throw new InvalidOperationException("请先停止当前任务或图鉴扫描。");
		}
	}

	private void RequireHunting()
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		if (ArenaCombatPolicy.IsArena(Services.ClientState.TerritoryType))
		{
			throw new InvalidOperationException("斗兽奇弈场内不执行捕获或野外练级");
		}
		IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
		if (localPlayer == null || ((ICharacter)localPlayer).ClassJob.RowId != 43)
		{
			throw new InvalidOperationException("请先切换为驯兽师。");
		}
		if (((ICharacter)Services.Objects.LocalPlayer).Level == 0)
		{
			throw new InvalidOperationException("角色等级尚未加载。");
		}
		if (Notebook.GameVersion != Catalog.GameVersion)
		{
			throw new InvalidOperationException("游戏版本与魔物目录版本不一致，请先核对目录数据。");
		}
		string interruption = GetInterruption();
		if (interruption != null)
		{
			throw new InvalidOperationException(interruption);
		}
		try
		{
			integrations.RequireHunting();
		}
		catch
		{
			OpenSetup();
			throw;
		}
	}

	private void Locate(MonsterEntry monster, bool capture = false)
	{
		if (monster.UnsupportedDuty)
		{
			throw new InvalidOperationException("49、50 所在多人副本暂不支持");
		}
		if (!monster.CanHunt)
		{
			throw new InvalidOperationException("该条目位置尚未补充");
		}
		RequireIdle();
		RequireHunting();
		if (capture)
		{
			RequireCombat();
		}
		if (monster.Kind == MonsterLocationKind.Duty)
		{
			if (!config.EnableAutoDuty)
			{
				OpenSetup();
				throw new InvalidOperationException("请在插件配置启用 AutoDuty 副本捕猎");
			}
			if (!integrations.AutoDuty.Available || !integrations.AutoDuty.HasPath(monster.TerritoryId))
			{
				throw new InvalidOperationException("AutoDuty 未就绪或没有该副本路线，请先在 AutoDuty 中配置");
			}
		}
		MonsterObservation monsterObservation = huntingWorld.FindMonster(monster);
		if ((object)monsterObservation != null && monsterObservation.Level == 0)
		{
			throw new InvalidOperationException("附近魔物等级尚未加载。");
		}
		if (monster.Kind != MonsterLocationKind.Duty && huntingWorld.TerritoryId != monster.TerritoryId && huntingWorld.SelectAetheryte(monster.Destination) == null)
		{
			throw new InvalidOperationException("目标区域没有已解锁的大水晶。");
		}
		Start(new WorkflowPlan($"{(capture ? "捕获" : "寻找")} #{monster.Number:00} {monster.Name}", IsPreview: false, new global::_003C_003Ez__ReadOnlySingleElementList<IWorkflowStep>(new HuntSequenceStep(monster, huntingWorld, combatWorld, integrations.Navigation, integrations.AutoDuty, capture, capture && (automaticCapture || config.AutoLevelWhenNeeded), config.PreferFlight))));
	}

	internal void LevelOnce()
	{
		TryUiAction(delegate
		{
			RequireIdle();
			RequireHunting();
			RequireCombat();
			if (Services.Condition[(ConditionFlag)34] || Services.Condition[(ConditionFlag)56])
			{
				throw new InvalidOperationException("自动练级需要在野外区域启动");
			}
			if (huntingWorld.PlayerLevel >= 100)
			{
				throw new InvalidOperationException("已达到 Lv.100");
			}
			Start(new WorkflowPlan("自动练级提升一级", IsPreview: false, new global::_003C_003Ez__ReadOnlySingleElementList<IWorkflowStep>(new LevelingStep(huntingWorld.PlayerLevel + 1, combatWorld, huntingWorld, integrations.Navigation, config.PreferFlight))));
		});
	}

	private void TryUiAction(Action action)
	{
		try
		{
			action();
		}
		catch (Exception ex)
		{
			if (!HasTask)
			{
				automaticCapture = false;
			}
			Notice = ex.Message;
			Services.Log.Warning(ex, "Beastmaster action failed", Array.Empty<object>());
		}
	}

	private void Start(WorkflowPlan plan)
	{
		if (!plan.IsPreview && plan.Steps.Any((IWorkflowStep s) => (s is ArenaEncounterStep || s is ArenaRunStep || s is ArenaRepeatStep || s is ArenaBoardStep) ? true : false))
		{
			RequireArenaAccess();
		}
		IWorkflowStep workflowStep = plan.Steps.FirstOrDefault();
		bool flag = ((workflowStep is ArenaEncounterStep || workflowStep is ArenaRunStep || workflowStep is ArenaRepeatStep || workflowStep is ArenaShopProbeStep) ? true : false);
		string text = ((!flag) ? GetInterruption() : ((!Services.ClientState.IsLoggedIn) ? "玩家未登录" : null));
		if (text != null)
		{
			Notice = text;
			return;
		}
		combatWorld.StopAutoAttack();
		runTerritory = Services.ClientState.TerritoryType;
		lastHunt = plan.Steps.OfType<HuntSequenceStep>().FirstOrDefault();
		combatIntent.Begin(lastHunt?.IsCapture ?? false);
		Notice = (runner.Start(plan) ? ("已启动：" + plan.Name) : "已有任务，请先停止当前任务");
	}

	private void OnCommand(string command, string args)
	{
		string text = args.Trim().ToLowerInvariant();
		if (text == null || text.Length != 0)
		{
			switch (text)
			{
			case "stop":
				StopTask();
				break;
			case "setup":
				OpenSetup();
				break;
			case "pause":
				runner.Pause();
				break;
			case "resume":
				ResumeTask();
				break;
			case "status":
				Services.Chat.Print($"[Pawprint] {runner.State} · {runner.PlanName} · {runner.Message}", (string)null, (ushort?)null);
				break;
			default:
				Open();
				break;
			}
		}
		else
		{
			((Window)mainWindow).IsOpen = !((Window)mainWindow).IsOpen;
		}
	}

	private void OnTerritoryChanged(uint territory)
	{
		ArenaRunStep activeArenaRun = ActiveArenaRun;
		if ((activeArenaRun == null || !activeArenaRun.AcceptsTerritory(territory)) && (!(runner.ActiveStep is ArenaBoardStep arenaBoardStep) || !arenaBoardStep.AcceptsTerritory(territory)) && (!(runner.ActiveStep is HuntSequenceStep huntSequenceStep) || !huntSequenceStep.AcceptsTerritory(territory)) && (!(runner.ActiveStep is LevelingStep levelingStep) || !levelingStep.AcceptsTerritory(territory)) && HasTask)
		{
			StopTask("区域发生变化，任务已停止", releaseCombatIntent: false);
		}
	}

	private static string? GetInterruption(bool ignoreNotebookInteraction = false, bool allowCombat = false)
	{
		if (!Services.ClientState.IsLoggedIn || Services.Objects.LocalPlayer == null)
		{
			return "玩家未登录或未加载";
		}
		if (((IGameObject)Services.Objects.LocalPlayer).IsDead)
		{
			return "玩家已死亡";
		}
		ICondition condition = Services.Condition;
		if (condition[(ConditionFlag)45] || condition[(ConditionFlag)51])
		{
			return "正在切换区域";
		}
		if (condition[(ConditionFlag)58] || condition[(ConditionFlag)78] || condition[(ConditionFlag)35])
		{
			return "正在播放过场动画";
		}
		if (!allowCombat && condition[(ConditionFlag)26])
		{
			return "战斗中无法开始寻找任务";
		}
		if (!ignoreNotebookInteraction && condition[(ConditionFlag)31])
		{
			return "正在交互，无法开始寻找任务";
		}
		return null;
	}

	private void Update(IFramework framework)
	{
		//IL_01b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_074f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0754: Unknown result type (might be due to invalid IL or missing references)
		//IL_064a: Unknown result type (might be due to invalid IL or missing references)
		//IL_064f: Unknown result type (might be due to invalid IL or missing references)
		//IL_086b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0870: Unknown result type (might be due to invalid IL or missing references)
		//IL_04de: Unknown result type (might be due to invalid IL or missing references)
		//IL_04e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0689: Unknown result type (might be due to invalid IL or missing references)
		//IL_068e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0565: Unknown result type (might be due to invalid IL or missing references)
		//IL_056a: Unknown result type (might be due to invalid IL or missing references)
		try
		{
			releaseGuard.Tick();
			UpdateArenaIdentity();
			if (IsArenaAutomation && !ArenaAccessAllowed)
			{
				StopTask((!releaseGuard.CanRun) ? releaseGuard.FailureReason : ArenaAuthorizationStatus);
				UiInteractionDelay.Reset();
			}
			if (uiDelayRunState != runner.State)
			{
				UiInteractionDelay.Reset();
				uiDelayRunState = runner.State;
			}
			UpdateArenaCaptureMode();
			combatEvents.Update();
			combatWorld.UpdateConfirmation();
			Notebook.Update();
			ArenaRecording.Update();
			if (ArenaResultWorld.IsOutside)
			{
				ArenaStatistics? arenaStats = ArenaStats;
				if (arenaStats != null && arenaStats.ObserveExit())
				{
					Save();
				}
			}
			if (Environment.TickCount64 - lastProbe >= 3000)
			{
				lastProbe = Environment.TickCount64;
				integrations.Refresh();
				Notebook.Refresh();
			}
			if (Notebook.CompletedScans != resetNotebookScan)
			{
				resetNotebookScan = Notebook.CompletedScans;
				try
				{
					taskCombat.ResetCaptureAfterNotebook();
				}
				catch (Exception ex)
				{
					StopTask("图鉴核对后的捕捉模式重置失败：" + ex.Message);
					Services.Log.Warning(ex, "Notebook capture QT reset failed", Array.Empty<object>());
					return;
				}
			}
			if (pendingHunt)
			{
				string interruption = GetInterruption(ignoreNotebookInteraction: true, allowCombat: true);
				if (pendingHuntCharacter != 0L && pendingHuntCharacter == Services.PlayerState.ContentId)
				{
					IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
					if (localPlayer != null && ((ICharacter)localPlayer).ClassJob.RowId == 43 && interruption == null)
					{
						if (!Notebook.IsScanning)
						{
							if (Catalog.Monsters.Any((MonsterEntry m) => Notebook.GetFresh(m.Number) == CaptureState.Unknown))
							{
								pendingHunt = false;
								automaticCapture = false;
								Notice = "未能取得完整图鉴。" + Notebook.Status;
							}
							else if (!notebookClosedAt.HasValue)
							{
								if (Notebook.TryClose())
								{
									notebookClosedAt = Environment.TickCount64;
								}
								Notice = "图鉴已读取完成，正在关闭图鉴并准备出发…";
							}
							else if (!Notebook.IsVisibleNow && Services.Condition[(ConditionFlag)26])
							{
								notebookClosedAt = Environment.TickCount64;
								Notice = "图鉴已核对，等待脱战后前往下一只";
							}
							else if (Environment.TickCount64 - notebookClosedAt > 5000)
							{
								StopTask("图鉴已读取，但界面仍未退出交互状态；请关闭其他交互窗口后重试。", releaseCombatIntent: false);
							}
							else if (!Notebook.IsVisibleNow && GetInterruption() == null && Environment.TickCount64 - notebookClosedAt >= 300)
							{
								pendingHunt = false;
								notebookClosedAt = null;
								TryUiAction(StartNextMissing);
							}
						}
						else
						{
							Notice = Notebook.Status;
						}
						goto IL_03c5;
					}
				}
				StopTask(interruption ?? "角色或职业发生变化，已取消读取后出发。", releaseCombatIntent: false);
			}
			goto IL_03c5;
			IL_040b:
			bool flag2;
			bool flag = flag2;
			if (runner.ActiveStep is HuntSequenceStep huntSequenceStep)
			{
				string interruption2;
				if (!Services.ClientState.IsLoggedIn)
				{
					interruption2 = "玩家退出登录";
				}
				else
				{
					IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
					if (localPlayer2 != null && ((IGameObject)localPlayer2).IsDead)
					{
						interruption2 = "玩家已死亡";
					}
					else if (huntSequenceStep.NeedsCombat && !config.CombatEnabled)
					{
						interruption2 = "战斗插件已设为无";
					}
					else if (huntSequenceStep.UsesAutoDuty && !config.EnableAutoDuty)
					{
						interruption2 = "AutoDuty 副本捕猎已关闭";
					}
					else if (Services.Condition[(ConditionFlag)26] && !huntSequenceStep.AllowsCombat)
					{
						interruption2 = "进入战斗，寻找任务已停止";
					}
					else
					{
						IPlayerCharacter localPlayer3 = Services.Objects.LocalPlayer;
						if (localPlayer3 != null && ((ICharacter)localPlayer3).ClassJob.RowId != 43)
						{
							interruption2 = "当前职业已不是驯兽师";
						}
						else if (huntSequenceStep.CanWaitForCutscene && (huntingWorld.IsInCutscene || huntSequenceStep.WaitingForCutscene) && huntSequenceStep.AcceptsCutsceneTerritory(Services.ClientState.TerritoryType))
						{
							interruption2 = null;
						}
						else if (huntSequenceStep.AllowsZoneTransition && huntSequenceStep.AcceptsTerritory(Services.ClientState.TerritoryType))
						{
							interruption2 = null;
						}
						else
						{
							IPlayerCharacter localPlayer4 = Services.Objects.LocalPlayer;
							interruption2 = ((localPlayer4 != null && ((ICharacter)localPlayer4).ClassJob.RowId == 43) ? GetInterruption(huntSequenceStep.AllowsNotebook, huntSequenceStep.AllowsCombat) : "当前职业已不是驯兽师");
						}
					}
				}
				runner.Tick(interruption2);
				RunState state = runner.State;
				flag2 = (uint)(state - 4) <= 1u;
				Notice = (flag2 ? runner.Message : huntSequenceStep.Name);
			}
			else if (runner.ActiveStep is LevelingStep levelingStep)
			{
				object obj;
				if (Services.ClientState.IsLoggedIn)
				{
					IPlayerCharacter localPlayer2 = Services.Objects.LocalPlayer;
					if (localPlayer2 == null || !((IGameObject)localPlayer2).IsDead)
					{
						if (config.CombatEnabled)
						{
							IPlayerCharacter localPlayer5 = Services.Objects.LocalPlayer;
							if (localPlayer5 == null || ((ICharacter)localPlayer5).ClassJob.RowId == 43)
							{
								if (!levelingStep.AllowsZoneTransition || !levelingStep.AcceptsTerritory(Services.ClientState.TerritoryType))
								{
									IPlayerCharacter localPlayer6 = Services.Objects.LocalPlayer;
									obj = ((localPlayer6 == null || ((ICharacter)localPlayer6).ClassJob.RowId != 43) ? "当前职业不是驯兽师" : GetInterruption(ignoreNotebookInteraction: false, allowCombat: true));
								}
								else
								{
									obj = null;
								}
							}
							else
							{
								obj = "当前职业不是驯兽师";
							}
						}
						else
						{
							obj = "战斗插件已设为无";
						}
					}
					else
					{
						obj = "玩家已死亡";
					}
				}
				else
				{
					obj = "玩家退出登录";
				}
				string interruption3 = (string)obj;
				runner.Tick(interruption3);
				RunState state = runner.State;
				flag2 = (uint)(state - 4) <= 1u;
				Notice = (flag2 ? runner.Message : levelingStep.Name);
			}
			else if (ActiveArenaRun != null)
			{
				IWorkflowStep activeStep = runner.ActiveStep;
				object obj2;
				if (Services.ClientState.IsLoggedIn)
				{
					IPlayerCharacter localPlayer7 = Services.Objects.LocalPlayer;
					obj2 = ((localPlayer7 != null && ((ICharacter)localPlayer7).ClassJob.RowId != 43) ? "当前职业不是驯兽师" : null);
				}
				else
				{
					obj2 = "玩家退出登录";
				}
				string interruption4 = (string)obj2;
				runner.Tick(interruption4);
				RunState state = runner.State;
				flag2 = (uint)(state - 4) <= 1u;
				Notice = (flag2 ? runner.Message : activeStep.Name);
			}
			else if (runner.ActiveStep is ArenaEncounterStep arenaEncounterStep)
			{
				runner.Tick((!Services.ClientState.IsLoggedIn) ? "玩家退出登录" : null);
				RunState state = runner.State;
				flag2 = (uint)(state - 4) <= 1u;
				Notice = (flag2 ? runner.Message : arenaEncounterStep.Name);
			}
			else if (runner.ActiveStep is ArenaShopProbeStep arenaShopProbeStep)
			{
				WorkflowRunner workflowRunner = runner;
				object interruption5;
				if (Services.ClientState.IsLoggedIn)
				{
					IPlayerCharacter localPlayer8 = Services.Objects.LocalPlayer;
					interruption5 = ((localPlayer8 != null && ((ICharacter)localPlayer8).ClassJob.RowId != 43) ? "当前职业不是驯兽师" : null);
				}
				else
				{
					interruption5 = "玩家退出登录";
				}
				workflowRunner.Tick((string?)interruption5);
				RunState state = runner.State;
				flag2 = (uint)(state - 4) <= 1u;
				Notice = (flag2 ? runner.Message : arenaShopProbeStep.Name);
			}
			else
			{
				runner.Tick((runTerritory != Services.ClientState.TerritoryType) ? "区域发生变化" : GetInterruption());
			}
			if (!(!runner.IsActive && flag))
			{
				return;
			}
			combatWorld.StopAndClearTarget();
			if (automaticCapture && runner.State == RunState.Completed)
			{
				HuntSequenceStep huntSequenceStep2 = lastHunt;
				if (huntSequenceStep2 != null && (huntSequenceStep2.Captured || huntSequenceStep2.Skipped))
				{
					pendingHunt = true;
					pendingCapture = true;
					if (huntSequenceStep2.Skipped)
					{
						skippedHunts.Add(huntSequenceStep2.MonsterNumber);
						notebookClosedAt = null;
						Notebook.RequestScan();
						Notice = $"已跳过 #{huntSequenceStep2.MonsterNumber:00}，准备下一只未捕获魔物";
					}
					else
					{
						notebookClosedAt = null;
						Notice = "图鉴已更新，准备下一只";
					}
					return;
				}
			}
			automaticCapture = false;
			return;
			IL_03c5:
			if (!runner.IsActive)
			{
				return;
			}
			IWorkflowStep activeStep2 = runner.ActiveStep;
			if (activeStep2 is HuntSequenceStep huntSequenceStep3)
			{
				if (huntSequenceStep3.NeedsCombat)
				{
					goto IL_0403;
				}
			}
			else if (activeStep2 is LevelingStep)
			{
				goto IL_0403;
			}
			flag2 = false;
			goto IL_040b;
			IL_0403:
			flag2 = true;
			goto IL_040b;
		}
		catch (Exception ex2)
		{
			StopTask("框架更新异常", releaseCombatIntent: false);
			Services.Log.Error(ex2, "Beastmaster framework update failed", Array.Empty<object>());
		}
	}

	private void EnsureArenaCaptureOff()
	{
		IExposedPlugin val = IntegrationHub.FindInstalledPlugin("PromeRotation");
		if (val != null && val.IsLoaded && integrations.PromeRotation.CurrentAcr.Equals("XSZYYS", StringComparison.OrdinalIgnoreCase))
		{
			ArenaCombatPolicy.EnsureCaptureOff(new PromeTaskBackend(integrations.PromeRotation));
		}
	}

	private void UpdateArenaCaptureMode()
	{
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0093: Unknown result type (might be due to invalid IL or missing references)
		bool num = ArenaCombatPolicy.IsArena(Services.ClientState.TerritoryType);
		bool flag = !runner.IsPreview && runner.IsActive;
		if (flag)
		{
			IWorkflowStep activeStep = runner.ActiveStep;
			bool flag2 = ((activeStep is ArenaRunStep || activeStep is ArenaRepeatStep || activeStep is ArenaEncounterStep || activeStep is ArenaBoardStep) ? true : false);
			flag = flag2;
		}
		bool flag3 = flag;
		if ((num || flag3) && Services.ClientState.IsLoggedIn)
		{
			IPlayerCharacter localPlayer = Services.Objects.LocalPlayer;
			if (localPlayer != null && ((ICharacter)localPlayer).ClassJob.RowId == 43)
			{
				long tickCount = Environment.TickCount64;
				long? num2 = lastArenaModeCheck;
				if (num2.HasValue)
				{
					long valueOrDefault = num2.GetValueOrDefault();
					if (tickCount - valueOrDefault < 1000)
					{
						return;
					}
				}
				lastArenaModeCheck = tickCount;
				try
				{
					EnsureArenaCaptureOff();
					lastArenaModeError = null;
					return;
				}
				catch (Exception ex)
				{
					string text = "斗兽捕捉模式关闭失败：" + ex.Message;
					if (flag3)
					{
						StopTask(text);
					}
					else
					{
						Notice = text;
					}
					if (lastArenaModeError != text)
					{
						Services.Log.Warning(ex, text, Array.Empty<object>());
					}
					lastArenaModeError = text;
					return;
				}
			}
		}
		lastArenaModeCheck = null;
		lastArenaModeError = null;
	}

	public void Dispose()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected O, but got Unknown
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Expected O, but got Unknown
		Activation.Clear();
		Services.Framework.Update -= new OnUpdateDelegate(Update);
		Services.ClientState.TerritoryChanged -= OnTerritoryChanged;
		Services.ClientState.Logout -= new LogoutDelegate(OnLogout);
		Services.PluginInterface.UiBuilder.Draw -= Draw;
		Services.PluginInterface.UiBuilder.OpenMainUi -= Open;
		Services.PluginInterface.UiBuilder.OpenConfigUi -= OpenSetup;
		Services.Commands.RemoveHandler("/pawprint");
		runner.Dispose();
		arenaAuthorization?.Dispose();
		combatWorld.StopAutoAttack();
		combatWorld.CancelCaptureConfirmation();
		combatEvents.Dispose();
		Notebook.Dispose();
		ArenaRecording.Dispose();
		windows.RemoveAllWindows();
	}
}
