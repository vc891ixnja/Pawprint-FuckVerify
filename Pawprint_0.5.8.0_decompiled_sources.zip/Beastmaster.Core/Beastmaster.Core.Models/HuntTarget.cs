namespace Beastmaster.Core.Models;

public sealed record HuntTarget(string Name, uint DataId, WorldPoint Location);
