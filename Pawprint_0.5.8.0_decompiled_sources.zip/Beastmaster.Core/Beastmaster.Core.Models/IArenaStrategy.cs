namespace Beastmaster.Core.Models;

public interface IArenaStrategy
{
	string ProfileId { get; }

	bool IsAvailable(uint territoryId);

	bool IsVictoryConfirmed();
}
