namespace Beastmaster.Core.Models;

public interface ICaptureStrategy
{
	bool Supports(uint dataId);

	bool IsCaptureConfirmed(uint dataId);
}
