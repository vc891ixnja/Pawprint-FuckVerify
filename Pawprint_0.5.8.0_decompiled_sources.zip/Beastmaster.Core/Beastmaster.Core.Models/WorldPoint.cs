using System.Numerics;

namespace Beastmaster.Core.Models;

public sealed record WorldPoint(uint TerritoryId, float X, float Y, float Z)
{
	public Vector3 Position => new Vector3(X, Y, Z);

	public bool IsValid
	{
		get
		{
			if (TerritoryId != 0 && float.IsFinite(X) && float.IsFinite(Y))
			{
				return float.IsFinite(Z);
			}
			return false;
		}
	}
}
