using System.Collections.Generic;

namespace Beastmaster.Core.Models;

public sealed record ArenaProfile(string Id, string Name, uint TerritoryId, IReadOnlyList<string> Stages);
