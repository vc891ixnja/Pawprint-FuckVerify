namespace Beastmaster.Core.Security;

public sealed record ReleaseHashManifest(int Schema, string Version, ReleaseFileHash[] Files);
