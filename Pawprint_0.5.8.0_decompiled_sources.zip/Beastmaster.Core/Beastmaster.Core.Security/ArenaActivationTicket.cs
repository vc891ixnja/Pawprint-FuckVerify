using System;

namespace Beastmaster.Core.Security;

public sealed record ArenaActivationTicket(bool Success, string? Ticket, DateTimeOffset? ExpiresAt, string Reason);
