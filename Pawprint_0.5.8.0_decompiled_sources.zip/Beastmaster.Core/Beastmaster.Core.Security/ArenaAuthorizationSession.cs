using System;
using System.Threading;
using System.Threading.Tasks;

namespace Beastmaster.Core.Security;

public sealed class ArenaAuthorizationSession : IDisposable
{
	private readonly Task<IArenaAuthorizationClient> initialization;

	private readonly CancellationTokenSource lifetime = new CancellationTokenSource();

	private readonly TimeProvider clock;

	private IArenaAuthorizationClient? client;

	private Task? refresh;

	private ulong account;

	private ulong character;

	private bool refreshRequested = true;

	private string? failure;

	private bool disposed;

	public ArenaAuthorizationState Current
	{
		get
		{
			if (disposed)
			{
				return new ArenaAuthorizationState(Authorized: false, Refreshing: false, null, "Disposed");
			}
			if (failure != null)
			{
				return new ArenaAuthorizationState(Authorized: false, Refreshing: false, null, failure);
			}
			if (client == null)
			{
				return new ArenaAuthorizationState(Authorized: false, Refreshing: true, null, "Initializing");
			}
			if (account == 0L || character == 0L)
			{
				return new ArenaAuthorizationState(Authorized: false, Refreshing: false, null, "Verification.NotLoggedIn");
			}
			try
			{
				ArenaAuthorizationState current = client.Current;
				if (current.Authorized)
				{
					DateTimeOffset? expiresAt = current.ExpiresAt;
					if (expiresAt.HasValue)
					{
						DateTimeOffset valueOrDefault = expiresAt.GetValueOrDefault();
						if (valueOrDefault <= clock.GetUtcNow())
						{
							return current with
							{
								Authorized = false,
								Reason = "Verification.Expired"
							};
						}
					}
				}
				return current;
			}
			catch
			{
				failure = "ClientFailure";
				return new ArenaAuthorizationState(Authorized: false, Refreshing: false, null, failure);
			}
		}
	}

	public bool CanGenerateTicket
	{
		get
		{
			if (!disposed && failure == null && account != 0L && character != 0L)
			{
				return client is IArenaActivationClient;
			}
			return false;
		}
	}

	public ArenaAuthorizationSession(Func<IArenaAuthorizationClient> factory, TimeProvider? clock = null)
		: this(Task.Run(factory), clock)
	{
	}

	public ArenaAuthorizationSession(Task<IArenaAuthorizationClient> initialization, TimeProvider? clock = null)
	{
		this.initialization = initialization;
		this.clock = clock ?? TimeProvider.System;
	}

	public void Tick(ulong accountId, ulong contentId)
	{
		if (disposed || failure != null)
		{
			return;
		}
		try
		{
			if (client == null)
			{
				if (!initialization.IsCompleted)
				{
					return;
				}
				client = initialization.GetAwaiter().GetResult();
				client.UpdateIdentity(0uL, 0uL);
			}
			if (accountId == 0L || contentId == 0L)
			{
				accountId = (contentId = 0uL);
			}
			if (account != accountId || character != contentId)
			{
				account = accountId;
				character = contentId;
				client.UpdateIdentity(account, character);
				refreshRequested = true;
			}
			Task task = refresh;
			if (task != null && task.IsCompleted)
			{
				refresh = null;
				task.GetAwaiter().GetResult();
			}
			if (account != 0L && refresh == null && refreshRequested)
			{
				refreshRequested = false;
				refresh = client.RefreshAsync(lifetime.Token);
			}
		}
		catch
		{
			failure = "ClientFailure";
		}
	}

	public void RequestRefresh()
	{
		refreshRequested = true;
	}

	public Task<ArenaActivationTicket> CreateTicketAsync(ArenaCredentialKind kind)
	{
		if (!CanGenerateTicket)
		{
			throw new InvalidOperationException("验证客户端或身份尚未就绪");
		}
		return ((IArenaActivationClient)client).CreateTicketAsync(kind, lifetime.Token);
	}

	public void Dispose()
	{
		if (disposed)
		{
			return;
		}
		disposed = true;
		lifetime.Cancel();
		refresh?.ContinueWith(delegate(Task t)
		{
			_ = t.Exception;
		}, CancellationToken.None, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
		if (client != null)
		{
			client.Dispose();
		}
		else
		{
			initialization.ContinueWith(delegate(Task<IArenaAuthorizationClient> t)
			{
				if (t.IsCompletedSuccessfully)
				{
					t.Result.Dispose();
				}
				else
				{
					_ = t.Exception;
				}
			}, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
		}
		lifetime.Dispose();
	}
}
