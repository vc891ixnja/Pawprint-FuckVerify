using System;

namespace Beastmaster.Core.Security;

public sealed record ArenaAuthorizationState(bool Authorized, bool Refreshing, DateTimeOffset? ExpiresAt, string Reason);
