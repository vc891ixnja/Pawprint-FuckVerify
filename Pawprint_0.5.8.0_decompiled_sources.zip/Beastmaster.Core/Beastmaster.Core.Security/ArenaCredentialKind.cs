namespace Beastmaster.Core.Security;

public enum ArenaCredentialKind
{
	Machine,
	Account
}
