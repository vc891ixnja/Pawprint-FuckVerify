using System;
using System.Threading;
using System.Threading.Tasks;

namespace Beastmaster.Core.Security;

public interface IArenaAuthorizationClient : IDisposable
{
	ArenaAuthorizationState Current { get; }

	void UpdateIdentity(ulong accountId, ulong contentId);

	Task RefreshAsync(CancellationToken token);
}
