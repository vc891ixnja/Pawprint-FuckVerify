namespace Beastmaster.Core.Security;

public sealed record ReleaseFileHash(string Name, string Sha256);
