using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Beastmaster.Core.Security;

public sealed class ArenaActivationFlow
{
	private readonly TimeProvider clock = time ?? TimeProvider.System;

	private ArenaCredentialKind? requested;

	private ulong requestedCharacter;

	private ulong issuingAccount;

	private DateTimeOffset deadline;

	private Task<ArenaActivationTicket>? pending;

	public bool Busy
	{
		get
		{
			if (!requested.HasValue)
			{
				return pending != null;
			}
			return true;
		}
	}

	public string Message { get; private set; } = "";

	public DateTimeOffset? ExpiresAt { get; private set; }

	public ArenaActivationFlow(TimeProvider? time = null)
	{
	}

	public void Request(ArenaCredentialKind kind, ulong character)
	{
		if (!Busy)
		{
			if (character == 0L)
			{
				Message = "请先登录游戏";
				return;
			}
			requested = kind;
			requestedCharacter = character;
			issuingAccount = 0uL;
			deadline = clock.GetUtcNow().AddSeconds(30.0);
			ExpiresAt = null;
			Message = "正在准备激活凭证";
		}
	}

	public void Tick(ulong account, ulong character, bool canIssue, Func<ArenaCredentialKind, Task<ArenaActivationTicket>> issue, Action<string> copy)
	{
		if (requestedCharacter != 0L && (character != requestedCharacter || (issuingAccount != 0L && account != issuingAccount)))
		{
			Clear();
			Message = "身份已变化，请重新生成";
			return;
		}
		if (!Busy)
		{
			DateTimeOffset? expiresAt = ExpiresAt;
			if (expiresAt.HasValue)
			{
				DateTimeOffset valueOrDefault = expiresAt.GetValueOrDefault();
				if (valueOrDefault <= clock.GetUtcNow())
				{
					ExpiresAt = null;
					Message = "凭证已过期，请重新生成";
				}
			}
			return;
		}
		if (clock.GetUtcNow() >= deadline)
		{
			Clear();
			Message = "生成超时，请重试";
			return;
		}
		try
		{
			ArenaCredentialKind? arenaCredentialKind = requested;
			ArenaCredentialKind valueOrDefault2 = default(ArenaCredentialKind);
			int num;
			if (arenaCredentialKind.HasValue)
			{
				valueOrDefault2 = arenaCredentialKind.GetValueOrDefault();
				num = 1;
			}
			else
			{
				num = 0;
			}
			if (((uint)num & (canIssue ? 1u : 0u)) != 0 && account != 0L)
			{
				issuingAccount = account;
				requested = null;
				pending = issue(valueOrDefault2);
				Message = "正在生成激活凭证";
			}
			Task<ArenaActivationTicket> task = pending;
			if (task == null || !task.IsCompleted)
			{
				return;
			}
			pending = null;
			ArenaActivationTicket result = task.GetAwaiter().GetResult();
			if (!result.Success)
			{
				Message = Error(result.Reason);
				return;
			}
			DateTimeOffset? expiresAt = result.ExpiresAt;
			if (expiresAt.HasValue)
			{
				DateTimeOffset valueOrDefault3 = expiresAt.GetValueOrDefault();
				if (!(valueOrDefault3 <= clock.GetUtcNow()))
				{
					string ticket = result.Ticket;
					if (ticket == null || ticket.Length != 43 || !ticket.All(delegate(char c)
					{
						bool flag = char.IsAsciiLetterOrDigit(c);
						if (!flag)
						{
							bool flag2 = ((c == '-' || c == '_') ? true : false);
							flag = flag2;
						}
						return flag;
					}))
					{
						Message = "凭证格式不匹配，请联系发布者";
						return;
					}
					copy(ticket);
					ExpiresAt = valueOrDefault3;
					Message = "已复制，请在有效期内提交到认证频道";
					return;
				}
			}
			Message = "凭证已过期，请重新生成";
		}
		catch
		{
			Message = "生成或复制失败，请重试";
		}
	}

	public void Clear()
	{
		pending?.ContinueWith(delegate(Task<ArenaActivationTicket> t)
		{
			_ = t.Exception;
		}, CancellationToken.None, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
		pending = null;
		requested = null;
		requestedCharacter = (issuingAccount = 0uL);
		ExpiresAt = null;
		Message = "";
	}

	private static string Error(string reason)
	{
		switch (reason)
		{
		case "Verification.ActivationBusy":
			return "上一份凭证仍在生成，请稍后重试";
		case "Verification.IdentityChanged":
			return "身份已变化，请重新生成";
		case "Verification.ActivationTicketExpired":
			return "凭证已过期，请重新生成";
		case "Verification.NotLoggedIn":
			return "请先登录游戏";
		case "Verification.ClientKeyRejected":
			return "凭证签发权限被拒绝，请联系发布者";
		case "Verification.OfficeUnavailable":
		case "Verification.ServerUnavailable":
			return "认证服务暂时不可用，请稍后重试";
		case "Verification.NekoBlacklisted":
		case "Verification.OfficeBlacklisted":
			return "当前身份受限，无法生成凭证";
		default:
			return "无法生成凭证，请重试或联系发布者";
		}
	}
}
