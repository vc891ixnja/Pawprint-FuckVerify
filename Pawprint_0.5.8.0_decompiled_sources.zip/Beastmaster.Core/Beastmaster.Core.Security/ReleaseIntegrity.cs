using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;

namespace Beastmaster.Core.Security;

public static class ReleaseIntegrity
{
	public const string ManifestName = "Pawprint.integrity.json";

	public const string SignatureName = "Pawprint.integrity.sig";

	public static IntegrityResult Verify(string directory, string publicKey, string version)
	{
		try
		{
			byte[] array = ReadLimited(Path.Combine(directory, "Pawprint.integrity.json"), 65536);
			byte[] signature = ReadLimited(Path.Combine(directory, "Pawprint.integrity.sig"), 1024);
			using RSA rSA = RSA.Create();
			rSA.ImportFromPem(publicKey.AsSpan());
			if (!rSA.VerifyData(array, signature, HashAlgorithmName.SHA256, RSASignaturePadding.Pss))
			{
				return Failure("发布签名不匹配");
			}
			ReleaseHashManifest releaseHashManifest = JsonSerializer.Deserialize<ReleaseHashManifest>(array);
			if ((object)releaseHashManifest != null && releaseHashManifest.Schema == 1)
			{
				ReleaseFileHash[] files = releaseHashManifest.Files;
				if (files != null)
				{
					int num = files.Length;
					if (num > 0 && num <= 64 && !(releaseHashManifest.Version != version))
					{
						HashSet<string> names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
						files = releaseHashManifest.Files;
						num = 0;
						while (num < files.Length)
						{
							ReleaseFileHash releaseFileHash = files[num];
							if ((object)releaseFileHash != null && !string.IsNullOrWhiteSpace(releaseFileHash.Name) && releaseFileHash.Name.IndexOfAny(new char[3] { '/', '\\', ':' }) < 0 && releaseFileHash.Name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) && names.Add(releaseFileHash.Name))
							{
								string sha = releaseFileHash.Sha256;
								if (sha != null && sha.Length == 64)
								{
									using (FileStream source = File.OpenRead(Path.Combine(directory, releaseFileHash.Name)))
									{
										byte[] array2 = Convert.FromHexString(releaseFileHash.Sha256);
										if (!CryptographicOperations.FixedTimeEquals(SHA256.HashData(source), array2))
										{
											return Failure(releaseFileHash.Name + " 已变更");
										}
									}
									num++;
									continue;
								}
							}
							return Failure("发布清单无效");
						}
						if (!names.Contains("Pawprint.dll") || !names.Contains("Beastmaster.Core.dll"))
						{
							return Failure("发布清单缺少核心文件");
						}
						if (Directory.EnumerateFiles(directory, "*.dll").Any((string path) => !names.Contains(Path.GetFileName(path))))
						{
							return Failure("安装目录包含未登记的 DLL");
						}
						return new IntegrityResult(Valid: true, "文件校验通过");
					}
				}
			}
			return Failure("发布清单或版本不匹配");
		}
		catch (Exception ex) when (((ex is IOException || ex is UnauthorizedAccessException || ex is CryptographicException || ex is JsonException || ex is ArgumentException || ex is FormatException || ex is NotSupportedException) ? 1 : 0) != 0)
		{
			return Failure("文件、发布清单或签名无法读取");
		}
	}

	private static byte[] ReadLimited(string path, int maximum)
	{
		using FileStream fileStream = File.OpenRead(path);
		if (fileStream.Length <= 0 || fileStream.Length > maximum)
		{
			throw new IOException("Invalid release metadata size");
		}
		byte[] array = new byte[(int)fileStream.Length];
		fileStream.ReadExactly(array);
		return array;
	}

	private static IntegrityResult Failure(string detail)
	{
		return new IntegrityResult(Valid: false, "自动斗兽文件校验失败：" + detail + "，请重新安装完整发布包");
	}
}
