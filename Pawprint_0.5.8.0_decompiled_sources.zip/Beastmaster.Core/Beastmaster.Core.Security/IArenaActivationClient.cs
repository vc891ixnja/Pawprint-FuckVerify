using System.Threading;
using System.Threading.Tasks;

namespace Beastmaster.Core.Security;

public interface IArenaActivationClient
{
	Task<ArenaActivationTicket> CreateTicketAsync(ArenaCredentialKind kind, CancellationToken token);
}
