namespace Beastmaster.Core.Security;

public sealed record IntegrityResult(bool Valid, string Message);
