using System.Collections.Generic;

namespace Beastmaster.Core.Modules;

public sealed class ArenaModule : FeatureModule
{
	public override string Id => "arena";

	public override string Name => "斗兽奇弈";

	public override string ImplementationStatus => "关卡策略接口与流程演练可用；关卡数据、界面事件和胜负判定待接入";

	public override IReadOnlyList<string> Stages { get; } = new _003C_003Ez__ReadOnlyArray<string>(new string[5] { "识别关卡与规则", "检查编队与准备条件", "进入对局", "执行关卡策略", "确认胜负与结算" });
}
