using System.Collections.Generic;

namespace Beastmaster.Core.Modules;

public sealed class HuntingModule : FeatureModule
{
	public override string Id => "hunting";

	public override string Name => "捕猎";

	public override string ImplementationStatus => "目标记录与流程演练可用；可捕获名单、技能和成功判定待接入";

	public override IReadOnlyList<string> Stages { get; } = new _003C_003Ez__ReadOnlyArray<string>(new string[6] { "检查目标与捕获条件", "前往目标区域", "寻找并接近目标", "识破并捕获一次", "连击击杀", "刷新图鉴" });
}
