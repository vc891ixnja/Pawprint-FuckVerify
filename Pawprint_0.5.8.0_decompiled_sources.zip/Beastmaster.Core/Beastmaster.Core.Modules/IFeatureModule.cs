using System.Collections.Generic;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Modules;

public interface IFeatureModule
{
	string Id { get; }

	string Name { get; }

	string ImplementationStatus { get; }

	IReadOnlyList<string> Stages { get; }

	WorkflowPlan CreatePreview();
}
