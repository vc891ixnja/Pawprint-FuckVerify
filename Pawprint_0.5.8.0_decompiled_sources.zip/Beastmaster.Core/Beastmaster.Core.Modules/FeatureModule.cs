using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Modules;

public abstract class FeatureModule : IFeatureModule
{
	private sealed class PreviewStep(string name) : IWorkflowStep
	{
		public string Name => "[演练] " + name;

		public TimeSpan Timeout => TimeSpan.FromSeconds(5L);

		public StepResult Tick(TimeSpan elapsed)
		{
			if (!(elapsed >= TimeSpan.FromSeconds(1L)))
			{
				return StepResult.Running;
			}
			return StepResult.Completed;
		}

		public void Cancel()
		{
		}
	}

	public abstract string Id { get; }

	public abstract string Name { get; }

	public abstract string ImplementationStatus { get; }

	public abstract IReadOnlyList<string> Stages { get; }

	public WorkflowPlan CreatePreview()
	{
		return new WorkflowPlan(Name + "流程演练", IsPreview: true, ((IEnumerable<string>)Stages).Select((Func<string, IWorkflowStep>)((string s) => new PreviewStep(s))).ToArray());
	}
}
