using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;

namespace Beastmaster.Core.Diagnostics;

public sealed class ArenaTraceWriter : IDisposable
{
	private static readonly JsonSerializerOptions Json = new JsonSerializerOptions
	{
		Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
	};

	private readonly Dictionary<string, (string Json, long Id)> states = new Dictionary<string, (string, long)>();

	private readonly long partLimit;

	private readonly TimeSpan partDuration;

	private readonly TimeProvider clock;

	private StreamWriter? writer;

	private long partBytes;

	private long sequence;

	private long openedAt;

	private bool disposed;

	public string DirectoryPath { get; }

	public int PartCount { get; private set; }

	public long RawBytes { get; private set; }

	public long RecordCount => sequence;

	public ArenaTraceWriter(string directory, long partLimit = 67108864L, TimeSpan? partDuration = null, TimeProvider? clock = null)
	{
		if (partLimit <= 0)
		{
			throw new ArgumentOutOfRangeException("partLimit");
		}
		this.partDuration = partDuration ?? TimeSpan.FromMinutes(5L);
		if (this.partDuration <= TimeSpan.Zero)
		{
			throw new ArgumentOutOfRangeException("partDuration");
		}
		this.partLimit = partLimit;
		this.clock = clock ?? TimeProvider.System;
		DirectoryPath = directory;
		Directory.CreateDirectory(directory);
		OpenPart();
	}

	public long State(string channel, object? data)
	{
		ObjectDisposedException.ThrowIf(disposed, this);
		string text = JsonSerializer.Serialize(data, Json);
		if (states.TryGetValue(channel, out (string, long) value) && value.Item1 == text)
		{
			return value.Item2;
		}
		long num = Record("State", new
		{
			Channel = channel,
			Value = JsonSerializer.Deserialize<JsonElement>(text)
		});
		states[channel] = (text, num);
		return num;
	}

	public long Record(string kind, object? data)
	{
		ObjectDisposedException.ThrowIf(disposed, this);
		long num = sequence + 1;
		string text = JsonSerializer.Serialize(new
		{
			Kind = kind,
			Id = num,
			At = clock.GetUtcNow(),
			Data = data
		}, Json);
		int num2 = Encoding.UTF8.GetByteCount(text) + 1;
		if (partBytes > 0 && (partBytes + num2 > partLimit || clock.GetElapsedTime(openedAt) >= partDuration))
		{
			writer.Dispose();
			writer = null;
			OpenPart();
		}
		writer.WriteLine(text);
		sequence = num;
		partBytes += num2;
		RawBytes += num2;
		return num;
	}

	public void Flush()
	{
		ObjectDisposedException.ThrowIf(disposed, this);
		writer.Flush();
	}

	private void OpenPart()
	{
		FileStream fileStream = new FileStream(Path.Combine(DirectoryPath, $"part-{PartCount + 1:00000}.jsonl.gz"), FileMode.CreateNew, FileAccess.Write, FileShare.Read);
		try
		{
			writer = new StreamWriter(new GZipStream(fileStream, CompressionLevel.Fastest), new UTF8Encoding(encoderShouldEmitUTF8Identifier: false))
			{
				NewLine = "\n"
			};
		}
		catch
		{
			fileStream.Dispose();
			throw;
		}
		PartCount++;
		partBytes = 0L;
		openedAt = clock.GetTimestamp();
	}

	public void Dispose()
	{
		if (disposed)
		{
			return;
		}
		disposed = true;
		try
		{
			writer?.Dispose();
		}
		finally
		{
			writer = null;
			states.Clear();
		}
	}
}
