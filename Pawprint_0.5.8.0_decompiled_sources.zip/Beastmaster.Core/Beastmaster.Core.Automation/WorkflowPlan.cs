using System.Collections.Generic;

namespace Beastmaster.Core.Automation;

public sealed record WorkflowPlan(string Name, bool IsPreview, IReadOnlyList<IWorkflowStep> Steps);
