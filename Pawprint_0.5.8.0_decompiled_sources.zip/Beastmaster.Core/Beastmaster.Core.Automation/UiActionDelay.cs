using System;

namespace Beastmaster.Core.Automation;

public sealed class UiActionDelay(Func<int, int, int>? sample = null)
{
	private string? pending;

	private TimeSpan due;

	public bool Ready(string action, TimeSpan now, int minimumMs = 300, int maximumMs = 900)
	{
		if (minimumMs < 0 || maximumMs < minimumMs)
		{
			throw new ArgumentOutOfRangeException("minimumMs");
		}
		if (pending != action)
		{
			pending = action;
			int value = (sample ?? new Func<int, int, int>(Random.Shared.Next))(minimumMs, maximumMs + 1);
			due = now + TimeSpan.FromMilliseconds(Math.Clamp(value, minimumMs, maximumMs));
			return false;
		}
		if (now < due)
		{
			return false;
		}
		pending = null;
		return true;
	}

	public void Reset()
	{
		pending = null;
	}
}
