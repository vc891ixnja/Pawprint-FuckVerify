using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Automation;

public sealed class NavigationStep(INavigationProvider nav, WorldPoint destination, Func<WorldPoint?> getPlayer, bool fly = false, float arrivalTolerance = 2f) : IWorkflowStep
{
	private CancellationTokenSource? cancellation;

	private Task<List<Vector3>>? path;

	private bool ownsMovement;

	public string Name
	{
		get
		{
			if (!fly)
			{
				return "地面前往目标";
			}
			return "飞行前往目标";
		}
	}

	public bool IsFlyingPath => fly;

	public WorldPoint Destination => destination;

	public TimeSpan Timeout => TimeSpan.FromSeconds(90L);

	public StepResult Tick(TimeSpan elapsed)
	{
		WorldPoint worldPoint = getPlayer() ?? throw new InvalidOperationException("玩家未加载");
		if (!worldPoint.IsValid || !destination.IsValid || destination.TerritoryId != worldPoint.TerritoryId)
		{
			throw new InvalidOperationException("目标点无效或不在当前区域");
		}
		if (Vector3.Distance(worldPoint.Position, destination.Position) <= arrivalTolerance)
		{
			return StepResult.Completed;
		}
		if (!nav.IsReady || !nav.MovementAllowed)
		{
			throw new InvalidOperationException("导航网格未就绪或移动被禁用");
		}
		if (path == null)
		{
			if (nav.IsRunning || nav.IsPathfinding)
			{
				throw new InvalidOperationException("vnavmesh 已被其他任务使用");
			}
			cancellation = new CancellationTokenSource();
			path = nav.FindPath(worldPoint.Position, destination.Position, cancellation.Token, fly);
			return StepResult.Running;
		}
		if (!path.IsCompleted)
		{
			return StepResult.Running;
		}
		if (!ownsMovement)
		{
			List<Vector3> result = path.GetAwaiter().GetResult();
			if (result.Count == 0 || result.Any((Vector3 p) => !float.IsFinite(p.X) || !float.IsFinite(p.Y) || !float.IsFinite(p.Z)))
			{
				throw new InvalidOperationException("未找到有效路径");
			}
			if (nav.IsRunning || nav.IsPathfinding)
			{
				throw new InvalidOperationException("寻路期间导航被其他任务占用");
			}
			ownsMovement = true;
			nav.Move(result, fly);
			return StepResult.Running;
		}
		if (!nav.IsRunning)
		{
			throw new InvalidOperationException("导航提前结束，尚未到达目标");
		}
		return StepResult.Running;
	}

	public void Cancel()
	{
		Task<List<Vector3>> task = path;
		path = null;
		try
		{
			cancellation?.Cancel();
		}
		finally
		{
			cancellation?.Dispose();
			cancellation = null;
			task?.ContinueWith(delegate(Task<List<Vector3>> t)
			{
				_ = t.Exception;
			}, CancellationToken.None, TaskContinuationOptions.OnlyOnFaulted | TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Default);
			if (ownsMovement)
			{
				ownsMovement = false;
				nav.Stop();
			}
		}
	}
}
