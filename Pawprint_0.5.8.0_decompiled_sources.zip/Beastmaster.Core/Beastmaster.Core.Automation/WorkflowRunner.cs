using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Automation;

public sealed class WorkflowRunner : IDisposable
{
	private readonly TimeProvider clock = clock ?? TimeProvider.System;

	private readonly Queue<RunEvent> history = new Queue<RunEvent>();

	private WorkflowPlan? plan;

	private long stepStarted;

	private TimeSpan previousElapsed;

	private bool entered;

	public RunState State { get; private set; }

	public string Message { get; private set; } = "就绪";

	public string PlanName => plan?.Name ?? "无任务";

	public bool IsPreview => plan?.IsPreview ?? true;

	public int StepIndex { get; private set; }

	public int StepCount => plan?.Steps.Count ?? 0;

	public string CurrentStep
	{
		get
		{
			if (StepIndex >= StepCount)
			{
				return "—";
			}
			return plan.Steps[StepIndex].Name;
		}
	}

	public IReadOnlyCollection<RunEvent> History => history;

	public bool IsActive
	{
		get
		{
			RunState state = State;
			if ((uint)(state - 1) <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public IWorkflowStep? ActiveStep
	{
		get
		{
			if (!IsActive || StepIndex >= StepCount)
			{
				return null;
			}
			return plan.Steps[StepIndex];
		}
	}

	public WorkflowRunner(TimeProvider? clock = null)
	{
	}

	public bool Start(WorkflowPlan next)
	{
		if (IsActive)
		{
			return false;
		}
		if (next.Steps.Count == 0)
		{
			throw new ArgumentException("流程不能为空", "next");
		}
		if (next.Steps.Any((IWorkflowStep s) => s.Timeout <= TimeSpan.Zero))
		{
			throw new ArgumentException("步骤必须有正数超时", "next");
		}
		plan = next with
		{
			Steps = next.Steps.ToArray()
		};
		StepIndex = 0;
		previousElapsed = TimeSpan.Zero;
		entered = false;
		Change(RunState.Running, "开始" + (next.IsPreview ? "演练" : "执行") + "：" + next.Name);
		return true;
	}

	public void Tick(string? interruption = null)
	{
		if (!IsActive)
		{
			return;
		}
		if (interruption != null)
		{
			Stop(interruption);
		}
		else
		{
			if (State != RunState.Running)
			{
				return;
			}
			IWorkflowStep workflowStep = plan.Steps[StepIndex];
			try
			{
				if (!entered)
				{
					stepStarted = clock.GetTimestamp();
					entered = true;
				}
				TimeSpan timeSpan = previousElapsed + clock.GetElapsedTime(stepStarted);
				if (timeSpan >= workflowStep.Timeout)
				{
					throw new TimeoutException("步骤超时：" + workflowStep.Name);
				}
				if (workflowStep.Tick(timeSpan) == StepResult.Completed)
				{
					entered = false;
					workflowStep.Cancel();
					StepIndex++;
					previousElapsed = TimeSpan.Zero;
					if (StepIndex == StepCount)
					{
						Change(RunState.Completed, IsPreview ? "演练完成；未执行游戏操作" : "流程完成");
					}
					else
					{
						Record("进入步骤：" + CurrentStep);
					}
				}
			}
			catch (Exception ex)
			{
				string text = CancelCurrent();
				Change(RunState.Failed, ex.Message + text);
			}
		}
	}

	public void Pause()
	{
		if (State == RunState.Running)
		{
			if (entered)
			{
				previousElapsed += clock.GetElapsedTime(stepStarted);
			}
			string text = CancelCurrent();
			Change((text.Length == 0) ? RunState.Paused : RunState.Failed, "已暂停；恢复时重新进入当前步骤" + text);
		}
	}

	public void Resume()
	{
		if (State == RunState.Paused)
		{
			Change(RunState.Running, "已恢复");
		}
	}

	public void Stop(string reason = "手动停止")
	{
		if (IsActive)
		{
			string text = CancelCurrent();
			Change((text.Length == 0) ? RunState.Stopped : RunState.Failed, reason + text);
		}
	}

	private string CancelCurrent()
	{
		if (!entered || plan == null || StepIndex >= StepCount)
		{
			return "";
		}
		entered = false;
		try
		{
			plan.Steps[StepIndex].Cancel();
			return "";
		}
		catch (Exception ex)
		{
			return "；清理失败：" + ex.Message;
		}
	}

	private void Change(RunState state, string message)
	{
		State = state;
		Message = message;
		Record(message);
	}

	private void Record(string message)
	{
		history.Enqueue(new RunEvent(clock.GetUtcNow(), message));
		while (history.Count > 200)
		{
			history.Dequeue();
		}
	}

	public void Dispose()
	{
		Stop("插件卸载");
	}
}
