using System.Collections.Generic;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;

namespace Beastmaster.Core.Automation;

public interface INavigationProvider
{
	bool IsReady { get; }

	bool IsRunning { get; }

	bool IsPathfinding { get; }

	bool MovementAllowed { get; }

	Task<List<Vector3>> FindPath(Vector3 from, Vector3 to, CancellationToken token, bool fly = false);

	void Move(List<Vector3> points, bool fly = false);

	void Stop();
}
