namespace Beastmaster.Core.Automation;

public enum RunState
{
	Idle,
	Running,
	Paused,
	Completed,
	Stopped,
	Failed
}
