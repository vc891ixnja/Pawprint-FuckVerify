using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Automation;

public sealed class SequentialStep(IReadOnlyList<IWorkflowStep> steps) : IWorkflowStep
{
	private int index;

	public string Name
	{
		get
		{
			if (index >= steps.Count)
			{
				return "";
			}
			return steps[index].Name;
		}
	}

	public TimeSpan Timeout => steps.FirstOrDefault()?.Timeout ?? TimeSpan.FromSeconds(30L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (index >= steps.Count)
		{
			return StepResult.Completed;
		}
		if (steps[index].Tick(elapsed) == StepResult.Completed)
		{
			steps[index].Cancel();
			index++;
		}
		if (index < steps.Count)
		{
			return StepResult.Running;
		}
		return StepResult.Completed;
	}

	public void Cancel()
	{
		if (index < steps.Count)
		{
			steps[index].Cancel();
		}
		index = steps.Count;
	}
}
