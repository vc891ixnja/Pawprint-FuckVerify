namespace Beastmaster.Core.Automation;

public enum StepResult
{
	Running,
	Completed
}
