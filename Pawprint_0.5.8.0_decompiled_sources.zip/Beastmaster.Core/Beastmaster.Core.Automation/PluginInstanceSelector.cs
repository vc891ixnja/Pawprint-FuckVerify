using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Automation;

public static class PluginInstanceSelector
{
	public static T? Select<T>(IEnumerable<T> plugins, string name, Func<T, string> internalName, Func<T, bool> isLoaded) where T : class
	{
		T val = null;
		foreach (T plugin in plugins)
		{
			if (internalName(plugin).Equals(name, StringComparison.OrdinalIgnoreCase))
			{
				if (isLoaded(plugin))
				{
					return plugin;
				}
				if (val == null)
				{
					val = plugin;
				}
			}
		}
		return val;
	}
}
