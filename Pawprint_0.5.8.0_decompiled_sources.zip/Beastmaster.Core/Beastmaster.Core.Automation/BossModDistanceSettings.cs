using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Beastmaster.Core.Automation;

public static class BossModDistanceSettings
{
	public static IReadOnlyDictionary<string, string> Resolve(Func<string, IReadOnlyList<string>> query)
	{
		Dictionary<string, IReadOnlyList<string>> replies = new Dictionary<string, IReadOnlyList<string>>();
		bool flag = Available("MaxDistanceToTarget");
		bool flag2 = false;
		(string, string)[] array = new(string, string)[2]
		{
			("MaxDistanceToTargetMelee", "MaxDistanceToTargetRanged"),
			("MeleeMaxDistanceToTarget", "RangedMaxDistanceToTarget")
		};
		for (int i = 0; i < array.Length; i++)
		{
			(string, string) tuple = array[i];
			string item = tuple.Item1;
			string item2 = tuple.Item2;
			bool flag3 = Available(item);
			bool flag4 = Available(item2);
			flag2 = flag2 || flag3 || flag4;
			if (flag3 && flag4)
			{
				return new Dictionary<string, string>
				{
					[item] = "2.6",
					[item2] = "2.6"
				};
			}
		}
		if (flag && !flag2)
		{
			return new Dictionary<string, string> { ["MaxDistanceToTarget"] = "2.6" };
		}
		throw new InvalidOperationException("BossMod 距离字段不兼容：" + string.Join("；", replies.Select<KeyValuePair<string, IReadOnlyList<string>>, string>((KeyValuePair<string, IReadOnlyList<string>> p) => p.Key + ": " + ((p.Value.Count == 0) ? "空结果" : string.Join(" / ", p.Value.Take(4))))));
		bool Available(string text)
		{
			IReadOnlyList<string> readOnlyList = query(text);
			replies[text] = readOnlyList;
			if (readOnlyList.Count == 1 && (double.TryParse(readOnlyList[0], NumberStyles.Float, CultureInfo.InvariantCulture, out var result) || double.TryParse(readOnlyList[0], NumberStyles.Float, CultureInfo.CurrentCulture, out result)) && double.IsFinite(result))
			{
				return result >= 0.0;
			}
			return false;
		}
	}
}
