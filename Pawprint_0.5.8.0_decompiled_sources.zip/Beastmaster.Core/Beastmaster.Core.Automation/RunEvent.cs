using System;

namespace Beastmaster.Core.Automation;

public sealed record RunEvent(DateTimeOffset At, string Message);
