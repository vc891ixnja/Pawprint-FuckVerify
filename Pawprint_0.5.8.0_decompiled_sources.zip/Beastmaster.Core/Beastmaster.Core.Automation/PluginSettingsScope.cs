using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Automation;

public sealed class PluginSettingsScope(Func<string, string> read, Action<string, string> write) : IDisposable
{
	private readonly List<(string Key, string Previous, string Applied)> changes = new List<(string, string, string)>();

	public void Apply(IReadOnlyDictionary<string, string> values)
	{
		Dictionary<string, string> dictionary = values.ToDictionary<KeyValuePair<string, string>, string, string>((KeyValuePair<string, string> p) => p.Key, (KeyValuePair<string, string> p) => read(p.Key));
		if (dictionary.Any((KeyValuePair<string, string> p) => string.IsNullOrWhiteSpace(p.Value)))
		{
			throw new InvalidOperationException("插件配置接口不兼容，请更新插件");
		}
		try
		{
			foreach (KeyValuePair<string, string> value in values)
			{
				changes.Add((value.Key, dictionary[value.Key], value.Value));
				write(value.Key, value.Value);
				if (!read(value.Key).Equals(value.Value, StringComparison.OrdinalIgnoreCase))
				{
					throw new InvalidOperationException("插件配置未生效：" + value.Key);
				}
			}
		}
		catch
		{
			Dispose();
			throw;
		}
	}

	public void Dispose()
	{
		List<Exception> list = new List<Exception>();
		foreach (var item2 in changes.AsEnumerable().Reverse())
		{
			try
			{
				if (read(item2.Key).Equals(item2.Applied, StringComparison.OrdinalIgnoreCase))
				{
					write(item2.Key, item2.Previous);
				}
			}
			catch (Exception item)
			{
				list.Add(item);
			}
		}
		changes.Clear();
		if (list.Count > 0)
		{
			throw new AggregateException("插件配置恢复失败", list);
		}
	}
}
