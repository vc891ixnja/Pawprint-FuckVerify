using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.ExceptionServices;

namespace Beastmaster.Core.Automation;

public sealed class BossModAiBinding
{
	public object Manager { get; }

	public FieldInfo Behavior { get; }

	public BossModAiBinding(object manager, FieldInfo behavior, MethodInfo command, string commandName)
	{
		_003Ccommand_003EP = command;
		_003CcommandName_003EP = commandName;
		Manager = manager;
		Behavior = behavior;
		base._002Ector();
	}

	public void SetEnabled(bool enabled)
	{
		try
		{
			_003Ccommand_003EP.Invoke(Manager, new object[2]
			{
				_003CcommandName_003EP,
				enabled ? "on" : "off"
			});
		}
		catch (TargetInvocationException ex) when (ex.InnerException != null)
		{
			ExceptionDispatchInfo.Capture(ex.InnerException).Throw();
		}
	}

	public static BossModAiBinding Resolve(IEnumerable<Type> types, IEnumerable<(string Name, Delegate Handler)> commands)
	{
		(string, Delegate)[] source = commands.ToArray();
		Dictionary<object, BossModAiBinding> dictionary = new Dictionary<object, BossModAiBinding>(ReferenceEqualityComparer.Instance);
		foreach (Type type in types.Distinct())
		{
			FieldInfo field = type.GetField("Beh", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
			MethodInfo method = type.GetMethod("OnCommand", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic, new Type[2]
			{
				typeof(string),
				typeof(string)
			});
			if (field == null || method == null)
			{
				continue;
			}
			(string, Delegate)[] source2 = source.Where(((string Name, Delegate Handler) c) => c.Handler.Method.DeclaringType == type && c.Handler.Target != null).ToArray();
			FieldInfo? field2 = type.GetField("Instance", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			object obj = field2?.GetValue(null);
			object[] array = ((!(field2 != null)) ? source2.Select(((string Name, Delegate Handler) c) => c.Handler.Target).ToArray() : new object[1] { obj });
			foreach (object owner in array)
			{
				if (owner != null && type.IsInstanceOfType(owner))
				{
					dictionary.TryAdd(owner, new BossModAiBinding(owner, field, method, source2.FirstOrDefault(((string Name, Delegate Handler) c) => c.Handler.Target == owner).Name ?? ""));
				}
			}
		}
		if (dictionary.Count != 1)
		{
			throw new InvalidOperationException((dictionary.Count == 0) ? "AI 管理实例未就绪或接口不兼容" : "发现多个活动 AI 实例，请重载所选插件");
		}
		return dictionary.Values.Single();
	}
}
