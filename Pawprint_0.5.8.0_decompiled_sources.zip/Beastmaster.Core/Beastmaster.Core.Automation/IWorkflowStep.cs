using System;

namespace Beastmaster.Core.Automation;

public interface IWorkflowStep
{
	string Name { get; }

	TimeSpan Timeout { get; }

	StepResult Tick(TimeSpan elapsed);

	void Cancel();
}
