using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace Beastmaster.Core.Hunting;

public sealed record LevelingCatalog(string GameVersion, string Source, string SourceSha256, LevelingLocation[] Locations)
{
	private static readonly Lazy<LevelingCatalog> Data = new Lazy<LevelingCatalog>(delegate
	{
		using Stream utf8Json = typeof(LevelingCatalog).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.leveling.json") ?? throw new InvalidOperationException("练级分布数据缺失");
		return JsonSerializer.Deserialize<LevelingCatalog>(utf8Json) ?? throw new InvalidOperationException("练级分布数据为空");
	});

	public static LevelingCatalog Load()
	{
		return Data.Value;
	}

	[CompilerGenerated]
	private LevelingCatalog(LevelingCatalog original)
	{
		GameVersion = original.GameVersion;
		Source = original.Source;
		SourceSha256 = original.SourceSha256;
		Locations = original.Locations;
	}
}
