using System;

namespace Beastmaster.Core.Hunting;

public sealed class NotebookPageTurnController
{
	private TimeSpan lastRequest;

	public int? WaitingPage { get; private set; }

	public int Attempts { get; private set; }

	public static NotebookPageCallback CallbackFor(int page)
	{
		return page switch
		{
			0 => new NotebookPageCallback(3, 1u), 
			1 => new NotebookPageCallback(3, 0u), 
			_ => throw new InvalidOperationException("图鉴页码无效"), 
		};
	}

	public void Reset()
	{
		WaitingPage = null;
		Attempts = 0;
		lastRequest = default(TimeSpan);
	}

	public bool TryRequest(int page, TimeSpan now)
	{
		CallbackFor(page);
		if (WaitingPage != page)
		{
			Reset();
		}
		if (Attempts > 0 && now - lastRequest < TimeSpan.FromMilliseconds(1500L))
		{
			return false;
		}
		if (Attempts >= 3)
		{
			throw new TimeoutException("图鉴自动翻页未响应，已停止扫描");
		}
		WaitingPage = page;
		lastRequest = now;
		Attempts++;
		return true;
	}
}
