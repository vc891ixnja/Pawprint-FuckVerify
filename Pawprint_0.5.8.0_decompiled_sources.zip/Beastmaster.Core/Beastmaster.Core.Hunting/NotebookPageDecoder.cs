using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Hunting;

public static class NotebookPageDecoder
{
	public const string VerifiedVersion = "2026.09.01.0000.0000";

	public static NotebookPage Decode(NotebookSnapshot snapshot)
	{
		if (snapshot.GameVersion != "2026.09.01.0000.0000" || snapshot.ContentId == 0L)
		{
			throw new InvalidOperationException("图鉴版本或角色未通过校验");
		}
		Dictionary<int, NotebookValue> values = snapshot.Values.ToDictionary((NotebookValue v) => v.Index);
		bool flag = At(9).Type != "UInt" || At(10).Type != "UInt" || At(9).Number != 2;
		bool flag2;
		if (!flag)
		{
			long? number = At(10).Number;
			if (number.HasValue)
			{
				long valueOrDefault = number.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag2 = true;
					goto IL_00ed;
				}
			}
			flag2 = false;
			goto IL_00ed;
		}
		goto IL_00f4;
		IL_00ed:
		flag = !flag2;
		goto IL_00f4;
		IL_00f4:
		if (flag)
		{
			throw new InvalidOperationException("请清除图鉴筛选，显示完整的两页魔物");
		}
		int num = (int)At(10).Number.Value;
		string[] array = (At(7).Text ?? "").Split('/');
		int result = default(int);
		flag = array.Length != 2 || array[1] != "50" || !int.TryParse(array[0], out result);
		if (!flag)
		{
			flag2 = ((result < 0 || result > 50) ? true : false);
			flag = flag2;
		}
		if (flag)
		{
			throw new InvalidOperationException("图鉴总数未通过校验");
		}
		Dictionary<int, CaptureState> dictionary = new Dictionary<int, CaptureState>();
		int num2 = 0;
		while (num2 < 25)
		{
			int num3 = 1 + num * 25 + num2;
			int num4 = 24 + num2 * 8;
			NotebookValue notebookValue = At(num4 + 2);
			flag = At(num4).Type != "UInt" || At(num4).Number != num3 || GameText.BestiaryNumber(At(num4 + 5).Text ?? "") != num3 || notebookValue.Type != "Bool";
			if (!flag)
			{
				long? number = notebookValue.Number;
				if (number.HasValue)
				{
					long valueOrDefault = number.GetValueOrDefault();
					if ((ulong)valueOrDefault <= 1uL)
					{
						flag2 = true;
						goto IL_02a2;
					}
				}
				flag2 = false;
				goto IL_02a2;
			}
			goto IL_02a9;
			IL_02a9:
			if (flag || At(num4 + 4).Type != "UInt")
			{
				throw new InvalidOperationException("图鉴分页行结构不匹配，停止自动判定");
			}
			bool flag3 = notebookValue.Number == 1;
			if (At(num4 + 4).Number != (flag3 ? (242000 + num3) : 242051))
			{
				throw new InvalidOperationException("图鉴收集标志与图标不一致，等待界面刷新");
			}
			dictionary.Add(num3, (!flag3) ? CaptureState.Missing : CaptureState.Captured);
			num2++;
			continue;
			IL_02a2:
			flag = !flag2;
			goto IL_02a9;
		}
		if (dictionary.Count((KeyValuePair<int, CaptureState> s) => s.Value == CaptureState.Captured) > result || dictionary.Count((KeyValuePair<int, CaptureState> s) => s.Value == CaptureState.Missing) > 50 - result)
		{
			throw new InvalidOperationException("图鉴页状态与总数不一致");
		}
		return new NotebookPage(snapshot, num, result, dictionary);
		NotebookValue At(int index)
		{
			return values.GetValueOrDefault(index) ?? throw new InvalidOperationException("图鉴字段不完整");
		}
	}
}
