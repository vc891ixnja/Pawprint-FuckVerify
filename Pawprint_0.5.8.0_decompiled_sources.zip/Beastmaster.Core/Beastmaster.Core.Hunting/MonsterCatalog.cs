using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Hunting;

public sealed record MonsterCatalog(string GameVersion, string CoordinateSource, MonsterEntry[] Monsters)
{
	public static MonsterCatalog Load()
	{
		using Stream utf8Json = typeof(MonsterCatalog).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.monsters.json") ?? throw new InvalidOperationException("魔物目录资源缺失");
		JsonSerializerOptions options = new JsonSerializerOptions
		{
			Converters = { (JsonConverter)new JsonStringEnumConverter() }
		};
		MonsterCatalog monsterCatalog = JsonSerializer.Deserialize<MonsterCatalog>(utf8Json, options) ?? throw new InvalidOperationException("魔物目录为空");
		if (monsterCatalog.Monsters.Length != 50 || !monsterCatalog.Monsters.Select((MonsterEntry m) => m.Number).Order().SequenceEqual(Enumerable.Range(1, 50)))
		{
			throw new InvalidOperationException("目录必须包含完整且不重复的 1–50 号魔物");
		}
		return monsterCatalog;
	}

	public IEnumerable<MonsterEntry> MissingOverworld(Func<int, CaptureState> state, IReadOnlySet<int>? skipped = null)
	{
		return from m in Monsters.Where(delegate(MonsterEntry m)
			{
				if (m.CanLocate)
				{
					IReadOnlySet<int>? readOnlySet = skipped;
					if (readOnlySet == null || !readOnlySet.Contains(m.Number))
					{
						return state(m.Number) == CaptureState.Missing;
					}
				}
				return false;
			})
			orderby m.Number
			select m;
	}

	public IEnumerable<MonsterEntry> MissingAutomatic(Func<int, CaptureState> state, bool includeDuties)
	{
		return from m in Monsters
			where (m.CanLocate || (includeDuties && m.Kind == MonsterLocationKind.Duty && m.CanHunt)) && state(m.Number) == CaptureState.Missing
			orderby m.Number
			select m;
	}
}
