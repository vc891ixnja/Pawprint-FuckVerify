namespace Beastmaster.Core.Hunting;

public enum FieldDodgeBackend
{
	None,
	BossMod,
	BossModReborn
}
