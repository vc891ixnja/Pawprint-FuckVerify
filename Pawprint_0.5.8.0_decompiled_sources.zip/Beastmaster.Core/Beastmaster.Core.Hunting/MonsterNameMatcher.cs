using System;
using System.Linq;
using System.Text;

namespace Beastmaster.Core.Hunting;

public static class MonsterNameMatcher
{
	public static bool IsCandidate(MonsterEntry entry, string actualName, bool isCombatant, bool isTargetable, bool isDead, uint currentHp, uint nameId = 0u)
	{
		if (isCombatant && isTargetable && !isDead && currentHp != 0)
		{
			return Matches(entry, actualName, nameId);
		}
		return false;
	}

	public static bool MatchesId(MonsterEntry entry, uint nameId)
	{
		if (nameId != 0)
		{
			return entry.MatchNameIds.Contains(nameId);
		}
		return false;
	}

	public static bool Matches(MonsterEntry entry, string actualName, uint nameId = 0u)
	{
		if (!MatchesId(entry, nameId))
		{
			if (!string.IsNullOrWhiteSpace(actualName))
			{
				return entry.MatchNames.Any((string name) => string.Equals(Normalize(name), Normalize(actualName), StringComparison.OrdinalIgnoreCase));
			}
			return false;
		}
		return true;
	}

	private static string Normalize(string text)
	{
		return text.Normalize(NormalizationForm.FormKC).Trim();
	}
}
