using System;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class DutyRouteStep(MonsterEntry monster, IHuntingWorld world, INavigationProvider nav, IAutoDutyNavigator duty) : IWorkflowStep
{
	private ulong character;

	private uint startTerritory;

	private bool requested;

	private bool ownsDuty;

	private bool observedRunning;

	private bool handingOff;

	private bool suspended;

	private TimeSpan handoffAt;

	private TimeSpan locateAt;

	private TimeSpan startedAt;

	private TimeSpan? loadingAt;

	private LocateMonsterStep? locate;

	public MonsterObservation? FoundMonster => locate?.FoundMonster;

	public bool SearchExhausted => locate?.SearchExhausted ?? false;

	public int? RequiredLevel => locate?.RequiredLevel;

	public bool AllowsTransition
	{
		get
		{
			if (requested)
			{
				return locate == null;
			}
			return false;
		}
	}

	public bool IsFollowingRoute
	{
		get
		{
			if (ownsDuty)
			{
				return !handingOff;
			}
			return false;
		}
	}

	public string Name { get; private set; } = "检查 AutoDuty 副本路线";

	public TimeSpan Timeout => TimeSpan.FromMinutes(45L);

	public bool AcceptsTerritory(uint territory)
	{
		if (AllowsTransition)
		{
			if (territory != 0 && territory != startTerritory)
			{
				return territory == monster.TerritoryId;
			}
			return true;
		}
		return false;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (!requested)
		{
			if (monster.UnsupportedDuty)
			{
				throw new InvalidOperationException("该魔物所在多人副本暂不支持自动捕获");
			}
			character = world.ContentId;
			startTerritory = world.TerritoryId;
			if (character == 0L)
			{
				throw new InvalidOperationException("角色未加载");
			}
			if (!duty.HasPath(monster.TerritoryId))
			{
				throw new InvalidOperationException("AutoDuty 没有该副本路线");
			}
			if (duty.IsRunning || !duty.IsStopped || nav.IsRunning || nav.IsPathfinding)
			{
				throw new InvalidOperationException("AutoDuty 或导航正在执行其他任务");
			}
			ownsDuty = true;
			requested = true;
			duty.Run(monster.TerritoryId);
			startedAt = elapsed;
			Name = "AutoDuty 前往 " + monster.LocationName + " 并寻找 " + monster.Name;
			return StepResult.Running;
		}
		if (world.ContentId != character && (world.ContentId != 0L || !AllowsTransition))
		{
			throw new InvalidOperationException("角色变化，副本捕猎已停止");
		}
		if (locate != null)
		{
			StepResult result = locate.Tick(elapsed - locateAt);
			Name = locate.Name;
			return result;
		}
		if (!AcceptsTerritory(world.TerritoryId))
		{
			throw new InvalidOperationException("副本路线进入了非预期区域");
		}
		if (world.IsTransitioning || world.Player == null)
		{
			TimeSpan valueOrDefault = loadingAt.GetValueOrDefault();
			if (!loadingAt.HasValue)
			{
				valueOrDefault = elapsed;
				loadingAt = valueOrDefault;
			}
			TimeSpan? timeSpan = loadingAt;
			if (elapsed - timeSpan > TimeSpan.FromSeconds(90L))
			{
				throw new TimeoutException("副本切图超过 90 秒");
			}
			return StepResult.Running;
		}
		loadingAt = null;
		if (suspended)
		{
			if (duty.IsRunning || !duty.IsStopped || nav.IsRunning || nav.IsPathfinding)
			{
				throw new InvalidOperationException("恢复时控制仍被其他任务占用");
			}
			ownsDuty = true;
			suspended = false;
			observedRunning = false;
			startedAt = elapsed;
			if (world.TerritoryId == monster.TerritoryId)
			{
				duty.Resume();
			}
			else
			{
				duty.Run(monster.TerritoryId);
			}
			return StepResult.Running;
		}
		observedRunning |= duty.IsRunning;
		if (!handingOff && world.TerritoryId == monster.TerritoryId && world.FindMonster(monster) != null)
		{
			duty.Stop();
			handingOff = true;
			handoffAt = elapsed;
			Name = "发现副本目标，等待 AutoDuty 释放移动与战斗控制";
		}
		if (handingOff)
		{
			if (elapsed - handoffAt > TimeSpan.FromSeconds(15L))
			{
				throw new TimeoutException("AutoDuty 尚未释放控制，未开始捕获");
			}
			if (duty.IsRunning || !duty.IsStopped || nav.IsRunning || nav.IsPathfinding)
			{
				return StepResult.Running;
			}
			ownsDuty = false;
			locate = new LocateMonsterStep(monster, world, nav, preferFlight: false);
			locateAt = elapsed;
		}
		else if ((!observedRunning && elapsed - startedAt > TimeSpan.FromSeconds(120L)) || (observedRunning && !duty.IsRunning && duty.IsStopped))
		{
			throw new InvalidOperationException("AutoDuty 未启动或已结束，尚未找到捕获目标；请检查副本进入条件和路线");
		}
		return StepResult.Running;
	}

	public void Cancel()
	{
		locate?.Cancel();
		if (ownsDuty)
		{
			ownsDuty = false;
			suspended = !handingOff;
			duty.Stop();
		}
	}

	public void SuspendLocalMovement()
	{
		locate?.Cancel();
	}
}
