using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Hunting;

public sealed record NotebookCache(ulong ContentId, string GameVersion, DateTimeOffset ObservedAt, Dictionary<int, CaptureState> States)
{
	public CaptureState Get(int number, ulong character, string version)
	{
		if (character == 0L || ContentId != character || !(GameVersion == version))
		{
			return CaptureState.Unknown;
		}
		return States.GetValueOrDefault(number, CaptureState.Unknown);
	}
}
