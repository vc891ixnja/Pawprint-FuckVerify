using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Beastmaster.Core.Hunting;

public sealed class MonsterNameIndex
{
	private readonly Dictionary<uint, MonsterNameRow> names = rows.Where((MonsterNameRow r) => r.NameId != 0 && !string.IsNullOrWhiteSpace(r.Name)).ToDictionary((MonsterNameRow r) => r.NameId);

	public MonsterNameIndex(IEnumerable<MonsterNameRow> rows)
	{
	}

	public MonsterNameSearch Search(string query, int limit = 100)
	{
		query = query.Trim();
		if (query.Length == 0)
		{
			return new MonsterNameSearch(0, Array.Empty<MonsterNameRow>());
		}
		string text;
		if (!query.StartsWith('#'))
		{
			text = query;
		}
		else
		{
			string text2 = query;
			text = text2.Substring(1, text2.Length - 1);
		}
		string text3 = text;
		bool flag = text3.StartsWith("0x", StringComparison.OrdinalIgnoreCase);
		IEnumerable<MonsterNameRow> source;
		if (flag || text3.All(char.IsAsciiDigit))
		{
			string s;
			if (!flag)
			{
				s = text3;
			}
			else
			{
				string text2 = text3;
				s = text2.Substring(2, text2.Length - 2);
			}
			if (!uint.TryParse(s, flag ? NumberStyles.AllowHexSpecifier : NumberStyles.None, CultureInfo.InvariantCulture, out var result))
			{
				return new MonsterNameSearch(0, Array.Empty<MonsterNameRow>());
			}
			IEnumerable<MonsterNameRow> enumerable2;
			if (!names.TryGetValue(result, out MonsterNameRow value))
			{
				IEnumerable<MonsterNameRow> enumerable = Array.Empty<MonsterNameRow>();
				enumerable2 = enumerable;
			}
			else
			{
				IEnumerable<MonsterNameRow> enumerable = new _003C_003Ez__ReadOnlySingleElementList<MonsterNameRow>(value);
				enumerable2 = enumerable;
			}
			source = enumerable2;
		}
		else
		{
			source = names.Values.Where((MonsterNameRow r) => r.Name.Contains(query, StringComparison.OrdinalIgnoreCase));
		}
		MonsterNameRow[] array = source.OrderBy((MonsterNameRow r) => r.NameId).ToArray();
		return new MonsterNameSearch(array.Length, array.Take(Math.Clamp(limit, 1, 200)).ToArray());
	}

	public void RequireTargets(MonsterEntry monster)
	{
		if (monster.NameIds.Length == 0)
		{
			throw new InvalidOperationException($"#{monster.Number:00} 缺少目标 NameId");
		}
		uint[] nameIds = monster.NameIds;
		foreach (uint num in nameIds)
		{
			if (!names.TryGetValue(num, out MonsterNameRow value))
			{
				throw new InvalidOperationException($"#{monster.Number:00} 的 NameId {num} 不存在于当前游戏表");
			}
			if (value.IsNotebookCompanion)
			{
				throw new InvalidOperationException($"#{monster.Number:00} 的 NameId {num} 是伙伴行，不能用于寻找野外魔物");
			}
		}
	}
}
