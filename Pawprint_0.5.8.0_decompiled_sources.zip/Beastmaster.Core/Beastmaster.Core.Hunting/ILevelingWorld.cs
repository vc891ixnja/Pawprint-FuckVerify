namespace Beastmaster.Core.Hunting;

public interface ILevelingWorld : ICombatWorld
{
	float PlayerHpRatio { get; }

	CombatTarget? FindLevelingTarget();

	CombatTarget? FindEngagedTarget()
	{
		return null;
	}

	bool IsEngagedTarget(ulong id)
	{
		return false;
	}

	bool CanTravelTo(uint territory);
}
