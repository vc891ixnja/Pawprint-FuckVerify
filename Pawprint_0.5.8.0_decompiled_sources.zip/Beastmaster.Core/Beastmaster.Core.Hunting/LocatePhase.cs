namespace Beastmaster.Core.Hunting;

public enum LocatePhase
{
	Prepare,
	AwaitArrival,
	AwaitMesh,
	Searching,
	Approaching,
	Landing,
	ConfirmTarget,
	Found,
	Skipped
}
