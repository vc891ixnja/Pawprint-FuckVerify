namespace Beastmaster.Core.Hunting;

public enum CaptureState
{
	Unknown,
	Missing,
	Captured
}
