using System.Collections.Generic;
using System.Numerics;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public interface IHuntingWorld
{
	ulong ContentId { get; }

	uint TerritoryId { get; }

	bool IsTransitioning { get; }

	bool IsInCutscene { get; }

	bool IsCasting { get; }

	byte PlayerLevel { get; }

	bool CanFlyInTerritory { get; }

	bool IsMounted { get; }

	bool IsFlying { get; }

	bool IsMountTransition { get; }

	bool CanTakeOff { get; }

	WorldPoint? Player { get; }

	bool TryMount();

	bool TryTakeOff();

	bool TryDismount();

	AetheryteDestination? SelectAetheryte(MapDestination destination);

	bool Teleport(AetheryteDestination destination);

	WorldPoint ResolveGround(MapDestination destination, Vector2 offset);

	MonsterObservation? FindMonster(MonsterEntry monster, IReadOnlySet<ulong>? excludedObjectIds = null, ulong? preferredObjectId = null);

	bool SelectMonster(MonsterObservation monster);

	bool IsMonsterSelected(MonsterObservation monster);
}
