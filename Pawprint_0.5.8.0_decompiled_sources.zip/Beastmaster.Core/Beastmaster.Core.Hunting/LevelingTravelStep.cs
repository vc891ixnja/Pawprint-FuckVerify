using System;
using System.Numerics;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed class LevelingTravelStep(LevelingLocation site, IHuntingWorld world, INavigationProvider nav, bool preferFlight) : IWorkflowStep
{
	private enum Phase
	{
		Prepare,
		Arrival,
		Mesh,
		Move
	}

	private Phase phase;

	private ulong character;

	private uint startingTerritory;

	private TimeSpan phaseAt;

	private TimeSpan moveAt;

	private TimeSpan landingAt;

	private TimeSpan? mountAt;

	private TimeSpan? lastMount;

	private TimeSpan? takeoffAt;

	private TimeSpan? lastTakeoff;

	private int mountAttempts;

	private bool groundFallback;

	private WorldPoint? destination;

	private NavigationStep? movement;

	private LandAndDismountStep? landing;

	public string Name { get; private set; } = $"前往{site.Region} Lv.{site.Level} 魔物分布区";

	public TimeSpan Timeout => TimeSpan.FromMinutes(8L);

	public bool AllowsZoneTransition => phase == Phase.Arrival;

	public bool CanSearch
	{
		get
		{
			if (!world.IsTransitioning && phase != Phase.Arrival)
			{
				return world.TerritoryId == site.TerritoryId;
			}
			return false;
		}
	}

	public bool AcceptsTerritory(uint territory)
	{
		if (AllowsZoneTransition)
		{
			if (territory != 0 && territory != startingTerritory)
			{
				return territory == site.TerritoryId;
			}
			return true;
		}
		return false;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed > Timeout)
		{
			throw new TimeoutException("前往练级区域超时");
		}
		if (character == 0L)
		{
			character = world.ContentId;
			startingTerritory = world.TerritoryId;
		}
		if (character == 0L)
		{
			throw new InvalidOperationException("角色尚未加载");
		}
		if (world.ContentId == 0L && AllowsZoneTransition && elapsed - phaseAt < TimeSpan.FromSeconds(60L))
		{
			return StepResult.Running;
		}
		if (world.ContentId != character)
		{
			throw new InvalidOperationException("练级期间角色发生变化");
		}
		if (phase == Phase.Prepare)
		{
			if (world.IsTransitioning || world.Player == null || world.IsCasting)
			{
				return StepResult.Running;
			}
			if (world.TerritoryId != site.TerritoryId)
			{
				if (world.IsFlying || world.IsMounted || world.IsMountTransition || landing != null)
				{
					if (landing == null)
					{
						landing = new LandAndDismountStep(world, nav);
						landingAt = elapsed;
					}
					if (landing.Tick(elapsed - landingAt) != StepResult.Completed)
					{
						Name = landing.Name;
						return StepResult.Running;
					}
					landing = null;
				}
				AetheryteDestination aetheryteDestination = world.SelectAetheryte(site.Destination) ?? throw new InvalidOperationException(site.Region + "没有已解锁的大水晶");
				if (!world.Teleport(aetheryteDestination))
				{
					throw new InvalidOperationException("练级传送请求被拒绝");
				}
				phase = Phase.Arrival;
				phaseAt = elapsed;
				Name = $"传送至{aetheryteDestination.Name}，寻找 Lv.{site.Level} 魔物";
				return StepResult.Running;
			}
			phase = Phase.Mesh;
			phaseAt = elapsed;
		}
		if (phase == Phase.Arrival)
		{
			if (elapsed - phaseAt > TimeSpan.FromSeconds(60L))
			{
				throw new TimeoutException("练级传送到达超时");
			}
			if (!AcceptsTerritory(world.TerritoryId))
			{
				throw new InvalidOperationException("练级传送抵达非预期区域");
			}
			if (world.IsTransitioning || world.IsCasting || world.Player == null || world.TerritoryId != site.TerritoryId)
			{
				return StepResult.Running;
			}
			phase = Phase.Mesh;
			phaseAt = elapsed;
		}
		if (world.Player == null || world.IsTransitioning || world.TerritoryId != site.TerritoryId)
		{
			throw new InvalidOperationException("练级移动期间区域发生变化");
		}
		if (phase == Phase.Mesh)
		{
			if (elapsed - phaseAt > TimeSpan.FromSeconds(120L))
			{
				throw new TimeoutException("练级地图网格加载超时");
			}
			if (!nav.IsReady || elapsed - phaseAt < TimeSpan.FromSeconds(2L))
			{
				Name = "等待练级区域加载";
				return StepResult.Running;
			}
			destination = world.ResolveGround(site.Destination, Vector2.Zero);
			phase = Phase.Move;
		}
		if (landing != null)
		{
			if (landing.Tick(elapsed - landingAt) != StepResult.Completed)
			{
				Name = landing.Name;
				return StepResult.Running;
			}
			landing = null;
			return StepResult.Completed;
		}
		Vector3 vector = world.Player.Position - destination.Position;
		if (new Vector2(vector.X, vector.Z).Length() <= 8f && (world.IsFlying || vector.Length() <= 8f))
		{
			movement?.Cancel();
			movement = null;
			if (world.IsFlying || world.IsMounted || world.IsMountTransition)
			{
				landing = new LandAndDismountStep(world, nav);
				landingAt = elapsed;
				landing.Tick(TimeSpan.Zero);
				Name = landing.Name;
				return StepResult.Running;
			}
			return StepResult.Completed;
		}
		if (movement == null)
		{
			if (!PrepareFlight(elapsed, vector.Length()))
			{
				return StepResult.Running;
			}
			movement = new NavigationStep(nav, destination, () => world.Player, world.IsFlying);
			moveAt = elapsed;
		}
		if (elapsed - moveAt > TimeSpan.FromMinutes(6L))
		{
			throw new TimeoutException("练级巡回路径超时");
		}
		StepResult num = movement.Tick(elapsed - moveAt);
		Name = $"{(world.IsFlying ? "飞往" : "前往")}{site.Region}（{site.MapX:F1}, {site.MapY:F1}）· Lv.{site.Level} {site.Name}";
		if (num == StepResult.Completed)
		{
			movement.Cancel();
			movement = null;
		}
		return num;
	}

	private bool PrepareFlight(TimeSpan elapsed, float distance)
	{
		if (world.IsMountTransition || world.IsCasting)
		{
			Name = "等待坐骑或读条完成";
			return false;
		}
		if (!preferFlight || groundFallback || !world.CanFlyInTerritory || distance < 30f)
		{
			return true;
		}
		TimeSpan valueOrDefault;
		TimeSpan value;
		TimeSpan? timeSpan;
		if (!world.IsMounted)
		{
			valueOrDefault = mountAt.GetValueOrDefault();
			if (!mountAt.HasValue)
			{
				valueOrDefault = elapsed;
				mountAt = valueOrDefault;
			}
			value = elapsed;
			timeSpan = mountAt;
			if (value - timeSpan > TimeSpan.FromSeconds(15L))
			{
				groundFallback = true;
				return true;
			}
			if (mountAttempts < 5)
			{
				if (lastMount.HasValue)
				{
					value = elapsed;
					timeSpan = lastMount;
					if (!(value - timeSpan >= TimeSpan.FromSeconds(2L)))
					{
						goto IL_0176;
					}
				}
				lastMount = elapsed;
				mountAttempts++;
				world.TryMount();
			}
			goto IL_0176;
		}
		if (world.IsFlying)
		{
			return true;
		}
		valueOrDefault = takeoffAt.GetValueOrDefault();
		if (!takeoffAt.HasValue)
		{
			valueOrDefault = elapsed;
			takeoffAt = valueOrDefault;
		}
		value = elapsed;
		timeSpan = takeoffAt;
		if (value - timeSpan > TimeSpan.FromSeconds(8L))
		{
			groundFallback = true;
			return true;
		}
		if (world.CanTakeOff)
		{
			if (lastTakeoff.HasValue)
			{
				value = elapsed;
				timeSpan = lastTakeoff;
				if (!(value - timeSpan >= TimeSpan.FromMilliseconds(500L)))
				{
					goto IL_02a0;
				}
			}
			lastTakeoff = elapsed;
			world.TryTakeOff();
		}
		goto IL_02a0;
		IL_0176:
		Name = "召唤坐骑前往练级分布区";
		return false;
		IL_02a0:
		Name = "起飞前往练级分布区";
		return false;
	}

	public void Cancel()
	{
		movement?.Cancel();
		movement = null;
		landing?.Cancel();
		landing = null;
	}
}
