using System;
using System.Collections.Generic;
using System.Numerics;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed class LevelingStep : IWorkflowStep
{
	private readonly LevelingRoutePlanner planner;

	private ulong character;

	private uint expectedTerritory;

	private CombatTarget? target;

	private NavigationStep? movement;

	private WorldPoint? movementTarget;

	private LandAndDismountStep? landing;

	private LevelingLocation? site;

	private LevelingTravelStep? travel;

	private TimeSpan movingSince;

	private TimeSpan landingSince;

	private TimeSpan travelSince;

	private TimeSpan nextAction;

	private TimeSpan? arrivedAt;

	private TimeSpan? noEnemyInCombatAt;

	private int routeFailures;

	public string Name { get; private set; }

	public string? LastRouteError { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(60L);

	public bool AllowsZoneTransition => travel?.AllowsZoneTransition ?? false;

	public object Diagnostics => new
	{
		TargetLevel = _003CtargetLevel_003EP,
		Target = target?.ObjectId,
		Site = site,
		Name = Name,
		LastRouteError = LastRouteError,
		routeFailures = routeFailures,
		AllowsZoneTransition = AllowsZoneTransition
	};

	public LevelingStep(int targetLevel, ILevelingWorld combat, IHuntingWorld world, INavigationProvider nav, bool preferFlight = true, IEnumerable<LevelingLocation>? locations = null)
	{
		_003CtargetLevel_003EP = targetLevel;
		_003Ccombat_003EP = combat;
		_003Cworld_003EP = world;
		_003Cnav_003EP = nav;
		_003CpreferFlight_003EP = preferFlight;
		planner = new LevelingRoutePlanner(locations ?? LevelingCatalog.Load().Locations);
		Name = $"自动练级至 Lv.{_003CtargetLevel_003EP}";
		base._002Ector();
	}

	public bool AcceptsTerritory(uint territory)
	{
		return travel?.AcceptsTerritory(territory) ?? false;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (character == 0L)
		{
			character = _003Ccombat_003EP.ContentId;
			expectedTerritory = _003Ccombat_003EP.TerritoryId;
		}
		if (character == 0L)
		{
			throw new InvalidOperationException("角色尚未加载");
		}
		if (AllowsZoneTransition)
		{
			if (_003Ccombat_003EP.ContentId != 0L && _003Ccombat_003EP.ContentId != character)
			{
				throw new InvalidOperationException("练级期间角色发生变化");
			}
			if (!AcceptsTerritory(_003Ccombat_003EP.TerritoryId))
			{
				throw new InvalidOperationException("练级传送抵达非预期区域");
			}
			TickTravel(elapsed);
			if (!AllowsZoneTransition)
			{
				expectedTerritory = _003Ccombat_003EP.TerritoryId;
			}
			return StepResult.Running;
		}
		if (character != _003Ccombat_003EP.ContentId || expectedTerritory != _003Ccombat_003EP.TerritoryId || _003Cworld_003EP.IsTransitioning)
		{
			throw new InvalidOperationException("角色或区域意外变化，练级已停止");
		}
		if (_003Ccombat_003EP.PlayerLevel >= _003CtargetLevel_003EP && !_003Ccombat_003EP.InCombat)
		{
			Cancel();
			Name = $"已达到 Lv.{_003Ccombat_003EP.PlayerLevel}，练级完成";
			return StepResult.Completed;
		}
		if (_003Ccombat_003EP.Player == null)
		{
			return StepResult.Running;
		}
		if (landing != null)
		{
			if (landing.Tick(elapsed - landingSince) != StepResult.Completed)
			{
				Name = landing.Name;
				return StepResult.Running;
			}
			landing = null;
		}
		CombatTarget combatTarget;
		if (target != null)
		{
			target = _003Ccombat_003EP.ReadTarget(target.ObjectId);
			combatTarget = target;
			if ((object)combatTarget == null || combatTarget.IsDead || !combatTarget.IsTargetable || !combatTarget.IsAttackable || combatTarget.Hp == 0 || (_003Ccombat_003EP.PlayerLevel >= _003CtargetLevel_003EP && !_003Ccombat_003EP.IsEngagedTarget(target.ObjectId)))
			{
				CancelApproach();
				_003Ccombat_003EP.CombatSupport?.Stop();
				_003Ccombat_003EP.StopAutoAttack();
				target = null;
			}
		}
		if (!_003Ccombat_003EP.InCombat && _003Ccombat_003EP.PlayerHpRatio < 0.6f)
		{
			CancelApproach();
			travel?.Cancel();
			_003Ccombat_003EP.CombatSupport?.Stop();
			Name = "等待自然恢复血量至 60%";
			return StepResult.Running;
		}
		if ((object)target == null)
		{
			target = (_003Ccombat_003EP.InCombat ? _003Ccombat_003EP.FindEngagedTarget() : _003Ccombat_003EP.FindLevelingTarget());
		}
		combatTarget = target;
		if ((object)combatTarget == null || combatTarget.IsDead || !combatTarget.IsTargetable || !combatTarget.IsAttackable || combatTarget.Hp == 0)
		{
			target = null;
		}
		if (target == null)
		{
			_003Ccombat_003EP.CombatSupport?.Stop();
			if (_003Ccombat_003EP.InCombat)
			{
				CancelApproach();
				travel?.Cancel();
				TimeSpan valueOrDefault = noEnemyInCombatAt.GetValueOrDefault();
				if (!noEnemyInCombatAt.HasValue)
				{
					valueOrDefault = elapsed;
					noEnemyInCombatAt = valueOrDefault;
				}
				TimeSpan? timeSpan = noEnemyInCombatAt;
				if (elapsed - timeSpan > TimeSpan.FromSeconds(20L))
				{
					throw new InvalidOperationException("当前战斗没有可处理的练级目标，已停止");
				}
				Name = "等待当前战斗结束后继续搜索";
				return StepResult.Running;
			}
			noEnemyInCombatAt = null;
			Patrol(elapsed);
			return StepResult.Running;
		}
		noEnemyInCombatAt = null;
		arrivedAt = null;
		travel?.Cancel();
		travel = null;
		if (site != null)
		{
			planner.Visit(site, elapsed);
			site = null;
		}
		if (target.Level == 0 || (target.Level > _003Ccombat_003EP.PlayerLevel && !_003Ccombat_003EP.IsEngagedTarget(target.ObjectId)))
		{
			throw new InvalidOperationException("练级目标等级不合适，停止攻击");
		}
		ITaskCombatSupport combatSupport = _003Ccombat_003EP.CombatSupport;
		float num = Math.Max(0f, Vector3.Distance(_003Ccombat_003EP.Player.Position, target.Location.Position) - target.HitboxRadius);
		Vector3 vector = _003Ccombat_003EP.Player.Position - target.Location.Position;
		if ((_003Cworld_003EP.IsFlying || _003Cworld_003EP.IsMounted || _003Cworld_003EP.IsMountTransition) && new Vector2(vector.X, vector.Z).Length() <= 6f + target.HitboxRadius)
		{
			combatSupport?.Stop();
			CancelApproach();
			landing = new LandAndDismountStep(_003Cworld_003EP, _003Cnav_003EP);
			landingSince = elapsed;
			landing.Tick(TimeSpan.Zero);
			Name = landing.Name;
			return StepResult.Running;
		}
		bool flag = combatSupport?.WantsMovement(target) ?? false;
		if (flag)
		{
			CancelApproach();
			combatSupport.UpdateMovement(target.ObjectId);
		}
		else
		{
			combatSupport?.StopMovement();
		}
		if (num > 3f)
		{
			combatSupport?.StopRotation();
			if (flag)
			{
				Name = "躲避并接近练级目标";
				return StepResult.Running;
			}
			if (movementTarget != null && Vector3.Distance(movementTarget.Position, target.Location.Position) > 2f)
			{
				CancelApproach();
			}
			if (movement == null)
			{
				movementTarget = target.Location;
				movement = new NavigationStep(_003Cnav_003EP, target.Location, () => _003Ccombat_003EP.Player, _003Cworld_003EP.IsFlying);
				movingSince = elapsed;
			}
			if (elapsed - movingSince > movement.Timeout)
			{
				throw new TimeoutException("练级目标接近超时");
			}
			if (movement.Tick(elapsed - movingSince) == StepResult.Completed)
			{
				CancelApproach();
			}
			Name = $"接近 Lv.{target.Level} 练级目标，距离 {num:F1} 米";
			return StepResult.Running;
		}
		CancelApproach();
		combatSupport?.Prepare();
		if (combatSupport != null && combatSupport.UsesExternalRotation)
		{
			combatSupport.RunRotation(target.ObjectId, capture: false);
			Name = $"练级 Lv.{_003Ccombat_003EP.PlayerLevel} → {_003CtargetLevel_003EP} · PR";
			return StepResult.Running;
		}
		if (elapsed < nextAction)
		{
			return StepResult.Running;
		}
		nextAction = elapsed + TimeSpan.FromMilliseconds(250L);
		uint actionId = BeastmasterActions.NextAttack(_003Ccombat_003EP.PlayerLevel, _003Ccombat_003EP.ComboAction);
		_003Ccombat_003EP.TryAction(actionId, target.ObjectId);
		Name = $"练级 Lv.{_003Ccombat_003EP.PlayerLevel} → {_003CtargetLevel_003EP} · 目标 Lv.{target.Level}";
		return StepResult.Running;
	}

	private void Patrol(TimeSpan elapsed)
	{
		if (site != null && (site.Level < Math.Max(1, _003Ccombat_003EP.PlayerLevel - 2) || site.Level > _003Ccombat_003EP.PlayerLevel))
		{
			travel?.Cancel();
			travel = null;
			site = null;
			arrivedAt = null;
		}
		if (arrivedAt.HasValue)
		{
			TimeSpan? timeSpan = arrivedAt;
			if (elapsed - timeSpan < TimeSpan.FromSeconds(3L))
			{
				Name = $"搜索{site.Region} Lv.{site.Level} 魔物";
				return;
			}
			planner.Visit(site, elapsed);
			site = null;
			arrivedAt = null;
		}
		if (travel == null)
		{
			if (_003Cnav_003EP.IsRunning || _003Cnav_003EP.IsPathfinding)
			{
				throw new InvalidOperationException("vnavmesh 正被其他任务使用");
			}
			site = planner.Next(_003Ccombat_003EP.PlayerLevel, _003Ccombat_003EP.Player, _003Ccombat_003EP.CanTravelTo, elapsed) ?? throw new InvalidOperationException($"已解锁区域没有可用的 Lv.{Math.Max(1, _003Ccombat_003EP.PlayerLevel - 2)}–{_003Ccombat_003EP.PlayerLevel} 练级路线");
			travel = new LevelingTravelStep(site, _003Cworld_003EP, _003Cnav_003EP, _003CpreferFlight_003EP);
			travelSince = elapsed;
		}
		TickTravel(elapsed);
	}

	private void TickTravel(TimeSpan elapsed)
	{
		try
		{
			if (travel.Tick(elapsed - travelSince) == StepResult.Completed)
			{
				travel.Cancel();
				travel = null;
				arrivedAt = elapsed;
				routeFailures = 0;
			}
			else
			{
				Name = travel.Name;
			}
		}
		catch (Exception ex) when (((ex is InvalidOperationException || ex is TimeoutException) ? 1 : 0) != 0)
		{
			bool allowsZoneTransition = travel.AllowsZoneTransition;
			travel.Cancel();
			travel = null;
			LastRouteError = ex.Message;
			if (allowsZoneTransition || _003Cworld_003EP.IsTransitioning || _003Cworld_003EP.TerritoryId != expectedTerritory)
			{
				throw;
			}
			planner.Visit(site, elapsed, failed: true);
			site = null;
			arrivedAt = null;
			if (++routeFailures >= 8)
			{
				throw new InvalidOperationException("连续 8 条练级路线不可达：" + LastRouteError, ex);
			}
			Name = "此处分布点不可达，改去另一处搜索";
		}
	}

	private void CancelApproach()
	{
		movement?.Cancel();
		movement = null;
		movementTarget = null;
	}

	public void Cancel()
	{
		try
		{
			CancelApproach();
			travel?.Cancel();
			landing?.Cancel();
		}
		finally
		{
			landing = null;
			try
			{
				_003Ccombat_003EP.CombatSupport?.Stop();
			}
			finally
			{
				_003Ccombat_003EP.StopAutoAttack();
			}
		}
	}
}
