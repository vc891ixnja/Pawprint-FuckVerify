using System.Collections.Generic;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public interface ICombatWorld
{
	ITaskCombatSupport? CombatSupport => null;

	WorldPoint? Player { get; }

	ulong ContentId { get; }

	uint TerritoryId { get; }

	byte PlayerLevel { get; }

	bool IsOnFoot { get; }

	bool InCombat { get; }

	uint ComboAction { get; }

	long EventSequence { get; }

	CombatTarget? ReadTarget(ulong id);

	IReadOnlyList<CombatEvent> EventsAfter(long sequence);

	bool TryAction(uint actionId, ulong targetId);

	void StopAutoAttack();

	void RequestCaptureConfirmation(int number);

	void CancelCaptureConfirmation();

	CaptureState ReadCaptureConfirmation(int number);
}
