using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed class LevelingRoutePlanner
{
	private readonly LevelingLocation[] sites = locations.ToArray();

	private readonly Dictionary<int, TimeSpan> visited = new Dictionary<int, TimeSpan>();

	private readonly Dictionary<int, TimeSpan> blockedUntil = new Dictionary<int, TimeSpan>();

	private readonly Dictionary<uint, int> regionVisits = new Dictionary<uint, int>();

	public LevelingRoutePlanner(IEnumerable<LevelingLocation> locations)
	{
	}

	public LevelingLocation? Next(int level, WorldPoint player, Func<uint, bool> accessible, TimeSpan now)
	{
		TimeSpan value;
		LevelingLocation[] array = sites.Where((LevelingLocation p) => p.Level >= Math.Max(1, level - 2) && p.Level <= level && (p.TerritoryId == player.TerritoryId || accessible(p.TerritoryId)) && (!blockedUntil.TryGetValue(p.Id, out value) || now >= value)).ToArray();
		if (array.Length == 0)
		{
			return null;
		}
		bool rotate = regionVisits.GetValueOrDefault(player.TerritoryId) >= 6 && array.Any((LevelingLocation p) => p.TerritoryId != player.TerritoryId);
		return (from p in array
			orderby (visited.TryGetValue(p.Id, out value) && now - value < TimeSpan.FromMinutes(3L)) ? 1 : 0, ((!rotate) ? (p.TerritoryId != player.TerritoryId) : (p.TerritoryId == player.TerritoryId)) ? 1 : 0, (p.TerritoryId != player.TerritoryId) ? regionVisits.GetValueOrDefault(p.TerritoryId) : 0, visited.GetValueOrDefault(p.Id, TimeSpan.MinValue), (p.TerritoryId != player.TerritoryId) ? 0f : Vector2.Distance(new Vector2(p.WorldX, p.WorldZ), new Vector2(player.X, player.Z)), level - p.Level, p.Id
			select p).First();
	}

	public void Visit(LevelingLocation site, TimeSpan now, bool failed = false)
	{
		visited[site.Id] = now;
		regionVisits[site.TerritoryId] = regionVisits.GetValueOrDefault(site.TerritoryId) + 1;
		if (failed)
		{
			blockedUntil[site.Id] = now + TimeSpan.FromMinutes(5L);
		}
	}
}
