namespace Beastmaster.Core.Hunting;

public sealed record MonsterNameSearch(int Total, MonsterNameRow[] Rows);
