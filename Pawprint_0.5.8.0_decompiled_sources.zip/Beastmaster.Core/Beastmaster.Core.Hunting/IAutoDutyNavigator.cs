namespace Beastmaster.Core.Hunting;

public interface IAutoDutyNavigator
{
	bool IsRunning { get; }

	bool IsStopped { get; }

	bool HasPath(uint territory);

	void Run(uint territory);

	void Resume();

	void Stop();
}
