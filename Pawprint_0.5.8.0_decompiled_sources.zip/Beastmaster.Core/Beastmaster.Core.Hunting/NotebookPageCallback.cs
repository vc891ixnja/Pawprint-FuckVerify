namespace Beastmaster.Core.Hunting;

public sealed record NotebookPageCallback(int Callback, uint Page);
