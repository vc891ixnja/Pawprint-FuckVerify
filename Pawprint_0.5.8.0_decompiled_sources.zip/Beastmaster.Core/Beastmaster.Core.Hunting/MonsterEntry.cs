using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Hunting;

public sealed record MonsterEntry(int Number, uint PetId, string Name, uint[] NameIds, MonsterLocationKind Kind, uint TerritoryId, uint MapId, string LocationName, uint DutyId, float? MapX, float? MapY, string? Note = null, string? SpeciesName = null, string[]? TargetNames = null, string? DownloadedName = null, uint[]? DownloadedNameIds = null)
{
	public IEnumerable<string> MatchNames => from n in new string[2]
		{
			Name,
			DownloadedName ?? string.Empty
		}.Concat(TargetNames ?? Array.Empty<string>())
		where !string.IsNullOrWhiteSpace(n)
		select n;

	public IEnumerable<uint> MatchNameIds => from id in NameIds.Concat(DownloadedNameIds ?? Array.Empty<uint>())
		where id != 0
		select id;

	public bool HasTargetIdentity
	{
		get
		{
			if (!MatchNames.Any())
			{
				return MatchNameIds.Any();
			}
			return true;
		}
	}

	public MapDestination Destination => new MapDestination(TerritoryId, MapId, LocationName, MapX ?? throw new InvalidOperationException("缺少坐标"), MapY ?? throw new InvalidOperationException("缺少坐标"));

	public bool UnsupportedDuty
	{
		get
		{
			int number = Number;
			if ((uint)(number - 49) <= 1u)
			{
				return true;
			}
			return false;
		}
	}

	public bool CanHunt
	{
		get
		{
			if (!CanLocate)
			{
				if (Kind == MonsterLocationKind.Duty && !UnsupportedDuty)
				{
					return HasTargetIdentity;
				}
				return false;
			}
			return true;
		}
	}

	public bool CanLocate
	{
		get
		{
			if (Kind == MonsterLocationKind.OpenWorld && TerritoryId != 0 && MapId != 0)
			{
				float? mapX = MapX;
				if (mapX.HasValue)
				{
					float valueOrDefault = mapX.GetValueOrDefault();
					if (valueOrDefault > 0f && valueOrDefault < 100f)
					{
						mapX = MapY;
						if (mapX.HasValue)
						{
							valueOrDefault = mapX.GetValueOrDefault();
							if (valueOrDefault > 0f && valueOrDefault < 100f)
							{
								return HasTargetIdentity;
							}
						}
					}
				}
			}
			return false;
		}
	}
}
