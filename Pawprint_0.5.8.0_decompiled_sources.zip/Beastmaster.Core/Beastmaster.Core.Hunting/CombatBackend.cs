namespace Beastmaster.Core.Hunting;

public enum CombatBackend
{
	BuiltIn,
	PromeRotation,
	None
}
