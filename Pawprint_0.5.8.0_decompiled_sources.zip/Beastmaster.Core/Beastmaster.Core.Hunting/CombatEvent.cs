namespace Beastmaster.Core.Hunting;

public sealed record CombatEvent(long Sequence, ulong TargetId, uint ActionId, uint LogMessageId, uint Damage = 0u);
