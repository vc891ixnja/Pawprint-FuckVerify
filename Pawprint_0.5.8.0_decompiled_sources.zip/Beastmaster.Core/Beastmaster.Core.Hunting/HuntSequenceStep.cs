using System;
using System.Collections.Generic;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class HuntSequenceStep : IWorkflowStep
{
	private readonly MonsterEntry monster;

	private readonly IHuntingWorld world;

	private readonly ILevelingWorld combat;

	private readonly INavigationProvider nav;

	private readonly bool capture;

	private readonly bool autoLevel;

	private readonly bool preferFlight;

	private IWorkflowStep current;

	private TimeSpan enteredAt;

	private int levelingPasses;

	private int captureRetries;

	private readonly ulong character;

	private TimeSpan? cutsceneStarted;

	private TimeSpan nextCutsceneCheck;

	private TimeSpan cutsceneElapsed;

	private readonly HashSet<ulong> failedTargets = new HashSet<ulong>();

	public string Name
	{
		get
		{
			if (!WaitingForCutscene)
			{
				if (captureRetries <= 0 || !(current is LocateMonsterStep))
				{
					return current.Name;
				}
				return "未捕获，地面寻找下一只 · " + current.Name;
			}
			return "等待副本过场结束（每秒检查）";
		}
	}

	public TimeSpan Timeout => TimeSpan.FromMinutes(75L);

	public bool Captured { get; private set; }

	public bool Skipped { get; private set; }

	public int MonsterNumber => monster.Number;

	public object Diagnostics => new
	{
		Monster = monster.Number,
		Stage = current.GetType().Name,
		Name = Name,
		Skipped = Skipped,
		levelingPasses = levelingPasses,
		captureRetries = captureRetries,
		failedTargets = failedTargets,
		WaitingForCutscene = WaitingForCutscene,
		cutsceneStarted = cutsceneStarted,
		nextCutsceneCheck = nextCutsceneCheck,
		cutsceneElapsed = cutsceneElapsed,
		Capture = (current as CaptureMonsterStep)?.Diagnostics,
		Leveling = (current as LevelingStep)?.Diagnostics
	};

	public bool AllowsZoneTransition
	{
		get
		{
			IWorkflowStep workflowStep = current;
			if (workflowStep is LocateMonsterStep locateMonsterStep)
			{
				if (locateMonsterStep.AllowsZoneTransition)
				{
					goto IL_0041;
				}
			}
			else if (workflowStep is DutyRouteStep dutyRouteStep)
			{
				if (dutyRouteStep.AllowsTransition)
				{
					goto IL_0041;
				}
			}
			else if (workflowStep is LevelingStep { AllowsZoneTransition: not false })
			{
				goto IL_0041;
			}
			return false;
			IL_0041:
			return true;
		}
	}

	public bool UsesAutoDuty => current is DutyRouteStep;

	public bool CanWaitForCutscene => monster.Kind == MonsterLocationKind.Duty;

	public bool WaitingForCutscene => cutsceneStarted.HasValue;

	public bool NeedsCombat
	{
		get
		{
			if (!capture)
			{
				return autoLevel;
			}
			return true;
		}
	}

	public bool IsCapture => capture;

	public bool AllowsNotebook => current is CaptureMonsterStep;

	public bool AllowsCombat
	{
		get
		{
			IWorkflowStep workflowStep = current;
			if ((!(workflowStep is CaptureMonsterStep) && !(workflowStep is LevelingStep) && !(workflowStep is DutyRouteStep) && !(workflowStep is ClearCombatStep)) || 1 == 0)
			{
				if (capture)
				{
					return current is LocateMonsterStep;
				}
				return false;
			}
			return true;
		}
	}

	public HuntSequenceStep(MonsterEntry monster, IHuntingWorld world, ILevelingWorld combat, INavigationProvider nav, IAutoDutyNavigator duty, bool capture, bool autoLevel, bool preferFlight)
	{
		this.monster = monster;
		this.world = world;
		this.combat = combat;
		this.nav = nav;
		this.capture = capture;
		this.autoLevel = autoLevel;
		this.preferFlight = preferFlight;
		character = world.ContentId;
		IWorkflowStep workflowStep2;
		if (monster.Kind != MonsterLocationKind.Duty)
		{
			IWorkflowStep workflowStep = CreateLocate();
			workflowStep2 = workflowStep;
		}
		else
		{
			IWorkflowStep workflowStep = new DutyRouteStep(monster, world, nav, duty);
			workflowStep2 = workflowStep;
		}
		current = workflowStep2;
	}

	private LocateMonsterStep CreateLocate()
	{
		return new LocateMonsterStep(monster, world, nav, preferFlight && captureRetries == 0, failedTargets, capture ? combat : null);
	}

	public bool AcceptsTerritory(uint territory)
	{
		IWorkflowStep workflowStep = current;
		if (!(workflowStep is LocateMonsterStep locateMonsterStep))
		{
			if (!(workflowStep is DutyRouteStep dutyRouteStep))
			{
				if (workflowStep is LevelingStep levelingStep)
				{
					return levelingStep.AcceptsTerritory(territory);
				}
				return false;
			}
			return dutyRouteStep.AcceptsTerritory(territory);
		}
		return locateMonsterStep.AcceptsTerritory(territory);
	}

	public bool AcceptsCutsceneTerritory(uint territory)
	{
		if (world.TerritoryId != monster.TerritoryId || territory != monster.TerritoryId)
		{
			return AcceptsTerritory(territory);
		}
		return true;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (CanWaitForCutscene)
		{
			if (WaitingForCutscene || world.IsInCutscene)
			{
				if (world.ContentId != 0L && world.ContentId != character)
				{
					throw new InvalidOperationException("角色变化，副本过场等待已停止");
				}
				if (!AcceptsCutsceneTerritory(world.TerritoryId))
				{
					throw new InvalidOperationException("过场期间进入了非预期区域");
				}
			}
			if (WaitingForCutscene && elapsed < nextCutsceneCheck)
			{
				return StepResult.Running;
			}
			if (world.IsInCutscene)
			{
				if (!WaitingForCutscene)
				{
					cutsceneStarted = elapsed;
					if (current is DutyRouteStep dutyRouteStep)
					{
						dutyRouteStep.SuspendLocalMovement();
					}
					else
					{
						current.Cancel();
					}
				}
				nextCutsceneCheck = elapsed + TimeSpan.FromSeconds(1L);
				return StepResult.Running;
			}
			TimeSpan? timeSpan = cutsceneStarted;
			if (timeSpan.HasValue)
			{
				TimeSpan valueOrDefault = timeSpan.GetValueOrDefault();
				cutsceneElapsed += elapsed - valueOrDefault;
				cutsceneStarted = null;
			}
		}
		elapsed -= cutsceneElapsed;
		if (elapsed - enteredAt >= current.Timeout)
		{
			throw new TimeoutException("步骤超时：" + current.Name);
		}
		StepResult stepResult;
		try
		{
			stepResult = current.Tick(elapsed - enteredAt);
		}
		catch (InvalidOperationException) when (autoLevel && current is LocateMonsterStep { RequiredLevel: var requiredLevel } && requiredLevel.HasValue)
		{
			int value = ((LocateMonsterStep)current).RequiredLevel.Value;
			if (monster.Kind == MonsterLocationKind.Duty || ++levelingPasses > 3)
			{
				throw;
			}
			Replace(new LevelingStep(value, combat, world, nav, preferFlight), elapsed);
			return StepResult.Running;
		}
		if (stepResult != StepResult.Completed)
		{
			return stepResult;
		}
		IWorkflowStep workflowStep = current;
		if (workflowStep is LocateMonsterStep locateMonsterStep2)
		{
			if (locateMonsterStep2.SearchExhausted)
			{
				goto IL_0273;
			}
		}
		else if (workflowStep is DutyRouteStep { SearchExhausted: not false })
		{
			goto IL_0273;
		}
		bool flag = false;
		goto IL_027b;
		IL_0273:
		flag = true;
		goto IL_027b;
		IL_027b:
		if (flag)
		{
			Skipped = true;
			return StepResult.Completed;
		}
		if (current is LevelingStep)
		{
			Replace(CreateLocate(), elapsed);
			return StepResult.Running;
		}
		if (current is CaptureMonsterStep captureMonsterStep)
		{
			if (captureMonsterStep.NeedsRetry)
			{
				failedTargets.Add(captureMonsterStep.TargetObjectId);
				captureRetries++;
				Replace(CreateLocate(), elapsed);
				return StepResult.Running;
			}
			Captured = captureMonsterStep.Captured;
			if (Captured && combat.InCombat)
			{
				Replace(new ClearCombatStep(combat, nav), elapsed);
				return StepResult.Running;
			}
			return StepResult.Completed;
		}
		if (current is ClearCombatStep)
		{
			return StepResult.Completed;
		}
		if (!capture)
		{
			return StepResult.Completed;
		}
		workflowStep = current;
		MonsterObservation monsterObservation = ((workflowStep is LocateMonsterStep locateMonsterStep3) ? locateMonsterStep3.FoundMonster : ((!(workflowStep is DutyRouteStep dutyRouteStep3)) ? null : dutyRouteStep3.FoundMonster));
		MonsterObservation found = monsterObservation;
		Replace(new CaptureMonsterStep(monster, () => found, combat, nav), elapsed);
		return StepResult.Running;
	}

	private void Replace(IWorkflowStep next, TimeSpan elapsed)
	{
		current.Cancel();
		current = next;
		enteredAt = elapsed;
	}

	public void Cancel()
	{
		current.Cancel();
	}
}
