using System.Numerics;

namespace Beastmaster.Core.Hunting;

public sealed record AetheryteDestination(uint Id, uint TerritoryId, string Name, uint GilCost, Vector2 Position);
