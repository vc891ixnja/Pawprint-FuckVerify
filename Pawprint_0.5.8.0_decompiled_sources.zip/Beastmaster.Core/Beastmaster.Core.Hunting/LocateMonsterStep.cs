using System;
using System.Collections.Generic;
using System.Numerics;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed class LocateMonsterStep(MonsterEntry monster, IHuntingWorld world, INavigationProvider nav, bool preferFlight = true, IReadOnlySet<ulong>? excludedObjectIds = null, ICombatWorld? combat = null) : IWorkflowStep
{
	private static readonly Vector2[] SearchOffsets = new Vector2[6]
	{
		Vector2.Zero,
		new Vector2(30f, 0f),
		new Vector2(0f, 30f),
		new Vector2(-30f, 0f),
		new Vector2(0f, -30f),
		Vector2.Zero
	};

	private NavigationStep? movement;

	private TimeSpan movementStarted;

	private TimeSpan phaseStarted;

	private TimeSpan? searchStarted;

	private ulong character;

	private uint startingTerritory;

	private bool teleportRequested;

	private int searchPoint;

	private readonly HashSet<Vector2> unavailablePoints = new HashSet<Vector2>();

	private MonsterObservation? approaching;

	private TimeSpan approachStarted;

	private TimeSpan? selectionStarted;

	private TimeSpan lastSelection;

	private TimeSpan? mountStarted;

	private TimeSpan? lastMountAttempt;

	private TimeSpan? mountedObserved;

	private TimeSpan? takeoffStarted;

	private TimeSpan? lastTakeoff;

	private int mountAttempts;

	private LandAndDismountStep? landing;

	private TimeSpan landingStarted;

	private bool groundFallback;

	private bool combatMovement;

	public const float ApproachDistance = 3f;

	public const float GroundSearchDistance = 60f;

	public LocatePhase Phase { get; private set; }

	public MonsterObservation? FoundMonster { get; private set; }

	public bool SearchExhausted => Phase == LocatePhase.Skipped;

	public int? RequiredLevel { get; private set; }

	public string Detail { get; private set; } = "检查角色与目的地";

	public string Name => $"#{monster.Number:00} {monster.Name} · {Detail}";

	public TimeSpan Timeout => TimeSpan.FromMinutes(12L);

	public bool AllowsZoneTransition
	{
		get
		{
			if (teleportRequested)
			{
				return Phase == LocatePhase.AwaitArrival;
			}
			return false;
		}
	}

	private string MovementMode
	{
		get
		{
			NavigationStep? navigationStep = movement;
			if (navigationStep == null || !navigationStep.IsFlyingPath)
			{
				return "地面";
			}
			return "飞行";
		}
	}

	public bool AcceptsTerritory(uint territory)
	{
		if (AllowsZoneTransition)
		{
			if (territory != startingTerritory && territory != monster.TerritoryId)
			{
				return territory == 0;
			}
			return true;
		}
		return false;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (SearchExhausted)
		{
			return StepResult.Completed;
		}
		if (!monster.CanLocate && monster.Kind != MonsterLocationKind.Duty)
		{
			throw new InvalidOperationException("该魔物缺少可执行的位置");
		}
		if (character == 0L)
		{
			character = world.ContentId;
			startingTerritory = world.TerritoryId;
		}
		if (character == 0L)
		{
			throw new InvalidOperationException("角色尚未加载");
		}
		if (world.ContentId == 0L && AllowsZoneTransition && elapsed - phaseStarted <= TimeSpan.FromSeconds(60L))
		{
			return StepResult.Running;
		}
		if (world.ContentId != character)
		{
			throw new InvalidOperationException("角色发生变化或尚未加载");
		}
		if (Phase == LocatePhase.Prepare)
		{
			if (world.IsTransitioning || world.Player == null || world.IsCasting)
			{
				return StepResult.Running;
			}
			if (world.TerritoryId == monster.TerritoryId)
			{
				SetPhase(LocatePhase.AwaitMesh, elapsed, "等待导航网格");
			}
			else
			{
				AetheryteDestination aetheryteDestination = world.SelectAetheryte(monster.Destination) ?? throw new InvalidOperationException("目标区域没有已解锁的大水晶");
				if (!world.Teleport(aetheryteDestination))
				{
					throw new InvalidOperationException("传送请求被拒绝，请检查传送条件与金币");
				}
				teleportRequested = true;
				SetPhase(LocatePhase.AwaitArrival, elapsed, $"传送至 {aetheryteDestination.Name}（{aetheryteDestination.GilCost} 金币）");
			}
			return StepResult.Running;
		}
		if (Phase == LocatePhase.AwaitArrival)
		{
			if (elapsed - phaseStarted > TimeSpan.FromSeconds(60L))
			{
				throw new TimeoutException("传送未在 60 秒内到达");
			}
			if (!AcceptsTerritory(world.TerritoryId))
			{
				throw new InvalidOperationException("抵达了非预期区域");
			}
			if (world.IsTransitioning || world.Player == null || world.IsCasting || world.TerritoryId != monster.TerritoryId)
			{
				return StepResult.Running;
			}
			SetPhase(LocatePhase.AwaitMesh, elapsed, "等待目标区域导航网格");
		}
		if (world.TerritoryId != monster.TerritoryId || world.IsTransitioning || world.Player == null)
		{
			throw new InvalidOperationException("搜索期间区域发生变化");
		}
		if (Phase == LocatePhase.AwaitMesh)
		{
			if (elapsed - phaseStarted > TimeSpan.FromSeconds(120L))
			{
				throw new TimeoutException("导航网格加载超时");
			}
			if (!nav.IsReady)
			{
				MonsterObservation monsterObservation = world.FindMonster(monster, excludedObjectIds);
				if (monsterObservation == null || Vector3.Distance(world.Player.Position, monsterObservation.Location.Position) - monsterObservation.HitboxRadius > 3f)
				{
					return StepResult.Running;
				}
			}
			if (teleportRequested && elapsed - phaseStarted < TimeSpan.FromSeconds(2L))
			{
				Detail = "等待切图后角色与飞行状态稳定";
				return StepResult.Running;
			}
			SetPhase(LocatePhase.Searching, elapsed, "前往分布点并搜索魔物");
		}
		if (landing != null)
		{
			if (landing.Tick(elapsed - landingStarted) != StepResult.Completed)
			{
				SetPhase(LocatePhase.Landing, elapsed, landing.Name);
				return StepResult.Running;
			}
			landing = null;
			groundFallback = true;
		}
		LocatePhase phase = Phase;
		MonsterObservation monsterObservation2;
		float num;
		bool flag;
		int num3;
		TimeSpan value;
		TimeSpan? timeSpan;
		if ((uint)(phase - 3) <= 3u)
		{
			monsterObservation2 = world.FindMonster(monster, excludedObjectIds, approaching?.ObjectId);
			if (monsterObservation2 != null)
			{
				if (world.PlayerLevel == 0 || monsterObservation2.Level == 0)
				{
					throw new InvalidOperationException("无法读取角色或魔物等级，暂不能捕猎");
				}
				if (world.PlayerLevel < monsterObservation2.Level)
				{
					RequiredLevel = monsterObservation2.Level;
					throw new InvalidOperationException($"捕获条件不满足：角色 Lv.{world.PlayerLevel}，{monster.Name} Lv.{monsterObservation2.Level}；需要升到 Lv.{RequiredLevel}。");
				}
				num = Math.Max(0f, Vector3.Distance(world.Player.Position, monsterObservation2.Location.Position) - monsterObservation2.HitboxRadius);
				Vector3 vector = world.Player.Position - monsterObservation2.Location.Position;
				float num2 = new Vector2(vector.X, vector.Z).Length();
				flag = approaching?.ObjectId != monsterObservation2.ObjectId;
				if (flag)
				{
					CancelMovement();
					selectionStarted = null;
					approachStarted = elapsed;
				}
				if ((world.IsFlying || world.IsMounted || world.IsMountTransition) && num2 <= 6f + monsterObservation2.HitboxRadius)
				{
					StopCombatMovement();
					CancelMovement();
					approaching = monsterObservation2;
					BeginLanding(elapsed);
					return StepResult.Running;
				}
				if (!world.IsMounted && !world.IsFlying && !world.IsMountTransition)
				{
					CombatTarget combatTarget = combat?.ReadTarget(monsterObservation2.ObjectId);
					if ((object)combatTarget != null)
					{
						num3 = ((combat.CombatSupport?.WantsMovement(combatTarget) ?? false) ? 1 : 0);
						goto IL_068c;
					}
				}
				num3 = 0;
				goto IL_068c;
			}
			StopCombatMovement();
			if (approaching != null)
			{
				CancelMovement();
				landing?.Cancel();
				landing = null;
				approaching = null;
				selectionStarted = null;
			}
			if (!nav.IsReady)
			{
				SetPhase(LocatePhase.AwaitMesh, elapsed, "等待导航网格");
				return StepResult.Running;
			}
			if (Phase != LocatePhase.Searching)
			{
				SetPhase(LocatePhase.Searching, elapsed, "目标消失，重新搜索分布点");
			}
			while (searchPoint < SearchOffsets.Length && unavailablePoints.Contains(SearchOffsets[searchPoint]))
			{
				searchPoint++;
			}
			if (searchPoint >= SearchOffsets.Length && !searchStarted.HasValue)
			{
				return Skip(elapsed, "所有搜索点均无可达地面，本轮跳过");
			}
			if (movement == null && searchPoint < SearchOffsets.Length)
			{
				WorldPoint point;
				try
				{
					point = world.ResolveGround(monster.Destination, SearchOffsets[searchPoint]);
				}
				catch (GroundPointUnavailableException)
				{
					unavailablePoints.Add(SearchOffsets[searchPoint]);
					searchPoint++;
					Detail = "当前搜索点无可达地面，跳过并尝试下一点";
					return StepResult.Running;
				}
				if (!CreateMovement(point, elapsed))
				{
					return StepResult.Running;
				}
				Detail = ((searchPoint == 0) ? (MovementMode + "前往分布点") : $"{MovementMode}搜索分布点附近 {searchPoint}/{SearchOffsets.Length - 1}");
			}
			if (movement != null && TickNavigation(elapsed) == StepResult.Completed)
			{
				movement.Cancel();
				movement = null;
				searchPoint++;
				TimeSpan valueOrDefault = searchStarted.GetValueOrDefault();
				if (!searchStarted.HasValue)
				{
					valueOrDefault = elapsed;
					searchStarted = valueOrDefault;
				}
			}
			if (movement != null && elapsed - movementStarted > movement.Timeout)
			{
				throw new TimeoutException("搜索路径移动超时");
			}
			if (searchPoint >= SearchOffsets.Length)
			{
				Detail = "等待目标出现";
			}
			if (searchStarted.HasValue)
			{
				value = elapsed;
				timeSpan = searchStarted;
				if (value - timeSpan > TimeSpan.FromMinutes(3L))
				{
					return Skip(elapsed, "分布点附近未找到目标，本轮跳过");
				}
			}
		}
		return StepResult.Running;
		IL_068c:
		bool flag2 = (byte)num3 != 0;
		if (flag2)
		{
			CancelMovement();
			combatMovement = true;
			combat.CombatSupport.UpdateMovement(monsterObservation2.ObjectId);
		}
		else
		{
			StopCombatMovement();
		}
		if (num > 3f)
		{
			landing?.Cancel();
			landing = null;
			if (elapsed - approachStarted > TimeSpan.FromSeconds(90L))
			{
				throw new TimeoutException("接近魔物超时，目标可能持续移动或路径不可达");
			}
			selectionStarted = null;
			if (flag2)
			{
				approaching = monsterObservation2;
				SetPhase(LocatePhase.Approaching, elapsed, $"由 BossMod 接近 Lv.{monsterObservation2.Level} {monster.Name}，距离 {num:F1} 米");
				return StepResult.Running;
			}
			if (approaching != null && Vector3.Distance(approaching.Location.Position, monsterObservation2.Location.Position) > 2f)
			{
				CancelMovement();
			}
			if (movement == null)
			{
				approaching = monsterObservation2;
				if (!CreateMovement(monsterObservation2.Location, elapsed))
				{
					return StepResult.Running;
				}
			}
			SetPhase(LocatePhase.Approaching, elapsed, $"{MovementMode}接近 Lv.{monsterObservation2.Level} {monster.Name}，距离 {num:F1} 米");
			TickMovement(elapsed);
			return StepResult.Running;
		}
		CancelMovement();
		approaching = monsterObservation2;
		if (selectionStarted.HasValue && !flag && world.IsMonsterSelected(monsterObservation2))
		{
			SetPhase(LocatePhase.Found, elapsed, $"已接近并确认选中 Lv.{monsterObservation2.Level} 目标（{num:F1} 米）；等待捕获操作");
			FoundMonster = monsterObservation2;
			return StepResult.Completed;
		}
		if (!selectionStarted.HasValue || elapsed - lastSelection >= TimeSpan.FromSeconds(1L))
		{
			world.SelectMonster(monsterObservation2);
			TimeSpan valueOrDefault = selectionStarted.GetValueOrDefault();
			if (!selectionStarted.HasValue)
			{
				valueOrDefault = elapsed;
				selectionStarted = valueOrDefault;
			}
			lastSelection = elapsed;
		}
		value = elapsed;
		timeSpan = selectionStarted;
		if (value - timeSpan > TimeSpan.FromSeconds(5L))
		{
			throw new InvalidOperationException("已接近魔物，但游戏未保持选中目标；请检查目标是否消失或有其他插件切换目标。");
		}
		SetPhase(LocatePhase.ConfirmTarget, elapsed, $"正在确认选中 Lv.{monsterObservation2.Level} {monster.Name}（{num:F1} 米）");
		return StepResult.Running;
	}

	private StepResult Skip(TimeSpan elapsed, string reason)
	{
		CancelMovement();
		SetPhase(LocatePhase.Skipped, elapsed, reason);
		return StepResult.Completed;
	}

	private void SetPhase(LocatePhase phase, TimeSpan elapsed, string detail)
	{
		Phase = phase;
		phaseStarted = elapsed;
		Detail = detail;
	}

	private bool CreateMovement(WorldPoint point, TimeSpan elapsed)
	{
		if (!nav.IsReady)
		{
			Detail = "已找到目标，等待导航网格以接近";
			return false;
		}
		float num = Vector3.Distance(world.Player.Position, point.Position);
		if (!preferFlight || num <= 60f)
		{
			groundFallback = true;
		}
		if (groundFallback && (world.IsFlying || world.IsMounted || world.IsMountTransition))
		{
			CancelMovement();
			BeginLanding(elapsed);
			return false;
		}
		if (preferFlight && !groundFallback && world.CanFlyInTerritory && !world.IsMounted && num >= 30f)
		{
			TimeSpan valueOrDefault = mountStarted.GetValueOrDefault();
			if (!mountStarted.HasValue)
			{
				valueOrDefault = elapsed;
				mountStarted = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = mountStarted;
			if (value - timeSpan < TimeSpan.FromSeconds(15L))
			{
				if (!world.IsMountTransition && !world.IsCasting && mountAttempts < 5)
				{
					if (lastMountAttempt.HasValue)
					{
						value = elapsed;
						timeSpan = lastMountAttempt;
						if (!(value - timeSpan >= TimeSpan.FromSeconds(2L)))
						{
							goto IL_0204;
						}
					}
					mountAttempts++;
					lastMountAttempt = elapsed;
					world.TryMount();
				}
				goto IL_0204;
			}
			groundFallback = true;
		}
		if (world.IsMountTransition || world.IsCasting)
		{
			Detail = "等待坐骑或读条完成";
			return false;
		}
		if (preferFlight && !groundFallback && world.CanFlyInTerritory && world.IsMounted && !world.CanTakeOff)
		{
			TimeSpan valueOrDefault = mountedObserved.GetValueOrDefault();
			if (!mountedObserved.HasValue)
			{
				valueOrDefault = elapsed;
				mountedObserved = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = mountedObserved;
			if (value - timeSpan < TimeSpan.FromSeconds(3L))
			{
				Detail = "已上坐骑，等待起飞条件就绪";
				return false;
			}
		}
		if (!world.IsFlying && preferFlight && !groundFallback && world.CanFlyInTerritory && world.IsMounted && world.CanTakeOff)
		{
			TimeSpan valueOrDefault = takeoffStarted.GetValueOrDefault();
			if (!takeoffStarted.HasValue)
			{
				valueOrDefault = elapsed;
				takeoffStarted = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = takeoffStarted;
			if (value - timeSpan < TimeSpan.FromSeconds(8L))
			{
				if (lastTakeoff.HasValue)
				{
					value = elapsed;
					timeSpan = lastTakeoff;
					if (!(value - timeSpan >= TimeSpan.FromMilliseconds(500L)))
					{
						goto IL_0498;
					}
				}
				lastTakeoff = elapsed;
				world.TryTakeOff();
				goto IL_0498;
			}
			groundFallback = true;
		}
		bool isFlying = world.IsFlying;
		movement = new NavigationStep(nav, point, () => world.Player, isFlying);
		movementStarted = elapsed;
		return true;
		IL_0498:
		Detail = "已上坐骑，正在起飞并等待飞行状态";
		return false;
		IL_0204:
		Detail = $"等待召唤坐骑生效（尝试 {mountAttempts}/5）";
		return false;
	}

	private StepResult TickNavigation(TimeSpan elapsed)
	{
		NavigationStep navigationStep = movement;
		if (navigationStep != null && navigationStep.IsFlyingPath)
		{
			WorldPoint player = world.Player;
			if ((object)player != null)
			{
				Vector3 vector = player.Position - navigationStep.Destination.Position;
				if (new Vector2(vector.X, vector.Z).Length() <= 6f)
				{
					CancelMovement();
					BeginLanding(elapsed);
					return StepResult.Running;
				}
			}
		}
		try
		{
			return movement.Tick(elapsed - movementStarted);
		}
		catch (Exception) when (((Func<bool>)delegate
		{
			// Could not convert BlockContainer to single expression
			NavigationStep? navigationStep2 = movement;
			return navigationStep2 != null && navigationStep2.IsFlyingPath && !world.IsFlying && !groundFallback;
		}).Invoke())
		{
			CancelMovement();
			groundFallback = true;
			Detail = "飞行路径不可用，改用地面寻路";
			return StepResult.Running;
		}
	}

	private void BeginLanding(TimeSpan elapsed)
	{
		landing = new LandAndDismountStep(world, nav);
		landingStarted = elapsed;
		landing.Tick(TimeSpan.Zero);
		SetPhase(LocatePhase.Landing, elapsed, landing.Name);
	}

	private void TickMovement(TimeSpan elapsed)
	{
		if (movement != null)
		{
			if (elapsed - movementStarted > movement.Timeout)
			{
				throw new TimeoutException("接近目标的路径移动超时");
			}
			if (TickNavigation(elapsed) == StepResult.Completed)
			{
				CancelMovement();
			}
		}
	}

	private void CancelMovement()
	{
		movement?.Cancel();
		movement = null;
	}

	private void StopCombatMovement()
	{
		if (combatMovement)
		{
			combatMovement = false;
			combat?.CombatSupport?.StopMovement();
		}
	}

	public void Cancel()
	{
		try
		{
			CancelMovement();
			selectionStarted = null;
			landing?.Cancel();
			landing = null;
		}
		finally
		{
			StopCombatMovement();
		}
		if (Phase == LocatePhase.Searching)
		{
			Detail = "已暂停搜索，恢复后重新寻路";
		}
	}
}
