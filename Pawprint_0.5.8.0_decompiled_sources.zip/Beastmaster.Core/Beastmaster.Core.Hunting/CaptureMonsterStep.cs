using System;
using System.Numerics;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class CaptureMonsterStep(MonsterEntry entry, Func<MonsterObservation?> getLocated, ICombatWorld world, INavigationProvider? nav = null) : IWorkflowStep
{
	private NavigationStep? approach;

	private TimeSpan approachStarted;

	private ulong character;

	private ulong targetId;

	private uint territory;

	private long cursor;

	private bool initialized;

	private bool inspected;

	private bool pending;

	private bool confirming;

	private bool captureSubmitted;

	private bool successObserved;

	private int capturesApplied;

	private uint pendingAction;

	private TimeSpan submittedAt;

	private TimeSpan nextAttempt;

	private TimeSpan? outcomeObservedAt;

	private TimeSpan confirmationStartedAt;

	public static readonly TimeSpan ConfirmationDelay = TimeSpan.FromSeconds(2L);

	public bool Captured { get; private set; }

	public bool NeedsRetry { get; private set; }

	public ulong TargetObjectId => targetId;

	public string Name { get; private set; } = "识破并捕获魔物";

	public TimeSpan Timeout => TimeSpan.FromMinutes(5L);

	public object Diagnostics => new
	{
		targetId, territory, cursor, initialized, inspected, pending, pendingAction, confirming, outcomeObservedAt, confirmationStartedAt,
		captureSubmitted, capturesApplied, successObserved, Captured, NeedsRetry, Name
	};

	public StepResult Tick(TimeSpan elapsed)
	{
		if (!initialized)
		{
			MonsterObservation monsterObservation = getLocated() ?? throw new InvalidOperationException("没有经过接近与选中确认的目标");
			targetId = monsterObservation.ObjectId;
			character = world.ContentId;
			territory = world.TerritoryId;
			cursor = world.EventSequence;
			initialized = true;
		}
		if (character == 0L || character != world.ContentId || territory != world.TerritoryId)
		{
			throw new InvalidOperationException("角色或区域变化，捕获已停止");
		}
		if (!world.IsOnFoot)
		{
			throw new InvalidOperationException("尚未落地并下坐骑，未执行捕获");
		}
		ITaskCombatSupport combatSupport = world.CombatSupport;
		bool flag = combatSupport?.UsesExternalRotation ?? false;
		if (!flag || !inspected)
		{
			world.StopAutoAttack();
		}
		foreach (CombatEvent item in world.EventsAfter(cursor))
		{
			cursor = Math.Max(cursor, item.Sequence);
			if (item.TargetId != targetId)
			{
				continue;
			}
			if (flag && inspected && item.ActionId == 44880)
			{
				captureSubmitted = true;
				capturesApplied++;
			}
			if (item.LogMessageId == 11400 && captureSubmitted)
			{
				successObserved = true;
			}
			if (item.LogMessageId == 11425)
			{
				throw new InvalidOperationException("游戏提示该魔物已经收录，请刷新图鉴");
			}
			if (pending && pendingAction == 44882 && CaptureMessages.IsInspect(item.LogMessageId))
			{
				if (!CaptureMessages.CanCapture(item.LogMessageId))
				{
					throw new InvalidOperationException($"识破提示无法捕获（结果 ID {item.LogMessageId}）");
				}
				inspected = true;
				pending = false;
				pendingAction = 0u;
				nextAttempt = elapsed + TimeSpan.FromMilliseconds(500L);
			}
			if (pending && item.ActionId != 0 && item.ActionId == pendingAction && pendingAction != 44882)
			{
				pending = false;
				nextAttempt = elapsed + TimeSpan.FromMilliseconds(650L);
				if (item.ActionId == 44880)
				{
					capturesApplied++;
				}
				pendingAction = 0u;
			}
		}
		CombatTarget combatTarget = world.ReadTarget(targetId);
		if (outcomeObservedAt.HasValue || successObserved || combatTarget == null || combatTarget.IsDead || combatTarget.Hp == 0)
		{
			approach?.Cancel();
			approach = null;
			combatSupport?.Stop();
			world.StopAutoAttack();
			TimeSpan valueOrDefault = outcomeObservedAt.GetValueOrDefault();
			if (!outcomeObservedAt.HasValue)
			{
				valueOrDefault = elapsed;
				outcomeObservedAt = valueOrDefault;
			}
			TimeSpan timeSpan = ConfirmationDelay - (elapsed - outcomeObservedAt.Value);
			if (timeSpan > TimeSpan.Zero)
			{
				Name = $"等待捕获结果更新，{Math.Ceiling(timeSpan.TotalSeconds):0} 秒后核对图鉴";
				return StepResult.Running;
			}
			if (!confirming)
			{
				confirming = true;
				confirmationStartedAt = elapsed;
				world.RequestCaptureConfirmation(entry.Number);
			}
			switch (world.ReadCaptureConfirmation(entry.Number))
			{
			case CaptureState.Captured:
				Captured = true;
				Name = $"#{entry.Number:00} {entry.Name}：图鉴确认捕获成功";
				return StepResult.Completed;
			case CaptureState.Missing:
				if (!inspected)
				{
					throw new InvalidOperationException("目标消失前未确认可捕获，图鉴仍未收录");
				}
				NeedsRetry = true;
				Name = "本次未捕获，继续寻找下一只";
				return StepResult.Completed;
			default:
				if (elapsed - confirmationStartedAt > TimeSpan.FromSeconds(30L))
				{
					throw new InvalidOperationException("图鉴核对未完成，无法读取本次收录状态，请刷新图鉴后继续");
				}
				Name = "正在核对捕获结果";
				return StepResult.Running;
			}
		}
		if (!combatTarget.IsTargetable || combatTarget.NameId != getLocated()?.NameId)
		{
			throw new InvalidOperationException("目标身份或可选中状态发生变化");
		}
		if (combatTarget.Level == 0 || combatTarget.MaxHp == 0)
		{
			throw new InvalidOperationException("魔物等级或血量尚未加载");
		}
		if (!combatTarget.IsAttackable)
		{
			throw new InvalidOperationException("游戏判定目标不可攻击，捕获已停止");
		}
		if (world.PlayerLevel < combatTarget.Level)
		{
			throw new InvalidOperationException("角色等级不足，捕获已停止");
		}
		combatSupport?.Prepare();
		bool flag2 = combatSupport?.WantsMovement(combatTarget) ?? false;
		if (flag2)
		{
			approach?.Cancel();
			approach = null;
			combatSupport.UpdateMovement(targetId);
		}
		else
		{
			combatSupport?.StopMovement();
		}
		if (pending)
		{
			if (elapsed - submittedAt > TimeSpan.FromSeconds(8L))
			{
				throw new TimeoutException($"技能 {pendingAction} 的游戏结果未确认，请导出捕获诊断");
			}
			Name = ((pendingAction == 44882) ? "等待识破结果 ID" : $"等待技能 {pendingAction} 生效");
			return StepResult.Running;
		}
		if (Vector3.Distance((world.Player ?? throw new InvalidOperationException("角色位置尚未加载")).Position, combatTarget.Location.Position) - combatTarget.HitboxRadius > 3f)
		{
			combatSupport?.StopRotation();
			if (flag2)
			{
				Name = "躲避并接近捕获目标";
				return StepResult.Running;
			}
			if (nav == null)
			{
				throw new InvalidOperationException("目标已离开技能范围");
			}
			if (approach != null && Vector3.Distance(approach.Destination.Position, combatTarget.Location.Position) > 1f)
			{
				approach.Cancel();
				approach = null;
			}
			if (approach == null)
			{
				approach = new NavigationStep(nav, combatTarget.Location, () => world.Player);
				approachStarted = elapsed;
			}
			if (elapsed - approachStarted > approach.Timeout)
			{
				throw new TimeoutException("接近捕获目标超时");
			}
			if (approach.Tick(elapsed - approachStarted) == StepResult.Completed)
			{
				approach.Cancel();
				approach = null;
			}
			Name = "接近目标至 3 米内";
			return StepResult.Running;
		}
		approach?.Cancel();
		approach = null;
		if (flag && inspected)
		{
			combatSupport.RunRotation(targetId, capture: true);
			Name = entry.Name + " · PR 捕捉模式";
			return StepResult.Running;
		}
		if (elapsed < nextAttempt)
		{
			return StepResult.Running;
		}
		uint num = (inspected ? CapturePolicy.Choose(combatTarget, world.PlayerLevel, world.ComboAction, capturesApplied) : 44882u);
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(250L);
		if (!world.TryAction(num, targetId))
		{
			Name = $"等待技能 {num} 可用（距离、朝向或冷却）";
			return StepResult.Running;
		}
		world.StopAutoAttack();
		pending = true;
		pendingAction = num;
		submittedAt = elapsed;
		captureSubmitted |= num == 44880;
		string text;
		if (num == 44882)
		{
			text = "识破";
		}
		else
		{
			string text2 = ((num != 44880) ? "连击攻击" : (capturesApplied switch
			{
				0 => "起手捕获", 
				1 => "血量低于 33%，再次捕获", 
				_ => "血量低于 10%，再次捕获", 
			}));
			text = text2;
		}
		string value = text;
		Name = $"{entry.Name} Lv.{combatTarget.Level} · {value} · 技能 {num}";
		return StepResult.Running;
	}

	public void Cancel()
	{
		try
		{
			approach?.Cancel();
		}
		finally
		{
			approach = null;
			try
			{
				world.CombatSupport?.Stop();
			}
			finally
			{
				if (initialized)
				{
					world.StopAutoAttack();
				}
				world.CancelCaptureConfirmation();
				confirming = false;
			}
		}
	}
}
