using System;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.InteropServices;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class LandAndDismountStep(IHuntingWorld world, INavigationProvider nav) : IWorkflowStep
{
	private bool ownsDescent;

	private TimeSpan? lastDismount;

	private TimeSpan? lastDescent;

	public string Name { get; private set; } = "确认落地与下坐骑";

	public TimeSpan Timeout => TimeSpan.FromSeconds(25L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed > Timeout)
		{
			throw new TimeoutException("未能落地并下坐骑，已停止，未施放攻击或捕获");
		}
		if (world.IsTransitioning || world.Player == null)
		{
			throw new InvalidOperationException("落地期间角色或区域发生变化");
		}
		if (world.IsMountTransition || world.IsCasting)
		{
			return StepResult.Running;
		}
		if (world.IsFlying)
		{
			if (ownsDescent)
			{
				if (nav.IsRunning)
				{
					goto IL_0180;
				}
				if (lastDescent.HasValue)
				{
					TimeSpan? timeSpan = lastDescent;
					if (!(elapsed - timeSpan >= TimeSpan.FromSeconds(1L)))
					{
						goto IL_0180;
					}
				}
			}
			if (nav.IsRunning || nav.IsPathfinding)
			{
				throw new InvalidOperationException("降落路径被其他任务占用");
			}
			ownsDescent = true;
			lastDescent = elapsed;
			INavigationProvider navigationProvider = nav;
			int num = 1;
			List<Vector3> list = new List<Vector3>(num);
			CollectionsMarshal.SetCount(list, num);
			CollectionsMarshal.AsSpan(list)[0] = world.Player.Position - new Vector3(0f, 30f, 0f);
			navigationProvider.Move(list, fly: true);
			goto IL_0180;
		}
		Cancel();
		if (world.IsMounted)
		{
			Name = "已落地，等待下坐骑";
			Dismount(elapsed);
			return StepResult.Running;
		}
		return StepResult.Completed;
		IL_0180:
		Name = "下降到地面后下坐骑";
		Dismount(elapsed);
		return StepResult.Running;
	}

	private void Dismount(TimeSpan elapsed)
	{
		if (lastDismount.HasValue)
		{
			TimeSpan? timeSpan = lastDismount;
			if (elapsed - timeSpan < TimeSpan.FromSeconds(1L))
			{
				return;
			}
		}
		lastDismount = elapsed;
		world.TryDismount();
	}

	public void Cancel()
	{
		if (ownsDescent)
		{
			ownsDescent = false;
			nav.Stop();
		}
	}
}
