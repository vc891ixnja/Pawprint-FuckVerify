using System;
using System.Numerics;

namespace Beastmaster.Core.Hunting;

public static class MapCoordinates
{
	public static Vector2 ToWorld(float mapX, float mapY, uint sizeFactor, int offsetX, int offsetY)
	{
		if (sizeFactor == 0 || !float.IsFinite(mapX) || !float.IsFinite(mapY))
		{
			throw new ArgumentException("地图参数无效");
		}
		return new Vector2((mapX - 1f - 2048f / (float)sizeFactor) * 50f - (float)offsetX, (mapY - 1f - 2048f / (float)sizeFactor) * 50f - (float)offsetY);
	}
}
