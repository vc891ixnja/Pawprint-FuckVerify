using System;

namespace Beastmaster.Core.Hunting;

public static class CapturePolicy
{
	public static uint Choose(CombatTarget target, byte playerLevel, uint combo, int capturesApplied)
	{
		if (playerLevel < target.Level)
		{
			throw new InvalidOperationException($"需达到魔物等级：角色 {playerLevel}，魔物 {target.Level}");
		}
		if (target.MaxHp == 0 || target.Level == 0)
		{
			throw new InvalidOperationException("魔物等级或血量尚未加载");
		}
		if (capturesApplied != 0 && (capturesApplied != 1 || (ulong)((long)target.Hp * 100L) >= (ulong)((long)target.MaxHp * 33L)) && (capturesApplied != 2 || (ulong)((long)target.Hp * 100L) >= (ulong)((long)target.MaxHp * 10L)))
		{
			return BeastmasterActions.NextAttack(playerLevel, combo);
		}
		return 44880u;
	}
}
