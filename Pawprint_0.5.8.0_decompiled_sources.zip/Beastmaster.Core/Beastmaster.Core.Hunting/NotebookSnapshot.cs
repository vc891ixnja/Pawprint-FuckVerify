using System;

namespace Beastmaster.Core.Hunting;

public sealed record NotebookSnapshot(string GameVersion, ulong ContentId, DateTimeOffset ObservedAt, NotebookValue[] Values);
