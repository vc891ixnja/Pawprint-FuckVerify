namespace Beastmaster.Core.Hunting;

public interface ITaskCombatSupport
{
	bool UsesExternalRotation { get; }

	void Prepare();

	void RunRotation(ulong targetId, bool capture);

	void StopRotation();

	bool WantsMovement(CombatTarget target);

	void UpdateMovement(ulong targetId);

	void StopMovement();

	void Stop();
}
