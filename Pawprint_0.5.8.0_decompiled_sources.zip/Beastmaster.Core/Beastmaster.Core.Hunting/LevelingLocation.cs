namespace Beastmaster.Core.Hunting;

public sealed record LevelingLocation(int Id, string Name, uint TerritoryId, uint MapId, string Region, int Level, float MapX, float MapY, float WorldX, float WorldZ)
{
	public MapDestination Destination => new MapDestination(TerritoryId, MapId, Region, MapX, MapY);
}
