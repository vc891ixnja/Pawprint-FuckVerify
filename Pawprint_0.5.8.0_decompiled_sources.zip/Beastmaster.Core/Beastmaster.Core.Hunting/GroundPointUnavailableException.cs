using System;

namespace Beastmaster.Core.Hunting;

public sealed class GroundPointUnavailableException : InvalidOperationException
{
	public GroundPointUnavailableException(string message)
		: base(message)
	{
	}
}
