using System;
using System.Numerics;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class ClearCombatStep(ILevelingWorld combat, INavigationProvider nav) : IWorkflowStep
{
	private readonly ulong character = combat.ContentId;

	private readonly uint territory = combat.TerritoryId;

	private CombatTarget? target;

	private NavigationStep? movement;

	private Vector3? destination;

	private TimeSpan movingAt;

	private TimeSpan nextAction;

	private TimeSpan? missingAt;

	public string Name { get; private set; } = "已捕获 · 清理交战中的敌人";

	public TimeSpan Timeout => TimeSpan.FromMinutes(5L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (character == 0L || combat.ContentId != character || combat.TerritoryId != territory)
		{
			throw new InvalidOperationException("清理战斗期间角色或区域已变化");
		}
		if (!combat.InCombat)
		{
			Cancel();
			Name = "已捕获并脱离战斗";
			return StepResult.Completed;
		}
		CombatTarget combatTarget;
		if (target != null)
		{
			target = combat.ReadTarget(target.ObjectId);
			combatTarget = target;
			if ((object)combatTarget == null || combatTarget.IsDead || !combatTarget.IsTargetable || !combatTarget.IsAttackable || combatTarget.Hp == 0 || !combat.IsEngagedTarget(target.ObjectId))
			{
				ReleaseMovement();
				combat.CombatSupport?.Stop();
				combat.StopAutoAttack();
				target = null;
			}
		}
		if ((object)target == null)
		{
			target = combat.FindEngagedTarget();
		}
		combatTarget = target;
		if ((object)combatTarget == null || combatTarget.IsDead || !combatTarget.IsTargetable || !combatTarget.IsAttackable || combatTarget.Hp == 0 || !combat.IsEngagedTarget(target.ObjectId))
		{
			target = null;
			Cancel();
			TimeSpan valueOrDefault = missingAt.GetValueOrDefault();
			if (!missingAt.HasValue)
			{
				valueOrDefault = elapsed;
				missingAt = valueOrDefault;
			}
			TimeSpan? timeSpan = missingAt;
			if (elapsed - timeSpan > TimeSpan.FromSeconds(30L))
			{
				throw new TimeoutException("仍在战斗，但仇恨列表中没有可攻击的目标");
			}
			Name = "已捕获 · 等待交战目标出现或脱战";
			return StepResult.Running;
		}
		missingAt = null;
		if (!combat.IsOnFoot || combat.Player == null)
		{
			Cancel();
			return StepResult.Running;
		}
		ITaskCombatSupport combatSupport = combat.CombatSupport;
		bool flag = combatSupport?.WantsMovement(target) ?? false;
		if (flag)
		{
			ReleaseMovement();
			combatSupport.UpdateMovement(target.ObjectId);
		}
		else
		{
			combatSupport?.StopMovement();
		}
		if (Vector3.Distance(combat.Player.Position, target.Location.Position) - target.HitboxRadius > 3f)
		{
			combatSupport?.StopRotation();
			Name = "已捕获 · 接近交战中的敌人";
			if (flag)
			{
				return StepResult.Running;
			}
			Vector3? vector = destination;
			if (vector.HasValue)
			{
				Vector3 valueOrDefault2 = vector.GetValueOrDefault();
				if (Vector3.Distance(valueOrDefault2, target.Location.Position) > 2f)
				{
					ReleaseMovement();
				}
			}
			if (movement == null)
			{
				destination = target.Location.Position;
				movingAt = elapsed;
				movement = new NavigationStep(nav, target.Location, () => combat.Player);
			}
			if (elapsed - movingAt >= movement.Timeout)
			{
				throw new TimeoutException("无法接近交战目标");
			}
			if (movement.Tick(elapsed - movingAt) == StepResult.Completed)
			{
				ReleaseMovement();
			}
			return StepResult.Running;
		}
		ReleaseMovement();
		combatSupport?.Prepare();
		Name = "已捕获 · 清理交战中的敌人";
		if (combatSupport != null && combatSupport.UsesExternalRotation)
		{
			combatSupport.RunRotation(target.ObjectId, capture: false);
		}
		else if (elapsed >= nextAction)
		{
			nextAction = elapsed + TimeSpan.FromMilliseconds(250L);
			combat.TryAction(BeastmasterActions.NextAttack(combat.PlayerLevel, combat.ComboAction), target.ObjectId);
		}
		return StepResult.Running;
	}

	private void ReleaseMovement()
	{
		movement?.Cancel();
		movement = null;
		destination = null;
	}

	public void Cancel()
	{
		try
		{
			ReleaseMovement();
		}
		finally
		{
			try
			{
				combat.CombatSupport?.Stop();
			}
			finally
			{
				combat.StopAutoAttack();
			}
		}
	}
}
