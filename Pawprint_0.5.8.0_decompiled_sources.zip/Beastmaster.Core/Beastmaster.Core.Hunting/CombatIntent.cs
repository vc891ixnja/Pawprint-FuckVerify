using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class CombatIntent
{
	public bool CaptureRequested { get; private set; }

	public static bool AllowsTaskActions(WorkflowRunner runner)
	{
		bool flag = runner.State == RunState.Running && !runner.IsPreview;
		bool flag2;
		if (flag)
		{
			IWorkflowStep activeStep = runner.ActiveStep;
			if (activeStep is HuntSequenceStep huntSequenceStep)
			{
				if (huntSequenceStep.IsCapture)
				{
					goto IL_003c;
				}
			}
			else if (activeStep is LevelingStep)
			{
				goto IL_003c;
			}
			flag2 = false;
			goto IL_0042;
		}
		goto IL_0044;
		IL_0044:
		return flag;
		IL_0042:
		flag = flag2;
		goto IL_0044;
		IL_003c:
		flag2 = true;
		goto IL_0042;
	}

	public void Begin(bool capture)
	{
		CaptureRequested = capture;
	}

	public void Reset()
	{
		CaptureRequested = false;
	}
}
