namespace Beastmaster.Core.Hunting;

public sealed record MapDestination(uint TerritoryId, uint MapId, string Name, float MapX, float MapY)
{
	public bool IsValid
	{
		get
		{
			if (TerritoryId != 0 && MapId != 0)
			{
				float mapX = MapX;
				if (mapX > 0f && mapX < 100f)
				{
					mapX = MapY;
					if (mapX > 0f)
					{
						return mapX < 100f;
					}
					return false;
				}
			}
			return false;
		}
	}
}
