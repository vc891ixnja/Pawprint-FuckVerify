using System.Collections.Generic;

namespace Beastmaster.Core.Hunting;

public sealed record NotebookPage(NotebookSnapshot Snapshot, int PageIndex, int CapturedCount, IReadOnlyDictionary<int, CaptureState> States);
