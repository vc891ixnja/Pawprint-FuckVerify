namespace Beastmaster.Core.Hunting;

public sealed record MonsterNameRow(uint NameId, string Name)
{
	public bool IsNotebookCompanion
	{
		get
		{
			uint nameId = NameId;
			if (nameId >= 14407)
			{
				return nameId <= 14456;
			}
			return false;
		}
	}
}
