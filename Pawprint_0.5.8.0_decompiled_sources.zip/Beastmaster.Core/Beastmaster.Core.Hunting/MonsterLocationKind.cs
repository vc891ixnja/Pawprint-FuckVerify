namespace Beastmaster.Core.Hunting;

public enum MonsterLocationKind
{
	Starter,
	OpenWorld,
	Duty,
	Unknown
}
