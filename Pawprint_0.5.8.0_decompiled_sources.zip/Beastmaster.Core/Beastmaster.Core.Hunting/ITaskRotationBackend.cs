namespace Beastmaster.Core.Hunting;

public interface ITaskRotationBackend
{
	bool IsRunning { get; }

	void RequireReady();

	string Read(string key);

	void Write(string key, string value);

	void Start();

	void Stop();
}
