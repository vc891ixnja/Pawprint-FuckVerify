namespace Beastmaster.Core.Hunting;

public static class CaptureMessages
{
	public const uint Easy = 11221u;

	public const uint VeryEasy = 11222u;

	public const uint Success = 11400u;

	public const uint AlreadyCollected = 11425u;

	public static bool IsInspect(uint id)
	{
		if (id >= 11217)
		{
			return id <= 11222;
		}
		return false;
	}

	public static bool CanCapture(uint id)
	{
		if (id >= 11218)
		{
			return id <= 11222;
		}
		return false;
	}
}
