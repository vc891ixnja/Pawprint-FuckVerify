using System;
using System.Collections.Generic;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Hunting;

public sealed class TaskRotationSession(ITaskRotationBackend backend) : IDisposable
{
	private PluginSettingsScope? settings;

	private bool prepared;

	private bool started;

	private bool? mode;

	public void Prepare()
	{
		backend.RequireReady();
		if (!prepared)
		{
			backend.Stop();
			prepared = true;
		}
	}

	public void Run(bool capture)
	{
		Prepare();
		if (mode.HasValue && mode != capture)
		{
			throw new InvalidOperationException("PR 任务模式变化，请重新启动任务");
		}
		if (settings == null)
		{
			settings = new PluginSettingsScope(backend.Read, backend.Write);
			settings.Apply(new Dictionary<string, string>
			{
				["CaptureMode"] = capture.ToString(),
				["AutoPull"] = "True",
				["TargetSelectorMode"] = "None"
			});
			mode = capture;
		}
		if (backend.Read("CaptureMode") != capture.ToString() || backend.Read("AutoPull") != "True" || backend.Read("TargetSelectorMode") != "None")
		{
			throw new InvalidOperationException("PR 的捕捉或选敌设置已在外部变更，任务已停止");
		}
		if (started && !backend.IsRunning)
		{
			throw new InvalidOperationException("PR 已停止，请检查 ACR 后恢复任务");
		}
		if (!started)
		{
			backend.Start();
			started = true;
		}
	}

	public void Dispose()
	{
		try
		{
			if (prepared)
			{
				backend.Stop();
			}
		}
		finally
		{
			prepared = (started = false);
			mode = null;
			PluginSettingsScope? pluginSettingsScope = settings;
			settings = null;
			pluginSettingsScope?.Dispose();
		}
	}
}
