namespace Beastmaster.Core.Hunting;

public sealed record NotebookValue(int Index, string Type, long? Number, string? Text);
