using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed record CombatTarget(ulong ObjectId, uint NameId, WorldPoint Location, byte Level, uint Hp, uint MaxHp, bool IsDead, bool IsTargetable, float HitboxRadius = 0f, bool IsAttackable = true);
