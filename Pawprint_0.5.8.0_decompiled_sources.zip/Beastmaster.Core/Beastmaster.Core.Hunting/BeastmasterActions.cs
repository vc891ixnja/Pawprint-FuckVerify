namespace Beastmaster.Core.Hunting;

public static class BeastmasterActions
{
	public const uint First = 44879u;

	public const uint Second = 44883u;

	public const uint Third = 44885u;

	public const uint Inspect = 44882u;

	public const uint Capture = 44880u;

	public const float Range = 3f;

	public static byte RequiredLevel(uint action)
	{
		return action switch
		{
			44883u => 2, 
			44885u => 12, 
			_ => 1, 
		};
	}

	public static uint NextAttack(byte level, uint combo)
	{
		if (combo != 44883 || level < 12)
		{
			if (combo != 44879 || level < 2)
			{
				return 44879u;
			}
			return 44883u;
		}
		return 44885u;
	}
}
