using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Hunting;

public sealed class PagedCaptureJournal
{
	private readonly Dictionary<int, CaptureState> states = new Dictionary<int, CaptureState>();

	private readonly Dictionary<int, NotebookPage> pages = new Dictionary<int, NotebookPage>();

	private ulong contentId;

	private int total = -1;

	private DateTimeOffset observed;

	public void Reset()
	{
		states.Clear();
		pages.Clear();
		contentId = 0uL;
		total = -1;
	}

	public void Apply(NotebookPage page)
	{
		if (page.Snapshot.ContentId != contentId || page.CapturedCount != total || page.States.Any((KeyValuePair<int, CaptureState> s) => states.TryGetValue(s.Key, out var value) && value != s.Value))
		{
			pages.Clear();
		}
		int[] array = (from p in pages
			where page.Snapshot.ObservedAt < p.Value.Snapshot.ObservedAt || page.Snapshot.ObservedAt - p.Value.Snapshot.ObservedAt > TimeSpan.FromMinutes(5L)
			select p.Key).ToArray();
		foreach (int key in array)
		{
			pages.Remove(key);
		}
		pages[page.PageIndex] = page;
		contentId = page.Snapshot.ContentId;
		total = page.CapturedCount;
		observed = pages.Values.Min((NotebookPage p) => p.Snapshot.ObservedAt);
		states.Clear();
		foreach (KeyValuePair<int, CaptureState> item in pages.Values.SelectMany((NotebookPage p) => p.States))
		{
			states.Add(item.Key, item.Value);
		}
		int num2 = states.Count((KeyValuePair<int, CaptureState> s) => s.Value == CaptureState.Captured);
		int num3 = states.Count((KeyValuePair<int, CaptureState> s) => s.Value == CaptureState.Missing);
		if (num2 > total || num3 > 50 - total)
		{
			Reset();
			throw new InvalidOperationException("跨页图鉴状态冲突");
		}
		if (num2 != total && num3 != 50 - total)
		{
			return;
		}
		foreach (int item2 in Enumerable.Range(1, 50))
		{
			states.TryAdd(item2, (num2 == total) ? CaptureState.Missing : CaptureState.Captured);
		}
	}

	public CaptureState Get(int number, ulong character, DateTimeOffset now)
	{
		if (character != 0L && contentId == character && !(now < observed) && !(now - observed > TimeSpan.FromMinutes(5L)))
		{
			return states.GetValueOrDefault(number, CaptureState.Unknown);
		}
		return CaptureState.Unknown;
	}
}
