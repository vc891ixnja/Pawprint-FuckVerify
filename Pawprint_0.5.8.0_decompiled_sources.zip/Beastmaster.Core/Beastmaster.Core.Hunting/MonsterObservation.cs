using Beastmaster.Core.Models;

namespace Beastmaster.Core.Hunting;

public sealed record MonsterObservation(ulong ObjectId, uint NameId, WorldPoint Location, byte Level, float HitboxRadius = 0f);
