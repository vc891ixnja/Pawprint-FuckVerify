using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace Beastmaster.Core.I18N;

public static class GameText
{
	public static readonly string[] LanguageCodes = new string[6] { "zhCN", "zhTW", "en", "ja", "fr", "de" };

	private static readonly IReadOnlyDictionary<string, GameTextTable.Entry> ByKey = GameTextTable.Entries.ToDictionary<GameTextTable.Entry, string>((GameTextTable.Entry e) => e.Key, StringComparer.Ordinal);

	private static int current = 0;

	public static string Language => LanguageCodes[current];

	public static int LanguageIndex => current;

	public static void SelectLanguage(object? language)
	{
		int num = ((language != null) ? ((language is string name) ? IndexOf(name) : ((!(language is int num2)) ? IndexOf(language.ToString()) : ((num2 >= 0 && num2 < 6) ? num2 : 0))) : 0);
		current = num;
	}

	private static int IndexOf(string? name)
	{
		if (string.IsNullOrEmpty(name))
		{
			return 0;
		}
		string text = name.Trim();
		for (int i = 0; i < LanguageCodes.Length; i++)
		{
			if (string.Equals(LanguageCodes[i], text, StringComparison.OrdinalIgnoreCase))
			{
				return i;
			}
		}
		switch (text)
		{
		case "ChineseSimplified":
			return 0;
		case "TraditionalChinese":
			return 1;
		case "English":
			return 2;
		case "Japanese":
			return 3;
		case "French":
			return 4;
		case "German":
			return 5;
		default:
		{
			if (int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result) && result >= 0 && result < 6)
			{
				return result;
			}
			return 0;
		}
		}
	}

	public static string Normalize(string? text)
	{
		if (text != null)
		{
			return string.Concat(text.Where((char c) => !char.IsWhiteSpace(c) && char.GetUnicodeCategory(c) != UnicodeCategory.PrivateUse));
		}
		return "";
	}

	public static IReadOnlyList<string?> Fragments(string key)
	{
		if (!ByKey.TryGetValue(key, out GameTextTable.Entry value))
		{
			throw new ArgumentException("未知文本表键: " + key, "key");
		}
		return value.Fragments[current] ?? Array.Empty<string>();
	}

	public static bool Matches(string key, string? text)
	{
		if (text == null || !ByKey.TryGetValue(key, out GameTextTable.Entry value))
		{
			return false;
		}
		string[] fragments = value.Fragments[current] ?? Array.Empty<string>();
		if (value.Match == "exact")
		{
			return Exact(text, fragments);
		}
		return Contains(text, fragments, value.AllFragments);
	}

	private static bool Exact(string text, IReadOnlyList<string?> fragments)
	{
		string text2 = Normalize(text);
		foreach (string fragment in fragments)
		{
			if (fragment != null && Normalize(fragment).Length > 0 && text2.Equals(Normalize(fragment), StringComparison.Ordinal))
			{
				return true;
			}
		}
		return false;
	}

	private static bool Contains(string text, IReadOnlyList<string?> fragments, bool all)
	{
		string text2 = Normalize(text);
		bool flag = false;
		foreach (string fragment in fragments)
		{
			if (fragment != null && Normalize(fragment).Length != 0)
			{
				bool flag2 = text2.Contains(Normalize(fragment), StringComparison.Ordinal);
				if (all && !flag2)
				{
					return false;
				}
				flag = flag || flag2;
			}
		}
		if (!all)
		{
			return flag;
		}
		return flag;
	}

	public static bool MatchesAnyLanguage(string key, string? text)
	{
		if (text == null || !ByKey.TryGetValue(key, out GameTextTable.Entry value))
		{
			return false;
		}
		for (int i = 0; i < LanguageCodes.Length; i++)
		{
			string[] fragments = value.Fragments[i] ?? Array.Empty<string>();
			if ((!(value.Match == "exact")) ? Contains(text, fragments, value.AllFragments) : Exact(text, fragments))
			{
				return true;
			}
		}
		return false;
	}

	public static uint? BestiaryNumber(string text)
	{
		string text2 = string.Concat(text.Where(char.IsDigit));
		if (text2.Length <= 0 || !uint.TryParse(text2, NumberStyles.Integer, CultureInfo.InvariantCulture, out var result))
		{
			return null;
		}
		return result;
	}
}
