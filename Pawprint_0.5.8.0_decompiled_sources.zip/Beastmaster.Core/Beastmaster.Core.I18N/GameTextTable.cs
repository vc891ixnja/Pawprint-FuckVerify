namespace Beastmaster.Core.I18N;

public static class GameTextTable
{
	public sealed record Entry(string Key, string Match, bool AllFragments, string?[]?[] Fragments);

	public const int ZhCN = 0;

	public const int ZhTW = 1;

	public const int En = 2;

	public const int Ja = 3;

	public const int Fr = 4;

	public const int De = 5;

	public static readonly Entry[] Entries = new Entry[129]
	{
		new Entry("Capture.Success", "contains", AllFragments: true, new string[6][]
		{
			new string[2] { "成功结识了", "种的魔兽" },
			new string[2] { "成功結識了", "種的魔獸" },
			new string[2] { "Pact successfully forged!", "Master's Bestiary" },
			new string[1] { "種の魔獣と契約することに成功した" },
			new string[2] { "capturé", "cible" },
			new string[2] { "Pakt mit einer Bestie", "geschlossen" }
		}),
		new Entry("Capture.Inspect.Cannot", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎无法捕获……" },
			new string[1] { "似乎無法捕獲……" },
			new string[1] { "No pact can be forged with this target..." },
			new string[1] { "は「とらえる」ことができない相手のようだ……。" },
			new string[1] { "Impossible de capturer la cible." },
			new string[1] { "Mit diesem Ziel ist ein Pakt nicht möglich ..." }
		}),
		new Entry("Capture.Inspect.VeryHard", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎非常难以捕获。" },
			new string[1] { "似乎非常難以捕獲。" },
			new string[1] { "Befriending this beast will be exceedingly difficult." },
			new string[1] { "を「とらえる」のはとても難しいようだ。" },
			new string[1] { "Capturer la cible s'annonce très difficile." },
			new string[1] { "Einen Pakt mit dieser Bestie zu schließen, dürfte sehr schwierig sein." }
		}),
		new Entry("Capture.Inspect.Hard", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎比较难以捕获。" },
			new string[1] { "似乎比較難以捕獲。" },
			new string[1] { "Befriending this beast will be difficult." },
			new string[1] { "を「とらえる」のは難しいようだ。" },
			new string[1] { "Capturer la cible devrait être difficle." },
			new string[1] { "Einen Pakt mit dieser Bestie zu schließen, dürfte schwierig sein." }
		}),
		new Entry("Capture.Inspect.NotEasy", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎不太容易捕获。" },
			new string[1] { "似乎不太容易捕獲。" },
			new string[1] { "Befriending this beast will not be easy." },
			new string[1] { "を「とらえる」のは簡単ではないようだ。" },
			new string[1] { "Capturer la cible ne sera pas évident." },
			new string[1] { "Einen Pakt mit dieser Bestie zu schließen, dürfte nicht einfach sein." }
		}),
		new Entry("Capture.Inspect.Easy", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎很容易捕获。" },
			new string[1] { "似乎很容易捕獲。" },
			new string[1] { "Befriending this beast should be easy." },
			new string[1] { "を「とらえる」のは簡単なようだ。" },
			new string[1] { "Capturer la cible devrait être simple." },
			new string[1] { "Einen Pakt mit dieser Bestie zu schließen, dürfte einfach sein." }
		}),
		new Entry("Capture.Inspect.VeryEasy", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "似乎非常容易捕获。" },
			new string[1] { "似乎非常容易捕獲。" },
			new string[1] { "Befriending this beast should take no effort at all." },
			new string[1] { "を「とらえる」のはとても簡単なようだ。" },
			new string[1] { "Capturer la cible devrait être un jeu d'enfant." },
			new string[1] { "Einen Pakt mit dieser Bestie zu schließen, dürfte sehr einfach sein." }
		}),
		new Entry("Capture.Fled", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "产生了警惕逃走了。" },
			new string[1] { "產生了警惕逃走了。" },
			new string[1] { "sensed your presence and scampered away." },
			new string[1] { "は、警戒して逃げ出してしまった……。" },
			new string[1] { "a pris peur et s'est enfui" },
			new string[1] { "ist aufgeschreckt und hat sich davongemacht" }
		}),
		new Entry("Capture.NoContact", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "无法捕获，尚未接触到目标。" },
			new string[1] { "無法捕獲，尚未接觸到目標。" },
			new string[1] { "You are too far away from your quarry." },
			new string[1] { "対象に接触していないため、捕獲できません。" },
			new string[1] { "Action impossible. Vous n'êtes pas en contact avec la cible." },
			new string[1] { "Kann nicht gefangen werden, da noch kein Kontakt besteht." }
		}),
		new Entry("Capture.AlreadyCaptured", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "已经收录至魔兽图鉴，无法捕获。" },
			new string[1] { "已經收錄至魔獸圖鑑，無法捕獲。" },
			new string[1] { "You have already befriended this beast." },
			new string[1] { "は魔獣図鑑に登録済みなため、「とらえる」ことができない。" },
			new string[1] { "Vous avez déjà capturé cette bête." },
			new string[1] { "Mit dieser Bestie hast du bereits einen Pakt geschlossen." }
		}),
		new Entry("Capture.LevelTooLow", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "当前驯兽师等级不足以捕获" },
			new string[1] { "當前馴獸師等級不足以捕獲" },
			new string[1] { "You are not yet strong enough to befriend this beast..." },
			new string[2] { "魔獣使いとして力不足なため、", "を「とらえる」ことができない。" },
			new string[2] { "Vous n'êtes pas encore assez", "pour capturer cette bête." },
			new string[1] { "Du bist noch nicht stark genug, um einen Pakt mit dieser Bestie zu schließen." }
		}),
		new Entry("Battle.SandsRewind", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "时之沙发挥了效果，时间开始回溯！" },
			new string[1] { "時之沙發揮了效果，時間開始回溯！" },
			new string[1] { "Temporal sands turn back time!" },
			new string[1] { "時の砂の効果が発動し、時間が巻き戻る！" },
			new string[1] { "Vous bénéficiez de l'effet Retournement de sablier et revenez avant le début du combat" },
			new string[1] { "Der Sand der Zeit wirkt und dreht die Zeit zurück!" }
		}),
		new Entry("Flee.Result", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "利用道具效果从战斗中逃走了。" },
			new string[1] { "利用道具效果從戰鬥中逃走了。" },
			new string[1] { "You flee from battle..." },
			new string[1] { "アイテムの効果により、バトルから逃走しました。" },
			new string[1] { "L'effet de l'objet vous permet de fuir le combat." },
			new string[1] { "Du fliehst aus dem Kampf ..." }
		}),
		new Entry("Tent.RestResult", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "在帐篷中休息后，", "的体力恢复了" },
			new string[2] { "在帳篷中休息後，", "的體力恢復了" },
			new string[2] { "You recover", "HP by resting at the campsite." },
			new string[3] { "テントで休息したことで、", "のＨＰが", "回復しました。" },
			new string[1] { "Après un repos au campement," },
			new string[2] { "Durch die Rast hast du", "LP regeneriert." }
		}),
		new Entry("Feed.AlreadyFull", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "已经吃饱了，无法继续进食。" },
			new string[1] { "已經喫飽了，無法繼續進食。" },
			new string[2] { "Your", "is not hungry and dismisses the suggestion of feed." },
			new string[1] { "」は満腹のため、これ以上フィードを食べられません。" },
			new string[2] { "Votre", "refuse de s'alimenter davantage." },
			new string[1] { "Diese Bestie ist momentan satt und mag nichts mehr fressen." }
		}),
		new Entry("Feed.SameFood", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "已经吃了", "，无法继续进食相同食物。" },
			new string[2] { "已經喫了", "，無法繼續進食相同食物。" },
			new string[2] { "Your", "desires variety in its diet. It will not consume another" },
			new string[2] { "」はすでに「", "」を食べています。同じフィードを食べることはできません。" },
			new string[3] { "Votre", "a déjà englouti", "et refuse d'en avaler davantage." },
			new string[2] { "Diese Bestie hat bereits", "gefressen. Achte auf eine abwechslungsreiche Ernährung." }
		}),
		new Entry("Feed.CannotEat", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "无法食用" },
			new string[1] { "無法食用" },
			new string[3] { "Your", "looks askance at", "and refuses to consume it." },
			new string[1] { "」を食べられません。" },
			new string[2] { "Votre", "refuse d'avaler" },
			new string[2] { "Bestien der Familie „", "“ fressen keine" }
		}),
		new Entry("Entry.NpcName", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "劳妲" },
			new string[1] { "勞妲" },
			new string[1] { "Lauda" },
			new string[1] { "ラウダ" },
			new string[1] { "Lauda" },
			new string[1] { "Lauda" }
		}),
		new Entry("Entry.DepartButton", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "出发" },
			new string[1] { "出發" },
			new string[2] { "Commence", "Deploy" },
			new string[2] { "突入", "ボイジャー出港" },
			new string[2] { "Commencer", "Expédier" },
			new string[2] { "Teilnehmen", "Erkundung starten" }
		}),
		new Entry("Entry.ChallengeBoard", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "挑战此奇盘" },
			new string[1] { "挑戰此奇盤" },
			new string[1] { "Challenge This Board" },
			new string[1] { "この盤面に挑む" },
			new string[1] { "Entrer dans ce Dédale" },
			new string[1] { "Spielen" }
		}),
		new Entry("Entry.ResumeProgress", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "从“中断存档”继续" },
			new string[1] { "從“中斷存檔”繼續" },
			new string[1] { "Resume Progress" },
			new string[1] { "「中断データ」から再開" },
			new string[1] { "Reprendre la partie" },
			new string[1] { "Fortsetzen" }
		}),
		new Entry("Entry.AbandonConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要放弃挑战斗兽奇弈吗？" },
			new string[1] { "確定要放棄挑戰鬥獸奇弈嗎？" },
			new string[1] { "Forfeit and exit the Crucible of the Unbroken?" },
			new string[2] { "闘獣練の挑戦をギブアップします。", "よろしいですか？" },
			new string[1] { "Désirez-vous abandonner le Dédale bestial" },
			new string[1] { "Aufgeben und das Brett der Bestie verlassen?" }
		}),
		new Entry("Entry.SuspendConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要暂时中断挑战斗兽奇弈，退出任务吗？", "退出后想继续挑战时，可以在进入斗兽奇弈的菜单选择“从‘中断存档’继续”。" },
			new string[2] { "確定要暫時中斷挑戰鬥獸奇弈，退出任務嗎？", "退出後想繼續挑戰時，可以在進入鬥獸奇弈的菜單選擇“從‘中斷存檔’繼續”。" },
			new string[2] { "Suspend progress and exit the Crucible of the Unbroken?", "Select “Resume Progress” when speaking with Lauda to reenter the Crucible from this point." },
			new string[2] { "闘獣練の挑戦を一時中断し、コンテンツから退出します。よろしいですか？", "退出後、続きからプレイするには、突入NPCメニューの『「中断データ」から再開する』を選んでください。" },
			new string[2] { "Souhaitez-vous sauvegarder votre progression puis quitter le Dédale bestial", "Pour reprendre votre partie, veuillez choisir l'option “Reprendre une partie suspendue” lorsque vous vous addresserez à nouveau à Lauda." },
			new string[2] { "Die Partie unterbrechen und das Brett der Bestie verlassen?", "Sprich mit Lauda und wähle „Partie fortsetzen“, um von diesem Punkt aus weiterzumachen." }
		}),
		new Entry("Entry.RankScore", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "斗兽奇弈排名得分" },
			new string[1] { "鬥獸奇弈排名得分" },
			new string[1] { "Crucible Ranking Score:" },
			new string[1] { "闘獣練ランキング" },
			new string[1] { "Classements du Dédale bestial" },
			new string[1] { "Punkte" }
		}),
		new Entry("Party.Title", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "魔兽编队" },
			new string[1] { "魔獸編隊" },
			new string[1] { "Team Composition" },
			new string[2] { "BEAST PARTY", "パーティ編成" },
			new string[1] { "Formation de l'équipe" },
			new string[1] { "FORMATION BEARBEITEN" }
		}),
		new Entry("Party.Recommended", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "推荐编队" },
			new string[1] { "推薦編隊" },
			new string[1] { "Recommended Team" },
			new string[1] { "おすすめ編成" },
			new string[1] { "Équipe conseillée" },
			new string[1] { "Empfohlene Formation" }
		}),
		new Entry("Party.RemoveAll", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "清空整个队伍" },
			new string[1] { "清空整個隊伍" },
			new string[1] { "Remove All Familiars" },
			new string[1] { "すべてのペットをパーティから外す" },
			new string[1] { "Retirer toutes les bêtes de l'équipe" },
			new string[1] { "Alle Bestien entfernen" }
		}),
		new Entry("Party.RemoveAllConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要清空整个队伍吗？" },
			new string[1] { "確定要清空整個隊伍嗎？" },
			new string[1] { "Remove all familiars from your current team?" },
			new string[2] { "すべてのペットをパーティから外します。", "よろしいですか？" },
			new string[1] { "Voulez-vous retirer toutes les bêtes de votre équipe" },
			new string[1] { "Alle Bestien aus der aktuellen Formation entfernen?" }
		}),
		new Entry("Party.EnableConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要启用此编队吗？" },
			new string[1] { "確定要啓用此編隊嗎？" },
			new string[1] { "Proceed with this team composition?" },
			new string[2] { "この編成を反映します。", "よろしいですか？" },
			new string[1] { "Continuer avec cette équipe" },
			new string[1] { "Mit dieser Formation fortfahren?" }
		}),
		new Entry("Party.SaveConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要保存此编队吗？" },
			new string[1] { "確定要保存此編隊嗎？" },
			new string[1] { "Save this team composition?" },
			new string[2] { "この編成を保存します。", "よろしいですか？" },
			new string[1] { "Voulez-vous enregistrer la composition de cette équipe" },
			new string[1] { "Diese Formation speichern?" }
		}),
		new Entry("Party.LoadConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要读取此编队吗？" },
			new string[1] { "確定要讀取此編隊嗎？" },
			new string[1] { "Import this team composition?" },
			new string[2] { "この編成を呼び出しします。", "よろしいですか？" },
			new string[1] { "Voulez-vous utiliser cette composition d'équipe" },
			new string[1] { "Diese Formation rufen?" }
		}),
		new Entry("Party.ContinueWithTeam", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "以此编队继续。" },
			new string[1] { "以此編隊繼續。" },
			new string[1] { "You will resume progress with this team composition." },
			new string[1] { "この編成でつづきから再開します。" },
			new string[1] { "Votre progression reprendra avec cette composition d'équipe." },
			new string[1] { "Du setzt die Partie mit dieser Formation fort." }
		}),
		new Entry("Party.AutoBuildHint", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "根据奇盘自动组建编队。" },
			new string[1] { "根據奇盤自動組建編隊。" },
			new string[1] { "A team suited for the current board will be automatically selected for you." },
			new string[1] { "盤面にあわせた編成が自動的に選択されます。" },
			new string[2] { "Une équipe adaptée au plateau sera au", "ment choisie." },
			new string[1] { "Stellt automatisch eine Formation für das aktuelle Brett zusammen." }
		}),
		new Entry("Party.SaveLoadHint", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "保存、读取魔兽编队。" },
			new string[1] { "保存、讀取魔獸編隊。" },
			new string[1] { "Save and import team compositions." },
			new string[1] { "ペットの編成を保存・読み込みできます。" },
			new string[1] { "Enregistrer et charger des compositions d'équipe." },
			new string[1] { "Formationen speichern und laden" }
		}),
		new Entry("Party.SelectFamiliars", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "请选择要在战斗中召唤的魔兽。" },
			new string[1] { "請選擇要在戰鬥中召喚的魔獸。" },
			new string[1] { "Select familiars to call upon during combat." },
			new string[1] { "戦闘に呼び出すペットを選択しましょう。" },
			new string[1] { "Sélectionner les bêtes que vous souhaitez appeler en combat." },
			new string[1] { "Wähle die Bestien, die du im Kampf rufen möchtest." }
		}),
		new Entry("Battle.Warning", "any", AllFragments: false, new string[6][]
		{
			new string[4] { "确定要在存在以下问题的情况下开始挑战吗？", "魔兽未满编", "兽级比推荐低3级", "排名统计时间已不足10分钟" },
			new string[4] { "確定要在存在以下問題的情況下開始挑戰嗎？", "魔獸未滿編", "獸級比推薦低3級", "排名統計時間已不足10分鐘" },
			new string[4] { "Proceed to challenge this board?", "smaller than the maximum allowance", "at least 3 beast ranks lower", "less than 10 minutes" },
			new string[4] { "それでも挑戦しますか？", "規定よりも少ないペット数", "ビーストランクより3ランク以上低い", "残り時間が10分を切っています" },
			new string[4] { "Voulez-vous tout de même entrer dans le Dédale bestial", "moins de bêtes que le maximum permis", "au moins 3 rangs de moins", "moins de 10 minutes" },
			new string[4] { "Trotzdem fortfahren?", "kleiner als erforderlich", "3 oder mehr Stufen zu niedrig", "nur noch 10 Minuten gezählt" }
		}),
		new Entry("Battle.BattlehornWarning", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要在有兽笛未设置魔兽的情况下开始战斗吗？" },
			new string[1] { "確定要在有獸笛未設置魔獸的情況下開始戰鬥嗎？" },
			new string[2] { "At least one battlehorn has not been assigned.", "Commence battle anyway?" },
			new string[1] { "ペットを設定していない呼び笛がありますが、このまま戦闘を開始してもよろしいですか？" },
			new string[2] { "Toutes les cornes d'appel n'ont pas été assignées.", "Commencer tout de même le combat" },
			new string[1] { "Mindestens ein Kampfhorn wurde noch nicht zugewiesen. Trotzdem kämpfen?" }
		}),
		new Entry("Battle.DiscardTeam", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要放弃编队，返回选择奇盘吗？" },
			new string[1] { "確定要放棄編隊，返回選擇奇盤嗎？" },
			new string[1] { "Discard changes and return to board selection?" },
			new string[1] { "パーティの編成中ですが、これを破棄して盤面選択に戻ってもよろしいですか？" },
			new string[2] { "Votre équipe est en cours de formation.", "Annuler et revenir à la sélection de plateau" },
			new string[1] { "Änderungen an der Formation verwerfen und zur Brettauswahl zurückkehren?" }
		}),
		new Entry("Battle.AssignHorn1", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "设置到一号兽笛" },
			new string[1] { "設置到一號獸笛" },
			new string[1] { "Assign to First Battlehorn" },
			new string[1] { "壱の呼び笛に設定" },
			new string[1] { "Assigner à Corne d'appel I" },
			new string[1] { "Kampfhorn I zuweisen" }
		}),
		new Entry("Battle.AssignHorn2", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "设置到二号兽笛" },
			new string[1] { "設置到二號獸笛" },
			new string[1] { "Assign to Second Battlehorn" },
			new string[1] { "弐の呼び笛に設定" },
			new string[1] { "Assigner à Corne d'appel II" },
			new string[1] { "Kampfhorn II zuweisen" }
		}),
		new Entry("Battle.AssignHorn3", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "设置到三号兽笛" },
			new string[1] { "設置到三號獸笛" },
			new string[1] { "Assign to Third Battlehorn" },
			new string[1] { "参の呼び笛に設定" },
			new string[1] { "Assigner à Corne d'appel III" },
			new string[1] { "Kampfhorn III zuweisen" }
		}),
		new Entry("Battle.HornsLabel", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "当前兽笛设置" },
			new string[1] { "當前獸笛設置" },
			new string[1] { "Battlehorns" },
			new string[1] { "ACTIVE BEASTS" },
			new string[1] { "Cornes d'appel" },
			new string[1] { "KAMPFHÖRNER" }
		}),
		new Entry("Battle.StartBanner", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "战斗开始！" },
			new string[1] { "戰鬥開始！" },
			new string[1] { "Commence Battle" },
			new string[1] { "戦闘開始！" },
			new string[1] { "Commencer le combat" },
			new string[1] { "Kämpfen" }
		}),
		new Entry("Reward.Title", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "战利品" },
			new string[1] { "戰利品" },
			new string[1] { "Loot" },
			new string[1] { "LOOT" },
			new string[1] { "Butin" },
			new string[1] { "BEUTE" }
		}),
		new Entry("Reward.Prompt", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "得到了以下战利品。", "请选择全部获取或挑选获取。" },
			new string[2] { "得到了以下戰利品。", "請選擇全部獲取或挑選獲取。" },
			new string[1] { "Spoils of battle lie at your feet. You may take all rewards listed below or make individual selections." },
			new string[2] { "以下の戦利品を獲得しました。", "すべて入手するか、個別にアイテムを選択して入手してください。" },
			new string[1] { "Les récompenses de la bataille se trouvent devant vous. Vous pouvez choisir de toutes les récupérer ou les sélectionner une à une." },
			new string[1] { "Du hast Beute gefunden. Nimm sie gesammelt entgegen oder wähle einzelne Beutestücke aus." }
		}),
		new Entry("Reward.TakeAll", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "全部获取" },
			new string[1] { "全部獲取" },
			new string[1] { "Take All" },
			new string[1] { "すべて入手" },
			new string[1] { "Tout prendre" },
			new string[1] { "Alles annehmen" }
		}),
		new Entry("Reward.TakeAllConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "全部获取吗？" },
			new string[1] { "全部獲取嗎？" },
			new string[1] { "You will receive:" },
			new string[1] { "をすべて入手します。よろしいですか？" },
			new string[1] { "Voulez-vous récupérer toutes les récompenses ci-dessous" },
			new string[1] { "Folgende Beute entgegennehmen?" }
		}),
		new Entry("Reward.CoinConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要获取", "斗兽币吗？" },
			new string[2] { "確定要獲取", "鬥獸幣嗎？" },
			new string[2] { "Take", "territory tokens?" },
			new string[2] { "ビーストコイン", "枚を入手します。よろしいですか？" },
			new string[2] { "Voulez-vous récupérer", "jetons bestiaux" },
			new string[1] { "Bestientaler entgegennehmen?" }
		}),
		new Entry("Reward.ExitWithUnclaimed", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "还有战利品没拿，确定要结束吗？" },
			new string[1] { "還有戰利品沒拿，確定要結束嗎？" },
			new string[1] { "Some loot remains unclaimed. Leave it behind?" },
			new string[1] { "まだ入手していない戦利品がありますが、終了してもよろしいですか？" },
			new string[1] { "Certaines récompenses n'ont pas été récupérées. Voulez-vous les abandonner" },
			new string[1] { "Es gibt unbeanspruchte Beute. Willst du sie zurücklassen?" }
		}),
		new Entry("Reward.CannotTakeAll", "contains", AllFragments: false, new string[6][]
		{
			new string[4] { "由于下列原因无法执行“全部获取”，请逐个挑选获取。", "·奇弈道具会超出可持有上限", "·无法重复获取已持有的斗兽装备", "·斗兽装备会超出可持有上限" },
			new string[4] { "由於下列原因無法執行“全部獲取”，請逐個挑選獲取。", "·奇弈道具會超出可持有上限", "·無法重複獲取已持有的鬥獸裝備", "·鬥獸裝備會超出可持有上限" },
			new string[4] { "Unable to take all.", "※You will exceed the capacity of your crucible item inventory.", "※You will receive duplicates of beast gear.", "※You will exceed the capacity of your beast gear inventory." },
			new string[4] { "・クルーシブルアイテムが所持上限を超えてしまう", "・すでに所持中のビーストギアは入手できない", "・ビーストギアが所持上限を超えてしまう", "ため「すべて入手」を実行できません。個別に入手操作を行ってください。" },
			new string[4] { "Impossible de récupérer toutes les récompenses.", "Vous ne pouvez plus porter davantage d'objets du Dédale.", "Vous possédez déjà cet équipement de dressage.", "Vous ne pouvez plus porter davantage d'équipements de dressage." },
			new string[4] { "Du kannst nicht alles entgegennehmen.", "※ In deinem Inventar für Bändigerutensilien ist nicht genug Platz.", "※ Du besitzt mindestens einen Bestienausrüstungsgegenstand schon einmal.", "※ In deinem Inventar für Bestienausrüstung ist nicht genug Platz." }
		}),
		new Entry("Reward.Exit", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "结束" },
			new string[1] { "結束" },
			new string[1] { "Close" },
			new string[1] { "終了" },
			new string[1] { "Fermer" },
			new string[1] { "Beenden" }
		}),
		new Entry("Reward.ExitConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要不拿道具直接结束吗？" },
			new string[1] { "確定要不拿道具直接結束嗎？" },
			new string[1] { "Close the coffer without receiving any items?" },
			new string[1] { "アイテムを入手せず、このまま終了しますか？" },
			new string[1] { "Refermer le coffre sans obtenir d'objet" },
			new string[1] { "Die Schatzkiste schließen, ohne einen Gegenstand zu entnehmen?" }
		}),
		new Entry("Reward.GetConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要获取“" },
			new string[1] { "確定要獲取“" },
			new string[1] { "Choose" },
			new string[2] { "」を入手します。", "よろしいですか？" },
			new string[1] { "Voulez-vous obtenir" },
			new string[1] { "entgegennehmen?" }
		}),
		new Entry("Reward.AlreadyOwned", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "已持有“", "”，无法再次获取。" },
			new string[2] { "已持有“", "”，無法再次獲取。" },
			new string[2] { "Unable to receive", ". You may not possess duplicate beast gear." },
			new string[1] { "」をすでに所持しているため、入手できません。" },
			new string[3] { "Impossible d'obtenir", ". Vous", "possédez déjà." },
			new string[2] { "Du besitzt", "bereits und kannst den Gegenstand deshalb kein weiteres Mal an dich nehmen." }
		}),
		new Entry("Reward.CrucibleFull", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "拿不了更多奇弈道具了。", "想获取“", "”，需要先清理出一个位置。" },
			new string[3] { "拿不了更多奇弈道具了。", "想獲取“", "”，需要先清理出一個位置。" },
			new string[2] { "You cannot carry any more crucible items. To receive", ", you must first discard an item from your inventory." },
			new string[2] { "クルーシブルアイテムをこれ以上持てません。", "」を入手するために、所持中のいずれかのクルーシブルアイテムを手放してください。" },
			new string[2] { "Vous ne pouvez plus porter davantage d'objets du Dédale. Pour recevoir", ", veuillez vous séparer d'un objet dans votre inventaire au préalable." },
			new string[2] { "Mehr Bändigerutensilien kannst du nicht tragen. Um", "zu erwerben, musst du dich zuerst von einem anderen trennen." }
		}),
		new Entry("Reward.GearFull", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "拿不了更多斗兽装备了。", "想获取“", "”，需要先清理出一个位置。" },
			new string[3] { "拿不了更多鬥獸裝備了。", "想獲取“", "”，需要先清理出一個位置。" },
			new string[2] { "You cannot carry any more beast gear. To receive", ", you must first discard a piece from your inventory." },
			new string[2] { "ビーストギアをこれ以上持てません。", "」を入手するために、所持中のいずれかのビーストギアを手放してください。" },
			new string[2] { "Vous ne pouvez plus porter davantage d'équipements de dressage. Pour recevoir", ", veuillez vous séparer d'une pièce d'équipement dans votre inventaire au préalable." },
			new string[2] { "Mehr Bestienausrüstung kannst du nicht tragen. Um", "an dich zu nehmen, musst du dich zuerst von einem anderen Stück Bestienausrüstung trennen." }
		}),
		new Entry("Reward.GearReplaceConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要获取“", "”替换掉“" },
			new string[2] { "確定要獲取“", "”替換掉“" },
			new string[2] { "Discard your", "in exchange for" },
			new string[3] { "」を手放して", "」を入手します。", "よろしいですか？" },
			new string[2] { "Jeter", "pour obtenir" },
			new string[2] { "wegwerfen und dafür", "an dich nehmen?" }
		}),
		new Entry("Reward.ItemReceived", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "已获得此道具。" },
			new string[1] { "已獲得此道具。" },
			new string[1] { "Acquired." },
			new string[1] { "このアイテムは獲得済みです。" },
			new string[1] { "Vous avez obtenu cet objet." },
			new string[1] { "Erhalten" }
		}),
		new Entry("Reward.CoinReceived", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "已获得斗兽币。" },
			new string[1] { "已獲得鬥獸幣。" },
			new string[1] { "Acquired." },
			new string[1] { "ビーストコインは獲得済みです。" },
			new string[1] { "Vous avez obtenu les jetons." },
			new string[1] { "Erhalten" }
		}),
		new Entry("Shop.Title", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "商店" },
			new string[1] { "商店" },
			new string[1] { "Shop" },
			new string[1] { "SHOP" },
			new string[1] { "Marchand" },
			new string[1] { "GESCHÄFT" }
		}),
		new Entry("Shop.Exit", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "结束" },
			new string[1] { "結束" },
			new string[1] { "Close" },
			new string[1] { "終了" },
			new string[1] { "Quitter" },
			new string[1] { "Beenden" }
		}),
		new Entry("Shop.ExitConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要结束购买吗？" },
			new string[1] { "確定要結束購買嗎？" },
			new string[1] { "Conclude purchasing and leave the shop?" },
			new string[1] { "アイテム購入を終了してよろしいですか？" },
			new string[1] { "Voulez-vous quitter l'échoppe du marchand" },
			new string[1] { "Das Einkaufen beenden?" }
		}),
		new Entry("Shop.PurchaseConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要购买“" },
			new string[1] { "確定要購買“" },
			new string[2] { "Purchase", "Choose the" },
			new string[2] { "」を購入します。", "よろしいですか？" },
			new string[1] { "Acheter" },
			new string[1] { "wirklich erwerben?" }
		}),
		new Entry("Shop.ReplaceConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要购买“", "”替换掉“" },
			new string[2] { "確定要購買“", "”替換掉“" },
			new string[2] { "Discard your", "to purchase" },
			new string[3] { "」を手放して", "」を購入します。", "よろしいですか？" },
			new string[2] { "Jeter", "pour acheter" },
			new string[2] { "wegwerfen und", "erwerben?" }
		}),
		new Entry("Shop.AlreadyOwned", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "已持有“", "”，无法重复购买。" },
			new string[2] { "已持有“", "”，無法重複購買。" },
			new string[2] { "Unable to purchase", ". You may not possess duplicate beast gear." },
			new string[1] { "」をすでに所持しているため、購入できません。" },
			new string[3] { "Impossible d'acheter", ". Vous", "possédez déjà." },
			new string[2] { "Du besitzt", "bereits und kannst den Gegenstand deshalb nicht erwerben." }
		}),
		new Entry("Shop.CrucibleFull", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "拿不了更多奇弈道具了。", "想购买“", "”，需要先清理出一个位置。" },
			new string[3] { "拿不了更多奇弈道具了。", "想購買“", "”，需要先清理出一個位置。" },
			new string[2] { "You cannot carry any more crucible items. To purchase", ", you must first discard an item from your inventory." },
			new string[2] { "クルーシブルアイテムをこれ以上持てません。", "」を購入するために、所持中のいずれかのクルーシブルアイテムを手放してください。" },
			new string[2] { "Vous ne pouvez plus porter davantage d'objets du Dédale. Pour acheter", ", veuillez vous séparer d'un objet dans votre inventaire au préalable." },
			new string[2] { "Mehr Bändigerutensilien kannst du nicht tragen. Um", "zu erwerben, musst du dich zuerst von einem anderen Utensil trennen." }
		}),
		new Entry("Shop.GearFull", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "拿不了更多斗兽装备了。", "想购买“", "”，需要先清理出一个位置。" },
			new string[3] { "拿不了更多鬥獸裝備了。", "想購買“", "”，需要先清理出一個位置。" },
			new string[2] { "You cannot carry any more beast gear. To purchase", ", you must first discard a different piece." },
			new string[2] { "ビーストギアをこれ以上持てません。", "」を購入するために、所持中のいずれかのビーストギアを手放してください。" },
			new string[2] { "Vous ne pouvez plus porter davantage d'équipements de dressage. Pour acheter", ", veuillez vous séparer d'une pièce d'équipement dans votre inventaire au préalable." },
			new string[2] { "Mehr Bestienausrüstung kannst du nicht tragen. Um", "an dich zu nehmen, musst du dich zuerst von einem anderen Stück Bestienausrüstung trennen." }
		}),
		new Entry("Shop.FeedPrompt", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要购买“", "”，喂给“" },
			new string[2] { "確定要購買“", "”，餵給“" },
			new string[2] { "Purchase", "and feed it to your" },
			new string[3] { "」を購入し、「", "」に与えます。", "よろしいですか？" },
			new string[2] { "Acheter", "donner à votre" },
			new string[1] { "erwerben und an folgende Bestie verfüttern:" }
		}),
		new Entry("Shop.SellButton", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "出售" },
			new string[1] { "出售" },
			new string[1] { "Sell" },
			new string[1] { "売る" },
			new string[1] { "Vendre" },
			new string[1] { "Verkaufen" }
		}),
		new Entry("Shop.SellConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "要卖掉“", "斗兽币吗？" },
			new string[2] { "要賣掉“", "鬥獸幣嗎？" },
			new string[2] { "Sell", "territory tokens?" },
			new string[2] { "」をビーストコイン", "枚で買い取ってもらいます。よろしいですか？" },
			new string[3] { "Vendre", "contre", "jetons bestiaux" },
			new string[1] { "Bestientaler verkaufen?" }
		}),
		new Entry("Shop.CoinName", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "斗兽币" },
			new string[1] { "鬥獸幣" },
			new string[1] { "Territory Tokens" },
			new string[1] { "ビーストコイン" },
			new string[1] { "Jetons bestiaux" },
			new string[1] { "Bestientaler" }
		}),
		new Entry("Shop.PouchDiscovery", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "“药师腰包”效果发动，发现了“" },
			new string[1] { "“藥師腰包”效果發動，發現了“" },
			new string[2] { "You find", "within your chemist's satchel!" },
			new string[2] { "「薬師のカバン」効果が発動し、「", "」を見つけました。" },
			new string[2] { "Vous avez trouvé", "dans votre sac d'alchimiste." },
			new string[2] { "Du findest", "in deinem Arzneibeutel." }
		}),
		new Entry("Tent.Rest", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "休息" },
			new string[1] { "休息" },
			new string[1] { "Rest" },
			new string[1] { "休息する" },
			new string[1] { "Vous reposer" },
			new string[1] { "Rasten" }
		}),
		new Entry("Tent.RestConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "确定要就这样休息吗？", "和你一起休息", "只让玩家休息" },
			new string[3] { "確定要就這樣休息嗎？", "和你一起休息", "只讓玩家休息" },
			new string[1] { "このまま休んでもよろしいですか？" },
			new string[1] { "このまま休んでもよろしいですか？" },
			new string[1] { "このまま休んでもよろしいですか？" },
			new string[1] { "このまま休んでもよろしいですか？" }
		}),
		new Entry("Tent.RestSoloConfirm", "contains", AllFragments: false, new string[6][]
		{
			null,
			null,
			new string[2] { "Rest alone while your familiars", "recover 90% of HP?" },
			new string[2] { "ペットを休息させず自分ひとりで休み、", "よろしいですか？" },
			null,
			null
		}),
		new Entry("Tent.LeaveConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要直接离开帐篷，不进行休息吗？" },
			new string[1] { "確定要直接離開帳篷，不進行休息嗎？" },
			new string[2] { "Leave the campsite without resting?", "You cannot return to the campsite after leaving." },
			new string[2] { "休息を行わずに、このままテントから立ち去ります。", "よろしいですか？" },
			new string[2] { "Quitter le campement sans vous reposer", "Attention, il est impossible de revenir une fois parti" },
			new string[2] { "Nicht übernachten?", "Wenn du das Zelt verlässt, kannst du nicht zu ihm zurückkehren." }
		}),
		new Entry("Tent.Info", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "可恢复玩家和", "只魔兽的体力。", "※喂食的食料效果会在休息后消失。" },
			new string[3] { "可恢復玩家和", "只魔獸的體力。", "※餵食的食料效果會在休息後消失。" },
			new string[1] { "You and" },
			new string[3] { "プレイヤーおよび", "体のペットのＨＰを回復できます。", "※フィードを食べた効果は休息後に消失します。" },
			new string[3] { "Vous et", "de vos bêtes pouvez récupérer des PV.", "Les bêtes perdront les effets des aliments." },
			new string[1] { "In diesem Zelt kannst du mit" }
		}),
		new Entry("Tent.FeedPrompt", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "”喂给哪个魔兽？" },
			new string[1] { "”餵給哪個魔獸？" },
			new string[2] { "Feed", "to whom?" },
			new string[2] { "どの魔獣に「", "」を与えますか？" },
			new string[1] { "À quelle bête voulez-vous donner" },
			new string[2] { "An welche Bestie soll", "verfüttert werden?" }
		}),
		new Entry("Treasure.Prompt", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "请选择想获取的临时道具。" },
			new string[1] { "請選擇想獲取的臨時道具。" },
			new string[1] { "A treasure coffer lies open. Choose the ephemeral item you wish to receive." },
			new string[1] { "入手したいテンポラリアイテムを選んでください。" },
			new string[1] { "Choisissez un des objets temporaires parmi la liste." },
			new string[1] { "Wähle einen der temporären Gegenstände aus." }
		}),
		new Entry("Treasure.AlreadyTaken", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "已获取此道具。" },
			new string[1] { "已獲取此道具。" },
			new string[1] { "Acquired." },
			new string[1] { "このアイテムは獲得済みです。" },
			new string[1] { "Vous avez obtenu cet objet." },
			new string[1] { "Erhalten." }
		}),
		new Entry("Treasure.ExitConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "确定要结束寻宝吗？" },
			null,
			null,
			null,
			null,
			null
		}),
		new Entry("Flee.Button", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "逃离" },
			new string[1] { "逃離" },
			new string[1] { "Flee" },
			new string[1] { "逃走する" },
			new string[1] { "S'enfuir" },
			new string[1] { "Fliehen" }
		}),
		new Entry("Flee.GearConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要使用斗兽装备“", "”的效果，逃离战斗吗？" },
			new string[2] { "確定要使用鬥獸裝備“", "”的效果，逃離戰鬥嗎？" },
			new string[2] { "Use your", "to flee from battle?" },
			new string[2] { "ビーストギア「", "」の効果を使い、戦闘から逃走しますか？" },
			new string[2] { "Utiliser l'effet de votre", "pour vous enfuir" },
			new string[1] { "benutzen, um aus dem Kampf zu fliehen?" }
		}),
		new Entry("Flee.ItemConfirm", "contains", AllFragments: false, new string[6][]
		{
			new string[2] { "确定要消耗奇弈道具“", "”，逃离战斗吗？" },
			new string[2] { "確定要消耗奇弈道具“", "”，逃離戰鬥嗎？" },
			new string[1] { "to flee from battle?" },
			new string[2] { "クルーシブルアイテム「", "」を消費して、戦闘から逃走しますか？" },
			new string[2] { "Utiliser", "pour vous enfuir" },
			new string[1] { "verbrauchen, um aus dem Kampf zu fliehen?" }
		}),
		new Entry("Results.NextPage", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "下一页" },
			new string[1] { "下一頁" },
			new string[1] { "Continue" },
			new string[1] { "次のページ" },
			new string[1] { "Page suivante" },
			new string[1] { "Nächste Seite" }
		}),
		new Entry("Results.Leave", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "退出" },
			new string[1] { "退出" },
			new string[1] { "Leave" },
			new string[1] { "退出" },
			new string[1] { "Quitter" },
			new string[1] { "Verlassen" }
		}),
		new Entry("Equip.ReplaceButton", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "替换" },
			new string[1] { "替換" },
			new string[1] { "Yes" },
			new string[1] { "代用する" },
			new string[1] { "Remplacer" },
			new string[1] { "Ja" }
		}),
		new Entry("Equip.ReplacePrompt.Main", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "没有发现该套装中主手上的", "。要用其他的", "替换该装备吗？" },
			new string[3] { "沒有發現該套裝中主手上的", "。要用其他的", "替換該裝備嗎？" },
			new string[1] { "registered to this gear set could not be found in your Armoury Chest. Replace it with another" },
			new string[3] { "メインアームに設定された", "と詳細情報が等しいアイテムがアーマリーチェストから見つかりませんでした。別の", "で代用しますがよろしいですか？" },
			new string[1] { "L'objet de la main directrice n'est pas dans l'arsenal. Le remplacer par un autre objet" },
			new string[2] { "Im Arsenal befindet sich", "mit den registrierten Parametern. Stattdessen einen leicht abweichenden Gegenstand für deine Haupthand verwenden?" }
		}),
		new Entry("Equip.ReplacePrompt.Suit", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "没有发现该套装中主手上的", "。要用适合同职业的", "替换该装备吗？" },
			new string[3] { "沒有發現該套裝中主手上的", "。要用適合同職業的", "替換該裝備嗎？" },
			new string[1] { "registered to this gear set could not be found in your Armoury Chest. Replace it with" },
			new string[3] { "メインアームに設定された", "と詳細情報が等しいアイテムがアーマリーチェストから見つかりませんでした。同じクラス・ジョブが装備可能な", "で代用しますがよろしいですか？" },
			new string[1] { "L'objet de la main directrice n'est pas dans l'arsenal. Le remplacer par" },
			new string[3] { "Im Arsenal befindet sich", "für deine Haupthand, aber", "wäre ebenfalls für deinen Job/deine Klasse geeignet. Diesen Gegenstand verwenden?" }
		}),
		new Entry("Equip.ReplacePrompt.No", "contains", AllFragments: false, new string[6][]
		{
			new string[3] { "该套装中主手上的", "无法进行装备。要用适合同职业的", "替换该装备吗？" },
			new string[3] { "該套裝中主手上的", "無法進行裝備。要用適合同職業的", "替換該裝備嗎？" },
			new string[1] { "registered to this gear set cannot be equipped. Replace it with" },
			new string[3] { "メインアームに設定された", "は現在装備できません。同じクラス・ジョブが装備可能な", "で代用しますがよろしいですか？" },
			new string[2] { "L'objet de la main directrice ne peut pas être équipé ac", "ment. Le remplacer par" },
			new string[2] { "für deine Haupthand kann momentan nicht angelegt werden, aber", "wäre ebenfalls für deinen Job/deine Klasse geeignet. Diesen Gegenstand verwenden?" }
		}),
		new Entry("Item.Use", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "使用" },
			new string[1] { "使用" },
			new string[1] { "Use" },
			new string[1] { "使う" },
			new string[1] { "Utiliser" },
			new string[1] { "Benutzen" }
		}),
		new Entry("Item.Discard", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "丢弃" },
			new string[1] { "丟棄" },
			new string[1] { "Discard" },
			new string[1] { "捨てる" },
			new string[1] { "Jeter" },
			new string[1] { "Wegwerfen" }
		}),
		new Entry("Bestiary.Title", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "魔兽图鉴" },
			new string[1] { "魔獸圖鑑" },
			new string[1] { "Master's Bestiary" },
			new string[1] { "MASTER‘S BESTIARY" },
			new string[1] { "Bestiaire de dresseur" },
			new string[1] { "BESTIENBUCH" }
		}),
		new Entry("Bestiary.Captured", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "捕获数量" },
			new string[1] { "捕獲數量" },
			new string[1] { "Beasts Captured" },
			new string[1] { "TOTAL PETS" },
			new string[1] { "Bêtes" },
			new string[1] { "Bestien" }
		}),
		new Entry("Bestiary.UnknownRow", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "？？？？" },
			new string[1] { "？？？？" },
			new string[1] { "???" },
			new string[1] { "？？？？" },
			new string[1] { "???" },
			new string[1] { "???" }
		}),
		new Entry("Bestiary.NoPact", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "尚未与该魔兽缔结契约。" },
			new string[1] { "尚未與該魔獸締結契約。" },
			new string[1] { "A pact has yet to be forged..." },
			new string[1] { "この魔獣とはまだ契約を結んでいません。" },
			new string[1] { "Cette bête n'a pas encore été capturée." },
			new string[1] { "Noch keinen Pakt geschlossen ..." }
		}),
		new Entry("Bestiary.OpenMenu", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "打开魔兽图鉴" },
			new string[1] { "打開魔獸圖鑑" },
			new string[1] { "Master's Bestiary" },
			new string[1] { "魔獣図鑑を開く" },
			new string[1] { "Bestiaire de dresseur" },
			new string[1] { "Bestienbuch öffnen" }
		}),
		new Entry("Job.Beastmaster", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "驯兽师" },
			new string[1] { "馴獸師" },
			new string[1] { "beastmaster" },
			new string[1] { "魔獣使い" },
			new string[1] { "dresseur" },
			new string[1] { "Bestienbändiger" }
		}),
		new Entry("Taxonomy.Beastkin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "百兽纲" },
			new string[1] { "百獸綱" },
			new string[1] { "Beastkin" },
			new string[1] { "百獣綱" },
			new string[1] { "Thériens" },
			new string[1] { "Biestling" }
		}),
		new Entry("Taxonomy.Vilekin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "百虫纲" },
			new string[1] { "百蟲綱" },
			new string[1] { "Vilekin" },
			new string[1] { "百蟲綱" },
			new string[1] { "Insectoïdes" },
			new string[1] { "Gezieferling" }
		}),
		new Entry("Taxonomy.Cloudkin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "有翼纲" },
			new string[1] { "有翼綱" },
			new string[1] { "Cloudkin" },
			new string[1] { "有翼綱" },
			new string[1] { "Ptériens" },
			new string[1] { "Wölkling" }
		}),
		new Entry("Taxonomy.Seedkin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "草木纲" },
			new string[1] { "草木綱" },
			new string[1] { "Seedkin" },
			new string[1] { "草木綱" },
			new string[1] { "Floréens" },
			new string[1] { "Saatling" }
		}),
		new Entry("Taxonomy.Wavekin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "水栖纲" },
			new string[1] { "水棲綱" },
			new string[1] { "Wavekin" },
			new string[1] { "水棲綱" },
			new string[1] { "Hydrides" },
			new string[1] { "Wogling" }
		}),
		new Entry("Taxonomy.Scalekin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "甲鳞纲" },
			new string[1] { "甲鱗綱" },
			new string[1] { "Scalekin" },
			new string[1] { "甲鱗綱" },
			new string[1] { "Cuirassiens" },
			new string[1] { "Schuppling" }
		}),
		new Entry("Taxonomy.Soulkin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "咒具纲" },
			new string[1] { "咒具綱" },
			new string[1] { "Soulkin" },
			new string[1] { "呪具綱" },
			new string[1] { "Animides" },
			new string[1] { "Ätherling" }
		}),
		new Entry("Taxonomy.Ashkin", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "死尸纲" },
			new string[1] { "死屍綱" },
			new string[1] { "Ashkin" },
			new string[1] { "死屍綱" },
			new string[1] { "Nécroïdes" },
			new string[1] { "Todling" }
		}),
		new Entry("Npc.LaudaBoss", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "魔斧之主 劳妲" },
			new string[1] { "魔斧之主 勞妲" },
			new string[1] { "Lauda the Spellcleaver" },
			new string[1] { "魔斧のラウダ" },
			new string[1] { "Lauda la hache habitée" },
			new string[1] { "Lauda [t] Spruchspalterin[p]" }
		}),
		new Entry("Bestiary.Detail.Appearance", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "当前外观" },
			new string[1] { "當前外觀" },
			new string[1] { "Appearance" },
			new string[1] { "外見設定" },
			new string[1] { "Taille" },
			new string[1] { "Aussehen" }
		}),
		new Entry("Bestiary.Detail.Release", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "释放（18级）" },
			new string[1] { "釋放（18級）" },
			new string[1] { "Tempered Release (Lv. 18)" },
			new string[1] { "はなつ(Lv18～)" },
			new string[1] { "Salve (Nv 18)" },
			new string[1] { "Entfesseln (St. 18)" }
		}),
		new Entry("Bestiary.Detail.Trick", "contains", AllFragments: false, new string[6][]
		{
			new string[1] { "大招（8级）" },
			new string[1] { "大招（8級）" },
			new string[1] { "Trick (Lv. 8)" },
			new string[1] { "おおわざ(Lv8～)" },
			new string[1] { "Assaut (Nv 8)" },
			new string[1] { "Dressur (St. 8)" }
		}),
		new Entry("Bestiary.Detail.Exp", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "经验值" },
			new string[1] { "經驗值" },
			new string[1] { "EXP" },
			new string[1] { "EXP" },
			new string[1] { "Exp" },
			new string[1] { "Routine" }
		}),
		new Entry("Bestiary.Detail.Strength", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "力量" },
			new string[1] { "力量" },
			new string[1] { "Strength" },
			new string[1] { "力" },
			new string[1] { "Force" },
			new string[1] { "Stärke" }
		}),
		new Entry("Bestiary.Detail.Intelligence", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "智力" },
			new string[1] { "智力" },
			new string[1] { "Intelligence" },
			new string[1] { "賢さ" },
			new string[1] { "Intelligence" },
			new string[1] { "Intelligenz" }
		}),
		new Entry("Bestiary.Detail.PhysRes", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "物理耐性" },
			new string[1] { "物理耐性" },
			new string[1] { "Phys. Resistance" },
			new string[1] { "物理耐性" },
			new string[1] { "Rés. physique" },
			new string[1] { "Phys. Resistenz" }
		}),
		new Entry("Bestiary.Detail.MagRes", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "魔法耐性" },
			new string[1] { "魔法耐性" },
			new string[1] { "Mag. Resistance" },
			new string[1] { "魔法耐性" },
			new string[1] { "Rés. magique" },
			new string[1] { "Mag. Resistenz" }
		}),
		new Entry("Bestiary.Detail.Constitution", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "耐力" },
			new string[1] { "耐力" },
			new string[1] { "Constitution" },
			new string[1] { "体力" },
			new string[1] { "Vitalité" },
			new string[1] { "Vitalität" }
		}),
		new Entry("Bestiary.Detail.Satiety", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "饱腹度" },
			new string[1] { "飽腹度" },
			new string[1] { "Satiety" },
			new string[1] { "満腹度" },
			new string[1] { "Satiété" },
			new string[1] { "Sättigung" }
		}),
		new Entry("Bestiary.Weakness.SingleTarget", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "单体攻击" },
			new string[1] { "單體攻擊" },
			new string[1] { "Single Target" },
			new string[1] { "単体攻撃" },
			new string[1] { "Cible unique" },
			new string[1] { "Einzelangriff" }
		}),
		new Entry("Bestiary.Weakness.AoE", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "范围攻击" },
			new string[1] { "範圍攻擊" },
			new string[1] { "Area of Effect" },
			new string[1] { "範囲攻撃" },
			new string[1] { "Aire d'effet" },
			new string[1] { "Flächenangriff" }
		}),
		new Entry("Bestiary.Weakness.Weakness", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "弱点" },
			new string[1] { "弱點" },
			new string[1] { "Weakness:" },
			new string[1] { "弱点" },
			new string[1] { "Faiblesse" },
			new string[1] { "Schwächen" }
		}),
		new Entry("Bestiary.Weakness.Vulnerabilities", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "有效异常状态" },
			new string[1] { "有效異常狀態" },
			new string[1] { "Vulnerabilities:" },
			new string[1] { "有効な状態異常" },
			new string[1] { "Vulnérabilités" },
			new string[1] { "Effektive Status" }
		}),
		new Entry("Bestiary.Weakness.Poison", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "中毒" },
			new string[1] { "中毒" },
			new string[1] { "Poison" },
			new string[1] { "毒" },
			new string[1] { "Poison" },
			new string[1] { "Gift" }
		}),
		new Entry("Route.ViewBonuses", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "额外奖励" },
			new string[1] { "額外獎勵" },
			new string[1] { "View Bonuses" },
			new string[1] { "ボーナス一覧" },
			new string[1] { "Liste des bonus" },
			new string[1] { "Boni ansehen" }
		}),
		new Entry("Party.AddToTeam", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "加入队伍" },
			new string[1] { "加入隊伍" },
			new string[1] { "Add to Team" },
			new string[1] { "パーティに加える" },
			new string[1] { "Ajouter à l'équipe" },
			new string[1] { "Zur Formation hinzufügen" }
		}),
		new Entry("Route.BonusList", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "额外奖励" },
			new string[1] { "額外獎勵" },
			new string[1] { "Bonuses" },
			new string[1] { "BONUS LIST" },
			new string[1] { "Liste des bonus" },
			new string[1] { "BONI" }
		}),
		new Entry("Common.Close", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "关闭" },
			new string[1] { "關閉" },
			new string[1] { "Close" },
			new string[1] { "閉じる" },
			new string[1] { "Fermer" },
			new string[1] { "Schließen" }
		}),
		new Entry("Entry.LatestScore", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "最近得分" },
			new string[1] { "最近得分" },
			new string[1] { "Latest" },
			new string[1] { "直近スコア" },
			new string[1] { "Actuel" },
			new string[1] { "Letzte" }
		}),
		new Entry("Entry.MenuActivity", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "斗兽奇弈" },
			null,
			null,
			null,
			null,
			null
		}),
		new Entry("Entry.MenuChallenge", "exact", AllFragments: false, new string[6][]
		{
			new string[1] { "挑战“斗兽奇弈”" },
			null,
			new string[1] { "Challenge the Crucible of the Unbroken." },
			new string[1] { "「闘獣練」に挑戦する" },
			null,
			null
		})
	};
}
