using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace Beastmaster.Core.Configuration;

public static class LegacyConfigurationReader
{
	public static T? Read<T>(string currentConfigFile) where T : class
	{
		if (File.Exists(currentConfigFile))
		{
			return null;
		}
		string path = Path.Combine(Path.GetDirectoryName(Path.GetFullPath(currentConfigFile)), "Beastmaster.json");
		if (!File.Exists(path))
		{
			return null;
		}
		JsonObject node = (JsonNode.Parse(File.ReadAllText(path)) as JsonObject) ?? throw new JsonException("旧 Beastmaster 配置不是有效的配置对象，未迁移或覆盖配置");
		RemoveTypeMetadata(node);
		return node.Deserialize<T>() ?? throw new JsonException("旧 Beastmaster 配置读取失败，未迁移或覆盖配置");
	}

	private static void RemoveTypeMetadata(JsonNode? node)
	{
		if (node is JsonObject jsonObject)
		{
			jsonObject.Remove("$type");
			{
				foreach (KeyValuePair<string, JsonNode> item in jsonObject)
				{
					RemoveTypeMetadata(item.Value);
				}
				return;
			}
		}
		if (!(node is JsonArray jsonArray))
		{
			return;
		}
		foreach (JsonNode item2 in jsonArray)
		{
			RemoveTypeMetadata(item2);
		}
	}
}
