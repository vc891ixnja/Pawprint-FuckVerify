using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRandomOutcomePreset
{
	public int Node { get; set; }

	public int Outcome { get; set; }

	public ArenaBattlePreset? Battle { get; set; }

	public List<uint>? ItemPriority { get; set; }

	public ArenaNodeResources? Resources { get; set; }
}
