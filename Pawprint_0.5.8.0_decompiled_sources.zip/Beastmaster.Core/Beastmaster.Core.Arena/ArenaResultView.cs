namespace Beastmaster.Core.Arena;

public sealed record ArenaResultView(ArenaResultPhase Phase, ArenaRunResult? Result = null);
