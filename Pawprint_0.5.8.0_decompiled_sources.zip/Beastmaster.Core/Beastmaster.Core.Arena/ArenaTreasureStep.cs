using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaTreasureStep(IArenaTreasureWorld world, IReadOnlyList<uint>? priority = null, IReadOnlyList<uint>? equipmentPriority = null, ArenaResourcePolicy? resources = null) : IWorkflowStep
{
	private readonly ArenaEquipmentExchange equipment = new ArenaEquipmentExchange(world.Equipment, equipmentPriority, resources);

	private readonly HashSet<uint> skipped = new HashSet<uint>();

	private bool exitSent;

	private bool exitConfirmed;

	private ArenaTreasureOption? pending;

	private readonly HashSet<uint> claimed = new HashSet<uint>();

	private ArenaTreasurePhase? lastPhase;

	private TimeSpan deadlineAt;

	private TimeSpan nextAttempt;

	private TimeSpan? returnedAt;

	private bool selected;

	private bool confirmed;

	private bool dismissed;

	public string Name { get; private set; } = "宝箱 · 读取奖励";

	public TimeSpan Timeout => TimeSpan.FromMinutes(2L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed >= Timeout)
		{
			throw new TimeoutException("宝箱处理超时");
		}
		if (equipment.Tick(elapsed, out ArenaEquipmentOutcome outcome))
		{
			Name = equipment.Name;
			deadlineAt = elapsed;
			return StepResult.Running;
		}
		if (outcome != null)
		{
			deadlineAt = elapsed;
			selected = (confirmed = (dismissed = false));
			pending = null;
			if (outcome.Accepted)
			{
				claimed.Add(outcome.ItemId);
			}
			else
			{
				skipped.Add(outcome.ItemId);
			}
		}
		ArenaTreasureView view = world.Read();
		if (lastPhase != view.Phase)
		{
			lastPhase = view.Phase;
			deadlineAt = elapsed;
		}
		if (elapsed - deadlineAt > TimeSpan.FromSeconds((view.Phase == ArenaTreasurePhase.Loading) ? 60 : 15))
		{
			throw new TimeoutException(Name + "，未收到操作结果");
		}
		if (view.Phase == ArenaTreasurePhase.Loading)
		{
			returnedAt = null;
			return StepResult.Running;
		}
		if (view.Phase == ArenaTreasurePhase.Blocked)
		{
			throw new InvalidOperationException("宝箱界面已变化");
		}
		if (view.Phase == ArenaTreasurePhase.Returned)
		{
			if (claimed.Count == 0 && !exitConfirmed && !exitSent)
			{
				throw new InvalidOperationException("宝箱未确认领取就已关闭");
			}
			TimeSpan valueOrDefault = returnedAt.GetValueOrDefault();
			if (!returnedAt.HasValue)
			{
				valueOrDefault = elapsed;
				returnedAt = valueOrDefault;
			}
			TimeSpan? timeSpan = returnedAt;
			if (elapsed - timeSpan < TimeSpan.FromSeconds(2L))
			{
				return StepResult.Running;
			}
			Name = ((claimed.Count > 0) ? "宝箱 · 已领取" : "宝箱 · 已结束领取");
			return StepResult.Completed;
		}
		returnedAt = null;
		if (view.Phase == ArenaTreasurePhase.Confirmation)
		{
			if (ArenaTreasureDecoder.IsExitPrompt(view.Prompt) && exitSent)
			{
				if (!exitConfirmed && Attempt(() => world.TryConfirmExit(view.Prompt), elapsed))
				{
					exitConfirmed = true;
				}
				return StepResult.Running;
			}
			if (confirmed || dismissed)
			{
				return StepResult.Running;
			}
			ArenaTreasureOption arenaTreasureOption = pending ?? Choose(view.Contents);
			ArenaTreasureOption actual = view.Contents.Options.FirstOrDefault((ArenaTreasureOption o) => ArenaTreasureDecoder.MatchesPrompt(view.Prompt, o.ItemId)) ?? throw new InvalidOperationException("不是当前宝箱奖励的确认窗口：" + view.Prompt);
			bool yes = actual.ItemId == arenaTreasureOption?.ItemId && Eligible(view.Contents, actual);
			Name = (yes ? ("宝箱 · 领取" + ArenaItemCatalog.Items[arenaTreasureOption.ItemId].Name) : "宝箱 · 返回选择奖励");
			if (Attempt(() => world.TryAnswer(actual.ItemId, yes), elapsed))
			{
				if (yes)
				{
					pending = arenaTreasureOption;
					confirmed = true;
					claimed.Add(arenaTreasureOption.ItemId);
				}
				else
				{
					dismissed = true;
				}
				deadlineAt = elapsed;
			}
			return StepResult.Running;
		}
		if (dismissed)
		{
			dismissed = (selected = false);
			pending = null;
		}
		if (confirmed)
		{
			if (pending != null && view.Contents.Options.Any((ArenaTreasureOption o) => o.ItemId == pending.ItemId) && !((ReadOnlySpan<uint>)view.Contents.Equipment).Contains(pending.ItemId))
			{
				return StepResult.Running;
			}
			confirmed = (selected = false);
			pending = null;
		}
		if (selected || exitSent)
		{
			return StepResult.Running;
		}
		pending = Choose(view.Contents);
		if (pending == null)
		{
			Name = "宝箱 · 结束领取";
			if (Attempt(world.TryExit, elapsed))
			{
				exitSent = true;
			}
			return StepResult.Running;
		}
		Name = "宝箱 · 选择" + ArenaItemCatalog.Items[pending.ItemId].Name;
		if (Attempt(() => world.TryChoose(pending), elapsed))
		{
			selected = true;
			deadlineAt = elapsed;
		}
		return StepResult.Running;
	}

	private ArenaTreasureOption? Choose(ArenaTreasureContents contents)
	{
		HashSet<uint> hashSet = claimed.Concat(skipped).ToHashSet();
		if (resources != null)
		{
			ArenaTreasureOption[] options = contents.Options;
			foreach (ArenaTreasureOption arenaTreasureOption in options)
			{
				if (resources.CanAcquire(arenaTreasureOption.ItemId) && ArenaItemCatalog.Items[arenaTreasureOption.ItemId].Category != 3)
				{
					if (ArenaItemCatalog.Items[arenaTreasureOption.ItemId].Category != 2)
					{
						continue;
					}
					uint[] ownedItems = contents.OwnedItems;
					if (ownedItems == null || ownedItems.Length < 10)
					{
						continue;
					}
				}
				hashSet.Add(arenaTreasureOption.ItemId);
			}
		}
		if (world.Equipment != null)
		{
			ArenaTreasureOption[] options = contents.Options;
			foreach (ArenaTreasureOption arenaTreasureOption2 in options)
			{
				if (ArenaItemCatalog.Items[arenaTreasureOption2.ItemId].Category == 1 && !(resources?.CanEquip(arenaTreasureOption2.ItemId, (IReadOnlyCollection<uint>)(object)contents.Equipment) ?? ArenaEquipmentPolicy.CanAcquire(arenaTreasureOption2.ItemId, (IReadOnlyCollection<uint>)(object)contents.Equipment, equipmentPriority)))
				{
					hashSet.Add(arenaTreasureOption2.ItemId);
				}
			}
		}
		IReadOnlyList<uint> readOnlyList = resources?.Order ?? priority;
		ArenaResourcePolicy? arenaResourcePolicy = resources;
		if (arenaResourcePolicy != null && arenaResourcePolicy.Resources.UnifiedPriorities)
		{
			readOnlyList = readOnlyList.OrderBy(delegate(uint id)
			{
				ArenaResourcePolicy? arenaResourcePolicy2 = resources;
				int equipmentCount = contents.Equipment.Length;
				uint[]? ownedItems2 = contents.OwnedItems;
				return arenaResourcePolicy2.CategoryRank(id, equipmentCount, (ownedItems2 != null) ? ownedItems2.Length : 10);
			}).ToArray();
		}
		return ArenaTreasurePolicy.Choose(contents, hashSet, readOnlyList);
	}

	private bool Eligible(ArenaTreasureContents contents, ArenaTreasureOption option)
	{
		if (resources == null)
		{
			return true;
		}
		if (!resources.CanAcquire(option.ItemId))
		{
			return false;
		}
		switch (ArenaItemCatalog.Items[option.ItemId].Category)
		{
		case 1:
			return resources.CanEquip(option.ItemId, (IReadOnlyCollection<uint>)(object)contents.Equipment);
		case 2:
		{
			uint[] ownedItems = contents.OwnedItems;
			return ownedItems == null || ownedItems.Length < 10;
		}
		default:
			return false;
		}
	}

	private bool Attempt(Func<bool> action, TimeSpan elapsed)
	{
		if (elapsed < nextAttempt)
		{
			return false;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		return action();
	}

	public void Cancel()
	{
	}
}
