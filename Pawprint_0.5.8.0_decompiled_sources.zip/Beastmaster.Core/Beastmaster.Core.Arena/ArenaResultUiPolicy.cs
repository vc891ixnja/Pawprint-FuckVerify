using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaResultUiPolicy
{
	public static ArenaResultPhase ButtonPhase(string? label)
	{
		if (GameText.Matches("Results.NextPage", label))
		{
			return ArenaResultPhase.NextPage;
		}
		if (GameText.Matches("Results.Leave", label))
		{
			return ArenaResultPhase.ExitPage;
		}
		return ArenaResultPhase.Loading;
	}
}
