using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRosterSettings
{
	public ulong ContentId { get; set; }

	public List<uint> Numbers { get; set; } = new List<uint>();

	public List<uint> Pets { get; set; } = new List<uint>();

	public bool MigrateLegacyIds(MonsterCatalog catalog)
	{
		List<uint> pets = Pets;
		if (pets == null || pets.Count <= 0)
		{
			return false;
		}
		Dictionary<uint, uint> byPetId = catalog.Monsters.ToDictionary((MonsterEntry m) => m.PetId, (MonsterEntry m) => (uint)m.Number);
		pets = Numbers;
		if (pets == null || pets.Count <= 0)
		{
			Numbers = (from id in Pets.Where(byPetId.ContainsKey)
				select byPetId[id]).Distinct().Take(10).ToList();
		}
		Pets = new List<uint>();
		return true;
	}
}
