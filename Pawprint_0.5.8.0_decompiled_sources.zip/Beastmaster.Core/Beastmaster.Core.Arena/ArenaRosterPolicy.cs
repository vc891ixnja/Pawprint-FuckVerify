using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaRosterPolicy
{
	public static uint[] Select(IEnumerable<uint> unlocked, IEnumerable<uint> current, IEnumerable<uint>? preferred = null, int capacity = 10)
	{
		HashSet<uint> hashSet = unlocked.Where((uint id) => id >= 1 && id <= 50).ToHashSet();
		if ((capacity < 1 || capacity > 15) ? true : false)
		{
			throw new ArgumentOutOfRangeException("capacity");
		}
		uint[] array = preferred?.Distinct().Take(capacity).ToArray();
		uint[] obj = ((array != null && array.Length > 0) ? array.Where(hashSet.Contains).ToArray() : current.Where(hashSet.Contains).Concat(hashSet.Order()).Distinct()
			.Take(capacity)
			.ToArray());
		if (obj.Length == 0)
		{
			throw new InvalidOperationException((array != null && array.Length > 0) ? ("所选魔兽未解锁（图鉴编号：" + string.Join(", ", array) + "），请重新读取图鉴或调整编组") : "没有已解锁的魔兽可用于斗兽编组");
		}
		return obj;
	}
}
