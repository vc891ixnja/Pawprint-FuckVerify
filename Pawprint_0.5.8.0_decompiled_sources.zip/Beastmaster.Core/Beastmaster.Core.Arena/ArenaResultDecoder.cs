using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaResultDecoder
{
	public const uint LowCrystalItem = 51734u;

	public const uint HighCrystalItem = 51735u;

	public static ArenaRunResult Decode(IReadOnlyList<ArenaValue> values, ArenaStage stage)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue x) => x.Index);
		if (!string.IsNullOrWhiteSpace(v.GetValueOrDefault(0)?.Text))
		{
			long? num = N(68);
			if (num.HasValue)
			{
				long valueOrDefault = num.GetValueOrDefault();
				if (valueOrDefault >= 0 && valueOrDefault <= uint.MaxValue)
				{
					switch (N(47))
					{
					case 0L:
					case 1L:
					case 2L:
					case 3L:
					case 4L:
					case 5L:
					{
						uint num2 = 0u;
						uint num3 = 0u;
						int num4 = 0;
						while (num4 < N(47))
						{
							long? num5 = N(48 + num4);
							long? num6 = N(63 + num4);
							if (num5.HasValue)
							{
								valueOrDefault = num5.GetValueOrDefault();
								if (valueOrDefault > 0 && valueOrDefault <= uint.MaxValue && num6.HasValue)
								{
									valueOrDefault = num6.GetValueOrDefault();
									if (valueOrDefault >= 0 && valueOrDefault <= uint.MaxValue)
									{
										checked
										{
											if (num5 == 51734u)
											{
												num2 += (uint)num6.Value;
											}
											if (num5 == 51735u)
											{
												num3 += (uint)num6.Value;
											}
										}
										num4++;
										continue;
									}
								}
							}
							throw new InvalidOperationException("斗兽结算奖励未就绪");
						}
						if ((stage.Id <= 3 && num3 != 0) || (stage.Id >= 4 && num2 != 0))
						{
							throw new InvalidOperationException("结算兽核晶种类与奇盘不一致");
						}
						string rating = (from x in values
							where !string.IsNullOrWhiteSpace(x.Text) && IsRatingTitle(x.Text)
							select x.Text.Trim()).FirstOrDefault();
						return new ArenaRunResult(stage.Id, (uint)N(68).Value, num2, num3, Failed: false, rating);
					}
					}
				}
			}
		}
		throw new InvalidOperationException("斗兽结算数据未就绪");
		long? N(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	private static bool IsRatingTitle(string text)
	{
		return GameText.Fragments("Job.Beastmaster").Any((string f) => !string.IsNullOrEmpty(f) && text.TrimEnd().EndsWith(f.Trim(), StringComparison.OrdinalIgnoreCase));
	}
}
