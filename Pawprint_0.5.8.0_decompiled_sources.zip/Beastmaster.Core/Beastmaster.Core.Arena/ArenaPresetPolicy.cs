using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaPresetPolicy
{
	public static int Priority(IReadOnlyList<uint>? priority, uint item)
	{
		if (priority != null)
		{
			for (int i = 0; i < priority.Count; i++)
			{
				if (priority[i] == item)
				{
					return i;
				}
			}
		}
		return int.MaxValue;
	}

	public static uint[] ResolveFlutes(IReadOnlyList<ArenaPet> pets, IReadOnlyList<uint>? roster, ArenaBattlePreset? battle)
	{
		HashSet<uint> hashSet = (from p in pets
			where p.Hp != 0
			select p.PetId).ToHashSet();
		uint[] source = (roster ?? Array.Empty<uint>()).Concat(from p in pets
			orderby p.Row
			select p.PetId).Distinct().Where(hashSet.Contains)
			.ToArray();
		if (battle == null)
		{
			return source.Take(3).ToArray();
		}
		uint[] array = new uint[3];
		HashSet<uint> used = new HashSet<uint>();
		for (int num = 0; num < 2; num++)
		{
			for (int num2 = 0; num2 < 3; num2++)
			{
				if (array[num2] == 0)
				{
					ArenaFluteChoice arenaFluteChoice = battle.Flutes.ElementAtOrDefault(num2);
					uint num3 = ((num != 0) ? (arenaFluteChoice?.B ?? 0) : (arenaFluteChoice?.A ?? 0));
					if (hashSet.Contains(num3) && used.Add(num3))
					{
						array[num2] = num3;
					}
				}
			}
		}
		for (int num4 = 0; num4 < 3; num4++)
		{
			if (array[num4] == 0)
			{
				uint num5 = source.FirstOrDefault((uint id) => !used.Contains(id));
				if (num5 != 0)
				{
					array[num4] = num5;
					used.Add(num5);
				}
			}
		}
		return array.Where((uint id) => id != 0).ToArray();
	}

	public static int? Next(ArenaPreset preset, int current)
	{
		ArenaStageMap map = ArenaMaps.Get(preset.StageId);
		int[] next = map.Nodes[current].Next;
		if (next.Length == 0)
		{
			return null;
		}
		if (next.Length == 1)
		{
			return next[0];
		}
		if (preset.BranchTargets.TryGetValue(current, out var value) && ((ReadOnlySpan<int>)next).Contains(value))
		{
			return value;
		}
		ArenaRoutePreference valueOrDefault = preset.Branches.GetValueOrDefault(current, preset.Route);
		switch (valueOrDefault)
		{
		case ArenaRoutePreference.Right:
			return next[^1];
		case ArenaRoutePreference.Left:
			return next[0];
		default:
		{
			ArenaTileKind desired = ((valueOrDefault == ArenaRoutePreference.Treasure) ? ArenaTileKind.Treasure : ArenaTileKind.Camp);
			HashSet<int>[] array = next.Select(map.Reachable).ToArray();
			HashSet<int> second = array.Skip(1).Aggregate(array[0].ToHashSet(), delegate(HashSet<int> set, HashSet<int> path)
			{
				set.IntersectWith(path);
				return set;
			});
			for (int num = 0; num < next.Length; num++)
			{
				if (array[num].Except(second).Any((int n) => map.Nodes[n].Kind == desired))
				{
					return next[num];
				}
			}
			return next[0];
		}
		}
	}
}
