using System;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaFoodStep(IArenaFoodWorld world) : IWorkflowStep
{
	public static readonly TimeSpan Threshold = TimeSpan.FromMinutes(15L);

	public string Name { get; private set; } = "斗兽 · 检查食物";

	public TimeSpan Timeout => TimeSpan.FromSeconds(20L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (!world.Enabled)
		{
			Name = "斗兽 · 未启用使用食物";
			return StepResult.Completed;
		}
		if (elapsed >= Timeout)
		{
			Name = "斗兽 · 等待食物生效超时，继续任务";
			return StepResult.Completed;
		}
		ArenaFoodView arenaFoodView = world.Read();
		if (arenaFoodView.InDuty)
		{
			Name = "斗兽 · 已在奇盘内，跳过食物";
			return StepResult.Completed;
		}
		if (arenaFoodView.Remaining >= Threshold)
		{
			Name = $"斗兽 · 食物剩余 {arenaFoodView.Remaining:mm\\:ss}";
			return StepResult.Completed;
		}
		if (!arenaFoodView.HasFood)
		{
			Name = "斗兽 · 背包中没有炖剑山芋或焦糖爆米花";
			return StepResult.Completed;
		}
		if (arenaFoodView.Occupied)
		{
			Name = "斗兽 · 等待可以进食的时机";
			return StepResult.Running;
		}
		Name = $"斗兽 · 使用食物（增益剩余 {arenaFoodView.Remaining:mm\\:ss}）";
		world.TryEat();
		return StepResult.Running;
	}

	public void Cancel()
	{
	}
}
