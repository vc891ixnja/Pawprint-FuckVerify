namespace Beastmaster.Core.Arena;

public sealed record ArenaClearMenuRow(int Row, string[] Labels, bool Enabled);
