namespace Beastmaster.Core.Arena;

public sealed record ArenaEquipmentContents(uint Incoming, ArenaEquipmentSlot[] Slots);
