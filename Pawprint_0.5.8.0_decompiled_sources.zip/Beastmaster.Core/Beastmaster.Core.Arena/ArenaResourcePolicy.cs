using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public sealed class ArenaResourcePolicy(ArenaPreset preset, int? node = null, ArenaTileKind kind = ArenaTileKind.Battle, int? outcome = null)
{
	public ArenaResources Resources => preset.Resources;

	public ArenaNodeResources Rules
	{
		get
		{
			int? num = node;
			if (num.HasValue)
			{
				int n = num.GetValueOrDefault();
				num = outcome;
				if (num.HasValue)
				{
					int o = num.GetValueOrDefault();
					return preset.RandomOutcomes.FirstOrDefault((ArenaRandomOutcomePreset x) => x.Node == n && x.Outcome == o)?.Resources ?? Default;
				}
			}
			num = node;
			if (num.HasValue)
			{
				int valueOrDefault = num.GetValueOrDefault();
				if (Resources.Nodes.TryGetValue(valueOrDefault, out ArenaNodeResources value))
				{
					return value;
				}
			}
			return Default;
		}
	}

	private ArenaNodeResources Default
	{
		get
		{
			if (kind != ArenaTileKind.Shop)
			{
				return Resources.Rewards;
			}
			return Resources.Shop;
		}
	}

	public ArenaAcquisitionPriority Source
	{
		get
		{
			if (kind != ArenaTileKind.Shop)
			{
				if (kind != ArenaTileKind.Treasure)
				{
					return Resources.BattleRewards;
				}
				return Resources.TreasureRewards;
			}
			return Resources.Purchases;
		}
	}

	public int RestBelowPercent => Math.Clamp(Rules.RestBelowPercent, 1, 100);

	public ArenaResourcePolicy TriggeredRewards => new ArenaResourcePolicy(preset);

	public bool CanRest
	{
		get
		{
			if (!Resources.NoRest)
			{
				return Rules.Rest;
			}
			return false;
		}
	}

	public bool SellDisabled => Rules.SellDisabled;

	private IReadOnlyList<uint> EquipmentOrder
	{
		get
		{
			if (!Resources.SourcePriorities)
			{
				return preset.EquipmentPriority;
			}
			return Order.Where((uint id) => ArenaItemCatalog.Items[id].Category == 1).ToArray();
		}
	}

	public IReadOnlyList<uint> Order
	{
		get
		{
			if (!Resources.SourcePriorities)
			{
				if (!Resources.UnifiedPriorities)
				{
					int? num = outcome;
					if (num.HasValue)
					{
						int o = num.GetValueOrDefault();
						num = node;
						if (num.HasValue)
						{
							int n = num.GetValueOrDefault();
							List<uint> list = preset.RandomOutcomes.FirstOrDefault((ArenaRandomOutcomePreset x) => x.Node == n && x.Outcome == o)?.ItemPriority;
							if (list != null)
							{
								return list;
							}
						}
					}
					if (kind != ArenaTileKind.Shop)
					{
						return preset.TreasureOrder(node);
					}
					return preset.PurchaseOrder(node);
				}
				return Rules.Categories.SelectMany((int category) => (category != 1) ? (from id in ArenaPriorityOrder.Complete(Resources.SupplyPriority, ArenaPriorityKind.Supplies)
					where ArenaItemCatalog.Items[id].Category == category
					select id) : ArenaEquipmentPolicy.Complete(preset.EquipmentPriority)).ToArray();
			}
			return ArenaPriorityOrder.Complete(Rules.Priority ?? Source.Order, (kind != ArenaTileKind.Shop) ? ArenaPriorityKind.Rewards : ArenaPriorityKind.Shop);
		}
	}

	public bool IsSellCandidate(uint id)
	{
		ArenaItem value = default(ArenaItem);
		bool flag = SellDisabled && ArenaItemCatalog.Items.TryGetValue(id, out value);
		if (flag)
		{
			int category = value.Category;
			bool flag2 = (uint)(category - 1) <= 1u;
			flag = flag2;
		}
		if (flag)
		{
			if (!Resources.IsDisabled(id))
			{
				return Source.Disabled.Contains(id);
			}
			return true;
		}
		return false;
	}

	public bool CanAcquire(uint id)
	{
		ArenaItem value;
		bool flag = ArenaItemCatalog.Items.TryGetValue(id, out value) && !Resources.IsDisabled(id) && (!Resources.SourcePriorities || !Source.Disabled.Contains(id));
		if (flag)
		{
			flag = value.Category switch
			{
				1 => !Resources.NoEquipment && Rules.Equipment, 
				2 => Rules.Items, 
				3 => !Resources.NoFeeding && Rules.Food && !Resources.IsDisabled(id), 
				_ => false, 
			};
		}
		return flag;
	}

	public bool CanUse(uint id, int bagCount)
	{
		if (!Resources.NoItems && !Resources.DisabledUse.Contains(id) && ArenaItemCatalog.Items.TryGetValue(id, out ArenaItem value) && value.Category == 2)
		{
			if (Resources.ReserveTargetItems)
			{
				return bagCount > Resources.TargetItems;
			}
			return true;
		}
		return false;
	}

	public bool CanAfford(ArenaShopContents shop, ArenaShopOffer offer, uint spent)
	{
		uint num = Math.Max(Resources.ReserveCoins, Rules.ReserveCoins);
		if (CanAcquire(offer.ItemId) && (!Resources.NoSpending || offer.Price == 0) && (offer.Price == 0 || (shop.Balance >= num && offer.Price <= shop.Balance - num)))
		{
			if (Rules.Budget != 0)
			{
				if (spent <= Rules.Budget)
				{
					return offer.Price <= Rules.Budget - spent;
				}
				return false;
			}
			return true;
		}
		return false;
	}

	public ArenaEquipmentSlot? Replace(ArenaEquipmentContents contents)
	{
		if (CanAcquire(contents.Incoming))
		{
			return ArenaEquipmentPolicy.Replace(contents, EquipmentOrder);
		}
		return null;
	}

	public bool CanEquip(uint id, IReadOnlyCollection<uint> owned)
	{
		if (CanAcquire(id))
		{
			return ArenaEquipmentPolicy.CanAcquire(id, owned, EquipmentOrder);
		}
		return false;
	}

	public int CategoryRank(uint id, int equipmentCount, int itemCount)
	{
		if (Resources.SourcePriorities || !Resources.UnifiedPriorities)
		{
			return 0;
		}
		int category = ArenaItemCatalog.Items[id].Category;
		bool num;
		if (category != 1)
		{
			if (category != 2)
			{
				goto IL_0058;
			}
			num = itemCount < Resources.TargetItems;
		}
		else
		{
			num = equipmentCount < Resources.TargetEquipment;
		}
		if (!num)
		{
			goto IL_0058;
		}
		int num2 = 0;
		goto IL_005c;
		IL_0058:
		num2 = 3;
		goto IL_005c;
		IL_005c:
		return num2 + Array.IndexOf(Rules.Categories, category);
	}

	public bool Before(ArenaShopOffer a, ArenaShopOffer b, ArenaShopContents shop)
	{
		int num = CategoryRank(a.ItemId, shop.EquipmentCount, shop.BagCount).CompareTo(CategoryRank(b.ItemId, shop.EquipmentCount, shop.BagCount));
		if (num != 0)
		{
			return num < 0;
		}
		IReadOnlyList<uint> order = Order;
		int num2 = ShopRank(a, shop).CompareTo(ShopRank(b, shop));
		if (num2 != 0)
		{
			return num2 < 0;
		}
		return ArenaPresetPolicy.Priority(order, a.ItemId) < ArenaPresetPolicy.Priority(order, b.ItemId);
	}

	public long ShopRank(ArenaShopOffer offer, ArenaShopContents shop)
	{
		if (!Resources.SourcePriorities)
		{
			return PurchaseRank(offer, shop.EquipmentCount, shop.BagCount, Order);
		}
		IReadOnlyList<uint> order = Order;
		ArenaShopOffer[] offers = shop.Offers.OrderBy((ArenaShopOffer o) => ArenaPresetPolicy.Priority(order, o.ItemId)).ToArray();
		int category;
		for (category = 1; category <= 3; category++)
		{
			ArenaPurchaseSort arenaPurchaseSort = ((category == 1) ? Rules.EquipmentSort : ((category == 2) ? Rules.ItemSort : Rules.FoodSort));
			if (arenaPurchaseSort == ArenaPurchaseSort.Price || (arenaPurchaseSort == ArenaPurchaseSort.FillThenPriority && ((category == 1) ? (shop.EquipmentCount < Resources.TargetEquipment) : (shop.BagCount < Resources.TargetItems))))
			{
				int[] array = (from i in Enumerable.Range(0, offers.Length)
					where ArenaItemCatalog.Items[offers[i].ItemId].Category == category
					select i).ToArray();
				ArenaShopOffer[] array2 = (from i in array
					select offers[i] into o
					orderby o.Price, ArenaPresetPolicy.Priority(order, o.ItemId)
					select o).ToArray();
				for (int num = 0; num < array.Length; num++)
				{
					offers[array[num]] = array2[num];
				}
			}
		}
		int num2 = Array.FindIndex(offers, (ArenaShopOffer o) => o.ItemId == offer.ItemId);
		return (num2 < 0) ? int.MaxValue : num2;
	}

	public long PurchaseRank(ArenaShopOffer offer, int equipmentCount, int itemCount, IReadOnlyList<uint> order)
	{
		int category = ArenaItemCatalog.Items[offer.ItemId].Category;
		ArenaPurchaseSort arenaPurchaseSort = category switch
		{
			1 => Rules.EquipmentSort, 
			2 => Rules.ItemSort, 
			_ => Rules.FoodSort, 
		};
		int num = ((category == 1) ? Resources.TargetEquipment : Resources.TargetItems);
		int num2 = ((category == 1) ? equipmentCount : itemCount);
		if (arenaPurchaseSort != ArenaPurchaseSort.Price && (arenaPurchaseSort != ArenaPurchaseSort.FillThenPriority || num2 >= num))
		{
			return ArenaPresetPolicy.Priority(order, offer.ItemId);
		}
		return offer.Price;
	}
}
