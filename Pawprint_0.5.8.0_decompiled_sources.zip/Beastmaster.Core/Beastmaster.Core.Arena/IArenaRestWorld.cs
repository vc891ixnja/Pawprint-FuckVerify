namespace Beastmaster.Core.Arena;

public interface IArenaRestWorld
{
	IArenaEquipmentWorld? Equipment => null;

	IArenaRewardWorld? Rewards => null;

	bool TryLeave()
	{
		return false;
	}

	bool TryConfirmLeave()
	{
		return false;
	}

	ArenaRestView Read();

	bool TryToggle(uint number);

	bool TryRest();

	bool TryConfirm(uint[] numbers);

	bool TryDismissConfirmation();

	bool TryTakeReward();

	bool TryConfirmReward();

	void Dump(string reason)
	{
	}
}
