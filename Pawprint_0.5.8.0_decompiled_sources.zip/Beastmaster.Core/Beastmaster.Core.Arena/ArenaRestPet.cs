namespace Beastmaster.Core.Arena;

public sealed record ArenaRestPet(int Row, uint Number, string Name, uint Hp, uint MaxHp, bool Selected);
