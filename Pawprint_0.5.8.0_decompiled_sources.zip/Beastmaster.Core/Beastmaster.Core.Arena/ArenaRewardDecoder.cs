using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaRewardDecoder
{
	public static ArenaRewardContents Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue x) => x.Index);
		bool flag = N(0) != 1 || !v.ContainsKey(127);
		bool flag2;
		if (!flag)
		{
			long? num = N(3);
			if (num.HasValue)
			{
				long valueOrDefault = num.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag2 = true;
					goto IL_0090;
				}
			}
			flag2 = false;
			goto IL_0090;
		}
		goto IL_0096;
		IL_00f9:
		bool flag3;
		if (flag3)
		{
			throw new InvalidOperationException("战利品列表未就绪");
		}
		List<ArenaTreasureOption> list = new List<ArenaTreasureOption>();
		List<uint> list2 = new List<uint>();
		for (int num2 = 0; num2 < 4; num2++)
		{
			long? num = N(6 + 5 * num2);
			if (num.HasValue)
			{
				long valueOrDefault = num.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag3 = true;
					goto IL_014b;
				}
			}
			flag3 = false;
			goto IL_014b;
			IL_014b:
			if (!flag3)
			{
				throw new InvalidOperationException("战利品标记未就绪");
			}
			if (N(6 + 5 * num2) == 1)
			{
				list.Add(new ArenaTreasureOption(num2, Item(9 + 5 * num2)));
			}
		}
		for (int num3 = 0; num3 < 10; num3++)
		{
			long? num = N(30 + 5 * num3);
			if (num.HasValue && num.GetValueOrDefault() > 0)
			{
				list2.Add(Item(30 + 5 * num3, 2));
			}
			if (N(78 + 5 * num3) == 1)
			{
				list2.Add(Item(81 + 5 * num3, 1));
			}
			else if (N(78 + 5 * num3) != 0)
			{
				throw new InvalidOperationException("战利品装备栏未就绪");
			}
		}
		return new ArenaRewardContents(N(3) == 1 && N(5) == 0, (N(3) == 1) ? CoinAmount(v[4].Text ?? "") : 0u, ArenaShopDecoder.Price(v[2].Text ?? ""), list.ToArray(), list2.ToArray());
		IL_0096:
		flag3 = flag;
		bool flag4;
		if (!flag3)
		{
			flag2 = N(3) == 1;
			if (flag2)
			{
				long? num = N(5);
				if (num.HasValue)
				{
					long valueOrDefault = num.GetValueOrDefault();
					if ((ulong)valueOrDefault <= 1uL)
					{
						flag4 = true;
						goto IL_00ee;
					}
				}
				flag4 = false;
				goto IL_00ee;
			}
			goto IL_00f5;
		}
		goto IL_00f9;
		IL_0090:
		flag = !flag2;
		goto IL_0096;
		IL_00f5:
		flag3 = flag2;
		goto IL_00f9;
		IL_00ee:
		flag2 = !flag4;
		goto IL_00f5;
		uint Item(int i, int? category = null)
		{
			long? num4 = N(i);
			if (num4.HasValue)
			{
				long valueOrDefault2 = num4.GetValueOrDefault();
				if (valueOrDefault2 > 0 && valueOrDefault2 <= 203 && ArenaItemCatalog.Items.TryGetValue((uint)num4.Value, out ArenaItem value) && (!category.HasValue || value.Category == category))
				{
					return (uint)num4.Value;
				}
			}
			throw new InvalidOperationException("战利品物品编号未识别");
		}
		long? N(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	public static bool ExitPrompt(string text)
	{
		if (!GameText.Matches("Reward.ExitWithUnclaimed", text) && !GameText.Matches("Reward.ExitConfirm", text))
		{
			if (GameText.Language == "zhCN" && text.StartsWith("确定要", StringComparison.Ordinal) && text.Contains("结束", StringComparison.Ordinal))
			{
				if (!text.Contains("获取", StringComparison.Ordinal))
				{
					return text.Contains("战利品", StringComparison.Ordinal);
				}
				return true;
			}
			return false;
		}
		return true;
	}

	public static bool LooksLikeAcquisition(string text)
	{
		if (!GameText.Matches("Reward.GetConfirm", text) && !GameText.Matches("Reward.TakeAllConfirm", text) && !GameText.Matches("Reward.CoinConfirm", text) && !GameText.Matches("Reward.GearReplaceConfirm", text))
		{
			if (GameText.Language == "zhCN")
			{
				return text.Contains("获取", StringComparison.Ordinal);
			}
			return false;
		}
		return true;
	}

	public static bool ItemPrompt(string text, uint id)
	{
		return ArenaTreasureDecoder.MatchesPrompt(text, id);
	}

	public static bool CoinPrompt(string text, uint amount)
	{
		if (!GameText.Matches("Reward.CoinConfirm", text) || text.Contains("全部", StringComparison.Ordinal))
		{
			return false;
		}
		try
		{
			return CoinAmount(text) == amount;
		}
		catch (InvalidOperationException)
		{
			return false;
		}
	}

	public static uint CoinAmount(string text)
	{
		Match match = Regex.Match(text, "\\d[\\d,]*");
		if (!match.Success || !uint.TryParse(match.Value.Replace(",", ""), out var result))
		{
			throw new InvalidOperationException("斗兽币数量未就绪");
		}
		return result;
	}
}
