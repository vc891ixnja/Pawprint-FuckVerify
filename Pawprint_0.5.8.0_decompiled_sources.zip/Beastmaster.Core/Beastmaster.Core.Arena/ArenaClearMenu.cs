using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaClearMenu
{
	public const string Label = "清空整个队伍";

	public const string Prompt = "确定要清空整个队伍吗？";

	public static bool IsPrompt(string? text)
	{
		return GameText.Matches("Party.RemoveAllConfirm", text);
	}

	public static int? FindDisplayedRow(IReadOnlyList<ArenaClearMenuRow> rows)
	{
		int count = rows.Count;
		bool flag = ((count < 1 || count > 32) ? true : false);
		if (flag || !rows.Select((ArenaClearMenuRow r) => r.Row).SequenceEqual(Enumerable.Range(0, rows.Count)))
		{
			return null;
		}
		List<int> list = new List<int>();
		for (int num = 0; num < rows.Count; num++)
		{
			if (rows[num].Enabled && rows[num].Labels.Any((string l) => GameText.Matches("Party.RemoveAll", l)))
			{
				list.Add(rows[num].Row);
			}
		}
		if (list.Count > 1)
		{
			throw new InvalidOperationException("菜单中「清空整个队伍」选项不唯一");
		}
		if (list.Count != 1)
		{
			return null;
		}
		return list[0];
	}

	public static int? FindRow(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue x) => x.Index);
		long? num = v.GetValueOrDefault(0)?.Number;
		switch (num)
		{
		default:
			return null;
		case 1L:
		case 2L:
		case 3L:
		case 4L:
		case 5L:
		case 6L:
		case 7L:
		case 8L:
		case 9L:
		case 10L:
		case 11L:
		case 12L:
		case 13L:
		case 14L:
		case 15L:
		case 16L:
		case 17L:
		case 18L:
		case 19L:
		case 20L:
		case 21L:
		case 22L:
		case 23L:
		case 24L:
		case 25L:
		case 26L:
		case 27L:
		case 28L:
		case 29L:
		case 30L:
		case 31L:
		case 32L:
		{
			int num2 = ((values.Count != 0) ? (values.Max((ArenaValue x) => x.Index) + 1) : 0);
			bool flag = num2 > 8 + num;
			if (num2 < 8 + num || (flag && num2 < 8 + num * 2))
			{
				return null;
			}
			int[] array = (from i in Enumerable.Range(0, (int)num.Value)
				where GameText.Matches("Party.RemoveAll", v.GetValueOrDefault(8 + i)?.Text)
				select i).ToArray();
			if (array.Length != 1)
			{
				return null;
			}
			int num3 = array[0];
			if (flag)
			{
				ArenaValue? valueOrDefault = v.GetValueOrDefault(8 + (int)num.Value + num3);
				if ((object)valueOrDefault == null || valueOrDefault.Number != 0)
				{
					return null;
				}
			}
			return num3;
		}
		}
	}
}
