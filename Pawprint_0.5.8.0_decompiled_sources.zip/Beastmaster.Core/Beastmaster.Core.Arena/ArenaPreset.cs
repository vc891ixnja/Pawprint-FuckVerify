using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaPreset
{
	public string Id { get; set; } = Guid.NewGuid().ToString("N");

	public string Name { get; set; } = "默认";

	public int StageId { get; set; } = 1;

	public List<uint> Roster { get; set; } = new List<uint>();

	public ArenaRoutePreference Route { get; set; }

	public Dictionary<int, ArenaRoutePreference> Branches { get; set; } = new Dictionary<int, ArenaRoutePreference>();

	public Dictionary<int, int> BranchTargets { get; set; } = new Dictionary<int, int>();

	public List<uint> PurchasePriority { get; set; } = new List<uint>();

	public List<uint> TreasurePriority { get; set; } = new List<uint>();

	public List<uint> EquipmentPriority { get; set; } = new List<uint>();

	public Dictionary<int, List<uint>> NodeTreasurePriorities { get; set; } = new Dictionary<int, List<uint>>();

	public Dictionary<int, List<uint>> NodePurchasePriorities { get; set; } = new Dictionary<int, List<uint>>();

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool HealBeforeBattle { get; set; } = true;

	public bool UseFood { get; set; }

	public int HealBelowPercent { get; set; } = 50;

	public List<uint> HealingPriority { get; set; } = new List<uint>();

	public bool HealDuringBattle { get; set; }

	public int BattleHealBelowPercent { get; set; } = 50;

	public List<uint> BattleHealingPriority { get; set; } = new List<uint>();

	public bool AutoPullAfterTenSeconds { get; set; }

	public ArenaOpeningMode? OpeningMode { get; set; }

	[JsonIgnore]
	[IgnoreDataMember]
	public ArenaOpeningMode EffectiveOpeningMode
	{
		get
		{
			ArenaOpeningMode? openingMode = OpeningMode;
			if (!openingMode.HasValue)
			{
				if (!AutoPullAfterTenSeconds)
				{
					return ArenaOpeningMode.Disabled;
				}
				return ArenaOpeningMode.TenSecondAttack;
			}
			return openingMode.GetValueOrDefault();
		}
	}

	public bool RetryAfterDeath { get; set; }

	public List<ArenaBattlePreset> Battles { get; set; } = new List<ArenaBattlePreset>();

	public List<ArenaRandomOutcomePreset> RandomOutcomes { get; set; } = new List<ArenaRandomOutcomePreset>();

	public ArenaResources Resources { get; set; } = new ArenaResources();

	public IReadOnlyList<uint> TreasureOrder(int? node)
	{
		if (node.HasValue)
		{
			int valueOrDefault = node.GetValueOrDefault();
			if (NodeTreasurePriorities.TryGetValue(valueOrDefault, out List<uint> value))
			{
				return value;
			}
		}
		return TreasurePriority;
	}

	public IReadOnlyList<uint> PurchaseOrder(int? node)
	{
		if (node.HasValue)
		{
			int valueOrDefault = node.GetValueOrDefault();
			if (NodePurchasePriorities.TryGetValue(valueOrDefault, out List<uint> value))
			{
				return value;
			}
		}
		return PurchasePriority;
	}

	public ArenaRandomOutcomePreset RandomOutcome(int node, int outcome)
	{
		ArenaRandomOutcome arenaRandomOutcome = ArenaRandomEvents.Find(StageId, node, outcome) ?? throw new InvalidOperationException("当前地图没有此随机事件结果");
		ArenaRandomOutcomePreset arenaRandomOutcomePreset = RandomOutcomes.FirstOrDefault((ArenaRandomOutcomePreset o) => o.Node == node && o.Outcome == outcome);
		if (arenaRandomOutcomePreset == null)
		{
			arenaRandomOutcomePreset = new ArenaRandomOutcomePreset
			{
				Node = node,
				Outcome = outcome,
				Battle = ((arenaRandomOutcome.TileKind == ArenaTileKind.Battle) ? new ArenaBattlePreset
				{
					Node = node
				} : null)
			};
			RandomOutcomes.Add(arenaRandomOutcomePreset);
		}
		return arenaRandomOutcomePreset;
	}

	public bool RepairRepeatedLists()
	{
		string text = JsonSerializer.Serialize(this);
		Roster = Roster.Distinct().ToList();
		Battles = Battles.DistinctBy((ArenaBattlePreset b) => b.Node).ToList();
		RandomOutcomes = RandomOutcomes.DistinctBy((ArenaRandomOutcomePreset o) => (Node: o.Node, Outcome: o.Outcome)).ToList();
		foreach (ArenaRandomOutcomePreset randomOutcome in RandomOutcomes)
		{
			if (randomOutcome.ItemPriority != null)
			{
				randomOutcome.ItemPriority = randomOutcome.ItemPriority.Distinct().ToList();
			}
		}
		PurchasePriority = PurchasePriority.Distinct().ToList();
		TreasurePriority = TreasurePriority.Distinct().ToList();
		EquipmentPriority = EquipmentPriority.Distinct().ToList();
		HealingPriority = HealingPriority.Distinct().ToList();
		BattleHealingPriority = BattleHealingPriority.Distinct().ToList();
		Dictionary<int, List<uint>>[] array = new Dictionary<int, List<uint>>[2] { NodeTreasurePriorities, NodePurchasePriorities };
		foreach (Dictionary<int, List<uint>> dictionary in array)
		{
			int[] array2 = dictionary.Keys.ToArray();
			foreach (int key in array2)
			{
				dictionary[key] = dictionary[key].Distinct().ToList();
			}
		}
		foreach (ArenaBattlePreset item in Battles.Where((ArenaBattlePreset b) => b.HealOverride && !Resources.Nodes.ContainsKey(b.Node)))
		{
			Resources.Nodes[item.Node] = Resources.Rewards.Copy();
		}
		return text != JsonSerializer.Serialize(this);
	}

	public ArenaPreset Snapshot(int stage)
	{
		if (StageId != stage)
		{
			throw new InvalidOperationException("预设与当前奇盘不匹配");
		}
		ArenaPreset? arenaPreset = JsonSerializer.Deserialize<ArenaPreset>(JsonSerializer.Serialize(this));
		arenaPreset.Roster = arenaPreset.Roster.Where((uint n) => n >= 1 && n <= 50).Distinct().Take(ArenaStage.Get(stage).RosterCapacity)
			.ToList();
		arenaPreset.HealBelowPercent = Math.Clamp(arenaPreset.HealBelowPercent, 1, 100);
		arenaPreset.BattleHealBelowPercent = Math.Clamp(arenaPreset.BattleHealBelowPercent, 1, 100);
		return arenaPreset;
	}

	public ArenaPreset Duplicate()
	{
		ArenaPreset arenaPreset = Snapshot(StageId);
		arenaPreset.Id = Guid.NewGuid().ToString("N");
		arenaPreset.Name += " 副本";
		return arenaPreset;
	}

	public ArenaBattlePreset Battle(int node)
	{
		if (!ArenaMaps.Get(StageId).Nodes.Any((ArenaMapNode n) => n.Node == node && n.Kind == ArenaTileKind.Battle))
		{
			throw new InvalidOperationException("当前节点不是战斗格");
		}
		ArenaBattlePreset arenaBattlePreset = Battles.FirstOrDefault((ArenaBattlePreset b) => b.Node == node);
		if (arenaBattlePreset == null)
		{
			arenaBattlePreset = new ArenaBattlePreset
			{
				Node = node
			};
			Battles.Add(arenaBattlePreset);
		}
		return arenaBattlePreset;
	}
}
