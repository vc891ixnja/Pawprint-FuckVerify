using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Runtime.CompilerServices;
using System.Text;

namespace Beastmaster.Core.Arena;

public sealed record ArenaStageMap(int StageId, ArenaMapNode[] Nodes)
{
	public int LastNode => Nodes.Length - 1;

	public int Depth => Nodes.Max((ArenaMapNode n) => n.Depth);

	public IReadOnlyList<Vector2> Positions { get; } = Nodes.Select((ArenaMapNode n) => new Vector2(n.X, n.Depth)).ToArray();

	public IEnumerable<ArenaMapNode> Forks => Nodes.Where(delegate(ArenaMapNode n)
	{
		int[] next = n.Next;
		return next != null && next.Length > 1;
	});

	private readonly Dictionary<int, HashSet<int>> reachable = new Dictionary<int, HashSet<int>>();

	public HashSet<int> Reachable(int start)
	{
		if (reachable.TryGetValue(start, out HashSet<int> value))
		{
			return value;
		}
		HashSet<int> hashSet = new HashSet<int>();
		Stack<int> stack = new Stack<int>();
		stack.Push(start);
		int result;
		while (stack.TryPop(out result))
		{
			if (hashSet.Add(result))
			{
				int[] array = Nodes[result].Next ?? Array.Empty<int>();
				foreach (int item in array)
				{
					stack.Push(item);
				}
			}
		}
		reachable[start] = hashSet;
		return hashSet;
	}

	[CompilerGenerated]
	private bool PrintMembers(StringBuilder builder)
	{
		RuntimeHelpers.EnsureSufficientExecutionStack();
		builder.Append("StageId = ");
		builder.Append(StageId.ToString());
		builder.Append(", Nodes = ");
		builder.Append(Nodes);
		builder.Append(", LastNode = ");
		builder.Append(LastNode.ToString());
		builder.Append(", Depth = ");
		builder.Append(Depth.ToString());
		builder.Append(", Positions = ");
		builder.Append(Positions);
		builder.Append(", Forks = ");
		builder.Append(Forks);
		return true;
	}

	[CompilerGenerated]
	public override int GetHashCode()
	{
		return (((EqualityComparer<Type>.Default.GetHashCode(EqualityContract) * -1521134295 + EqualityComparer<int>.Default.GetHashCode(StageId)) * -1521134295 + EqualityComparer<ArenaMapNode[]>.Default.GetHashCode(Nodes)) * -1521134295 + EqualityComparer<Dictionary<int, HashSet<int>>>.Default.GetHashCode(reachable)) * -1521134295 + EqualityComparer<IReadOnlyList<Vector2>>.Default.GetHashCode(Positions);
	}

	[CompilerGenerated]
	public bool Equals(ArenaStageMap? other)
	{
		if ((object)this != other)
		{
			if ((object)other != null && EqualityContract == other.EqualityContract && EqualityComparer<int>.Default.Equals(StageId, other.StageId) && EqualityComparer<ArenaMapNode[]>.Default.Equals(Nodes, other.Nodes) && EqualityComparer<Dictionary<int, HashSet<int>>>.Default.Equals(reachable, other.reachable))
			{
				return EqualityComparer<IReadOnlyList<Vector2>>.Default.Equals(Positions, other.Positions);
			}
			return false;
		}
		return true;
	}

	[CompilerGenerated]
	private ArenaStageMap(ArenaStageMap original)
	{
		StageId = original.StageId;
		Nodes = original.Nodes;
		reachable = original.reachable;
		Positions = original.Positions;
	}
}
