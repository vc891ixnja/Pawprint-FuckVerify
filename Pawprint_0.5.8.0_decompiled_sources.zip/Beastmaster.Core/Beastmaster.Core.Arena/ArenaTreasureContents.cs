namespace Beastmaster.Core.Arena;

public sealed record ArenaTreasureContents(ArenaTreasureOption[] Options, uint[] Equipment, uint[]? OwnedItems = null);
