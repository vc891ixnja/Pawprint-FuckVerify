namespace Beastmaster.Core.Arena;

public sealed record ArenaEquipmentSlot(int Row, uint ItemId);
