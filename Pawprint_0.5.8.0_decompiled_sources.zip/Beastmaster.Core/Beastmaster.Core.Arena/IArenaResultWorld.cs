namespace Beastmaster.Core.Arena;

public interface IArenaResultWorld
{
	ArenaResultView Read();

	bool TryNext();

	bool TryExit();
}
