namespace Beastmaster.Core.Arena;

public interface IArenaFoodWorld
{
	bool Enabled { get; }

	ArenaFoodView Read();

	bool TryEat();
}
