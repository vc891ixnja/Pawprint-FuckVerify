namespace Beastmaster.Core.Arena;

public enum ArenaRewardPhase
{
	Closed,
	Loading,
	Selection,
	Confirmation,
	Returned
}
