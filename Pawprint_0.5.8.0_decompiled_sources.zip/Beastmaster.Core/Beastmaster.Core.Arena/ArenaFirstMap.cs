using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace Beastmaster.Core.Arena;

public static class ArenaFirstMap
{
	public static IReadOnlyList<ArenaMapNode> Nodes { get; } = Load();

	private static ArenaMapNode[] Load()
	{
		using Stream utf8Json = typeof(ArenaFirstMap).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-first-map.json");
		return JsonSerializer.Deserialize<ArenaMapNode[]>(utf8Json);
	}
}
