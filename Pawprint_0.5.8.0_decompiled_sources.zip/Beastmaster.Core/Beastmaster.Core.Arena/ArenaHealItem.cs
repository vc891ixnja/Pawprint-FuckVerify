namespace Beastmaster.Core.Arena;

public sealed record ArenaHealItem(int Slot, uint ItemId, bool Usable);
