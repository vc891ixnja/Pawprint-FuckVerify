namespace Beastmaster.Core.Arena;

public enum ArenaEncounterPhase
{
	Loading,
	Setup,
	Battle,
	Loot,
	Confirmation,
	Returned,
	Unknown
}
