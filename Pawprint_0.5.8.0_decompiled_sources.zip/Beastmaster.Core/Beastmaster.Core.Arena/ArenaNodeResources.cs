using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaNodeResources
{
	public List<uint>? Priority { get; set; }

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool Equipment { get; set; } = true;

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool Items { get; set; } = true;

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool Food { get; set; } = true;

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool Rest { get; set; } = true;

	public int RestBelowPercent { get; set; } = 100;

	public int[] Categories { get; set; } = new int[3] { 1, 2, 3 };

	public ArenaPurchaseSort EquipmentSort { get; set; }

	public ArenaPurchaseSort ItemSort { get; set; }

	public ArenaPurchaseSort FoodSort { get; set; }

	public uint Budget { get; set; }

	public uint ReserveCoins { get; set; }

	public bool SellDisabled { get; set; }

	public ArenaNodeResources Copy()
	{
		return new ArenaNodeResources
		{
			Equipment = Equipment,
			Items = Items,
			Food = Food,
			Rest = Rest,
			RestBelowPercent = RestBelowPercent,
			Categories = Categories.ToArray(),
			EquipmentSort = EquipmentSort,
			ItemSort = ItemSort,
			FoodSort = FoodSort,
			Budget = Budget,
			ReserveCoins = ReserveCoins,
			SellDisabled = SellDisabled,
			Priority = ((Priority == null) ? null : Priority.ToList())
		};
	}
}
