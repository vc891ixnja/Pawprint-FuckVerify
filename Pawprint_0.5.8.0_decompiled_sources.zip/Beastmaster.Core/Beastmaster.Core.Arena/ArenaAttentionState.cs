using System;

namespace Beastmaster.Core.Arena;

public sealed class ArenaAttentionState(TimeSpan? retryInterval = null)
{
	private (ulong ObjectId, uint BaseId) summon;

	private ulong target;

	private TimeSpan? submitted;

	private TimeSpan? confirmed;

	public void ObserveSummon(ulong objectId, uint baseId)
	{
		(ulong, uint) tuple = (objectId, baseId);
		(ulong, uint) tuple2 = tuple;
		(ulong, uint) tuple3 = summon;
		if (tuple2.Item1 != tuple3.Item1 || tuple2.Item2 != tuple3.Item2)
		{
			summon = tuple;
			target = 0uL;
			submitted = (confirmed = null);
		}
	}

	public bool NeedsUse(ulong targetId, TimeSpan now)
	{
		if (summon.ObjectId != 0L && targetId != 0L)
		{
			if (target == targetId)
			{
				TimeSpan? timeSpan = confirmed;
				if (timeSpan.HasValue)
				{
					TimeSpan valueOrDefault = timeSpan.GetValueOrDefault();
					if (!(now - valueOrDefault >= TimeSpan.FromSeconds(40L)))
					{
						return false;
					}
				}
				timeSpan = submitted;
				if (timeSpan.HasValue)
				{
					TimeSpan valueOrDefault2 = timeSpan.GetValueOrDefault();
					return now - valueOrDefault2 >= (retryInterval ?? TimeSpan.FromSeconds(2L));
				}
				return true;
			}
			return true;
		}
		return false;
	}

	public void Submitted(ulong targetId, TimeSpan now)
	{
		target = targetId;
		submitted = now;
		confirmed = null;
	}

	public void Confirm(ulong targetId, TimeSpan now)
	{
		if (summon.ObjectId != 0L && target == targetId && submitted.HasValue)
		{
			confirmed = now;
			submitted = null;
		}
	}
}
