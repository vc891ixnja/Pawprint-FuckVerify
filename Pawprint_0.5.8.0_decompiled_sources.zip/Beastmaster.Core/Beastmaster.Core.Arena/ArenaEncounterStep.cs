using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaEncounterStep : IWorkflowStep
{
	private readonly ArenaEquipmentExchange equipment;

	private ArenaRewardStep? reward;

	private TimeSpan rewardAt;

	private bool rewardComplete;

	private uint? assigning;

	private int expectedSlot;

	private TimeSpan? assignmentReadyAt;

	private TimeSpan nextAssignAttempt;

	private TimeSpan sentAt;

	private bool started;

	private bool fought;

	private bool lootSeen;

	private bool takeAllSent;

	private bool confirmed;

	private bool attached;

	private TimeSpan? pendingUiAt;

	private TimeSpan? battleAt;

	private bool startConfirmed;

	private bool assistActive;

	private string? assistError;

	private bool inBattle;

	public string BattleStatus
	{
		get
		{
			if (!inBattle)
			{
				return "";
			}
			object obj = assistError;
			if (obj == null)
			{
				if (!assistActive)
				{
					return "";
				}
				obj = _003CbattleAssist_003EP?.Name ?? "";
			}
			return (string)obj;
		}
	}

	public string Name { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(12L);

	public ArenaEncounterStep(IArenaEncounterWorld world, bool attachCurrent = false, uint[]? rosterOrder = null, ArenaBattlePreset? battlePreset = null, IWorkflowStep? battleAssist = null, IReadOnlyList<uint>? equipmentPriority = null, ArenaResourcePolicy? resources = null)
	{
		_003Cworld_003EP = world;
		_003CattachCurrent_003EP = attachCurrent;
		_003CrosterOrder_003EP = rosterOrder;
		_003CbattlePreset_003EP = battlePreset;
		_003CbattleAssist_003EP = battleAssist;
		_003Cresources_003EP = resources;
		equipment = new ArenaEquipmentExchange(_003Cworld_003EP.Equipment, equipmentPriority, _003Cresources_003EP);
		Name = "斗兽 · 读取当前战斗阶段";
		base._002Ector();
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (!rewardComplete && _003Cresources_003EP != null)
		{
			IArenaRewardWorld rewards = _003Cworld_003EP.Rewards;
			if (rewards != null && (reward != null || rewards.IsOpen))
			{
				inBattle = false;
				if (!fought && !_003CattachCurrent_003EP)
				{
					throw new InvalidOperationException("未观察到本次战斗，停止领取操作");
				}
				CancelAssist();
				attached = (started = (fought = (lootSeen = true)));
				if (reward == null)
				{
					reward = new ArenaRewardStep(rewards, _003Cresources_003EP);
					rewardAt = elapsed;
				}
				if (elapsed - rewardAt >= reward.Timeout)
				{
					throw new TimeoutException("战利品处理超时");
				}
				StepResult num = reward.Tick(elapsed - rewardAt);
				Name = reward.Name;
				if (num == StepResult.Completed)
				{
					rewardComplete = true;
					confirmed = (takeAllSent = true);
					sentAt = elapsed;
				}
				return StepResult.Running;
			}
		}
		if (equipment.Tick(elapsed, out ArenaEquipmentOutcome outcome))
		{
			CancelAssist();
			Name = equipment.Name;
			sentAt = elapsed;
			pendingUiAt = null;
			if (_003CattachCurrent_003EP)
			{
				attached = (started = (fought = (lootSeen = true)));
			}
			return StepResult.Running;
		}
		if (outcome != null)
		{
			sentAt = elapsed;
			confirmed = true;
			takeAllSent = false;
		}
		ArenaEncounterView arenaEncounterView = _003Cworld_003EP.Read();
		inBattle = arenaEncounterView.Phase == ArenaEncounterPhase.Battle;
		ArenaEncounterPhase phase = arenaEncounterView.Phase;
		if ((phase != ArenaEncounterPhase.Loading && phase != ArenaEncounterPhase.Battle && phase != ArenaEncounterPhase.Unknown) || 1 == 0)
		{
			CancelAssist();
		}
		phase = arenaEncounterView.Phase;
		if ((phase == ArenaEncounterPhase.Loading || phase == ArenaEncounterPhase.Unknown) ? true : false)
		{
			if (_003CbattleAssist_003EP is ArenaBattleAssist arenaBattleAssist)
			{
				arenaBattleAssist.WaitForUi();
			}
			Name = arenaEncounterView.PendingUi ?? "斗兽 · 等待场地切换";
			if (arenaEncounterView.PendingUi != null || arenaEncounterView.Phase == ArenaEncounterPhase.Unknown)
			{
				TimeSpan valueOrDefault = pendingUiAt.GetValueOrDefault();
				if (!pendingUiAt.HasValue)
				{
					valueOrDefault = elapsed;
					pendingUiAt = valueOrDefault;
				}
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = pendingUiAt;
				if (value - timeSpan > TimeSpan.FromSeconds(15L))
				{
					throw new TimeoutException((arenaEncounterView.PendingUi ?? "斗兽界面切换") + "，界面数据仍未就绪");
				}
			}
			else
			{
				pendingUiAt = null;
			}
			return StepResult.Running;
		}
		pendingUiAt = null;
		if (arenaEncounterView.Phase == ArenaEncounterPhase.Confirmation && arenaEncounterView.UnderfilledFlutesPrompt)
		{
			if (!started && !_003CattachCurrent_003EP)
			{
				throw new InvalidOperationException("未提交本场开战，不能确认");
			}
			attached = (started = true);
			Name = "本场战斗 · 确认兽笛未满开战";
			if (!startConfirmed)
			{
				if (_003Cworld_003EP.ConfirmStartBattle())
				{
					startConfirmed = true;
					sentAt = elapsed;
				}
			}
			else if (elapsed - sentAt > TimeSpan.FromSeconds(10L))
			{
				throw new TimeoutException("开战确认窗口未关闭");
			}
			return StepResult.Running;
		}
		if (!attached)
		{
			attached = true;
			if (_003CattachCurrent_003EP)
			{
				phase = arenaEncounterView.Phase;
				bool flag = (uint)(phase - 2) <= 1u;
				if (flag || (arenaEncounterView.Phase == ArenaEncounterPhase.Confirmation && arenaEncounterView.TakeAllPrompt))
				{
					started = (fought = true);
				}
				if (arenaEncounterView.Phase == ArenaEncounterPhase.Confirmation && arenaEncounterView.TakeAllPrompt)
				{
					lootSeen = (takeAllSent = true);
				}
				if (arenaEncounterView.Phase == ArenaEncounterPhase.Returned)
				{
					return StepResult.Completed;
				}
			}
		}
		if (arenaEncounterView.Phase == ArenaEncounterPhase.Setup)
		{
			if (started)
			{
				if (elapsed - sentAt > TimeSpan.FromSeconds(10L))
				{
					throw new TimeoutException("已提交开战，但未进入战斗场地");
				}
				return StepResult.Running;
			}
			uint? num2 = assigning;
			if (num2.HasValue)
			{
				uint petId = num2.GetValueOrDefault();
				if (!arenaEncounterView.Pets.Any((ArenaPet p) => p.PetId == petId && p.Slot == expectedSlot))
				{
					if (elapsed - sentAt > TimeSpan.FromSeconds(10L))
					{
						throw new TimeoutException(Name + "，兽笛设置未得到确认");
					}
					return StepResult.Running;
				}
				assigning = null;
			}
			ArenaPet arenaPet = ArenaPartyDecoder.NextToAssign(arenaEncounterView.Pets, ArenaPresetPolicy.ResolveFlutes(arenaEncounterView.Pets, _003CrosterOrder_003EP, _003CbattlePreset_003EP));
			if (arenaPet != null)
			{
				expectedSlot = ((arenaPet.Slot < 3) ? 3 : arenaEncounterView.Pets.Count((ArenaPet p) => p.Slot < 3));
				Name = ((expectedSlot == 3) ? ("本场战斗 · 撤下" + arenaPet.Name) : $"本场战斗 · {arenaPet.Name} → {expectedSlot + 1} 号兽笛");
				TimeSpan valueOrDefault = assignmentReadyAt.GetValueOrDefault();
				if (!assignmentReadyAt.HasValue)
				{
					valueOrDefault = elapsed;
					assignmentReadyAt = valueOrDefault;
				}
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = assignmentReadyAt;
				if (value - timeSpan > TimeSpan.FromSeconds(10L))
				{
					throw new TimeoutException(Name + "，编队控件未就绪");
				}
				if (elapsed < nextAssignAttempt)
				{
					return StepResult.Running;
				}
				nextAssignAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
				if (_003Cworld_003EP.TryAssign(arenaPet.Row))
				{
					assigning = arenaPet.PetId;
					sentAt = elapsed;
					assignmentReadyAt = null;
				}
			}
			else
			{
				Name = "本场战斗 · 开始战斗";
				if (_003Cworld_003EP.StartBattle())
				{
					started = true;
					sentAt = elapsed;
				}
			}
		}
		else if (arenaEncounterView.Phase == ArenaEncounterPhase.Battle)
		{
			if (!started)
			{
				throw new InvalidOperationException("请从本场战斗编队窗口启动");
			}
			fought = true;
			TimeSpan valueOrDefault = battleAt.GetValueOrDefault();
			if (!battleAt.HasValue)
			{
				valueOrDefault = elapsed;
				battleAt = valueOrDefault;
			}
			if (assistError == null)
			{
				assistActive = true;
				try
				{
					_003CbattleAssist_003EP?.Tick(elapsed - battleAt.Value);
				}
				catch (Exception ex) when (((ex is InvalidOperationException || ex is TimeoutException || ex is OperationCanceledException) ? 1 : 0) != 0)
				{
					assistError = "战斗辅助已跳过：" + ex.Message;
					try
					{
						CancelAssist();
					}
					catch (Exception ex2) when (((ex2 is InvalidOperationException || ex2 is TimeoutException || ex2 is OperationCanceledException) ? 1 : 0) != 0)
					{
						assistError = assistError + "；" + ex2.Message;
					}
				}
			}
			Name = "本场战斗 · 等待战斗结束";
		}
		else if (arenaEncounterView.Phase == ArenaEncounterPhase.Loot)
		{
			if (!fought)
			{
				throw new InvalidOperationException("未观察到本次战斗，停止领取操作");
			}
			lootSeen = true;
			Name = "本场战斗 · 领取战利品";
			if (!takeAllSent)
			{
				if (_003Cworld_003EP.TakeAll())
				{
					takeAllSent = true;
					confirmed = false;
					sentAt = elapsed;
				}
			}
			else if (elapsed - sentAt > TimeSpan.FromSeconds(10L))
			{
				throw new TimeoutException("战利品领取未完成");
			}
		}
		else if (arenaEncounterView.Phase == ArenaEncounterPhase.Confirmation)
		{
			if (!takeAllSent || !lootSeen || !arenaEncounterView.TakeAllPrompt)
			{
				throw new InvalidOperationException("出现未预期确认窗口，请手动处理");
			}
			if (!confirmed)
			{
				Name = "本场战斗 · 确认全部领取";
				if (_003Cworld_003EP.ConfirmTakeAll())
				{
					confirmed = true;
					sentAt = elapsed;
				}
			}
			else if (elapsed - sentAt > TimeSpan.FromSeconds(10L))
			{
				throw new TimeoutException("领取确认窗口未关闭");
			}
		}
		else
		{
			if (arenaEncounterView.Phase != ArenaEncounterPhase.Returned)
			{
				throw new InvalidOperationException("本场战斗界面或场地不匹配，已停止");
			}
			if (fought && confirmed)
			{
				Name = "本场战斗 · 完成，已返回棋盘";
				return StepResult.Completed;
			}
			if (!started)
			{
				throw new InvalidOperationException("请在本场战斗编队窗口启动");
			}
			Name = "本场战斗 · 等待进入战斗场地";
		}
		return StepResult.Running;
	}

	private void CancelAssist()
	{
		if (assistActive)
		{
			assistActive = false;
			_003CbattleAssist_003EP?.Cancel();
		}
	}

	public void Cancel()
	{
		CancelAssist();
	}
}
