using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaResources
{
	public bool UnifiedPriorities { get; set; }

	public bool SourcePriorities { get; set; }

	public ArenaAcquisitionPriority BattleRewards { get; set; } = new ArenaAcquisitionPriority();

	public ArenaAcquisitionPriority TreasureRewards { get; set; } = new ArenaAcquisitionPriority();

	public ArenaAcquisitionPriority Purchases { get; set; } = new ArenaAcquisitionPriority();

	public bool NoEquipment { get; set; }

	public bool NoSpending { get; set; }

	public bool NoItems { get; set; }

	public bool NoFeeding { get; set; }

	public bool NoRest { get; set; }

	public int TargetEquipment { get; set; }

	public int TargetItems { get; set; }

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool ReserveTargetItems { get; set; } = true;

	public uint ReserveCoins { get; set; }

	public List<uint> Disabled { get; set; } = new List<uint>();

	public List<uint> DisabledAcquisition { get; set; } = new List<uint>();

	public List<uint> DisabledUse { get; set; } = new List<uint>();

	public List<uint> CoreEquipment { get; set; } = new List<uint>();

	public List<uint> SupplyPriority { get; set; } = new List<uint>();

	public ArenaNodeResources Rewards { get; set; } = new ArenaNodeResources();

	public ArenaNodeResources Shop { get; set; } = new ArenaNodeResources();

	public Dictionary<int, ArenaNodeResources> Nodes { get; set; } = new Dictionary<int, ArenaNodeResources>();

	public bool IsDisabled(uint id)
	{
		if (!Disabled.Contains(id) && !DisabledAcquisition.Contains(id))
		{
			return DisabledUse.Contains(id);
		}
		return true;
	}

	public bool FoldLegacy()
	{
		if (DisabledAcquisition.Count == 0 && DisabledUse.Count == 0 && CoreEquipment.Count == 0)
		{
			return false;
		}
		foreach (uint item in DisabledAcquisition.Concat(DisabledUse))
		{
			if (!Disabled.Contains(item))
			{
				Disabled.Add(item);
			}
		}
		DisabledAcquisition.Clear();
		DisabledUse.Clear();
		CoreEquipment.Clear();
		return true;
	}

	public bool MigratePriorities(ArenaPreset preset)
	{
		if (SourcePriorities)
		{
			return false;
		}
		BattleRewards.Order = new ArenaResourcePolicy(preset).Order.ToList();
		TreasureRewards.Order = new ArenaResourcePolicy(preset, null, ArenaTileKind.Treasure).Order.ToList();
		Purchases.Order = new ArenaResourcePolicy(preset, null, ArenaTileKind.Shop).Order.ToList();
		foreach (var (key, list2) in preset.NodeTreasurePriorities.Concat(preset.NodePurchasePriorities))
		{
			if (!UnifiedPriorities && list2.Count != 0)
			{
				bool flag = preset.NodePurchasePriorities.ContainsKey(key);
				if (!Nodes.TryGetValue(key, out ArenaNodeResources value))
				{
					value = (Nodes[key] = (flag ? Shop : Rewards).Copy());
				}
				value.Priority = list2.ToList();
			}
		}
		foreach (ArenaRandomOutcomePreset randomOutcome in preset.RandomOutcomes)
		{
			if (UnifiedPriorities)
			{
				continue;
			}
			List<uint> itemPriority = randomOutcome.ItemPriority;
			if (itemPriority != null && itemPriority.Count > 0)
			{
				ArenaTileKind tileKind = ArenaRandomEvents.Find(preset.StageId, randomOutcome.Node, randomOutcome.Outcome).TileKind;
				ArenaRandomOutcomePreset arenaRandomOutcomePreset = randomOutcome;
				if (arenaRandomOutcomePreset.Resources == null)
				{
					ArenaNodeResources arenaNodeResources2 = (arenaRandomOutcomePreset.Resources = ((tileKind == ArenaTileKind.Shop) ? Shop : Rewards).Copy());
				}
				randomOutcome.Resources.Priority = itemPriority.ToList();
			}
		}
		BattleRewards.Order.RemoveAll((uint id) => ArenaItemCatalog.Items[id].Category == 3);
		TreasureRewards.Order.RemoveAll((uint id) => ArenaItemCatalog.Items[id].Category == 3);
		SourcePriorities = true;
		return true;
	}
}
