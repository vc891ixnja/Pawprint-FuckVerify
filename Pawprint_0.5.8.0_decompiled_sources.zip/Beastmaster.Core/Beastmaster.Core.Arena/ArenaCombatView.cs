using Beastmaster.Core.Models;

namespace Beastmaster.Core.Arena;

public sealed record ArenaCombatView(bool Ready, bool InCombat, WorldPoint? Player, bool AiControlsMovement = false);
