namespace Beastmaster.Core.Arena;

public sealed record ArenaShopPurchase(ArenaShopOffer Offer, uint? PetNumber = null);
