using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Beastmaster.Core.Arena;

public static class ArenaRandomEvents
{
	public static IReadOnlyList<ArenaRandomNode> All { get; } = Load();

	public static IReadOnlyList<ArenaRandomOutcome> Outcomes(int stage, int node)
	{
		return All.FirstOrDefault((ArenaRandomNode n) => n.StageId == stage && n.Node == node)?.Outcomes ?? Array.Empty<ArenaRandomOutcome>();
	}

	public static ArenaRandomOutcome? Find(int stage, int node, int outcome)
	{
		return Outcomes(stage, node).FirstOrDefault((ArenaRandomOutcome o) => o.PoolSubrow == outcome);
	}

	private static ArenaRandomNode[] Load()
	{
		using Stream utf8Json = typeof(ArenaRandomEvents).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-random-events.json");
		return JsonSerializer.Deserialize<ArenaRandomNode[]>(utf8Json);
	}
}
