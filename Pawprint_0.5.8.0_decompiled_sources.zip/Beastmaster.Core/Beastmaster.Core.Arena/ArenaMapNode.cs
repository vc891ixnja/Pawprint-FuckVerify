namespace Beastmaster.Core.Arena;

public sealed record ArenaMapNode(int Node, ArenaTileKind Kind, int BattleSubrow, string[] Enemies, int EventType = 0, int X = 0, int Depth = 0, int[]? Next = null)
{
	public ArenaBattleTier BattleTier
	{
		get
		{
			if (Kind != ArenaTileKind.Battle)
			{
				return ArenaBattleTier.None;
			}
			return EventType switch
			{
				3 => ArenaBattleTier.Elite, 
				4 => ArenaBattleTier.Boss, 
				_ => ArenaBattleTier.Normal, 
			};
		}
	}
}
