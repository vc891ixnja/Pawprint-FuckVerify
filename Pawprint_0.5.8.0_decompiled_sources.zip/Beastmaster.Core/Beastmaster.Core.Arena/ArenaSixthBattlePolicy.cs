using System;

namespace Beastmaster.Core.Arena;

public static class ArenaSixthBattlePolicy
{
	public static readonly TimeSpan AttentionRetryInterval = TimeSpan.FromMilliseconds(200L);

	public static bool Applies(int stage, int? node)
	{
		if (stage == 1)
		{
			return node == 6;
		}
		return false;
	}

	public static bool AllowsAttention(int stage, int? node, TimeSpan battleElapsed)
	{
		if (Applies(stage, node) && battleElapsed >= TimeSpan.Zero)
		{
			return battleElapsed < TimeSpan.FromSeconds(45L);
		}
		return false;
	}
}
