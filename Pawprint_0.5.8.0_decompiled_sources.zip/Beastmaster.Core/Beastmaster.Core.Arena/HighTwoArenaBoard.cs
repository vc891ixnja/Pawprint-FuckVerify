using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Beastmaster.Core.Arena;

public static class HighTwoArenaBoard
{
	public const float TileRadius = 2.5f;

	public static IReadOnlyList<ArenaBoardNode> Nodes { get; } = Array.AsReadOnly(new ArenaBoardNode[26]
	{
		new ArenaBoardNode(0, new Vector3(-700f, 0f, 0f), new int[1] { 1 }),
		new ArenaBoardNode(1, new Vector3(-700f, 0f, -9f), new int[2] { 2, 3 }),
		new ArenaBoardNode(2, new Vector3(-709f, 0f, -9f), new int[2] { 4, 5 }),
		new ArenaBoardNode(3, new Vector3(-691f, 0f, -9f), new int[2] { 5, 6 }),
		new ArenaBoardNode(4, new Vector3(-709f, 0f, -18f), new int[1] { 7 }),
		new ArenaBoardNode(5, new Vector3(-700f, 0f, -18f), new int[1] { 8 }),
		new ArenaBoardNode(6, new Vector3(-691f, 0f, -18f), new int[1] { 9 }),
		new ArenaBoardNode(7, new Vector3(-709f, 0f, -27f), new int[1] { 10 }),
		new ArenaBoardNode(8, new Vector3(-700f, 0f, -27f), new int[1] { 10 }),
		new ArenaBoardNode(9, new Vector3(-691f, 0f, -27f), new int[1] { 10 }),
		new ArenaBoardNode(10, new Vector3(-700f, 0f, -36f), new int[1] { 11 }),
		new ArenaBoardNode(11, new Vector3(-700f, 0f, -45f), new int[2] { 12, 13 }),
		new ArenaBoardNode(12, new Vector3(-709f, 0f, -45f), new int[1] { 14 }),
		new ArenaBoardNode(13, new Vector3(-691f, 0f, -45f), new int[1] { 15 }),
		new ArenaBoardNode(14, new Vector3(-718f, 0f, -45f), new int[1] { 16 }),
		new ArenaBoardNode(15, new Vector3(-682f, 0f, -45f), new int[1] { 17 }),
		new ArenaBoardNode(16, new Vector3(-718f, 0f, -54f), new int[1] { 18 }),
		new ArenaBoardNode(17, new Vector3(-682f, 0f, -54f), new int[1] { 18 }),
		new ArenaBoardNode(18, new Vector3(-700f, 0f, -54f), new int[1] { 19 }),
		new ArenaBoardNode(19, new Vector3(-700f, 0f, -63f), new int[3] { 20, 21, 22 }),
		new ArenaBoardNode(20, new Vector3(-709f, 0f, -63f), new int[1] { 23 }),
		new ArenaBoardNode(21, new Vector3(-700f, 0f, -72f), new int[1] { 25 }),
		new ArenaBoardNode(22, new Vector3(-691f, 0f, -63f), new int[1] { 24 }),
		new ArenaBoardNode(23, new Vector3(-709f, 0f, -72f), new int[1] { 25 }),
		new ArenaBoardNode(24, new Vector3(-691f, 0f, -72f), new int[1] { 25 }),
		new ArenaBoardNode(25, new Vector3(-700f, 0f, -81f), Array.Empty<int>())
	});

	public static bool IsOnBoard(Vector3 p)
	{
		if (float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z))
		{
			float x = p.X;
			if (x >= -723f && x <= -677f && Math.Abs(p.Y) < 1f)
			{
				x = p.Z;
				if (x >= -85f)
				{
					return x <= 4f;
				}
				return false;
			}
		}
		return false;
	}

	public static bool InTile(int index, Vector3 p)
	{
		if (IsOnBoard(p))
		{
			return Vector2.Distance(new Vector2(p.X, p.Z), new Vector2(Nodes[index].Center.X, Nodes[index].Center.Z)) <= 2.5f;
		}
		return false;
	}

	public static int? FindTile(Vector3 position)
	{
		return Nodes.Where((ArenaBoardNode n) => InTile(n.Index, position)).Select((Func<ArenaBoardNode, int?>)((ArenaBoardNode n) => n.Index)).SingleOrDefault();
	}

	public static (int From, int To)? FindBridge(Vector3 position)
	{
		if (!IsOnBoard(position) || FindTile(position).HasValue)
		{
			return null;
		}
		List<(int, int)> list = new List<(int, int)>();
		foreach (ArenaBoardNode node in Nodes)
		{
			int[] next = node.Next;
			foreach (int num in next)
			{
				Vector3 vector = Nodes[num].Center - node.Center;
				float num2 = Vector3.Dot(position - node.Center, vector) / vector.LengthSquared();
				if (num2 > 0f && num2 < 1f && Vector3.Distance(position, node.Center + vector * num2) <= 1f)
				{
					list.Add((node.Index, num));
				}
			}
		}
		if (list.Count != 1)
		{
			return null;
		}
		return list[0];
	}
}
