using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public static class ArenaHighBossPolicy
{
	public const uint BossNameId = 14628u;

	public const uint AddNameId = 14629u;

	public static bool Applies(int stage, int? node)
	{
		if (stage == 4)
		{
			return node == 14;
		}
		return false;
	}

	public static bool BurstItems(int stage, int? node, CombatTarget? boss)
	{
		if (Applies(stage, node) && (object)boss != null && boss.NameId == 14628 && !boss.IsDead && boss.Hp != 0 && boss.MaxHp != 0)
		{
			return (ulong)((long)boss.Hp * 2L) < (ulong)boss.MaxHp;
		}
		return false;
	}

	public static CombatTarget? Choose(IEnumerable<CombatTarget> targets, ulong? preferred)
	{
		return (from t in targets
			where (object)t != null && !t.IsDead && t.Hp != 0 && t.IsTargetable && t.IsAttackable
			orderby (t.NameId != 14628) ? 1 : 0, t.ObjectId == preferred descending, t.ObjectId
			select t).FirstOrDefault();
	}
}
