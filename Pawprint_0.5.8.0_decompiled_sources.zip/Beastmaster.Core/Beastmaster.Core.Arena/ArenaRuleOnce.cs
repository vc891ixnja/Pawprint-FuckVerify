namespace Beastmaster.Core.Arena;

public enum ArenaRuleOnce
{
	None,
	PerBattle,
	PerTargetInstance,
	PerPetSummon
}
