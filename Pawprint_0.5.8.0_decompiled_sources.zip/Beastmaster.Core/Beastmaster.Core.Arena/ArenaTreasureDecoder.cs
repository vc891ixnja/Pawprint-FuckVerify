using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaTreasureDecoder
{
	public static ArenaTreasureContents Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue arenaValue) => arenaValue.Index);
		if (Num(0) != 1 || !IsSelectionPrompt(v.GetValueOrDefault(1)?.Text ?? ""))
		{
			throw new InvalidOperationException("宝箱奖励列表未就绪");
		}
		List<ArenaTreasureOption> list = new List<ArenaTreasureOption>();
		for (int num = 0; num < 4; num++)
		{
			long? num2 = Num(3 + num * 5);
			bool flag;
			if (num2.HasValue)
			{
				long valueOrDefault = num2.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag = true;
					goto IL_00bf;
				}
			}
			flag = false;
			goto IL_00bf;
			IL_00bf:
			if (!flag)
			{
				throw new InvalidOperationException("宝箱奖励标记未就绪");
			}
			if (num2 == 0)
			{
				continue;
			}
			long? num3 = Num(6 + num * 5);
			if (num3.HasValue)
			{
				long valueOrDefault = num3.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault <= uint.MaxValue)
				{
					flag = false;
					goto IL_0120;
				}
			}
			flag = true;
			goto IL_0120;
			IL_0120:
			if (flag || !ArenaItemCatalog.Items.ContainsKey((uint)num3.Value))
			{
				throw new InvalidOperationException("宝箱道具编号未识别");
			}
			list.Add(new ArenaTreasureOption(num, (uint)num3.Value));
		}
		List<uint> list2 = new List<uint>();
		for (int num4 = 0; num4 < 10; num4++)
		{
			long? num5 = Num(75 + num4 * 5);
			bool flag;
			if (num5.HasValue)
			{
				long valueOrDefault = num5.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag = true;
					goto IL_01a4;
				}
			}
			flag = false;
			goto IL_01a4;
			IL_01a4:
			if (!flag)
			{
				throw new InvalidOperationException("已持有装备未就绪");
			}
			if (num5 == 0)
			{
				continue;
			}
			long? num6 = Num(78 + num4 * 5);
			if (num6.HasValue)
			{
				long valueOrDefault = num6.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault <= uint.MaxValue)
				{
					flag = false;
					goto IL_0206;
				}
			}
			flag = true;
			goto IL_0206;
			IL_0206:
			if (flag || !ArenaItemCatalog.Items.TryGetValue((uint)num6.Value, out ArenaItem value) || value.Category != 1)
			{
				throw new InvalidOperationException("已持有装备编号未识别");
			}
			list2.Add((uint)num6.Value);
		}
		List<uint> list3 = (Num(24).HasValue ? new List<uint>() : null);
		if (list3 != null)
		{
			for (int num7 = 0; num7 < 10; num7++)
			{
				long? num8 = Num(27 + num7 * 5);
				if (num8 == 0)
				{
					continue;
				}
				if (num8.HasValue)
				{
					long valueOrDefault = num8.GetValueOrDefault();
					if (valueOrDefault > 0 && valueOrDefault <= 203 && ArenaItemCatalog.Items[(uint)num8.Value].Category == 2)
					{
						list3.Add((uint)num8.Value);
						continue;
					}
				}
				throw new InvalidOperationException("宝箱持有道具未就绪");
			}
		}
		return new ArenaTreasureContents(list.ToArray(), list2.ToArray(), list3?.ToArray());
		long? Num(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	public static bool IsSelectionPrompt(string prompt)
	{
		if (GameText.Matches("Treasure.Prompt", prompt))
		{
			return true;
		}
		if (GameText.Language != "zhCN")
		{
			return false;
		}
		Match match = Regex.Match(GameText.Normalize(prompt), "^由于“盗贼匕首”的效果，能获取的临时道具变为([1-4])个。请选择第([1-4])个临时道具。$");
		if (match.Success)
		{
			return int.Parse(match.Groups[2].Value) <= int.Parse(match.Groups[1].Value);
		}
		return false;
	}

	public static bool IsExitPrompt(string prompt)
	{
		if (!GameText.Matches("Reward.ExitConfirm", prompt))
		{
			return GameText.Matches("Treasure.ExitConfirm", prompt);
		}
		return true;
	}

	public static bool MatchesPrompt(string prompt, uint itemId)
	{
		if (ArenaItemCatalog.Items.ContainsKey(itemId))
		{
			return ArenaPromptText.ContainsItem(prompt, "Reward.GetConfirm", itemId);
		}
		return false;
	}
}
