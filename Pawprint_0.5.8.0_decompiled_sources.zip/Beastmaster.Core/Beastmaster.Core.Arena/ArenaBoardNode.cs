using System.Numerics;

namespace Beastmaster.Core.Arena;

public sealed record ArenaBoardNode(int Index, Vector3 Center, int[] Next);
