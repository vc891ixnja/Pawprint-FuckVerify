namespace Beastmaster.Core.Arena;

public interface IArenaRewardWorld
{
	bool IsOpen { get; }

	IArenaEquipmentWorld? Equipment => null;

	bool TakeAllSupported => true;

	ArenaRewardView Read();

	bool TryChoose(int row);

	bool TryTakeAll();

	bool TryExit();

	bool TryAnswer(string prompt, bool yes);
}
