using System;
using System.Collections.Generic;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaBattleConfirmation
{
	public const string UnderfilledFlutes = "确定要在有兽笛未设置魔兽的情况下开始战斗吗？";

	public static bool Matches(string text)
	{
		if (!IsUnderfilled(text))
		{
			return IsUnderleveled(text);
		}
		return true;
	}

	public static bool IsUnderfilled(string text)
	{
		return GameText.Matches("Battle.BattlehornWarning", text);
	}

	public static bool IsUnderleveled(string text)
	{
		IReadOnlyList<string> readOnlyList = GameText.Fragments("Battle.Warning");
		if (readOnlyList.Count >= 3 && GameText.Matches("Battle.Warning", text) && Contains(text, readOnlyList[0]))
		{
			return Contains(text, readOnlyList[2]);
		}
		return false;
	}

	private static bool Contains(string text, string? fragment)
	{
		return GameText.Normalize(text).Contains(GameText.Normalize(fragment), StringComparison.Ordinal);
	}
}
