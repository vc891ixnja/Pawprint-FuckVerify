namespace Beastmaster.Core.Arena;

public sealed record ArenaTreasureOption(int Row, uint ItemId);
