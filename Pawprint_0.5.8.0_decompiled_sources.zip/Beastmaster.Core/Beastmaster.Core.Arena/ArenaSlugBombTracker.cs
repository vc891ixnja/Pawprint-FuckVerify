using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public sealed class ArenaSlugBombTracker
{
	private readonly Dictionary<ulong, TimeSpan> seenAt = new Dictionary<ulong, TimeSpan>();

	private readonly HashSet<ulong> bombed = new HashSet<ulong>();

	public int Seen => seenAt.Count;

	public bool IsBombed(ulong id)
	{
		return bombed.Contains(id);
	}

	public ulong? Due(TimeSpan now, IReadOnlyList<ulong> aliveIds)
	{
		foreach (ulong aliveId in aliveIds)
		{
			seenAt.TryAdd(aliveId, now);
		}
		ulong[] array = seenAt.Keys.Where((ulong id) => !aliveIds.Contains(id)).ToArray();
		foreach (ulong key in array)
		{
			seenAt.Remove(key);
		}
		foreach (ulong aliveId2 in aliveIds)
		{
			if (now - seenAt[aliveId2] >= ArenaSlugBombPolicy.Fuse && !bombed.Contains(aliveId2))
			{
				return aliveId2;
			}
		}
		return null;
	}

	public void MarkBombed(ulong id)
	{
		bombed.Add(id);
	}
}
