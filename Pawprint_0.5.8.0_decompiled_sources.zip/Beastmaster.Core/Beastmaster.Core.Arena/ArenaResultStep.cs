using System;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaResultStep : IWorkflowStep
{
	private readonly TimeSpan stability;

	private bool nextSent;

	private bool exitSent;

	private bool recorded;

	private bool done;

	private TimeSpan phaseAt;

	private TimeSpan nextAttempt;

	private ArenaResultPhase? phase;

	private TimeSpan? outsideAt;

	private ArenaRunResult? result;

	private ArenaRunResult? candidate;

	private TimeSpan? candidateAt;

	private bool failed;

	public ArenaRunResult? RecordedResult => result;

	public string Name { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(3L);

	public ArenaResultStep(IArenaResultWorld world, Action<ArenaRunResult> record, Action exited, TimeSpan? stabilityWindow = null)
	{
		_003Cworld_003EP = world;
		_003Crecord_003EP = record;
		_003Cexited_003EP = exited;
		stability = stabilityWindow ?? TimeSpan.FromSeconds(2L);
		Name = "斗兽 · 读取结算";
		base._002Ector();
	}

	public void MarkFailed()
	{
		failed = true;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		ArenaResultView arenaResultView = _003Cworld_003EP.Read();
		if (arenaResultView.Phase != phase)
		{
			phase = arenaResultView.Phase;
			phaseAt = elapsed;
		}
		if (elapsed - phaseAt > TimeSpan.FromSeconds((arenaResultView.Phase == ArenaResultPhase.Loading) ? 90 : 15))
		{
			throw new TimeoutException(Name + "，界面未更新");
		}
		if (arenaResultView.Phase == ArenaResultPhase.Loading)
		{
			outsideAt = null;
			Name = "斗兽 · 等待结算界面就绪";
			return StepResult.Running;
		}
		if (arenaResultView.Phase == ArenaResultPhase.Blocked)
		{
			throw new InvalidOperationException("斗兽结算界面已变化");
		}
		if (arenaResultView.Phase == ArenaResultPhase.Outside)
		{
			if (!recorded || !exitSent)
			{
				throw new InvalidOperationException("尚未处理本局结算就已离开");
			}
			TimeSpan valueOrDefault = outsideAt.GetValueOrDefault();
			if (!outsideAt.HasValue)
			{
				valueOrDefault = elapsed;
				outsideAt = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = outsideAt;
			if (value - timeSpan < TimeSpan.FromSeconds(2L))
			{
				return StepResult.Running;
			}
			if (!done)
			{
				_003Cexited_003EP();
				done = true;
			}
			Name = $"本局 {result.Score} 分 · 已退出";
			return StepResult.Completed;
		}
		if (arenaResultView.Result == null)
		{
			candidate = null;
			candidateAt = null;
			phaseAt = elapsed;
			Name = "斗兽 · 等待结算数据";
			return StepResult.Running;
		}
		ArenaRunResult arenaRunResult = arenaResultView.Result with
		{
			Failed = (failed || arenaResultView.Result.Failed)
		};
		if (recorded && result != arenaRunResult)
		{
			throw new InvalidOperationException("结算翻页后的成绩不一致");
		}
		if (!recorded)
		{
			if (candidate != arenaRunResult)
			{
				candidate = arenaRunResult;
				candidateAt = elapsed;
				Name = "斗兽 · 等待结算稳定";
			}
			phaseAt = elapsed;
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = candidateAt;
			if (value - timeSpan < stability)
			{
				return StepResult.Running;
			}
			result = candidate;
			_003Crecord_003EP(result);
			recorded = true;
		}
		Name = ((arenaResultView.Phase == ArenaResultPhase.NextPage) ? $"本局 {result.Score} 分 · 下一页" : "斗兽 · 退出奇盘");
		if (elapsed < nextAttempt)
		{
			return StepResult.Running;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		if (arenaResultView.Phase == ArenaResultPhase.NextPage && !nextSent)
		{
			nextSent = _003Cworld_003EP.TryNext();
		}
		if (arenaResultView.Phase == ArenaResultPhase.ExitPage && !exitSent)
		{
			exitSent = _003Cworld_003EP.TryExit();
		}
		return StepResult.Running;
	}

	public void Cancel()
	{
	}
}
