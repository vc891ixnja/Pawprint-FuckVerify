using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaShopStep(IArenaShopWorld world, Func<ArenaShopPet[], IEnumerable<uint>>? recipients = null, IReadOnlyList<uint>? priority = null, IReadOnlyList<uint>? equipmentPriority = null, ArenaResourcePolicy? resources = null) : IWorkflowStep
{
	private readonly ArenaEquipmentExchange equipment = new ArenaEquipmentExchange(world.Equipment, equipmentPriority, resources);

	private uint spent;

	private ArenaShopPet[]? pets;

	private readonly HashSet<uint> excluded = new HashSet<uint>();

	private readonly HashSet<uint> fed = new HashSet<uint>();

	private ArenaShopPurchase? purchase;

	private uint? openedItem;

	private uint balanceBefore;

	private bool opened;

	private bool petSent;

	private bool buySent;

	private bool backSent;

	private bool noSent;

	private bool exitSent;

	private bool exitConfirmed;

	private bool duplicateSent;

	private int sellStage;

	private uint sellTarget;

	private bool sellSubmitted;

	private bool sellAnswered;

	private readonly List<uint> sold = new List<uint>();

	private TimeSpan? sellReceiptAt;

	private TimeSpan sellDispatchSince;

	private uint[] sellOwnedAtStart = Array.Empty<uint>();

	private int sellCountBefore;

	private TimeSpan lastRequest;

	private TimeSpan nextAttempt;

	private ArenaShopPhase? lastPhase;

	private TimeSpan? returnedAt;

	public string Name { get; private set; } = "商店 · 读取商品";

	public TimeSpan Timeout => TimeSpan.FromMinutes(5L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed >= Timeout)
		{
			throw new TimeoutException("商店处理超时");
		}
		if (equipment.Tick(elapsed, out ArenaEquipmentOutcome outcome))
		{
			Name = equipment.Name;
			lastRequest = elapsed;
			return StepResult.Running;
		}
		if (outcome != null)
		{
			lastRequest = elapsed;
			if (!outcome.Accepted)
			{
				excluded.Add(outcome.ItemId);
				buySent = false;
				ResetRequest();
			}
		}
		ArenaShopView view = world.Read();
		if ((object)outcome != null && outcome.Accepted && !buySent && view.Phase == ArenaShopPhase.Selection)
		{
			if (purchase?.Offer.ItemId == outcome.ItemId)
			{
				buySent = true;
			}
			else if (((ReadOnlySpan<uint>)view.Contents.Owned).Contains(outcome.ItemId))
			{
				excluded.Add(outcome.ItemId);
				ResetRequest();
			}
		}
		if (view.Phase != lastPhase)
		{
			lastPhase = view.Phase;
			lastRequest = elapsed;
		}
		if (elapsed - lastRequest > TimeSpan.FromSeconds((view.Phase == ArenaShopPhase.Loading) ? 60 : 15))
		{
			throw new TimeoutException(Name + "，未收到操作结果");
		}
		if (view.Phase == ArenaShopPhase.Loading)
		{
			returnedAt = null;
			return StepResult.Running;
		}
		if (view.Phase == ArenaShopPhase.Blocked)
		{
			throw new InvalidOperationException("商店界面已变化");
		}
		if (view.Pets != null)
		{
			pets = view.Pets;
		}
		if (view.Phase == ArenaShopPhase.Returned)
		{
			if (!exitConfirmed)
			{
				throw new InvalidOperationException("商店未确认结束就已关闭");
			}
			TimeSpan valueOrDefault = returnedAt.GetValueOrDefault();
			if (!returnedAt.HasValue)
			{
				valueOrDefault = elapsed;
				returnedAt = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = returnedAt;
			if (value - timeSpan < TimeSpan.FromSeconds(2L))
			{
				return StepResult.Running;
			}
			Name = "商店 · 购买完成";
			return StepResult.Completed;
		}
		returnedAt = null;
		if (view.Phase == ArenaShopPhase.Duplicate)
		{
			uint? num = openedItem ?? ((IEnumerable<ArenaShopOffer>)view.Contents.Offers).Select((Func<ArenaShopOffer, uint?>)((ArenaShopOffer o) => o.ItemId)).FirstOrDefault((uint? id) => ArenaShopDecoder.IsDuplicate(view.Prompt, id.Value));
			if (!num.HasValue || !ArenaShopDecoder.IsDuplicate(view.Prompt, num.Value))
			{
				throw new InvalidOperationException("不是本次商店的重复持有提示：" + view.Prompt);
			}
			excluded.Add(num.Value);
			Name = "商店 · 跳过已持有道具";
			if (!duplicateSent && Attempt(() => world.TryDismissDuplicate(view.Prompt), elapsed))
			{
				duplicateSent = true;
			}
			return StepResult.Running;
		}
		ArenaResourcePolicy arenaResourcePolicy = resources;
		if (arenaResourcePolicy != null && arenaResourcePolicy.SellDisabled && sellStage == 0 && view.Phase == ArenaShopPhase.Selection)
		{
			if (view.Contents.Owned.Any(resources.IsSellCandidate))
			{
				sellStage = 1;
				sellDispatchSince = elapsed;
				sellOwnedAtStart = view.Contents.Owned;
			}
			else
			{
				sellStage = 2;
			}
		}
		if (sellStage == 1)
		{
			lastRequest = elapsed;
			if (elapsed - sellDispatchSince > TimeSpan.FromSeconds(30L))
			{
				sellStage = 2;
			}
			if (view.Phase == ArenaShopPhase.Selection)
			{
				if (sellSubmitted)
				{
					if (!sellAnswered)
					{
						return StepResult.Running;
					}
					if (view.Contents.Owned.Count((uint id) => id == sellTarget) >= sellCountBefore)
					{
						if (ArenaItemCatalog.Items[sellTarget].Category != 1)
						{
							return StepResult.Running;
						}
						TimeSpan valueOrDefault = sellReceiptAt.GetValueOrDefault();
						if (!sellReceiptAt.HasValue)
						{
							valueOrDefault = elapsed;
							sellReceiptAt = valueOrDefault;
						}
						TimeSpan value = elapsed;
						TimeSpan? timeSpan = sellReceiptAt;
						if (value - timeSpan < TimeSpan.FromSeconds(2L))
						{
							return StepResult.Running;
						}
					}
					sold.Add(sellTarget);
					sellSubmitted = (sellAnswered = false);
					sellTarget = 0u;
					sellReceiptAt = null;
				}
				if (!sellSubmitted)
				{
					uint next = sellOwnedAtStart.FirstOrDefault((uint id) => resources.IsSellCandidate(id) && sellOwnedAtStart.Count((uint x) => x == id) > sold.Count((uint x) => x == id));
					if (next == 0)
					{
						sellStage = 2;
					}
					else
					{
						Name = "商店 · 出售" + ArenaItemCatalog.Items[next].Name;
						sellCountBefore = view.Contents.Owned.Count((uint id) => id == next);
						if (Attempt(() => world.TrySell(next), elapsed))
						{
							sellSubmitted = true;
							sellTarget = next;
						}
					}
				}
				return StepResult.Running;
			}
		}
		if (view.Phase == ArenaShopPhase.Confirmation)
		{
			if (sellSubmitted)
			{
				if (sellAnswered)
				{
					return StepResult.Running;
				}
				if (!ArenaShopDecoder.IsSellPrompt(view.Prompt, sellTarget))
				{
					throw new InvalidOperationException("不是当前出售物品的确认窗口：" + view.Prompt);
				}
				Name = "商店 · 确认出售" + ArenaItemCatalog.Items[sellTarget].Name;
				if (Attempt(() => world.TryAnswer(view.Prompt, yes: true), elapsed))
				{
					sellAnswered = true;
				}
				return StepResult.Running;
			}
			if (buySent || exitConfirmed || noSent)
			{
				return StepResult.Running;
			}
			if (ArenaShopDecoder.IsExitPrompt(view.Prompt))
			{
				if (!exitSent)
				{
					Name = "商店 · 返回检查商品";
					if (Attempt(() => world.TryAnswer(view.Prompt, yes: false), elapsed))
					{
						noSent = true;
					}
				}
				else
				{
					Name = "商店 · 确认结束";
					if (Attempt(() => world.TryAnswer(view.Prompt, yes: true), elapsed))
					{
						exitConfirmed = true;
					}
				}
				return StepResult.Running;
			}
			if ((object)purchase == null)
			{
				purchase = ArenaShopPolicy.Choose(view.Contents, pets, excluded, fed, recipients, priority, (world.Equipment != null) ? (equipmentPriority ?? Array.Empty<uint>()) : null, resources, spent);
			}
			bool valid = purchase != null && ArenaShopDecoder.MatchesBuyPrompt(view.Prompt, purchase, pets ?? Array.Empty<ArenaShopPet>()) && StillEligible(view.Contents, purchase);
			Name = (valid ? ("商店 · 确认购买" + ArenaItemCatalog.Items[purchase.Offer.ItemId].Name) : "商店 · 返回重新选择");
			if (Attempt(() => world.TryAnswer(view.Prompt, valid), elapsed))
			{
				if (valid)
				{
					balanceBefore = view.Contents.Balance;
					buySent = true;
				}
				else
				{
					noSent = true;
				}
			}
			return StepResult.Running;
		}
		if (view.Phase == ArenaShopPhase.Feeding)
		{
			if (backSent || (petSent && !noSent))
			{
				return StepResult.Running;
			}
			if (noSent)
			{
				noSent = (petSent = false);
				purchase = null;
			}
			ArenaShopPurchase best = ArenaShopPolicy.Choose(view.Contents, pets, excluded, fed, recipients, priority, (world.Equipment != null) ? (equipmentPriority ?? Array.Empty<uint>()) : null, resources, spent);
			ArenaShopPurchase arenaShopPurchase = best;
			if ((object)arenaShopPurchase == null || !arenaShopPurchase.PetNumber.HasValue || best.Offer.ItemId != view.FoodId)
			{
				Name = "商店 · 返回选择食料";
				if (Attempt(world.TryBack, elapsed))
				{
					backSent = true;
				}
				return StepResult.Running;
			}
			purchase = best;
			openedItem = best.Offer.ItemId;
			ArenaShopPet pet = pets.Single((ArenaShopPet p) => p.Number == best.PetNumber);
			Name = "商店 · " + ArenaItemCatalog.Items[view.FoodId].Name + " → " + pet.Name;
			if (Attempt(() => world.TryFeed(pet.Number), elapsed))
			{
				petSent = true;
			}
			return StepResult.Running;
		}
		if (buySent)
		{
			uint num2 = balanceBefore - purchase.Offer.Price;
			if (view.Contents.Balance == balanceBefore && purchase.Offer.Price != 0)
			{
				return StepResult.Running;
			}
			if (view.Contents.Balance != num2)
			{
				throw new InvalidOperationException("商店扣款与确认价格不一致");
			}
			if (!((ReadOnlySpan<uint>)view.Contents.Owned).Contains(purchase.Offer.ItemId) && !view.Contents.Offers.Any((ArenaShopOffer o) => o.ItemId == purchase.Offer.ItemId && o.Sold))
			{
				return StepResult.Running;
			}
			excluded.Add(purchase.Offer.ItemId);
			checked
			{
				spent += purchase.Offer.Price;
				uint? petNumber = purchase.PetNumber;
				if (petNumber.HasValue)
				{
					uint recipient = petNumber.GetValueOrDefault();
					fed.Add(recipient);
					if (pets != null)
					{
						pets = pets.Select((ArenaShopPet p) => (p.Number != recipient) ? p : p with
						{
							FoodId = purchase.Offer.ItemId
						}).ToArray();
					}
				}
				ResetRequest();
			}
		}
		if (backSent || noSent || duplicateSent)
		{
			ResetRequest();
		}
		if (opened || exitSent)
		{
			return StepResult.Running;
		}
		purchase = ArenaShopPolicy.Choose(view.Contents, pets, excluded, fed, recipients, priority, (world.Equipment != null) ? (equipmentPriority ?? Array.Empty<uint>()) : null, resources, spent);
		ArenaShopOffer offer = purchase?.Offer;
		if (pets == null)
		{
			ArenaShopOffer arenaShopOffer = (from o in ArenaShopPolicy.Available(view.Contents, excluded)
				where ArenaItemCatalog.Items[o.ItemId].Category == 3 && (resources == null || resources.CanAfford(view.Contents, o, spent))
				orderby resources?.ShopRank(o, view.Contents) ?? ArenaPresetPolicy.Priority(priority, o.ItemId), ArenaFoodPolicy.DamageScore(o.ItemId) descending, o.Price
				select o).FirstOrDefault();
			if (arenaShopOffer != null && (offer == null || (resources?.Before(arenaShopOffer, offer, view.Contents) ?? (ArenaPresetPolicy.Priority(priority, arenaShopOffer.ItemId) < ArenaPresetPolicy.Priority(priority, offer.ItemId)))))
			{
				offer = arenaShopOffer;
				purchase = null;
			}
		}
		if (offer != null)
		{
			Name = $"商店 · {ArenaItemCatalog.Items[offer.ItemId].Name}（{offer.Price} 币）";
			if (Attempt(() => world.TryOpen(offer), elapsed))
			{
				opened = true;
				openedItem = offer.ItemId;
				balanceBefore = view.Contents.Balance;
			}
		}
		else
		{
			Name = "商店 · 结束购买";
			if (Attempt(world.TryExit, elapsed))
			{
				exitSent = true;
			}
		}
		return StepResult.Running;
	}

	private bool StillEligible(ArenaShopContents shop, ArenaShopPurchase p)
	{
		if (((ReadOnlySpan<ArenaShopOffer>)shop.Offers).Contains(p.Offer) && !p.Offer.Sold && (resources == null || resources.CanAfford(shop, p.Offer, spent)) && (ArenaItemCatalog.Items[p.Offer.ItemId].Category != 1 || resources == null || resources.CanEquip(p.Offer.ItemId, (IReadOnlyCollection<uint>)(object)shop.Owned)) && (ArenaItemCatalog.Items[p.Offer.ItemId].Category != 2 || shop.BagCount < 10) && p.Offer.Price <= shop.Balance && (ArenaItemCatalog.Items[p.Offer.ItemId].Category == 2 || !((ReadOnlySpan<uint>)shop.Owned).Contains(p.Offer.ItemId)) && !excluded.Contains(p.Offer.ItemId))
		{
			if (p.PetNumber.HasValue)
			{
				return pets?.Any((ArenaShopPet pet) => pet.Number == p.PetNumber && pet.Hp != 0 && pet.FoodId == 0 && !fed.Contains(pet.Number) && ArenaFoodPolicy.CanEat(pet.Number, p.Offer.ItemId)) ?? false;
			}
			return true;
		}
		return false;
	}

	private bool Attempt(Func<bool> action, TimeSpan elapsed)
	{
		if (elapsed < nextAttempt)
		{
			return false;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		if (!action())
		{
			return false;
		}
		lastRequest = elapsed;
		return true;
	}

	private void ResetRequest()
	{
		opened = (petSent = (buySent = (backSent = (noSent = (duplicateSent = false)))));
		purchase = null;
		openedItem = null;
	}

	public void Cancel()
	{
	}
}
