using System;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRuleTrigger
{
	public ArenaRuleTriggerKind Kind { get; set; }

	public uint EnemyNameId { get; set; }

	public int Seconds { get; set; }

	public int Percent { get; set; } = 50;

	public int Count { get; set; } = 1;

	public int PetSlot { get; set; }
}
