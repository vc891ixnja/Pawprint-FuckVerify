using System;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaPromptText
{
	public static bool ContainsItem(string text, string key, uint itemId)
	{
		string text2 = ArenaItemCatalog.LocalizedName(itemId);
		if (text2 != null && text2.Length > 0 && GameText.Matches(key, text))
		{
			return GameText.Normalize(text).Contains(GameText.Normalize(text2), StringComparison.Ordinal);
		}
		return false;
	}

	public static bool ItemThenFragment(string text, string key, uint itemId)
	{
		return ContainsItem(text, key, itemId);
	}
}
