using System.Collections.Generic;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Arena;

public interface IArenaRuleWorld
{
	IReadOnlyList<CombatTarget> AliveEnemies();

	CombatTarget? CurrentTarget();

	(ulong ObjectId, uint BaseId)[] SummonedPets();

	(ulong ObjectId, uint CurrentHp, uint MaxHp) PlayerState();

	WorldPoint? PlayerPosition();

	bool TryUseDutyAction(int slot, ulong targetId);

	long DutyConfirmSequence(int slot);

	IReadOnlyList<(ulong TargetId, long Seq)> DutyConfirmations(int slot);

	bool TryPrcFinisher();

	bool TryCountdown(int seconds);
}
