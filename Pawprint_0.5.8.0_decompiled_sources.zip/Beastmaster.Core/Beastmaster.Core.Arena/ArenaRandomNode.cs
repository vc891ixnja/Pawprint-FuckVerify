namespace Beastmaster.Core.Arena;

public sealed record ArenaRandomNode(int StageId, int Node, int RandomSlot, int PoolId, ArenaRandomOutcome[] Outcomes);
