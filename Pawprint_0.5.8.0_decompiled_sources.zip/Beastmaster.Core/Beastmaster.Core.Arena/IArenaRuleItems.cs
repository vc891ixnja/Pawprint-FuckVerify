namespace Beastmaster.Core.Arena;

public interface IArenaRuleItems
{
	string? LastDeny => null;

	ArenaHealView ReadHud();

	bool TryUseItem(int slot, uint itemId, ulong targetId);
}
