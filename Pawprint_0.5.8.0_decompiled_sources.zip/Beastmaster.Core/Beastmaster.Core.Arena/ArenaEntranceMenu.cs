using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaEntranceMenu
{
	public static int ActivityRow(IReadOnlyList<string> entries)
	{
		return MatchRow(entries, "Entry.MenuActivity");
	}

	public static int ChallengeRow(IReadOnlyList<string> entries)
	{
		return MatchRow(entries, "Entry.MenuChallenge");
	}

	public static int MatchRow(IReadOnlyList<string> entries, string key)
	{
		List<int> list = new List<int>();
		for (int i = 0; i < entries.Count; i++)
		{
			if (GameText.Matches(key, entries[i]))
			{
				list.Add(i);
			}
		}
		if (list.Count > 1)
		{
			throw new InvalidOperationException("菜单中匹配 " + key + " 的选项不唯一");
		}
		if (list.Count != 1)
		{
			return -1;
		}
		return list[0];
	}

	public static int FindRow(IEnumerable<IEnumerable<string>> rows, string title)
	{
		string expected = GameText.Normalize(title);
		if (expected.Length == 0)
		{
			throw new InvalidOperationException("选项名称尚未加载");
		}
		int[] array = (from r in rows.Select((IEnumerable<string> texts, int row) => (texts: texts, row: row))
			where r.texts.Any((string text) => GameText.Normalize(text) == expected)
			select r.row).ToArray();
		if (array.Length > 1)
		{
			throw new InvalidOperationException("菜单中的“" + title + "”不唯一");
		}
		if (array.Length != 1)
		{
			return -1;
		}
		return array[0];
	}
}
