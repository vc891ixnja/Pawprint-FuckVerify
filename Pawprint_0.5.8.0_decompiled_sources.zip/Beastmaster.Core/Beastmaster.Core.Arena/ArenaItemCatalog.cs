using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaItemCatalog
{
	private static readonly IReadOnlyDictionary<uint, string?[]> Names = LoadNames();

	public static IReadOnlyDictionary<uint, ArenaItem> Items { get; } = Load();

	public static string? LocalizedName(uint id)
	{
		if (!Items.ContainsKey(id) || !Names.TryGetValue(id, out string[] value))
		{
			return null;
		}
		return value[GameText.LanguageIndex] ?? value[0];
	}

	private static IReadOnlyDictionary<uint, string?[]> LoadNames()
	{
		using Stream utf8Json = typeof(ArenaItemCatalog).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-item-names.json") ?? throw new InvalidOperationException("斗兽道具名表缺失");
		return JsonSerializer.Deserialize<Dictionary<uint, Dictionary<string, string>>>(utf8Json).ToDictionary((KeyValuePair<uint, Dictionary<string, string>> kv) => kv.Key, (KeyValuePair<uint, Dictionary<string, string>> kv) => GameText.LanguageCodes.Select((string l) => kv.Value.GetValueOrDefault(l)).ToArray());
	}

	private static IReadOnlyDictionary<uint, ArenaItem> Load()
	{
		using Stream utf8Json = typeof(ArenaItemCatalog).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-items.json") ?? throw new InvalidOperationException("斗兽道具表缺失");
		return JsonSerializer.Deserialize<ArenaItem[]>(utf8Json).ToDictionary((ArenaItem i) => i.Id);
	}
}
