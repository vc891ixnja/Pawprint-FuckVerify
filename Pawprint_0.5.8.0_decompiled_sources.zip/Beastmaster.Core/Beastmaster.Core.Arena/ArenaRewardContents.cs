namespace Beastmaster.Core.Arena;

public sealed record ArenaRewardContents(bool CoinsAvailable, uint Coins, uint Balance, ArenaTreasureOption[] Options, uint[] Owned);
