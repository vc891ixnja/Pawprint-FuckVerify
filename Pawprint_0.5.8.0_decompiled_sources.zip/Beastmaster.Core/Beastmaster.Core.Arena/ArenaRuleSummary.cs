using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Beastmaster.Core.Arena;

public static class ArenaRuleSummary
{
	public static string Describe(ArenaBattleRule rule)
	{
		if (!string.IsNullOrWhiteSpace(rule.Name))
		{
			return rule.Name;
		}
		StringBuilder stringBuilder = new StringBuilder();
		ArenaRuleTrigger trigger = rule.Trigger;
		StringBuilder stringBuilder2 = stringBuilder;
		stringBuilder2.Append(trigger.Kind switch
		{
			ArenaRuleTriggerKind.Always => "进入战斗", 
			ArenaRuleTriggerKind.BattleElapsed => $"开战满 {trigger.Seconds} 秒", 
			ArenaRuleTriggerKind.EnemyHpBelow => (trigger.EnemyNameId != 0) ? $"{ArenaEnemyCatalog.Name(trigger.EnemyNameId)} HP<{trigger.Percent}%" : $"最强敌人 HP<{trigger.Percent}%", 
			ArenaRuleTriggerKind.EnemyAliveFor => $"{ArenaEnemyCatalog.Name(trigger.EnemyNameId)} 存活满 {trigger.Seconds} 秒", 
			ArenaRuleTriggerKind.EnemyCount => (trigger.EnemyNameId != 0) ? $"{ArenaEnemyCatalog.Name(trigger.EnemyNameId)}×{trigger.Count}" : $"敌人数量≥{trigger.Count}", 
			ArenaRuleTriggerKind.TargetIs => "目标是" + ArenaEnemyCatalog.Name(trigger.EnemyNameId), 
			ArenaRuleTriggerKind.PetSummoned => (trigger.PetSlot <= 0) ? "魔兽重新召唤" : $"{trigger.PetSlot} 号魔兽重新召唤", 
			ArenaRuleTriggerKind.PlayerHpBelow => $"玩家 HP<{trigger.Percent}%", 
			_ => trigger.Kind.ToString(), 
		});
		stringBuilder.Append(" → ");
		stringBuilder2 = stringBuilder;
		stringBuilder2.Append(rule.Action.Kind switch
		{
			ArenaRuleActionKind.UseItems => (rule.Action.ItemLimit > 0) ? $"使用道具（{ArenaRuleItemFilters.Label(rule.Action.ItemFilter)}，限 {rule.Action.ItemLimit} 件）" : ("使用道具（" + ArenaRuleItemFilters.Label(rule.Action.ItemFilter) + "）"), 
			ArenaRuleActionKind.UseDutyAction => $"职责技槽 {rule.Action.DutyActionSlot}", 
			ArenaRuleActionKind.SetTargetPriority => "目标优先 " + string.Join("→", rule.Action.PriorityEnemyIds.Select(ArenaEnemyCatalog.Name)), 
			ArenaRuleActionKind.Countdown => $"倒计时 {rule.Action.CountdownSeconds} 秒", 
			ArenaRuleActionKind.CallPrcFinisher => "PR 最后一击", 
			ArenaRuleActionKind.MoveBehind => "背后接近", 
			_ => rule.Action.Kind.ToString(), 
		});
		List<string> list = new List<string>();
		if (rule.Limit.WindowSeconds > 0)
		{
			list.Add($"前 {rule.Limit.WindowSeconds} 秒");
		}
		if (rule.Limit.Once == ArenaRuleOnce.PerPetSummon)
		{
			list.Add("每次召唤一次");
		}
		else if (rule.Limit.Once == ArenaRuleOnce.PerTargetInstance)
		{
			list.Add("每个目标一次");
		}
		else if (rule.Limit.Once == ArenaRuleOnce.None)
		{
			list.Add("可重复");
		}
		if (list.Count > 0)
		{
			stringBuilder.Append("（" + string.Join("，", list) + "）");
		}
		return stringBuilder.ToString();
	}
}
