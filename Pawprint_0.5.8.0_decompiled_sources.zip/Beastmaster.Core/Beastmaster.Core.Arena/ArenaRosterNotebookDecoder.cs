using System;
using System.Linq;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaRosterNotebookDecoder
{
	public static NotebookPage Decode(NotebookSnapshot snapshot)
	{
		if (!GameText.Matches("Party.Title", snapshot.Values.FirstOrDefault((NotebookValue v) => v.Index == 2)?.Text))
		{
			throw new InvalidOperationException("等待魔兽编队图鉴加载");
		}
		return NotebookPageDecoder.Decode(snapshot);
	}
}
