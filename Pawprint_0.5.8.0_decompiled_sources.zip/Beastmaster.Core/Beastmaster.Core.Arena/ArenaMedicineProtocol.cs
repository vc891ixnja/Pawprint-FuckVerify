using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaMedicineProtocol
{
	public static ArenaMedicineArgument[] Open(int slot)
	{
		if ((slot < 0 || slot > 9) ? true : false)
		{
			throw new ArgumentOutOfRangeException("slot");
		}
		return new ArenaMedicineArgument[3]
		{
			new ArenaMedicineArgument(3, 6),
			new ArenaMedicineArgument(3, slot),
			new ArenaMedicineArgument(0)
		};
	}

	public static int? UseRow(IReadOnlyList<ArenaValue> values)
	{
		long? count = values.FirstOrDefault((ArenaValue v) => v.Index == 0)?.Number;
		if (count.HasValue)
		{
			switch (count.GetValueOrDefault())
			{
			case 1L:
			case 2L:
			case 3L:
			case 4L:
			case 5L:
			case 6L:
			case 7L:
			case 8L:
			case 9L:
			case 10L:
			case 11L:
			case 12L:
			case 13L:
			case 14L:
			case 15L:
			case 16L:
			case 17L:
			case 18L:
			case 19L:
			case 20L:
			case 21L:
			case 22L:
			case 23L:
			case 24L:
			case 25L:
			case 26L:
			case 27L:
			case 28L:
			case 29L:
			case 30L:
			case 31L:
			case 32L:
				goto IL_006e;
			}
		}
		bool flag = true;
		goto IL_0071;
		IL_0071:
		if (flag)
		{
			return null;
		}
		ArenaValue[] array = values.Where((ArenaValue v) => v.Index >= 8 && v.Index < 8 + count && GameText.Matches("Item.Use", v.Text)).ToArray();
		if (array.Length != 1)
		{
			return null;
		}
		return array[0].Index - 8;
		IL_006e:
		flag = false;
		goto IL_0071;
	}

	public static ArenaMedicineArgument[] Use(int row)
	{
		if ((row < 0 || row > 31) ? true : false)
		{
			throw new ArgumentOutOfRangeException("row");
		}
		return new ArenaMedicineArgument[5]
		{
			new ArenaMedicineArgument(3),
			new ArenaMedicineArgument(3, row),
			new ArenaMedicineArgument(5),
			new ArenaMedicineArgument(0),
			new ArenaMedicineArgument(0)
		};
	}
}
