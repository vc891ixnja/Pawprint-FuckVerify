namespace Beastmaster.Core.Arena;

public interface IArenaHealWorld
{
	bool DuringBattle => false;

	bool DirectDispatch => false;

	ArenaHealView Read();

	bool TryOpen(ArenaHealItem item);

	bool TryUse(ArenaHealItem item);

	bool TryDispatch(ArenaHealItem item)
	{
		return false;
	}

	void RestoreTarget()
	{
	}
}
