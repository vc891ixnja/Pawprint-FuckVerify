using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaPartyDecoder
{
	public static ArenaPet[] Decode(IReadOnlyList<ArenaValue> values, bool allowEmpty = false)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue x) => x.Index);
		long num = Num(5);
		if (num < ((!allowEmpty) ? 1 : 0) || num > 15)
		{
			throw new InvalidOperationException("魔兽编队字段不匹配");
		}
		List<ArenaPet> list = new List<ArenaPet>();
		for (int num2 = 0; num2 < num; num2++)
		{
			int num3 = 6 + num2 * 77;
			long num4 = Num(num3 + 76);
			long num5 = Num(num3 + 5);
			long num6 = Num(num3 + 6);
			long num7 = Num(num3 + 74);
			string text = v.GetValueOrDefault(num3 + 3)?.Text;
			bool flag = ((num4 < 1 || num4 > 50) ? true : false);
			bool flag2 = flag || num5 < 0 || num6 <= 0 || num5 > num6;
			if (!flag2)
			{
				bool flag3 = ((num7 < 0 || num7 > 3) ? true : false);
				flag2 = flag3;
			}
			if (flag2 || string.IsNullOrEmpty(text))
			{
				throw new InvalidOperationException("魔兽编队数据未就绪");
			}
			list.Add(new ArenaPet(num2, (uint)num4, text, (uint)num5, (uint)num6, (int)num7));
		}
		if (list.Select((ArenaPet p) => p.PetId).Distinct().Count() != list.Count || (from p in list
			where p.Slot < 3
			group p by p.Slot).Any((IGrouping<int, ArenaPet> g) => g.Count() != 1))
		{
			throw new InvalidOperationException("魔兽编队含重复条目或兽笛");
		}
		return list.ToArray();
		long Num(int i)
		{
			if (!v.TryGetValue(i, out var value) || !value.Number.HasValue)
			{
				return -1L;
			}
			return value.Number.Value;
		}
	}

	public static ArenaPet? NextToAssign(IReadOnlyList<ArenaPet> pets, IReadOnlyList<uint>? order = null)
	{
		Dictionary<uint, ArenaPet> byId = pets.ToDictionary((ArenaPet p) => p.PetId);
		ArenaPet value;
		uint[] array = (from id in (order ?? (from p in pets
				orderby p.Row
				select p.PetId).ToArray()).Concat(from p in pets
				orderby p.Row
				select p.PetId).Distinct()
			where byId.TryGetValue(id, out value) && value.Hp != 0
			select id).Take(3).ToArray();
		if (array.Length == 0)
		{
			throw new InvalidOperationException("没有可设置到兽笛的存活魔兽");
		}
		int prefix;
		for (prefix = 0; prefix < array.Length && byId[array[prefix]].Slot == prefix; prefix++)
		{
		}
		ArenaPet arenaPet = (from p in pets
			where p.Slot < 3 && p.Slot >= prefix
			orderby p.Slot descending
			select p).FirstOrDefault();
		if ((object)arenaPet == null)
		{
			if (prefix >= array.Length)
			{
				return null;
			}
			arenaPet = byId[array[prefix]];
		}
		return arenaPet;
	}
}
