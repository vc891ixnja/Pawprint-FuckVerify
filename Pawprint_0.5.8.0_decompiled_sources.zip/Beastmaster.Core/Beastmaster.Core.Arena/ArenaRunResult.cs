namespace Beastmaster.Core.Arena;

public sealed record ArenaRunResult(int StageId, uint Score, uint LowCrystals, uint HighCrystals, bool Failed = false, string? Rating = null);
