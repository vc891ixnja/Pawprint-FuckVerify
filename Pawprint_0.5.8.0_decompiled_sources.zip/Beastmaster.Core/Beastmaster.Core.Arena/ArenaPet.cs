namespace Beastmaster.Core.Arena;

public sealed record ArenaPet(int Row, uint PetId, string Name, uint Hp, uint MaxHp, int Slot);
