namespace Beastmaster.Core.Arena;

public readonly record struct ArenaMedicineArgument(int Type, int Value = 0);
