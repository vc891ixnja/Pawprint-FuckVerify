using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaBattlePreset
{
	public int Node { get; set; }

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool EnableCustomLogic { get; set; } = true;

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool EnableCustomLogic2 { get; set; } = true;

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool EnableCustomLogic3 { get; set; } = true;

	public bool HealOverride { get; set; }

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool HealEnabled { get; set; } = true;

	public int HealBelowPercent { get; set; } = 50;

	public bool DisableHealItems { get; set; }

	public ArenaFluteChoice[] Flutes { get; set; } = new ArenaFluteChoice[3]
	{
		new ArenaFluteChoice(),
		new ArenaFluteChoice(),
		new ArenaFluteChoice()
	};

	public List<ArenaBattleRule> Rules { get; set; } = new List<ArenaBattleRule>();

	public bool RuleMode
	{
		get
		{
			List<ArenaBattleRule> rules = Rules;
			if (rules != null)
			{
				return rules.Count > 0;
			}
			return false;
		}
	}

	public bool LogicEnabled(int slot)
	{
		return slot switch
		{
			3 => EnableCustomLogic3, 
			2 => EnableCustomLogic2, 
			1 => EnableCustomLogic, 
			_ => false, 
		};
	}

	public void SetLogicEnabled(int slot, bool value)
	{
		switch (slot)
		{
		case 1:
			EnableCustomLogic = value;
			break;
		case 2:
			EnableCustomLogic2 = value;
			break;
		case 3:
			EnableCustomLogic3 = value;
			break;
		}
	}

	public void FoldLegacyHeal()
	{
		if (DisableHealItems)
		{
			HealOverride = true;
			HealEnabled = false;
			DisableHealItems = false;
		}
	}

	public static (bool Enabled, int Percent) EffectiveBattleHeal(ArenaBattlePreset? battle, bool globalEnabled, int globalPercent)
	{
		if (battle == null || !battle.HealOverride)
		{
			return (Enabled: globalEnabled, Percent: globalPercent);
		}
		return (Enabled: battle.HealEnabled, Percent: battle.HealBelowPercent);
	}

	public static bool EffectiveBoardHeal(ArenaBattlePreset? battle, bool globalEnabled)
	{
		if (battle == null || !battle.HealOverride)
		{
			return globalEnabled;
		}
		return battle.HealEnabled;
	}
}
