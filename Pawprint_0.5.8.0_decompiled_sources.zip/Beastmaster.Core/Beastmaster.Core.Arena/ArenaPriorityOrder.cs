using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaPriorityOrder
{
	public static List<uint> Complete(IReadOnlyList<uint> saved, ArenaPriorityKind kind)
	{
		if (kind == ArenaPriorityKind.Equipment)
		{
			return ArenaEquipmentPolicy.Complete(saved);
		}
		return (from i in ArenaItemCatalog.Items.Values.Where(delegate(ArenaItem i)
			{
				bool flag = kind != ArenaPriorityKind.Healing || ArenaHealPolicy.Healing(i.Id) > 0;
				if (flag)
				{
					bool flag2 = kind != ArenaPriorityKind.Rewards;
					if (!flag2)
					{
						int category = i.Category;
						bool flag3 = (uint)(category - 1) <= 1u;
						flag2 = flag3;
					}
					flag = flag2;
				}
				return flag && (kind != ArenaPriorityKind.Supplies || i.Category != 1);
			})
			orderby ArenaPresetPolicy.Priority(saved, i.Id), (kind == ArenaPriorityKind.Shop && i.Category == 3) ? 1 : 0, (kind != ArenaPriorityKind.Healing) ? ((kind != ArenaPriorityKind.Shop || i.Category != 3) ? ArenaTreasurePolicy.Score(i.Id, (IReadOnlyCollection<uint>)(object)Array.Empty<uint>()) : ArenaFoodPolicy.DamageScore(i.Id)) : ((double)ArenaHealPolicy.Healing(i.Id)) descending, i.Id
			select i.Id).ToList();
	}

	public static List<uint> Move(IReadOnlyList<uint> fullOrder, uint item, int rank)
	{
		List<uint> list = fullOrder.ToList();
		if (!list.Remove(item))
		{
			throw new ArgumentException("道具不在优先列表内", "item");
		}
		list.Insert(Math.Clamp(rank, 1, fullOrder.Count) - 1, item);
		return list;
	}
}
