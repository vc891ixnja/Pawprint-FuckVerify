namespace Beastmaster.Core.Arena;

public enum ArenaRuleTargetKind
{
	None,
	Self,
	CurrentTarget,
	TriggeredEnemy,
	Enemy,
	Pet
}
