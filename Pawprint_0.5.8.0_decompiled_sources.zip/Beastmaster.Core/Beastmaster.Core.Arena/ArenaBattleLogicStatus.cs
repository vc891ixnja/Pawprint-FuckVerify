using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaBattleLogicStatus
{
	private static readonly (int Stage, int Node, int Slot, string Note)[] Definitions = new(int, int, int, string)[9]
	{
		(1, 1, 1, "目标优先主教、其次骑士；骑士在场时对其使用吸引注意"),
		(1, 6, 1, "开局45秒内对已召唤魔兽使用吸引注意，重新召唤后补用"),
		(1, 8, 1, "优先攻击大鬼，大小火焰怪为备选目标"),
		(1, 12, 1, "梦魔血量低于一半时连续使用全部道具"),
		(4, 2, 1, "四只幼苗全部出现后调用 PR 的最后一击"),
		(4, 11, 1, "蛞蝓存活超过5秒就对其使用攻击类道具"),
		(4, 11, 2, "树精血量低于一半后对自己使用功能道具（不含时之沙）"),
		(4, 14, 1, "怨毒龙上天落地后立即重新选中它"),
		(4, 14, 2, "怨毒龙血量低于一半时连续使用全部非恢复道具")
	};

	public static bool IsComplete(int stageId, int node)
	{
		return Definitions.Any(((int Stage, int Node, int Slot, string Note) d) => d.Stage == stageId && d.Node == node);
	}

	public static bool IsComplete(int stageId, int node, int slot)
	{
		return Definitions.Any(((int Stage, int Node, int Slot, string Note) d) => d.Stage == stageId && d.Node == node && d.Slot == slot);
	}

	public static IReadOnlyList<int> Slots(int stageId, int node)
	{
		return (from d in Definitions
			where d.Stage == stageId && d.Node == node
			select d.Slot).ToArray();
	}

	public static string Note(int stageId, int node, int slot)
	{
		return Definitions.FirstOrDefault(((int Stage, int Node, int Slot, string Note) d) => d.Stage == stageId && d.Node == node && d.Slot == slot).Note ?? "";
	}
}
