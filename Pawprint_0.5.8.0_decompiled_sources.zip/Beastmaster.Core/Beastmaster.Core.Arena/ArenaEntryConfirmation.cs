using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaEntryConfirmation
{
	public const uint QuestionAddonId = 17787u;

	public const string Question = "确定要在存在以下问题的情况下开始挑战吗？";

	public const string Warning = "魔兽未满编";

	public static bool Matches(string text)
	{
		if (GameText.Fragments("Battle.Warning").Count == 0)
		{
			return false;
		}
		string language = GameText.Language;
		if ((!(language == "zhCN") && !(language == "zhTW")) || 1 == 0)
		{
			return GameText.Matches("Battle.Warning", text);
		}
		string text2 = Header();
		string text3 = GameText.Normalize(text);
		if (text2.Length > 0 && text3.StartsWith(text2, StringComparison.Ordinal))
		{
			return text3.Length > text2.Length;
		}
		return false;
	}

	public static bool IsUnderleveled(string text)
	{
		IReadOnlyList<string> readOnlyList = GameText.Fragments("Battle.Warning");
		if (readOnlyList.Count >= 3 && Matches(text))
		{
			return Contains(text, readOnlyList[2]);
		}
		return false;
	}

	public static bool IsUnderfilled(string text)
	{
		IReadOnlyList<string> readOnlyList = GameText.Fragments("Battle.Warning");
		if (readOnlyList.Count < 2 || !Matches(text))
		{
			return false;
		}
		return Contains(text, readOnlyList[1]);
	}

	private static string Header()
	{
		return GameText.Normalize(GameText.Fragments("Battle.Warning").FirstOrDefault() ?? "");
	}

	private static bool Contains(string text, string? fragment)
	{
		return GameText.Normalize(text).Contains(GameText.Normalize(fragment), StringComparison.Ordinal);
	}
}
