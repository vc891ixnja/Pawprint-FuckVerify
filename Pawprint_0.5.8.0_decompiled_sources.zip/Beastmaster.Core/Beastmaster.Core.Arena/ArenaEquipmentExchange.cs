using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public sealed class ArenaEquipmentExchange(IArenaEquipmentWorld? world, IReadOnlyList<uint>? priority, ArenaResourcePolicy? resources = null)
{
	private ArenaEquipmentContents? pending;

	private ArenaEquipmentSlot? target;

	private bool selected;

	private bool confirmed;

	private bool cancelled;

	private bool rejectedPrompt;

	private TimeSpan started;

	private TimeSpan nextAttempt;

	private TimeSpan? mismatchedAt;

	private TimeSpan? closedAt;

	private string answeredPrompt = "";

	public string Name { get; private set; } = "装备 · 读取替换列表";

	public bool Tick(TimeSpan elapsed, out ArenaEquipmentOutcome? outcome)
	{
		outcome = null;
		if (world == null)
		{
			return false;
		}
		ArenaEquipmentView view = world.Read();
		if (view.Phase == ArenaEquipmentPhase.ParentConfirmation)
		{
			if (pending != null)
			{
				started = elapsed;
			}
			closedAt = null;
			return false;
		}
		if (view.Phase == ArenaEquipmentPhase.Closed)
		{
			if (pending != null)
			{
				TimeSpan valueOrDefault = closedAt.GetValueOrDefault();
				if (!closedAt.HasValue)
				{
					valueOrDefault = elapsed;
					closedAt = valueOrDefault;
				}
				if ((!confirmed && !cancelled) || (confirmed && view.Owned != null))
				{
					uint[]? owned = view.Owned;
					if (owned == null || !((ReadOnlySpan<uint>)owned).Contains(pending.Incoming))
					{
						TimeSpan value = elapsed;
						TimeSpan? timeSpan = closedAt;
						if (value - timeSpan < TimeSpan.FromSeconds(1L))
						{
							return true;
						}
					}
				}
				uint incoming = pending.Incoming;
				uint[]? owned2 = view.Owned;
				outcome = new ArenaEquipmentOutcome(incoming, (owned2 != null) ? ((ReadOnlySpan<uint>)owned2).Contains(pending.Incoming) : confirmed);
				Reset();
			}
			return false;
		}
		if (view.Phase == ArenaEquipmentPhase.Loading)
		{
			return true;
		}
		closedAt = null;
		ArenaEquipmentContents contents = view.Contents;
		if (pending != null && pending.Incoming != contents.Incoming && (confirmed || cancelled))
		{
			Reset();
		}
		if (pending == null)
		{
			pending = contents;
			target = ((resources != null) ? resources.Replace(contents) : ArenaEquipmentPolicy.Replace(contents, priority));
			started = elapsed;
		}
		else if (pending.Incoming != contents.Incoming || (!confirmed && !((ReadOnlySpan<ArenaEquipmentSlot>)pending.Slots).SequenceEqual((ReadOnlySpan<ArenaEquipmentSlot>)contents.Slots)))
		{
			pending = contents;
			target = ((resources != null) ? resources.Replace(contents) : ArenaEquipmentPolicy.Replace(contents, priority));
			selected = (confirmed = (cancelled = (rejectedPrompt = false)));
			answeredPrompt = "";
		}
		if (elapsed - started > TimeSpan.FromSeconds(20L))
		{
			throw new TimeoutException("装备替换未收到操作结果");
		}
		if (elapsed < nextAttempt)
		{
			return true;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		if (view.Phase == ArenaEquipmentPhase.Confirmation)
		{
			if ((confirmed || rejectedPrompt) && answeredPrompt == view.Prompt)
			{
				return true;
			}
			if (answeredPrompt != view.Prompt)
			{
				confirmed = (rejectedPrompt = false);
			}
			ArenaEquipmentSlot arenaEquipmentSlot = contents.Slots.FirstOrDefault((ArenaEquipmentSlot s) => ArenaEquipmentPolicy.Matches(view.Prompt, contents.Incoming, s.ItemId));
			if (arenaEquipmentSlot == null)
			{
				TimeSpan valueOrDefault = mismatchedAt.GetValueOrDefault();
				if (!mismatchedAt.HasValue)
				{
					valueOrDefault = elapsed;
					mismatchedAt = valueOrDefault;
				}
				Name = "装备 · 等待替换确认更新";
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = mismatchedAt;
				if (value - timeSpan < TimeSpan.FromSeconds(1L))
				{
					return true;
				}
				if (ArenaEquipmentPolicy.TryReadPrompt(view.Prompt, out var _, out var _) && world.TryAnswer(view.Prompt, yes: false))
				{
					rejectedPrompt = true;
					selected = false;
					answeredPrompt = view.Prompt;
				}
				return true;
			}
			mismatchedAt = null;
			bool flag = target == arenaEquipmentSlot && (resources == null || resources.Replace(contents) == arenaEquipmentSlot);
			Name = (flag ? ("装备 · " + ArenaItemCatalog.Items[arenaEquipmentSlot.ItemId].Name + " → " + ArenaItemCatalog.Items[contents.Incoming].Name) : "装备 · 返回重新选择");
			if (world.TryAnswer(view.Prompt, flag))
			{
				confirmed = flag;
				rejectedPrompt = !flag;
				answeredPrompt = view.Prompt;
			}
			return true;
		}
		mismatchedAt = null;
		if (rejectedPrompt)
		{
			rejectedPrompt = (selected = false);
			answeredPrompt = "";
		}
		if (confirmed || cancelled || selected)
		{
			return true;
		}
		if (target == null)
		{
			Name = "装备 · 保留现有装备，跳过" + ArenaItemCatalog.Items[contents.Incoming].Name;
			cancelled = world.TryCancel(contents);
		}
		else
		{
			Name = "装备 · " + ArenaItemCatalog.Items[target.ItemId].Name + " → " + ArenaItemCatalog.Items[contents.Incoming].Name;
			selected = world.TryChoose(contents, target);
		}
		return true;
	}

	private void Reset()
	{
		pending = null;
		target = null;
		selected = (confirmed = (cancelled = (rejectedPrompt = false)));
		mismatchedAt = (closedAt = null);
		answeredPrompt = "";
	}
}
