using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Beastmaster.Core.Arena;

public static class ArenaRouteDiagram
{
	public static IReadOnlyList<Vector2> Positions { get; } = Array.AsReadOnly(new Vector2[13]
	{
		new Vector2(0f, 0f),
		new Vector2(0f, 1f),
		new Vector2(-1f, 2f),
		new Vector2(1f, 2f),
		new Vector2(-1f, 3f),
		new Vector2(1f, 3f),
		new Vector2(0f, 4f),
		new Vector2(0f, 5f),
		new Vector2(0f, 6f),
		new Vector2(-1f, 7f),
		new Vector2(1f, 7f),
		new Vector2(0f, 8f),
		new Vector2(0f, 9f)
	});

	public static HashSet<(int From, int To)> SelectedEdges(ArenaPreset preset)
	{
		HashSet<(int, int)> hashSet = new HashSet<(int, int)>();
		int num = 0;
		int num2 = ArenaMaps.Get(preset.StageId).Nodes.Count() + 1;
		while (num2-- > 0)
		{
			int? num3 = ArenaPresetPolicy.Next(preset, num);
			if (!num3.HasValue)
			{
				break;
			}
			int valueOrDefault = num3.GetValueOrDefault();
			hashSet.Add((num, valueOrDefault));
			num = valueOrDefault;
		}
		return hashSet;
	}

	public static bool ChooseEdge(ArenaPreset preset, int from, int to)
	{
		(int, int)[] array = EdgeChoices(preset.StageId, from, to).ToArray();
		ArenaStageMap arenaStageMap = ArenaMaps.Get(preset.StageId);
		(int, int)[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			var (num, num2) = array2[i];
			if (arenaStageMap.Nodes[num].Next.Length == 2)
			{
				preset.Branches[num] = ((arenaStageMap.Nodes[num].Next[0] != num2) ? ArenaRoutePreference.Right : ArenaRoutePreference.Left);
				preset.BranchTargets.Remove(num);
			}
			else
			{
				preset.BranchTargets[num] = num2;
			}
		}
		return array.Length != 0;
	}

	public static bool CanChooseEdge(int stage, int from, int to)
	{
		return EdgeChoices(stage, from, to).Any();
	}

	private static IEnumerable<(int Branch, int Child)> EdgeChoices(int stage, int from, int to)
	{
		ArenaStageMap map = ArenaMaps.Get(stage);
		if (from < 0 || from >= map.Nodes.Length || !((ReadOnlySpan<int>)map.Nodes[from].Next).Contains(to))
		{
			yield break;
		}
		foreach (ArenaMapNode fork in map.Forks)
		{
			if (fork.Node == from)
			{
				yield return (Branch: from, Child: to);
				continue;
			}
			int[] array = fork.Next.Where((int child) => map.Reachable(child).Contains(from)).ToArray();
			if (array.Length == 1)
			{
				yield return (Branch: fork.Node, Child: array[0]);
			}
		}
	}
}
