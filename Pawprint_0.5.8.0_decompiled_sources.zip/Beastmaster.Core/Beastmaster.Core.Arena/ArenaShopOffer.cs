namespace Beastmaster.Core.Arena;

public sealed record ArenaShopOffer(int Row, uint ItemId, uint Price, bool Sold);
