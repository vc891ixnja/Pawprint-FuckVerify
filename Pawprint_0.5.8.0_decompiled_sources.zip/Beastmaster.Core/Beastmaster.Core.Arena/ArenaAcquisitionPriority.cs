using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaAcquisitionPriority
{
	public List<uint> Order { get; set; } = new List<uint>();

	public List<uint> Disabled { get; set; } = new List<uint>();
}
