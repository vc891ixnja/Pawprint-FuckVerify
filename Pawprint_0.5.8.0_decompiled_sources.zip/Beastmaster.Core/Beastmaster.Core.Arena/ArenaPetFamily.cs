namespace Beastmaster.Core.Arena;

public sealed record ArenaPetFamily(uint Number, int FamilyId, string Family);
