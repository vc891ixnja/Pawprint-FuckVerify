namespace Beastmaster.Core.Arena;

public interface IArenaTreasureWorld
{
	IArenaEquipmentWorld? Equipment => null;

	ArenaTreasureView Read();

	bool TryExit()
	{
		return false;
	}

	bool TryConfirmExit(string prompt)
	{
		return false;
	}

	bool TryChoose(ArenaTreasureOption option);

	bool TryAnswer(uint itemId, bool yes);
}
