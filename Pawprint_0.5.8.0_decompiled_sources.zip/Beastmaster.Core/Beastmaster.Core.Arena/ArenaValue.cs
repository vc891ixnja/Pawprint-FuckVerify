namespace Beastmaster.Core.Arena;

public sealed record ArenaValue(int Index, long? Number = null, string? Text = null);
