using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaUseAllItemsStep(IArenaHealWorld world, ArenaResourcePolicy? resources = null, Func<uint, bool>? itemFilter = null, Action<string>? trace = null) : IWorkflowStep
{
	private readonly HashSet<(int Slot, uint Item)> attempted = new HashSet<(int, uint)>();

	private ArenaHealItem? selected;

	private int beforeCount;

	private int dispatched;

	private bool opened;

	private bool submitted;

	private bool done;

	private TimeSpan itemAt;

	private TimeSpan nextAction;

	public string Name { get; private set; } = "本场战斗 · 依次使用道具";

	public TimeSpan Timeout => TimeSpan.FromSeconds(100L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (done)
		{
			return StepResult.Completed;
		}
		ArenaHealView v = world.Read();
		if (v.Phase == ArenaHealPhase.Ended || elapsed >= Timeout)
		{
			if (elapsed >= Timeout)
			{
				trace?.Invoke($"all-items timeout with {v.Items.Length} slots left");
			}
			return Finish();
		}
		if (v.Phase == ArenaHealPhase.Loading)
		{
			return StepResult.Running;
		}
		bool flag = selected != null;
		if (flag)
		{
			bool flag2 = submitted;
			if (flag2)
			{
				ArenaHealPhase phase = v.Phase;
				bool flag3 = (uint)(phase - 1) <= 1u;
				flag2 = flag3;
			}
			flag = (flag2 && v.Items.Count((ArenaHealItem i) => i.ItemId == selected.ItemId) < beforeCount) || elapsed - itemAt >= TimeSpan.FromSeconds(8L);
		}
		if (flag)
		{
			if (elapsed - itemAt >= TimeSpan.FromSeconds(8L))
			{
				trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: not consumed in 8s, skip");
			}
			else
			{
				trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: consumed, next");
			}
			world.RestoreTarget();
			selected = null;
			opened = (submitted = false);
			dispatched = 0;
			return StepResult.Running;
		}
		if (v.Phase == ArenaHealPhase.Blocked)
		{
			return StepResult.Running;
		}
		if (selected != null)
		{
			ArenaResourcePolicy? arenaResourcePolicy = resources;
			if (arenaResourcePolicy != null && !arenaResourcePolicy.CanUse(selected.ItemId, v.Items.Length))
			{
				trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: forbidden by resources");
				return Finish();
			}
		}
		if (selected == null)
		{
			if (v.Phase != ArenaHealPhase.Board)
			{
				return StepResult.Running;
			}
			ArenaHealItem[] items = v.Items;
			foreach (ArenaHealItem arenaHealItem in items)
			{
				if (!arenaHealItem.Usable && (itemFilter == null || itemFilter(arenaHealItem.ItemId)))
				{
					trace?.Invoke($"slot {arenaHealItem.Slot} item {arenaHealItem.ItemId}: unusable, skip");
				}
			}
			selected = (from i in v.Items
				where i.Usable && (itemFilter == null || itemFilter(i.ItemId)) && !attempted.Contains((i.Slot, i.ItemId)) && (resources?.CanUse(i.ItemId, v.Items.Length) ?? true)
				orderby i.Slot
				select i).FirstOrDefault();
			if (selected == null)
			{
				trace?.Invoke($"all-items done, {v.Items.Length} slots left: [{string.Join(",", v.Items.Select((ArenaHealItem i) => $"{i.Slot}:{i.ItemId}{(i.Usable ? "" : "(unusable)")}"))}]");
				return Finish();
			}
			attempted.Add((selected.Slot, selected.ItemId));
			itemAt = elapsed;
			beforeCount = v.Items.Count((ArenaHealItem i) => i.ItemId == selected.ItemId);
			dispatched = 0;
			trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: selected, count={beforeCount}");
		}
		Name = "本场战斗 · 使用" + ArenaItemCatalog.Items[selected.ItemId].Name;
		if (elapsed < nextAction)
		{
			return StepResult.Running;
		}
		nextAction = elapsed + TimeSpan.FromMilliseconds(100L);
		if (!v.Items.Any((ArenaHealItem i) => i == selected && i.Usable))
		{
			return StepResult.Running;
		}
		if (world.DirectDispatch)
		{
			if (v.Phase == ArenaHealPhase.Board && dispatched < 2)
			{
				if (world.TryDispatch(selected))
				{
					dispatched++;
					submitted = true;
					trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: dispatched ({dispatched}/2)");
				}
				else if (dispatched == 0)
				{
					trace?.Invoke($"slot {selected.Slot} item {selected.ItemId}: dispatch rejected");
				}
			}
		}
		else if (v.Phase == ArenaHealPhase.Board)
		{
			opened = world.TryOpen(selected);
		}
		else if (v.Phase == ArenaHealPhase.Menu && opened && dispatched < 2 && world.TryUse(selected))
		{
			dispatched++;
			submitted = true;
		}
		return StepResult.Running;
	}

	private StepResult Finish()
	{
		done = true;
		world.RestoreTarget();
		return StepResult.Completed;
	}

	public void Cancel()
	{
		world.RestoreTarget();
	}
}
