using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRewardStep(IArenaRewardWorld world, ArenaResourcePolicy resources) : IWorkflowStep
{
	private readonly ArenaEquipmentExchange equipment = new ArenaEquipmentExchange(world.Equipment, null, resources);

	private TimeSpan? takeAllMissedAt;

	private TimeSpan? equipReceiptAt;

	private readonly HashSet<uint> skipped = new HashSet<uint>();

	private readonly HashSet<uint> claimed = new HashSet<uint>();

	private ArenaTreasureOption? pending;

	private bool coins;

	private bool submitted;

	private bool confirmed;

	private bool exiting;

	private bool ended;

	private bool takeAll;

	private bool exchangeCompleted;

	private uint coinAmount;

	private TimeSpan nextAttempt;

	private TimeSpan requestAt;

	private TimeSpan? closedAt;

	public string Name { get; private set; } = "战利品 · 读取奖励";

	public TimeSpan Timeout => TimeSpan.FromMinutes(3L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (ended)
		{
			return StepResult.Completed;
		}
		if (equipment.Tick(elapsed, out ArenaEquipmentOutcome outcome))
		{
			Name = equipment.Name;
			requestAt = elapsed;
			closedAt = null;
			return StepResult.Running;
		}
		if (outcome != null)
		{
			if (!outcome.Accepted)
			{
				skipped.Add(outcome.ItemId);
			}
			else
			{
				exchangeCompleted = true;
			}
			pending = null;
			submitted = (confirmed = false);
			requestAt = elapsed;
		}
		ArenaRewardView arenaRewardView = world.Read();
		if (arenaRewardView.Phase == ArenaRewardPhase.Loading)
		{
			requestAt = elapsed;
			closedAt = null;
			return StepResult.Running;
		}
		if (arenaRewardView.Phase == ArenaRewardPhase.Returned)
		{
			ended = true;
			Name = "战利品 · 已返回后续流程";
			return StepResult.Completed;
		}
		if (arenaRewardView.Phase == ArenaRewardPhase.Closed)
		{
			TimeSpan valueOrDefault = closedAt.GetValueOrDefault();
			if (!closedAt.HasValue)
			{
				valueOrDefault = elapsed;
				closedAt = valueOrDefault;
			}
			if (!exiting && !confirmed && !exchangeCompleted)
			{
				Name = "战利品 · 等待界面切换";
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = closedAt;
				if (value - timeSpan >= TimeSpan.FromSeconds(15L))
				{
					throw new TimeoutException("战利品窗口已关闭，尚未观察到棋盘、结算或后续奖励界面");
				}
				return StepResult.Running;
			}
			ended = true;
			Name = "战利品 · 已结束领取";
			return StepResult.Completed;
		}
		closedAt = null;
		if (elapsed - requestAt > TimeSpan.FromSeconds(15L))
		{
			throw new TimeoutException(Name + "，未收到操作结果");
		}
		ArenaRewardContents c = arenaRewardView.Contents;
		exchangeCompleted = false;
		bool num;
		if (submitted && !confirmed && arenaRewardView.Phase == ArenaRewardPhase.Selection)
		{
			if (!coins)
			{
				if (pending != null)
				{
					num = ((ReadOnlySpan<uint>)c.Owned).Contains(pending.ItemId);
					goto IL_0280;
				}
			}
			else if (!c.CoinsAvailable)
			{
				num = c.Coins != 0;
				goto IL_0280;
			}
		}
		goto IL_02ae;
		IL_0417:
		pending = null;
		coins = (submitted = (confirmed = false));
		requestAt = elapsed;
		equipReceiptAt = null;
		goto IL_044a;
		IL_044a:
		if (elapsed < nextAttempt)
		{
			return StepResult.Running;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(100L);
		if (arenaRewardView.Phase == ArenaRewardPhase.Confirmation)
		{
			if (confirmed)
			{
				return StepResult.Running;
			}
			if (elapsed - requestAt > TimeSpan.FromSeconds(3L))
			{
				requestAt = elapsed;
			}
			bool flag = (exiting && ArenaRewardDecoder.ExitPrompt(arenaRewardView.Prompt)) || (submitted && takeAll && GameText.Matches("Reward.TakeAllConfirm", arenaRewardView.Prompt)) || (submitted && coins && c.CoinsAvailable && c.Coins == coinAmount && ArenaRewardDecoder.CoinPrompt(arenaRewardView.Prompt, coinAmount)) || (submitted && pending != null && ArenaRewardDecoder.ItemPrompt(arenaRewardView.Prompt, pending.ItemId) && CanTake(c, pending));
			if (!flag && !ArenaRewardDecoder.LooksLikeAcquisition(arenaRewardView.Prompt) && !ArenaRewardDecoder.ExitPrompt(arenaRewardView.Prompt))
			{
				throw new InvalidOperationException("不是当前战利品的确认窗口");
			}
			if (world.TryAnswer(arenaRewardView.Prompt, flag))
			{
				confirmed = flag;
				if (flag && pending != null)
				{
					claimed.Add(pending.ItemId);
				}
				if (!flag)
				{
					submitted = (exiting = false);
				}
				requestAt = elapsed;
			}
			return StepResult.Running;
		}
		if (submitted || exiting)
		{
			if (submitted && !confirmed && !exiting && elapsed - requestAt > TimeSpan.FromSeconds(3L) && arenaRewardView.Phase == ArenaRewardPhase.Selection)
			{
				requestAt = elapsed;
				if (takeAll)
				{
					world.TryTakeAll();
				}
				else if (coins)
				{
					world.TryChoose(-1);
				}
				else
				{
					ArenaTreasureOption arenaTreasureOption = pending;
					if ((object)arenaTreasureOption != null)
					{
						world.TryChoose(arenaTreasureOption.Row);
					}
				}
			}
			return StepResult.Running;
		}
		if (world.TakeAllSupported && !takeAll && CanTakeAll(c))
		{
			Name = "战利品 · 全部获取";
			if (world.TryTakeAll())
			{
				takeAll = (submitted = true);
				requestAt = elapsed;
				return StepResult.Running;
			}
			TimeSpan valueOrDefault = takeAllMissedAt.GetValueOrDefault();
			if (!takeAllMissedAt.HasValue)
			{
				valueOrDefault = elapsed;
				takeAllMissedAt = valueOrDefault;
			}
			requestAt = elapsed;
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = takeAllMissedAt;
			if (value - timeSpan < TimeSpan.FromSeconds(3L))
			{
				return StepResult.Running;
			}
			takeAll = true;
		}
		if (c.CoinsAvailable)
		{
			Name = "战利品 · 获取斗兽币";
			if (world.TryChoose(-1))
			{
				coins = (submitted = true);
				coinAmount = c.Coins;
				requestAt = elapsed;
			}
			return StepResult.Running;
		}
		IReadOnlyList<uint> order = resources.Order;
		pending = (from o in c.Options
			where CanTake(c, o)
			orderby resources.CategoryRank(o.ItemId, c.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 1), c.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 2)), ArenaPresetPolicy.Priority(order, o.ItemId), ArenaTreasurePolicy.Score(o.ItemId, (IReadOnlyCollection<uint>)(object)c.Owned) descending
			select o).FirstOrDefault();
		if (pending != null)
		{
			Name = "战利品 · 获取" + ArenaItemCatalog.Items[pending.ItemId].Name;
			if (world.TryChoose(pending.Row))
			{
				submitted = true;
				requestAt = elapsed;
			}
		}
		else
		{
			Name = "战利品 · 结束领取";
			if (world.TryExit())
			{
				exiting = true;
				requestAt = elapsed;
			}
		}
		return StepResult.Running;
		IL_0280:
		if (num)
		{
			confirmed = true;
			if (pending != null)
			{
				claimed.Add(pending.ItemId);
			}
		}
		goto IL_02ae;
		IL_02ae:
		if (confirmed && arenaRewardView.Phase == ArenaRewardPhase.Selection)
		{
			if (takeAll)
			{
				return StepResult.Running;
			}
			bool num2;
			if (!coins)
			{
				if (!(pending != null) || !((ReadOnlySpan<ArenaTreasureOption>)c.Options).Contains(pending))
				{
					goto IL_0417;
				}
				num2 = !((ReadOnlySpan<uint>)c.Owned).Contains(pending.ItemId);
			}
			else
			{
				num2 = c.CoinsAvailable;
			}
			if (num2)
			{
				if (coins || !(pending != null) || ArenaItemCatalog.Items[pending.ItemId].Category != 1)
				{
					return StepResult.Running;
				}
				TimeSpan valueOrDefault = equipReceiptAt.GetValueOrDefault();
				if (!equipReceiptAt.HasValue)
				{
					valueOrDefault = elapsed;
					equipReceiptAt = valueOrDefault;
				}
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = equipReceiptAt;
				if (value - timeSpan < TimeSpan.FromSeconds(2L))
				{
					return StepResult.Running;
				}
				skipped.Add(pending.ItemId);
			}
			goto IL_0417;
		}
		goto IL_044a;
	}

	private bool CanTakeAll(ArenaRewardContents c)
	{
		if (c.Options.Length == 0 || !c.Options.All((ArenaTreasureOption o) => CanTake(c, o)))
		{
			return false;
		}
		int num = c.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 1) + c.Options.Count((ArenaTreasureOption o) => ArenaItemCatalog.Items[o.ItemId].Category == 1);
		int num2 = c.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 2) + c.Options.Count((ArenaTreasureOption o) => ArenaItemCatalog.Items[o.ItemId].Category == 2);
		if (num <= 10)
		{
			return num2 <= 10;
		}
		return false;
	}

	private bool CanTake(ArenaRewardContents c, ArenaTreasureOption o)
	{
		bool flag = ((ReadOnlySpan<ArenaTreasureOption>)c.Options).Contains(o) && !skipped.Contains(o.ItemId) && !claimed.Contains(o.ItemId) && resources.CanAcquire(o.ItemId);
		if (flag)
		{
			flag = ArenaItemCatalog.Items[o.ItemId].Category switch
			{
				1 => !((ReadOnlySpan<uint>)c.Owned).Contains(o.ItemId) && resources.CanEquip(o.ItemId, (IReadOnlyCollection<uint>)(object)c.Owned), 
				2 => c.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 2) < 10, 
				_ => false, 
			};
		}
		return flag;
	}

	public void Cancel()
	{
	}
}
