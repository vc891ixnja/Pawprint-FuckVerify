namespace Beastmaster.Core.Arena;

public interface IArenaEquipmentWorld
{
	ArenaEquipmentView Read();

	bool TryChoose(ArenaEquipmentContents contents, ArenaEquipmentSlot slot);

	bool TryAnswer(string prompt, bool yes);

	bool TryCancel(ArenaEquipmentContents contents);
}
