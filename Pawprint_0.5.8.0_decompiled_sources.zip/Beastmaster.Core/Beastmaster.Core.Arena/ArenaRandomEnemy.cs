namespace Beastmaster.Core.Arena;

public sealed record ArenaRandomEnemy(uint NameId, string Name);
