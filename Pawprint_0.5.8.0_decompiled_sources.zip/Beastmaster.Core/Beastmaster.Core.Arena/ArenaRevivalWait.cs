using System;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRevivalWait
{
	private TimeSpan? deathAt;

	private TimeSpan waiting;

	public bool IsWaiting => deathAt.HasValue;

	public bool Confirmed { get; private set; }

	public TimeSpan ActiveElapsed(TimeSpan elapsed)
	{
		return elapsed - waiting;
	}

	public bool Observe(bool dead, TimeSpan elapsed, bool stopOnDeath = true)
	{
		if (dead)
		{
			TimeSpan valueOrDefault = deathAt.GetValueOrDefault();
			if (!deathAt.HasValue)
			{
				valueOrDefault = elapsed;
				deathAt = valueOrDefault;
			}
			TimeSpan? timeSpan = deathAt;
			Confirmed = elapsed - timeSpan >= TimeSpan.FromSeconds(10L);
			if (Confirmed && stopOnDeath)
			{
				throw new InvalidOperationException("玩家持续死亡 10 秒，斗兽任务已停止");
			}
			return true;
		}
		TimeSpan? timeSpan2 = deathAt;
		if (timeSpan2.HasValue)
		{
			TimeSpan valueOrDefault2 = timeSpan2.GetValueOrDefault();
			waiting += elapsed - valueOrDefault2;
		}
		deathAt = null;
		Confirmed = false;
		return false;
	}
}
