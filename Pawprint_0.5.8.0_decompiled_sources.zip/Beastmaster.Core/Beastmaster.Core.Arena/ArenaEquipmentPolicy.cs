using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaEquipmentPolicy
{
	public const string GetVerb = "获取";

	public const string BuyVerb = "购买";

	private static bool IncomingFirst
	{
		get
		{
			string language = GameText.Language;
			if (language == "zhCN" || language == "zhTW")
			{
				return true;
			}
			return false;
		}
	}

	public static List<uint> Complete(IReadOnlyList<uint>? saved)
	{
		return (from i in ArenaItemCatalog.Items.Values
			where i.Category == 1
			orderby ArenaPresetPolicy.Priority(saved, i.Id), ArenaTreasurePolicy.Score(i.Id, (IReadOnlyCollection<uint>)(object)Array.Empty<uint>()) descending, i.Id
			select i.Id).ToList();
	}

	public static ArenaEquipmentSlot? Replace(ArenaEquipmentContents contents, IReadOnlyList<uint>? priority)
	{
		if (contents.Slots.Any((ArenaEquipmentSlot s) => s.ItemId == contents.Incoming))
		{
			return null;
		}
		List<uint> order = Complete(priority);
		ArenaEquipmentSlot arenaEquipmentSlot = (from s in contents.Slots
			orderby order.IndexOf(s.ItemId) descending, s.Row
			select s).FirstOrDefault();
		if (!(arenaEquipmentSlot != null) || order.IndexOf(contents.Incoming) >= order.IndexOf(arenaEquipmentSlot.ItemId))
		{
			return null;
		}
		return arenaEquipmentSlot;
	}

	public static bool CanAcquire(uint incoming, IReadOnlyCollection<uint> owned, IReadOnlyList<uint>? priority)
	{
		ArenaItem value;
		ArenaEquipmentSlot[] array = owned.Where((uint id) => ArenaItemCatalog.Items.TryGetValue(id, out value) && value.Category == 1).Select((uint id, int row) => new ArenaEquipmentSlot(row, id)).ToArray();
		if (!owned.Contains(incoming))
		{
			if (array.Length >= 10)
			{
				return Replace(new ArenaEquipmentContents(incoming, array), priority) != null;
			}
			return true;
		}
		return false;
	}

	public static ArenaEquipmentContents Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue arenaValue) => arenaValue.Index);
		if (Num(0) != 1)
		{
			throw new InvalidOperationException("当前不是装备替换窗口");
		}
		uint incoming = Item(5);
		List<ArenaEquipmentSlot> list = new List<ArenaEquipmentSlot>();
		for (int num = 0; num < 10; num++)
		{
			if (Num(6 + num * 5) != 1)
			{
				throw new InvalidOperationException("装备替换列表未读完整");
			}
			list.Add(new ArenaEquipmentSlot(num, Item(9 + num * 5)));
		}
		if (list.Select((ArenaEquipmentSlot s) => s.ItemId).Distinct().Count() != 10)
		{
			throw new InvalidOperationException("装备替换列表重复");
		}
		return new ArenaEquipmentContents(incoming, list.ToArray());
		uint Item(int i)
		{
			long? num2 = Num(i);
			bool flag;
			if (num2.HasValue)
			{
				long valueOrDefault = num2.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault <= uint.MaxValue)
				{
					flag = false;
					goto IL_0029;
				}
			}
			flag = true;
			goto IL_0029;
			IL_0029:
			if (flag || !ArenaItemCatalog.Items.TryGetValue((uint)num2.Value, out ArenaItem value) || value.Category != 1)
			{
				throw new InvalidOperationException("装备替换列表未就绪");
			}
			return (uint)num2.Value;
		}
		long? Num(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	public static string Prompt(uint incoming, uint removed)
	{
		return Prompt("获取", incoming, removed);
	}

	public static string Prompt(string verb, uint incoming, uint removed)
	{
		return $"确定要{verb}“{ArenaItemCatalog.Items[incoming].Name}”替换掉“{ArenaItemCatalog.Items[removed].Name}”吗？";
	}

	private static bool IsReplacePrompt(string text)
	{
		if (!GameText.Matches("Reward.GearReplaceConfirm", text))
		{
			return GameText.Matches("Shop.ReplaceConfirm", text);
		}
		return true;
	}

	public static bool Matches(string text, uint incoming, uint removed)
	{
		string text2 = GameText.Normalize(text);
		string text3 = ArenaItemCatalog.LocalizedName(incoming);
		string text4 = ArenaItemCatalog.LocalizedName(removed);
		if (string.IsNullOrEmpty(text3) || string.IsNullOrEmpty(text4))
		{
			return false;
		}
		if (IsReplacePrompt(text) && text2.Contains(GameText.Normalize(text3), StringComparison.Ordinal))
		{
			return text2.Contains(GameText.Normalize(text4), StringComparison.Ordinal);
		}
		return false;
	}

	public static bool TryReadPrompt(string text, out uint incoming, out uint removed)
	{
		incoming = (removed = 0u);
		if (!IsReplacePrompt(text))
		{
			return false;
		}
		if (IncomingFirst)
		{
			Match match = Regex.Match(ArenaShopDecoder.Compact(text), "^确定要(?:获取|购买)“([^“”]+)”替换掉“([^“”]+)”吗？$");
			if (!match.Success)
			{
				return false;
			}
			IEnumerable<ArenaItem> source = ArenaItemCatalog.Items.Values.Where((ArenaItem i) => i.Category == 1);
			ArenaItem[] array = source.Where((ArenaItem i) => Norm(ArenaItemCatalog.LocalizedName(i.Id) ?? "") == Norm(match.Groups[1].Value)).ToArray();
			ArenaItem[] array2 = source.Where((ArenaItem i) => Norm(ArenaItemCatalog.LocalizedName(i.Id) ?? "") == Norm(match.Groups[2].Value)).ToArray();
			if (array.Length != 1 || array2.Length != 1)
			{
				return false;
			}
			incoming = array[0].Id;
			removed = array2[0].Id;
			return true;
		}
		string text2 = GameText.Normalize(text);
		List<(int, uint)> list = new List<(int, uint)>();
		foreach (ArenaItem item in ArenaItemCatalog.Items.Values.Where((ArenaItem i) => i.Category == 1))
		{
			string text3 = GameText.Normalize(ArenaItemCatalog.LocalizedName(item.Id));
			if (text3.Length >= 2)
			{
				int num = text2.IndexOf(text3, StringComparison.Ordinal);
				if (num >= 0 && list.All<(int, uint)>(((int Index, uint Id) h) => h.Id != item.Id))
				{
					list.Add((num, item.Id));
				}
			}
		}
		list.Sort(((int Index, uint Id) a, (int Index, uint Id) b) => a.Index.CompareTo(b.Index));
		if (list.Count != 2)
		{
			return false;
		}
		removed = list[0].Item2;
		incoming = list[1].Item2;
		return true;
		static string Norm(string s)
		{
			return GameText.Normalize(s);
		}
	}
}
