using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace Beastmaster.Core.Arena;

public static class ArenaTreasurePolicy
{
	private static double Stat(ArenaItem item, string label)
	{
		Match match = Regex.Match(item.Description, "(?:^|\\r?\\n)" + Regex.Escape(label) + "([+-]\\d+(?:\\.\\d+)?)%?");
		if (!match.Success)
		{
			return 0.0;
		}
		return double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
	}

	public static double Score(uint id, IReadOnlyCollection<uint> equipment)
	{
		ArenaItem arenaItem = ArenaItemCatalog.Items[id];
		if (arenaItem.Category == 1 && equipment.Contains(id))
		{
			return -100.0;
		}
		bool flag = equipment.Any((uint i) => i >= 38 && i <= 43);
		double num = (flag ? 0.45 : 0.3);
		double num2 = Stat(arenaItem, "造成伤害") + Stat(arenaItem, "造成物理伤害") * (1.0 - num) + Stat(arenaItem, "造成魔法伤害") * num + Stat(arenaItem, "暴击发动率") * 0.5;
		double num3 = Stat(arenaItem, "加速") - Stat(arenaItem, "减速");
		num2 += 100.0 / Math.Max(0.1, 1.0 - num3 / 100.0) - 100.0;
		num2 += Stat(arenaItem, "高速复唱") * 0.15 + Stat(arenaItem, "以太爆发威力") * 0.2;
		double num4 = num2;
		double num5;
		switch (id)
		{
		case 7u:
			num5 = 3.0;
			break;
		case 8u:
			num5 = 3.0;
			break;
		case 11u:
			num5 = 1.5;
			break;
		case 19u:
			num5 = 1.0;
			break;
		case 27u:
			num5 = 4.0;
			break;
		case 30u:
			num5 = 3.0;
			break;
		case 32u:
			num5 = 2.0;
			break;
		case 33u:
			num5 = 1.0;
			break;
		case 38u:
		case 39u:
		case 40u:
		case 41u:
		case 42u:
		case 43u:
			num5 = ((!flag) ? 20 : 0);
			break;
		case 44u:
			num5 = 1.5;
			break;
		case 48u:
			num5 = 3.0;
			break;
		case 55u:
			num5 = 4.0;
			break;
		case 62u:
			num5 = 4.0;
			break;
		case 64u:
			num5 = 2.0;
			break;
		case 70u:
			num5 = 3.0;
			break;
		case 71u:
			num5 = 2.0;
			break;
		case 72u:
			num5 = 4.6;
			break;
		default:
			num5 = 0.0;
			break;
		}
		num2 = num4 + num5;
		if (arenaItem.Category != 1)
		{
			bool flag2 = num2 > 0.0;
			if (!flag2)
			{
				bool flag3;
				switch (arenaItem.Id)
				{
				case 103u:
				case 104u:
				case 105u:
				case 106u:
				case 107u:
				case 108u:
				case 109u:
				case 115u:
				case 128u:
				case 129u:
				case 130u:
				case 131u:
				case 132u:
				case 133u:
				case 134u:
				case 139u:
				case 142u:
				case 143u:
					flag3 = true;
					break;
				default:
					flag3 = false;
					break;
				}
				flag2 = flag3;
			}
			if (flag2)
			{
				num4 = 1.0 + Math.Max(0.0, num2) / 20.0;
				switch (arenaItem.Id)
				{
				case 128u:
				case 129u:
				case 130u:
				case 131u:
				case 132u:
				case 133u:
				case 134u:
				case 139u:
					flag2 = true;
					break;
				default:
					flag2 = false;
					break;
				}
				num5 = Math.Min(4.0, num4 + (double)(flag2 ? 1 : 0));
			}
			else
			{
				num5 = 0.0;
			}
			num2 = num5;
		}
		return num2;
	}

	public static ArenaTreasureOption? Choose(ArenaTreasureContents contents, IReadOnlySet<uint>? excluded = null, IReadOnlyList<uint>? priority = null)
	{
		return (from o in contents.Options.Where(delegate(ArenaTreasureOption o)
			{
				IReadOnlySet<uint>? readOnlySet = excluded;
				return readOnlySet == null || !readOnlySet.Contains(o.ItemId);
			})
			orderby ArenaPresetPolicy.Priority(priority, o.ItemId), Score(o.ItemId, (IReadOnlyCollection<uint>)(object)contents.Equipment) descending, o.Row
			select o).FirstOrDefault();
	}
}
