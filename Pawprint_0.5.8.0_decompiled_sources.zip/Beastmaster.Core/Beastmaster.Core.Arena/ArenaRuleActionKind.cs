namespace Beastmaster.Core.Arena;

public enum ArenaRuleActionKind
{
	UseItems,
	UseDutyAction,
	SetTargetPriority,
	Countdown,
	CallPrcFinisher,
	MoveBehind
}
