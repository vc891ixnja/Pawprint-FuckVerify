using System;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRuleLimit
{
	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public ArenaRuleOnce Once { get; set; } = ArenaRuleOnce.PerBattle;

	public int WindowSeconds { get; set; }

	public int CooldownSeconds { get; set; }

	public int RetrySeconds { get; set; } = 8;

	public int MaxAttemptsPerItem { get; set; } = 2;

	public int DebounceSeconds { get; set; }
}
