namespace Beastmaster.Core.Arena;

public enum ArenaPriorityKind
{
	Shop,
	Treasure,
	Healing,
	Equipment,
	Supplies,
	Rewards
}
