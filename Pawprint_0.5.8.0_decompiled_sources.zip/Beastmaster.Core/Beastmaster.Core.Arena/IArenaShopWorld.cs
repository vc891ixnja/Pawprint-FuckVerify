namespace Beastmaster.Core.Arena;

public interface IArenaShopWorld
{
	IArenaEquipmentWorld? Equipment => null;

	ArenaShopView Read();

	bool TryOpen(ArenaShopOffer offer);

	bool TryFeed(uint number);

	bool TryBack();

	bool TryAnswer(string prompt, bool yes);

	bool TrySell(uint itemId)
	{
		return false;
	}

	bool TryExit();

	bool TryDismissDuplicate(string prompt);
}
