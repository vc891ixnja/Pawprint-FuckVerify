namespace Beastmaster.Core.Arena;

public enum ArenaRuleItemFilter
{
	All,
	Function,
	FunctionNoTimeSand,
	Attack,
	NonHealing,
	Healing,
	ExplicitList
}
