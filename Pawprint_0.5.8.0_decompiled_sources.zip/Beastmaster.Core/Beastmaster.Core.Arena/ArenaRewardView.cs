namespace Beastmaster.Core.Arena;

public sealed record ArenaRewardView(ArenaRewardPhase Phase, ArenaRewardContents? Contents = null, string Prompt = "");
