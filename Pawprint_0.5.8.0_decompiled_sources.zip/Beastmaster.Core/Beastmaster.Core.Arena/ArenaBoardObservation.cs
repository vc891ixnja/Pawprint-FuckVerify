using System.Numerics;

namespace Beastmaster.Core.Arena;

public sealed record ArenaBoardObservation(uint Territory, uint Content, Vector3? Player, bool Blocked, bool NodeEvent, bool Result, string Phase, bool BattleReward = false, bool Loading = false, bool EncounterSetup = false, bool InCombat = false, bool RestEvent = false, bool TreasureEvent = false, bool ShopEvent = false);
