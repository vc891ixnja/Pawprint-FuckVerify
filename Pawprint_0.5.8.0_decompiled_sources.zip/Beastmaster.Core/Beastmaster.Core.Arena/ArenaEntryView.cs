namespace Beastmaster.Core.Arena;

public sealed record ArenaEntryView(ArenaEntryPhase Phase, uint[] Roster, int? StageId = null, bool UnderleveledWarning = false);
