using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaRestPolicy
{
	public static uint[] Select(IReadOnlyList<ArenaRestPet> pets, int capacity, int belowPercent = 100)
	{
		if ((belowPercent < 1 || belowPercent > 100) ? true : false)
		{
			throw new ArgumentOutOfRangeException("belowPercent");
		}
		if ((capacity < 0 || capacity > 15) ? true : false)
		{
			throw new InvalidOperationException("休息可恢复魔兽数量未就绪");
		}
		if (pets.Count > 15 || pets.Any(delegate(ArenaRestPet p)
		{
			uint number = p.Number;
			bool flag = ((number < 1 || number > 50) ? true : false);
			return flag || p.MaxHp == 0 || p.Hp > p.MaxHp;
		}) || pets.Select((ArenaRestPet p) => p.Number).Distinct().Count() != pets.Count)
		{
			throw new InvalidOperationException("休息魔兽列表未就绪");
		}
		return (from p in (from p in pets
				where p.Hp != 0 && (decimal)p.Hp * 100m < (decimal)p.MaxHp * (decimal)belowPercent
				orderby (decimal)p.Hp / (decimal)p.MaxHp, p.Row
				select p).Take(capacity)
			select p.Number).ToArray();
	}
}
