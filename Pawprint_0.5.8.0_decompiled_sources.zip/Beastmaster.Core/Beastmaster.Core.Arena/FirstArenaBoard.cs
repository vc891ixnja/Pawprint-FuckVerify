using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Beastmaster.Core.Arena;

public static class FirstArenaBoard
{
	public const uint Territory = 1339u;

	public const uint Content = 1088u;

	public const float TileRadius = 2.5f;

	public static IReadOnlyList<ArenaBoardNode> Nodes { get; } = Array.AsReadOnly(new ArenaBoardNode[13]
	{
		new ArenaBoardNode(0, new Vector3(-700f, 0f, 0f), new int[1] { 1 }),
		new ArenaBoardNode(1, new Vector3(-700f, 0f, -9f), new int[2] { 2, 3 }),
		new ArenaBoardNode(2, new Vector3(-705f, 0f, -16f), new int[1] { 4 }),
		new ArenaBoardNode(3, new Vector3(-695f, 0f, -16f), new int[1] { 5 }),
		new ArenaBoardNode(4, new Vector3(-705f, 0f, -25f), new int[1] { 6 }),
		new ArenaBoardNode(5, new Vector3(-695f, 0f, -25f), new int[1] { 6 }),
		new ArenaBoardNode(6, new Vector3(-700f, 0f, -33f), new int[1] { 7 }),
		new ArenaBoardNode(7, new Vector3(-700f, 0f, -42f), new int[1] { 8 }),
		new ArenaBoardNode(8, new Vector3(-700f, 0f, -51f), new int[2] { 9, 10 }),
		new ArenaBoardNode(9, new Vector3(-705f, 0f, -58f), new int[1] { 11 }),
		new ArenaBoardNode(10, new Vector3(-695f, 0f, -58f), new int[1] { 11 }),
		new ArenaBoardNode(11, new Vector3(-700f, 0f, -66f), new int[1] { 12 }),
		new ArenaBoardNode(12, new Vector3(-700f, 0f, -75f), Array.Empty<int>())
	});

	public static bool IsOnBoard(Vector3 p)
	{
		if (float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z))
		{
			float x = p.X;
			if (x >= -710f && x <= -690f && Math.Abs(p.Y) < 1f)
			{
				x = p.Z;
				if (x >= -79f)
				{
					return x <= 4f;
				}
				return false;
			}
		}
		return false;
	}

	public static bool InTile(int index, Vector3 p)
	{
		if (IsOnBoard(p))
		{
			return Vector2.Distance(new Vector2(p.X, p.Z), new Vector2(Nodes[index].Center.X, Nodes[index].Center.Z)) <= 2.5f;
		}
		return false;
	}

	public static bool IsBattle(int index)
	{
		switch (index)
		{
		case 1:
		case 2:
		case 3:
		case 6:
		case 8:
		case 12:
			return true;
		default:
			return false;
		}
	}

	public static int? FindTile(Vector3 position)
	{
		return Nodes.Where((ArenaBoardNode n) => InTile(n.Index, position)).Select((Func<ArenaBoardNode, int?>)((ArenaBoardNode n) => n.Index)).SingleOrDefault();
	}

	public static (int From, int To)? FindBridge(Vector3 position)
	{
		if (!IsOnBoard(position) || FindTile(position).HasValue)
		{
			return null;
		}
		List<(int, int)> list = new List<(int, int)>();
		foreach (ArenaBoardNode node in Nodes)
		{
			int[] next = node.Next;
			foreach (int num in next)
			{
				Vector3 vector = Nodes[num].Center - node.Center;
				float num2 = Vector3.Dot(position - node.Center, vector) / vector.LengthSquared();
				if (num2 > 0f && num2 < 1f && Vector3.Distance(position, node.Center + vector * num2) <= 1f)
				{
					list.Add((node.Index, num));
				}
			}
		}
		if (list.Count != 1)
		{
			return null;
		}
		return list[0];
	}

	public static int? Next(int index)
	{
		int num = Nodes[index].Next.FirstOrDefault(-1);
		if (num < 0)
		{
			return null;
		}
		return num;
	}
}
