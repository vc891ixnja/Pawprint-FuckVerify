using System;

namespace Beastmaster.Core.Arena;

public interface IArenaEntryWorld
{
	bool NotebookBusy { get; }

	bool NotebookClosed { get; }

	void Validate();

	ArenaEntryView Read();

	bool StartNotebook();

	uint[] ReadUnlocked();

	bool CloseNotebook();

	bool ApproachNpc(TimeSpan elapsed);

	bool Interact();

	bool TryChooseBoard();

	bool TryChooseChallenge();

	bool TryChooseActivity();

	bool TryOpenRoster();

	bool TryClearRoster();

	bool AddPet(uint id, TimeSpan elapsed);

	bool Enter();

	bool TryConfirmEntry();

	bool TryCommenceEntry();

	void Cancel();
}
