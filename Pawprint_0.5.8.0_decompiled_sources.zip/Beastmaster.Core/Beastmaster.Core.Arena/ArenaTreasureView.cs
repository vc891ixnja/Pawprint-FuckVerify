namespace Beastmaster.Core.Arena;

public sealed record ArenaTreasureView(ArenaTreasurePhase Phase, ArenaTreasureContents Contents, string Prompt = "");
