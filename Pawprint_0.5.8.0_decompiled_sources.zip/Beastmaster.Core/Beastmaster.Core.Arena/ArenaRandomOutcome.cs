using System;

namespace Beastmaster.Core.Arena;

public sealed record ArenaRandomOutcome(int PoolSubrow, int EventType, int ContentSubrow, uint BattleDetailId, ArenaRandomEnemy[] Enemies)
{
	public ArenaTileKind TileKind
	{
		get
		{
			switch (EventType)
			{
			case 2:
			case 3:
			case 4:
				return ArenaTileKind.Battle;
			case 5:
				return ArenaTileKind.Shop;
			case 6:
				return ArenaTileKind.Camp;
			case 7:
				return ArenaTileKind.Treasure;
			default:
				throw new InvalidOperationException("随机事件类型无效");
			}
		}
	}

	public string Label => EventType switch
	{
		2 => "普通战", 
		3 => "精英战", 
		4 => "首领战", 
		5 => "商店", 
		6 => "帐篷", 
		7 => "宝箱", 
		_ => "未知", 
	};
}
