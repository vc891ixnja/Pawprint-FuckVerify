namespace Beastmaster.Core.Arena;

public enum ArenaResultPhase
{
	Loading,
	NextPage,
	ExitPage,
	Outside,
	Blocked
}
