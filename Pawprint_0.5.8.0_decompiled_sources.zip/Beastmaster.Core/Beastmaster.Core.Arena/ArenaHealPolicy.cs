using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaHealPolicy
{
	public static int UiIntervalMilliseconds(bool duringBattle)
	{
		if (!duringBattle)
		{
			return 250;
		}
		return 100;
	}

	public static int MaxUseAttempts(bool duringBattle)
	{
		return 8000 / UiIntervalMilliseconds(duringBattle);
	}

	public static int Healing(uint id)
	{
		return id switch
		{
			76u => 10, 
			77u => 23, 
			78u => 36, 
			79u => 50, 
			80u => 10, 
			81u => 25, 
			82u => 40, 
			_ => 0, 
		};
	}

	public static bool IsHealingItem(uint id)
	{
		return Healing(id) > 0;
	}

	public static bool NeedsHealing(uint hp, uint maxHp, int percent = 50)
	{
		if (hp != 0 && maxHp != 0)
		{
			return (ulong)((long)hp * 100L) < (ulong)((long)maxHp * (long)(uint)Math.Clamp(percent, 1, 100));
		}
		return false;
	}

	public static ArenaHealItem? Choose(ArenaHealView view, int percent = 50, IReadOnlyList<uint>? priority = null)
	{
		if (NeedsHealing(view.Hp, view.MaxHp, percent))
		{
			return (from i in view.Items
				where i.Usable && Healing(i.ItemId) > 0
				orderby ArenaPresetPolicy.Priority(priority, i.ItemId), Healing(i.ItemId) descending, i.Slot
				select i).FirstOrDefault();
		}
		return null;
	}

	public static ArenaHealItem[] Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> dictionary = values.ToDictionary((ArenaValue x) => x.Index);
		ArenaValue? valueOrDefault = dictionary.GetValueOrDefault(0);
		if ((object)valueOrDefault == null || valueOrDefault.Number != 1 || !dictionary.ContainsKey(58))
		{
			throw new InvalidOperationException("斗兽道具栏未就绪");
		}
		List<ArenaHealItem> list = new List<ArenaHealItem>();
		for (int num = 0; num < 10; num++)
		{
			int num2 = 9 + num * 5;
			long? num3 = dictionary.GetValueOrDefault(num2 + 3)?.Number;
			if ((!num3.HasValue || num3.GetValueOrDefault() == 0L) ? true : false)
			{
				continue;
			}
			bool flag;
			if (num3.HasValue)
			{
				long valueOrDefault2 = num3.GetValueOrDefault();
				if (valueOrDefault2 < 0 || valueOrDefault2 > uint.MaxValue)
				{
					flag = true;
					goto IL_00e4;
				}
			}
			flag = false;
			goto IL_00e4;
			IL_00e4:
			if (flag || !ArenaItemCatalog.Items.ContainsKey((uint)num3.Value))
			{
				throw new InvalidOperationException("斗兽道具栏编号未识别");
			}
			int slot = num;
			int itemId = (int)num3.Value;
			ArenaValue? valueOrDefault3 = dictionary.GetValueOrDefault(num2);
			int usable;
			if ((object)valueOrDefault3 != null && valueOrDefault3.Number == 1)
			{
				ArenaValue? valueOrDefault4 = dictionary.GetValueOrDefault(num2 + 1);
				usable = (((object)valueOrDefault4 != null && valueOrDefault4.Number == 1) ? 1 : 0);
			}
			else
			{
				usable = 0;
			}
			list.Add(new ArenaHealItem(slot, (uint)itemId, (byte)usable != 0));
		}
		return list.ToArray();
	}
}
