using System.Collections.Generic;

namespace Beastmaster.Core.Arena;

public sealed class ArenaSeedlingFinisher
{
	private readonly HashSet<ulong> seen = new HashSet<ulong>();

	public int Seen => seen.Count;

	public bool Fired { get; private set; }

	public bool Ready(IEnumerable<ulong> seedlingIds)
	{
		foreach (ulong seedlingId in seedlingIds)
		{
			seen.Add(seedlingId);
		}
		if (!Fired)
		{
			return seen.Count >= 4;
		}
		return false;
	}

	public void MarkFired()
	{
		Fired = true;
	}
}
