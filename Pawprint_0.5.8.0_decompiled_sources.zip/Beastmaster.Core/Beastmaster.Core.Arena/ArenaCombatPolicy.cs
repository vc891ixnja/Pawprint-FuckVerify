using System;
using System.Linq;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public static class ArenaCombatPolicy
{
	public static bool IsArena(uint territory)
	{
		return ArenaStage.All.Any((ArenaStage stage) => stage.Territory == territory);
	}

	public static bool CaptureMode(uint territory, bool requested)
	{
		if (requested)
		{
			return !IsArena(territory);
		}
		return false;
	}

	public static bool AllowsAction(uint territory, uint action)
	{
		bool flag = !IsArena(territory);
		if (!flag)
		{
			bool flag2 = ((action == 44880 || action == 44882) ? true : false);
			flag = !flag2;
		}
		return flag;
	}

	public static void EnsureCaptureOff(ITaskRotationBackend backend, bool forceReset = false)
	{
		try
		{
			if (!bool.TryParse(backend.Read("CaptureMode"), out var result))
			{
				throw new InvalidOperationException("PR 捕捉模式状态无效");
			}
			if (result || forceReset)
			{
				backend.Write("CaptureMode", "False");
				if (!bool.TryParse(backend.Read("CaptureMode"), out result) || result)
				{
					throw new InvalidOperationException("PR 捕捉模式未能关闭");
				}
			}
		}
		catch
		{
			backend.Stop();
			throw;
		}
	}
}
