namespace Beastmaster.Core.Arena;

public sealed record ArenaEncounterView(ArenaEncounterPhase Phase, ArenaPet[] Pets, bool TakeAllPrompt = false, string? PendingUi = null, bool UnderfilledFlutesPrompt = false);
