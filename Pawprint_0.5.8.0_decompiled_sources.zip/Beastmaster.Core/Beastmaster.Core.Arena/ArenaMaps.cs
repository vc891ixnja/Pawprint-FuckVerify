using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;

namespace Beastmaster.Core.Arena;

public static class ArenaMaps
{
	public static IReadOnlyDictionary<int, ArenaStageMap> All { get; } = Load();

	public static ArenaStageMap Get(int stage)
	{
		if (!All.TryGetValue(stage, out ArenaStageMap value))
		{
			throw new ArgumentOutOfRangeException("stage");
		}
		return value;
	}

	private static IReadOnlyDictionary<int, ArenaStageMap> Load()
	{
		using Stream utf8Json = typeof(ArenaMaps).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-maps.json");
		return JsonSerializer.Deserialize<ArenaStageMap[]>(utf8Json).ToDictionary((ArenaStageMap m) => m.StageId);
	}
}
