using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaPresetCollection
{
	public ulong Character { get; set; }

	public int StageId { get; set; }

	public string SelectedId { get; set; } = "";

	public string DefaultPresetId { get; set; } = "";

	public List<ArenaPreset> Presets { get; set; } = new List<ArenaPreset>();

	[JsonIgnore]
	[IgnoreDataMember]
	public ArenaPreset Selected => Presets.FirstOrDefault((ArenaPreset p) => p.Id == SelectedId && p.StageId == StageId) ?? Presets.First((ArenaPreset p) => p.StageId == StageId);

	public static ArenaPresetCollection Create(ulong character, int stage, IEnumerable<uint> legacyRoster)
	{
		if (character == 0L || !ArenaMaps.All.ContainsKey(stage))
		{
			throw new InvalidOperationException("预设角色或地图无效");
		}
		ArenaPreset arenaPreset = new ArenaPreset
		{
			StageId = stage,
			Resources = new ArenaResources
			{
				UnifiedPriorities = true,
				SourcePriorities = true
			},
			Roster = legacyRoster.Where((uint n) => n >= 1 && n <= 50).Distinct().Take(ArenaStage.Get(stage).RosterCapacity)
				.ToList()
		};
		ArenaPresetCollection obj = new ArenaPresetCollection
		{
			Character = character,
			StageId = stage,
			SelectedId = arenaPreset.Id,
			DefaultPresetId = arenaPreset.Id
		};
		int num = 1;
		List<ArenaPreset> list = new List<ArenaPreset>(num);
		CollectionsMarshal.SetCount(list, num);
		CollectionsMarshal.AsSpan(list)[0] = arenaPreset;
		obj.Presets = list;
		return obj;
	}

	public ArenaPreset ResetDefault()
	{
		if (!ArenaMaps.All.ContainsKey(StageId))
		{
			throw new InvalidOperationException("预设地图无效");
		}
		ArenaPreset arenaPreset = Presets.FirstOrDefault((ArenaPreset p) => p.StageId == StageId && p.Id == DefaultPresetId);
		if (arenaPreset == null && string.IsNullOrEmpty(DefaultPresetId))
		{
			arenaPreset = Presets.FirstOrDefault((ArenaPreset p) => p.StageId == StageId && p.Name == "默认");
		}
		ArenaPreset arenaPreset2 = new ArenaPreset
		{
			StageId = StageId,
			Resources = new ArenaResources
			{
				UnifiedPriorities = true,
				SourcePriorities = true
			}
		};
		if (arenaPreset != null)
		{
			arenaPreset2.Id = arenaPreset.Id;
			Presets[Presets.IndexOf(arenaPreset)] = arenaPreset2;
		}
		else
		{
			Presets.Insert(0, arenaPreset2);
		}
		string defaultPresetId = (SelectedId = arenaPreset2.Id);
		DefaultPresetId = defaultPresetId;
		return arenaPreset2;
	}
}
