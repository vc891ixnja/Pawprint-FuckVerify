using System;
using System.Numerics;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public sealed class ArenaBattleAssist : IWorkflowStep
{
	private readonly double acrDelay;

	private TimeSpan? acrSelectedAt;

	private bool pulled;

	private bool pullSkipped;

	private bool enteredCombatAfterPull;

	private bool countdownSent;

	private TimeSpan nextCountdownAttempt;

	private CombatTarget? target;

	private NavigationStep? approach;

	private TimeSpan approachAt;

	private TimeSpan nextAttack;

	private TimeSpan nextHealCheck;

	private TimeSpan healAt;

	private TimeSpan nextTargetRule;

	private TimeSpan? pullStarted;

	private ArenaHealStep? heal;

	private ArenaUseAllItemsStep? items;

	private bool itemsStarted;

	private TimeSpan itemsAt;

	private TimeSpan origin;

	private TimeSpan? combatDroppedAt;

	public string Name { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(12L);

	public ArenaBattleAssist(IArenaBattleWorld world, INavigationProvider nav, ArenaOpeningMode openingMode, Func<ArenaHealStep>? healFactory = null, Func<ArenaUseAllItemsStep>? itemsFactory = null, Func<double>? acrDelaySeconds = null, ArenaBattleRuleEngine? engine = null)
	{
		_003Cworld_003EP = world;
		_003Cnav_003EP = nav;
		_003CopeningMode_003EP = openingMode;
		_003ChealFactory_003EP = healFactory;
		_003CitemsFactory_003EP = itemsFactory;
		_003Cengine_003EP = engine;
		acrDelay = Math.Clamp(acrDelaySeconds?.Invoke() ?? (3.0 + Random.Shared.NextDouble() * 4.0), 3.0, 7.0);
		Name = "本场战斗 · 等待战斗结束";
		base._002Ector();
	}

	public ArenaBattleAssist(IArenaBattleWorld world, INavigationProvider nav, bool autoPull, Func<ArenaHealStep>? healFactory = null, Func<ArenaUseAllItemsStep>? itemsFactory = null)
		: this(world, nav, (!autoPull) ? ArenaOpeningMode.Disabled : ArenaOpeningMode.TenSecondAttack, healFactory, itemsFactory)
	{
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		ArenaCombatView arenaCombatView = _003Cworld_003EP.Read();
		if (pulled || pullSkipped)
		{
			if (arenaCombatView.InCombat)
			{
				enteredCombatAfterPull = true;
			}
			if (enteredCombatAfterPull && arenaCombatView.Ready && !arenaCombatView.InCombat)
			{
				TimeSpan valueOrDefault = combatDroppedAt.GetValueOrDefault();
				if (!combatDroppedAt.HasValue)
				{
					valueOrDefault = elapsed;
					combatDroppedAt = valueOrDefault;
				}
				if (elapsed - combatDroppedAt.Value >= TimeSpan.FromSeconds(2.5))
				{
					RestartAfterRewind(elapsed);
				}
			}
			else
			{
				combatDroppedAt = null;
			}
		}
		else
		{
			combatDroppedAt = null;
		}
		TimeSpan timeSpan = elapsed - origin;
		if (_003CopeningMode_003EP == ArenaOpeningMode.TenSecondAttack && !pulled && !pullSkipped && !countdownSent && arenaCombatView.Player != null && timeSpan >= TimeSpan.FromSeconds(5L) && timeSpan < TimeSpan.FromSeconds(10L) && timeSpan >= nextCountdownAttempt)
		{
			nextCountdownAttempt = timeSpan + TimeSpan.FromMilliseconds(500L);
			countdownSent = _003Cworld_003EP.TryStartCountdown(5);
		}
		bool flag = _003Cengine_003EP?.HasRules ?? false;
		bool flag2 = (flag ? _003Cengine_003EP.HasCustomTargetRule : _003Cworld_003EP.HasCustomTargetRule);
		bool flag3 = arenaCombatView.Player != null && flag2 && elapsed >= nextTargetRule;
		if (flag3)
		{
			ArenaOpeningMode arenaOpeningMode = _003CopeningMode_003EP;
			bool flag4 = ((arenaOpeningMode == ArenaOpeningMode.AcrOpener || arenaOpeningMode == ArenaOpeningMode.AssistantAcr) ? true : false);
			flag3 = !flag4 || pulled || pullSkipped;
		}
		if (flag3)
		{
			nextTargetRule = elapsed + TimeSpan.FromMilliseconds(500L);
			CombatTarget combatTarget = (flag ? _003Cengine_003EP.ChoosePriorityTarget(target?.ObjectId) : _003Cworld_003EP.FindPriorityTarget(target?.ObjectId));
			if (combatTarget?.ObjectId != target?.ObjectId)
			{
				CancelApproach();
			}
			target = combatTarget;
			if (target != null && _003Cworld_003EP.TrySelectTarget(target.ObjectId))
			{
				_003Cworld_003EP.UpdateTargetAction(target.ObjectId);
			}
		}
		if (arenaCombatView.Player != null)
		{
			_003Cworld_003EP.RearLogicEnabled = _003Cengine_003EP?.RearEnabled ?? false;
			_003Cworld_003EP.UpdateBattleActions(elapsed);
		}
		_003Cengine_003EP?.Tick(elapsed);
		ArenaBattleRuleEngine arenaBattleRuleEngine = _003Cengine_003EP;
		if (arenaBattleRuleEngine != null && arenaBattleRuleEngine.ItemsBusy)
		{
			heal?.Cancel();
			heal = null;
			Name = _003Cengine_003EP.Name;
			return StepResult.Running;
		}
		if (!itemsStarted && _003CitemsFactory_003EP != null && _003Cworld_003EP.ShouldUseAllItems)
		{
			itemsStarted = true;
			heal?.Cancel();
			heal = null;
			items = _003CitemsFactory_003EP();
			itemsAt = elapsed;
		}
		if (items != null)
		{
			if (items.Tick(elapsed - itemsAt) != StepResult.Completed)
			{
				Name = items.Name;
				return StepResult.Running;
			}
			items.Cancel();
			items = null;
		}
		if (arenaCombatView.AiControlsMovement)
		{
			CancelApproach();
		}
		string text = null;
		if (heal != null || (arenaCombatView.Player != null && arenaCombatView.InCombat && _003ChealFactory_003EP != null && elapsed >= nextHealCheck))
		{
			if (heal == null)
			{
				heal = _003ChealFactory_003EP();
				healAt = elapsed;
			}
			if (heal.Tick(elapsed - healAt) == StepResult.Completed)
			{
				nextHealCheck = elapsed + TimeSpan.FromSeconds(1L);
				heal.Cancel();
				heal = null;
			}
			else
			{
				text = heal.Name;
			}
		}
		StepResult result = TickOpening(arenaCombatView, timeSpan);
		arenaBattleRuleEngine = _003Cengine_003EP;
		if (arenaBattleRuleEngine != null)
		{
			string name = arenaBattleRuleEngine.Name;
			if (name != null && name.Length > 0)
			{
				Name = _003Cengine_003EP.Name;
				return result;
			}
		}
		arenaBattleRuleEngine = _003Cengine_003EP;
		if (arenaBattleRuleEngine != null)
		{
			string name = arenaBattleRuleEngine.Notice;
			if (name != null && name.Length > 0)
			{
				Name = _003Cengine_003EP.Notice;
				return result;
			}
		}
		if (text != null)
		{
			Name = text;
		}
		return result;
	}

	private StepResult TickOpening(ArenaCombatView state, TimeSpan elapsed)
	{
		if (!state.Ready || state.Player == null)
		{
			CancelApproach();
			return StepResult.Running;
		}
		Name = (pullSkipped ? "本场战斗 · 已跳过自动开怪，等待战斗结束" : "本场战斗 · 等待战斗结束");
		if (_003CopeningMode_003EP == ArenaOpeningMode.Disabled || pulled || pullSkipped)
		{
			return StepResult.Running;
		}
		if (_003CopeningMode_003EP == ArenaOpeningMode.AcrOpener)
		{
			return TickAcrOpening(elapsed);
		}
		if (elapsed < TimeSpan.FromSeconds(10L))
		{
			Name = $"本场战斗 · {Math.Ceiling(10.0 - elapsed.TotalSeconds)} 秒后开怪";
			return StepResult.Running;
		}
		TimeSpan valueOrDefault = pullStarted.GetValueOrDefault();
		if (!pullStarted.HasValue)
		{
			valueOrDefault = elapsed;
			pullStarted = valueOrDefault;
		}
		TimeSpan value = elapsed;
		TimeSpan? timeSpan = pullStarted;
		if (value - timeSpan > TimeSpan.FromSeconds(60L))
		{
			return SkipPull();
		}
		if (target != null)
		{
			target = _003Cworld_003EP.ReadTarget(target.ObjectId);
		}
		CombatTarget combatTarget = target;
		if ((object)combatTarget == null || !combatTarget.IsAttackable || !combatTarget.IsTargetable || combatTarget.IsDead || combatTarget.Hp == 0)
		{
			CancelApproach();
			target = (_003Cworld_003EP.HasCustomTargetRule ? _003Cworld_003EP.FindPriorityTarget(null) : _003Cworld_003EP.FindNearestTarget());
		}
		combatTarget = target;
		if ((object)combatTarget == null || !combatTarget.IsAttackable || !combatTarget.IsTargetable || combatTarget.IsDead || combatTarget.Hp == 0)
		{
			Name = "本场战斗 · 等待可攻击目标";
			return StepResult.Running;
		}
		if (!_003Cworld_003EP.TrySelectTarget(target.ObjectId))
		{
			CancelApproach();
			Name = "本场战斗 · 等待选中目标";
			return StepResult.Running;
		}
		if (Vector3.Distance(state.Player.Position, target.Location.Position) - target.HitboxRadius > 3f)
		{
			Name = "本场战斗 · 接近开怪目标";
			if (state.AiControlsMovement)
			{
				CancelApproach();
				return StepResult.Running;
			}
			if (approach != null && Vector3.Distance(approach.Destination.Position, target.Location.Position) > 1f)
			{
				CancelApproach();
			}
			if (approach == null)
			{
				if (!_003Cnav_003EP.IsReady || !_003Cnav_003EP.MovementAllowed || _003Cnav_003EP.IsRunning || _003Cnav_003EP.IsPathfinding)
				{
					return StepResult.Running;
				}
				approach = new NavigationStep(_003Cnav_003EP, target.Location, () => _003Cworld_003EP.Read().Player);
				approachAt = elapsed;
			}
			try
			{
				if (approach.Tick(elapsed - approachAt) == StepResult.Completed)
				{
					CancelApproach();
				}
			}
			catch (Exception ex) when (((ex is InvalidOperationException || ex is TimeoutException || ex is OperationCanceledException) ? 1 : 0) != 0)
			{
				return SkipPull();
			}
			return StepResult.Running;
		}
		CancelApproach();
		if (elapsed < nextAttack)
		{
			return StepResult.Running;
		}
		nextAttack = elapsed + TimeSpan.FromMilliseconds(500L);
		if (_003Cworld_003EP.TryOpeningAttack(target.ObjectId))
		{
			pulled = true;
			Name = "本场战斗 · 已开怪";
			if (!_003Cworld_003EP.HasCustomTargetRule)
			{
				_003Cworld_003EP.ReleaseTargetControl();
			}
		}
		else
		{
			Name = "本场战斗 · 等待开怪技能可用" + ((_003Cworld_003EP.LastActionStatus.Length > 0) ? ("（" + _003Cworld_003EP.LastActionStatus + "）") : "");
		}
		return StepResult.Running;
	}

	private StepResult TickAcrOpening(TimeSpan elapsed)
	{
		TimeSpan valueOrDefault = pullStarted.GetValueOrDefault();
		if (!pullStarted.HasValue)
		{
			valueOrDefault = elapsed;
			pullStarted = valueOrDefault;
		}
		TimeSpan? timeSpan = pullStarted;
		if (elapsed - timeSpan > TimeSpan.FromSeconds(60L))
		{
			return SkipPull();
		}
		if (target != null)
		{
			target = _003Cworld_003EP.ReadTarget(target.ObjectId);
		}
		CombatTarget combatTarget = target;
		if ((object)combatTarget == null || !combatTarget.IsAttackable || !combatTarget.IsTargetable || combatTarget.IsDead || combatTarget.Hp == 0)
		{
			target = _003Cworld_003EP.FindNearestTarget();
			acrSelectedAt = null;
		}
		combatTarget = target;
		if ((object)combatTarget == null || !combatTarget.IsAttackable || !combatTarget.IsTargetable || combatTarget.IsDead || combatTarget.Hp == 0)
		{
			Name = "本场战斗 · 等待可攻击目标";
			return StepResult.Running;
		}
		if (!_003Cworld_003EP.TrySelectTarget(target.ObjectId))
		{
			Name = "本场战斗 · 等待选中目标";
			return StepResult.Running;
		}
		valueOrDefault = acrSelectedAt.GetValueOrDefault();
		if (!acrSelectedAt.HasValue)
		{
			valueOrDefault = elapsed;
			acrSelectedAt = valueOrDefault;
		}
		double num = ((_003CopeningMode_003EP == ArenaOpeningMode.AssistantAcr) ? 0.0 : acrDelay) - (elapsed - acrSelectedAt.Value).TotalSeconds;
		if (num > 0.0)
		{
			Name = $"本场战斗 · {Math.Ceiling(num)} 秒后调用 ACR 起手";
			return StepResult.Running;
		}
		if (elapsed < nextAttack)
		{
			return StepResult.Running;
		}
		nextAttack = elapsed + TimeSpan.FromMilliseconds(500L);
		if ((_003CopeningMode_003EP == ArenaOpeningMode.AssistantAcr) ? _003Cworld_003EP.TryAssistantAcrOpening(target.ObjectId) : _003Cworld_003EP.TryAcrOpening(target.ObjectId))
		{
			pulled = true;
			Name = "本场战斗 · 已调用 ACR 起手";
			if (!_003Cworld_003EP.HasCustomTargetRule)
			{
				_003Cworld_003EP.ReleaseTargetControl();
			}
		}
		else
		{
			Name = "本场战斗 · 等待 ACR 起手可用" + ((_003Cworld_003EP.LastActionStatus.Length > 0) ? ("（" + _003Cworld_003EP.LastActionStatus + "）") : "");
		}
		return StepResult.Running;
	}

	private void RestartAfterRewind(TimeSpan elapsed)
	{
		origin = elapsed;
		combatDroppedAt = null;
		pulled = false;
		pullSkipped = false;
		countdownSent = false;
		enteredCombatAfterPull = false;
		pullStarted = null;
		acrSelectedAt = null;
		nextCountdownAttempt = (nextAttack = (nextHealCheck = (nextTargetRule = default(TimeSpan))));
		healAt = (itemsAt = (approachAt = default(TimeSpan)));
		target = null;
		CancelApproach();
		heal?.Cancel();
		heal = null;
		items?.Cancel();
		items = null;
		itemsStarted = false;
		_003Cengine_003EP?.Restart();
		_003Cworld_003EP.SuspendBattleMovement();
	}

	private void CancelApproach()
	{
		approach?.Cancel();
		approach = null;
	}

	public void WaitForUi()
	{
		CancelApproach();
		_003Cworld_003EP.SuspendBattleMovement();
	}

	private StepResult SkipPull()
	{
		CancelApproach();
		pullSkipped = true;
		if (!_003Cworld_003EP.HasCustomTargetRule)
		{
			_003Cworld_003EP.ReleaseTargetControl();
		}
		Name = "本场战斗 · 已跳过自动开怪，等待战斗结束";
		return StepResult.Running;
	}

	public void Cancel()
	{
		try
		{
			CancelApproach();
			heal?.Cancel();
			items?.Cancel();
			_003Cengine_003EP?.Cancel();
		}
		finally
		{
			_003Cworld_003EP.SuspendBattleMovement();
			_003Cworld_003EP.ReleaseTargetControl();
		}
	}
}
