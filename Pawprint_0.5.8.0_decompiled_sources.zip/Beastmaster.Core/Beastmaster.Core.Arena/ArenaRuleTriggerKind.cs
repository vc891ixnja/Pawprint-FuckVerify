namespace Beastmaster.Core.Arena;

public enum ArenaRuleTriggerKind
{
	Always,
	BattleElapsed,
	EnemyHpBelow,
	EnemyAliveFor,
	EnemyCount,
	TargetIs,
	PetSummoned,
	PlayerHpBelow
}
