namespace Beastmaster.Core.Arena;

public static class ArenaHighOneSecondPolicy
{
	public const uint SeedlingNameId = 14600u;

	public const int SeedlingCount = 4;

	public const string FinisherCommand = "/pr hotkey 最后一击";

	public static bool Applies(int stage, int? node)
	{
		if (stage == 4)
		{
			return node == 2;
		}
		return false;
	}
}
