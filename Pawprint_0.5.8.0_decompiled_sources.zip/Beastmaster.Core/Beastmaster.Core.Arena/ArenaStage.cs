using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Beastmaster.Core.Arena;

public sealed record ArenaStage(int Id, string Name, uint Content, uint Territory, int RosterCapacity = 10)
{
	public static IReadOnlyList<ArenaStage> All { get; } = Array.AsReadOnly(new ArenaStage[5]
	{
		new ArenaStage(1, "第一盘", 1088u, 1339u),
		new ArenaStage(2, "第二盘", 1089u, 1340u, 12),
		new ArenaStage(3, "第三盘", 1090u, 1341u, 14),
		new ArenaStage(4, "高段第一盘", 1091u, 1342u, 12),
		new ArenaStage(5, "高段第二盘", 1092u, 1343u, 15)
	});

	public bool HasNavigationRoute => ArenaBoardRoute.Supports(Id);

	public static ArenaStage Get(int id)
	{
		return All.FirstOrDefault((ArenaStage s) => s.Id == id) ?? All[0];
	}

	public static ArenaStage? FromContent(uint id)
	{
		return All.FirstOrDefault((ArenaStage s) => s.Content == id);
	}

	[CompilerGenerated]
	private ArenaStage(ArenaStage original)
	{
		Id = original.Id;
		Name = original.Name;
		Content = original.Content;
		Territory = original.Territory;
		RosterCapacity = original.RosterCapacity;
	}
}
