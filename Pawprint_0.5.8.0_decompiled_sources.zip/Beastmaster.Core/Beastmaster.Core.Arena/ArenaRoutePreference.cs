namespace Beastmaster.Core.Arena;

public enum ArenaRoutePreference
{
	Left,
	Treasure,
	Camp,
	Right
}
