using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaRuleItemFilters
{
	public static bool IsFunctionItem(uint id)
	{
		if (id - 100 <= 1 || id == 115)
		{
			return true;
		}
		return false;
	}

	public static bool IsAttackItem(uint id)
	{
		switch (id)
		{
		case 128u:
		case 129u:
		case 130u:
		case 131u:
		case 132u:
		case 133u:
		case 134u:
		case 139u:
			return true;
		default:
			return false;
		}
	}

	public static bool Match(ArenaRuleItemFilter filter, IReadOnlyList<uint> explicitIds, uint itemId)
	{
		return filter switch
		{
			ArenaRuleItemFilter.All => true, 
			ArenaRuleItemFilter.Function => IsFunctionItem(itemId) || itemId == 138, 
			ArenaRuleItemFilter.FunctionNoTimeSand => IsFunctionItem(itemId), 
			ArenaRuleItemFilter.Attack => IsAttackItem(itemId), 
			ArenaRuleItemFilter.NonHealing => !ArenaHealPolicy.IsHealingItem(itemId), 
			ArenaRuleItemFilter.Healing => ArenaHealPolicy.IsHealingItem(itemId), 
			ArenaRuleItemFilter.ExplicitList => explicitIds.Contains(itemId), 
			_ => false, 
		};
	}

	public static string Label(ArenaRuleItemFilter filter)
	{
		return filter switch
		{
			ArenaRuleItemFilter.All => "全部道具", 
			ArenaRuleItemFilter.Function => "功能道具（含时之沙）", 
			ArenaRuleItemFilter.FunctionNoTimeSand => "功能道具（不含时之沙）", 
			ArenaRuleItemFilter.Attack => "攻击道具", 
			ArenaRuleItemFilter.NonHealing => "全部非恢复道具", 
			ArenaRuleItemFilter.Healing => "恢复药品", 
			ArenaRuleItemFilter.ExplicitList => "指定道具", 
			_ => filter.ToString(), 
		};
	}
}
