using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaRestDecoder
{
	public static bool IsLeavePrompt(string text)
	{
		return ContainsHead(text, "Tent.LeaveConfirm");
	}

	private static bool ContainsHead(string text, string key)
	{
		IReadOnlyList<string> readOnlyList = GameText.Fragments(key);
		if (readOnlyList.Count > 0)
		{
			return GameText.Normalize(text).Contains(GameText.Normalize(readOnlyList[0]), StringComparison.Ordinal);
		}
		return false;
	}

	public static int Capacity(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> dictionary = values.ToDictionary((ArenaValue v) => v.Index);
		ArenaValue? valueOrDefault = dictionary.GetValueOrDefault(2);
		if ((object)valueOrDefault == null || valueOrDefault.Number != 4 || !GameText.Matches("Tent.Rest", dictionary.GetValueOrDefault(1166)?.Text))
		{
			throw new InvalidOperationException("当前不是休息魔兽列表");
		}
		string text = GameText.Normalize(dictionary.GetValueOrDefault(1185)?.Text ?? "");
		IReadOnlyList<string> readOnlyList = GameText.Fragments("Tent.Info");
		if (readOnlyList.Count < 1)
		{
			throw new InvalidOperationException("休息可恢复魔兽数量未读到");
		}
		string text2 = GameText.Normalize(readOnlyList[0]);
		int num = text.IndexOf(text2, StringComparison.Ordinal);
		if (num < 0)
		{
			throw new InvalidOperationException("休息可恢复魔兽数量未读到");
		}
		int num2 = num + text2.Length;
		long num3 = 0L;
		int num4 = 0;
		for (; num2 < text.Length; num2++)
		{
			double numericValue = char.GetNumericValue(text[num2]);
			if (numericValue < 0.0 || numericValue % 1.0 != 0.0)
			{
				break;
			}
			num3 = num3 * 10 + (long)numericValue;
			num4++;
			if (num3 > 15)
			{
				throw new InvalidOperationException("休息可恢复魔兽数量未读到");
			}
		}
		if (num4 == 0)
		{
			throw new InvalidOperationException("休息可恢复魔兽数量未读到");
		}
		if (readOnlyList.Count >= 2)
		{
			string text3 = text;
			int num5 = num2;
			if (!text3.Substring(num5, text3.Length - num5).StartsWith(GameText.Normalize(readOnlyList[1]), StringComparison.Ordinal))
			{
				throw new InvalidOperationException("休息可恢复魔兽数量未读到");
			}
		}
		return (int)num3;
	}

	public static ArenaRestPet[] Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> fields = values.ToDictionary((ArenaValue v) => v.Index);
		ArenaValue? valueOrDefault = fields.GetValueOrDefault(2);
		if ((object)valueOrDefault == null || valueOrDefault.Number != 4 || !GameText.Matches("Tent.Rest", fields.GetValueOrDefault(1166)?.Text))
		{
			throw new InvalidOperationException("当前不是休息魔兽列表");
		}
		ArenaPet[] array = ArenaPartyDecoder.Decode(values, allowEmpty: true);
		if (array.Length > 15)
		{
			throw new InvalidOperationException("休息魔兽数量异常");
		}
		return array.Select(delegate(ArenaPet p)
		{
			long? num = fields.GetValueOrDefault(6 + p.Row * 77 + 75)?.Number;
			bool flag;
			if (num.HasValue)
			{
				long valueOrDefault2 = num.GetValueOrDefault();
				if ((ulong)valueOrDefault2 <= 1uL)
				{
					flag = true;
					goto IL_004a;
				}
			}
			flag = false;
			goto IL_004a;
			IL_004a:
			if (!flag)
			{
				throw new InvalidOperationException("休息选择标记未就绪");
			}
			return new ArenaRestPet(p.Row, p.PetId, p.Name, p.Hp, p.MaxHp, num == 1);
		}).ToArray();
	}

	public static bool IsRestPrompt(string text)
	{
		if (!GameText.Matches("Tent.RestConfirm", text) && !ContainsHead(text, "Tent.RestSoloConfirm"))
		{
			return false;
		}
		if (GameText.Language != "zhCN")
		{
			return true;
		}
		Match match = Regex.Match(GameText.Normalize(text), "^确定要(?:不让魔兽，只让玩家休息|(?:“[^“”]+”){1,15}和你一起休息)，恢复([0-9]+(?:\\.[0-9]+)?)%体力吗？");
		if (match.Success && decimal.TryParse(match.Groups[1].Value, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var result))
		{
			if (result > 0m)
			{
				return result <= 100m;
			}
			return false;
		}
		return false;
	}

	public static bool MatchesPrompt(string text, IEnumerable<ArenaRestPet> selected)
	{
		if (!IsRestPrompt(text))
		{
			return false;
		}
		if (GameText.Language != "zhCN")
		{
			return true;
		}
		ArenaRestPet[] array = selected.OrderBy((ArenaRestPet p) => p.Row).ToArray();
		if (array.Length > 15 || array.Any((ArenaRestPet p) => p.Hp == 0) || array.Select((ArenaRestPet p) => p.Number).Distinct().Count() != array.Length)
		{
			return false;
		}
		string text2 = ((array.Length == 0) ? "确定要不让魔兽，只让玩家休息，恢复" : string.Concat("确定要", string.Concat(array.Select((ArenaRestPet p) => "“" + p.Name + "”")), "和你一起休息，恢复"));
		string text3 = GameText.Normalize(text);
		text2 = GameText.Normalize(text2);
		string text4 = text3;
		int num = Math.Min(text2.Length, text3.Length);
		Match match = Regex.Match(text4.Substring(num, text4.Length - num), "^([0-9]+(?:\\.[0-9]+)?)%体力吗？", RegexOptions.CultureInvariant);
		if (text3.StartsWith(text2, StringComparison.Ordinal) && match.Success && decimal.TryParse(match.Groups[1].Value, NumberStyles.AllowDecimalPoint, CultureInfo.InvariantCulture, out var result))
		{
			if (result > 0m)
			{
				return result <= 100m;
			}
			return false;
		}
		return false;
	}
}
