namespace Beastmaster.Core.Arena;

public sealed record ArenaShopPet(int Row, uint Number, string Name, uint Hp, uint FoodId);
