namespace Beastmaster.Core.Arena;

public sealed record ArenaEquipmentOutcome(uint ItemId, bool Accepted);
