namespace Beastmaster.Core.Arena;

public enum ArenaOpeningMode
{
	TenSecondAttack,
	AcrOpener,
	Disabled,
	AssistantAcr
}
