using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public static class ArenaPrePullItemsPolicy
{
	public const uint TreantNameId = 14618u;

	public static bool Applies(int stage, int? node)
	{
		if (stage == 4)
		{
			return node == 11;
		}
		return false;
	}

	public static bool IsFunctionItem(uint itemId)
	{
		if (itemId - 100 <= 1 || itemId == 115)
		{
			return true;
		}
		return false;
	}

	public static bool BurstReady(CombatTarget? treant)
	{
		if ((object)treant != null && !treant.IsDead && treant.Hp != 0 && treant.MaxHp != 0)
		{
			return (ulong)((long)treant.Hp * 2L) < (ulong)treant.MaxHp;
		}
		return false;
	}
}
