using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRuleAction
{
	public ArenaRuleActionKind Kind { get; set; }

	public ArenaRuleItemFilter ItemFilter { get; set; }

	public List<uint> ItemIds { get; set; } = new List<uint>();

	public int DutyActionSlot { get; set; } = 1;

	public List<uint> PriorityEnemyIds { get; set; } = new List<uint>();

	public int CountdownSeconds { get; set; } = 5;

	public int ItemLimit { get; set; }
}
