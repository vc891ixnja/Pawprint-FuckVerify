using System;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaShopProbeStep(IArenaShopWorld world, uint sellItemId, uint buyItemId) : IWorkflowStep
{
	private int stage;

	private TimeSpan stageAt;

	private TimeSpan nextAttempt;

	private ArenaShopPhase? lastPhase;

	public string Name { get; private set; } = "出售测试 · 发起出售";

	public TimeSpan Timeout => TimeSpan.FromSeconds(120L);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed >= Timeout)
		{
			throw new TimeoutException("出售测试超时");
		}
		ArenaShopView view = world.Read();
		if (view.Phase != lastPhase)
		{
			lastPhase = view.Phase;
			stageAt = elapsed;
		}
		if (elapsed - stageAt > TimeSpan.FromSeconds((stage == 3) ? 10 : 20))
		{
			throw new TimeoutException(Name + "，未收到操作结果");
		}
		switch (stage)
		{
		case 0:
			if (view.Phase != ArenaShopPhase.Selection)
			{
				break;
			}
			if (!((ReadOnlySpan<uint>)view.Contents.Owned).Contains(sellItemId))
			{
				Move(3, elapsed, "出售测试 · 无可售道具，直接购买");
				break;
			}
			Name = "出售测试 · 出售" + ArenaItemCatalog.Items[sellItemId].Name;
			if (Attempt(() => world.TrySell(sellItemId), elapsed))
			{
				Move(1, elapsed, "出售测试 · 确认出售");
			}
			break;
		case 1:
			if (view.Phase == ArenaShopPhase.Confirmation && Attempt(() => world.TryAnswer(view.Prompt, yes: true), elapsed))
			{
				Move(2, elapsed, "出售测试 · 等待行消失");
			}
			break;
		case 2:
			if (view.Phase == ArenaShopPhase.Selection && !((ReadOnlySpan<uint>)view.Contents.Owned).Contains(sellItemId))
			{
				Move(3, elapsed, "出售测试 · 选择购买目标");
			}
			break;
		case 3:
			if (view.Phase == ArenaShopPhase.Selection)
			{
				if (((ReadOnlySpan<uint>)view.Contents.Owned).Contains(buyItemId))
				{
					Name = "出售测试 · 完成";
					return StepResult.Completed;
				}
				ArenaShopOffer offer = view.Contents.Offers.FirstOrDefault((ArenaShopOffer o) => o.ItemId == buyItemId && !o.Sold) ?? throw new InvalidOperationException("出售测试：商店里没有目标装备");
				Name = "出售测试 · 购买" + ArenaItemCatalog.Items[buyItemId].Name;
				if (Attempt(() => world.TryOpen(offer), elapsed))
				{
					Move(4, elapsed, "出售测试 · 确认购买");
				}
			}
			break;
		case 4:
			if (view.Phase == ArenaShopPhase.Confirmation && Attempt(() => world.TryAnswer(view.Prompt, yes: true), elapsed))
			{
				Move(5, elapsed, "出售测试 · 等待到手");
			}
			break;
		case 5:
			if (view.Phase == ArenaShopPhase.Selection && ((ReadOnlySpan<uint>)view.Contents.Owned).Contains(buyItemId))
			{
				Name = "出售测试 · 完成";
				return StepResult.Completed;
			}
			break;
		}
		return StepResult.Running;
	}

	private void Move(int next, TimeSpan elapsed, string name)
	{
		stage = next;
		stageAt = elapsed;
		Name = name;
	}

	private bool Attempt(Func<bool> action, TimeSpan elapsed)
	{
		if (elapsed < nextAttempt)
		{
			return false;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		return action();
	}

	public void Cancel()
	{
	}
}
