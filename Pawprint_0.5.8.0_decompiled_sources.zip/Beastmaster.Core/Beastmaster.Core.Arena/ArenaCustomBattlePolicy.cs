using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public static class ArenaCustomBattlePolicy
{
	public const uint Ogre = 14538u;

	public const uint Fire = 14539u;

	public const uint LargeFire = 14748u;

	public const uint Succubus = 14541u;

	public const uint Parry = 680u;

	public const uint Protected = 2413u;

	public static CombatTarget? ChooseEighth(IEnumerable<CombatTarget> targets, ulong? preferred)
	{
		return (from t in targets.Where(delegate(CombatTarget t)
			{
				bool flag = (object)t != null && t.IsTargetable && t.IsAttackable && !t.IsDead && t.Hp != 0;
				if (flag)
				{
					uint nameId = t.NameId;
					bool flag2 = ((nameId - 14538 <= 1 || nameId == 14748) ? true : false);
					flag = flag2;
				}
				return flag;
			})
			orderby (t.NameId != 14538) ? 1 : 0, t.ObjectId == preferred descending
			select t).FirstOrDefault();
	}

	public static bool BurstItems(int stage, int? node, CombatTarget? boss)
	{
		if (stage == 1 && node == 12 && (object)boss != null && boss.NameId == 14541 && !boss.IsDead && boss.Hp != 0 && boss.MaxHp != 0)
		{
			return (ulong)((long)boss.Hp * 2L) < (ulong)boss.MaxHp;
		}
		return false;
	}

	public static bool Rear(int stage, int? node, uint targetName, bool hasSummon, bool parry, bool protection)
	{
		return stage == 1 && node == 1 && targetName == 14531 && hasSummon && parry && protection;
	}
}
