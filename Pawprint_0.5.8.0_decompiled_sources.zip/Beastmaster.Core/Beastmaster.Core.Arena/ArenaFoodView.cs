using System;

namespace Beastmaster.Core.Arena;

public sealed record ArenaFoodView(bool InDuty, bool Occupied, TimeSpan Remaining, bool HasFood);
