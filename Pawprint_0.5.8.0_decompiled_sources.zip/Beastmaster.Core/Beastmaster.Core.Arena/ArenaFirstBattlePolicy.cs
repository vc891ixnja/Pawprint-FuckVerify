using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public static class ArenaFirstBattlePolicy
{
	public const uint BishopNameId = 14532u;

	public const uint KnightNameId = 14531u;

	public const uint AttractAttention = 46751u;

	public const uint AttentionDutyAction = 27u;

	public static bool IsBattleActor(uint nameId, uint baseId)
	{
		if (nameId != 14532 || baseId != 19335)
		{
			if (nameId == 14531)
			{
				return baseId == 19334;
			}
			return false;
		}
		return true;
	}

	public static bool Applies(int stage, int? node)
	{
		if (stage == 1)
		{
			return node == 1;
		}
		return false;
	}

	public static CombatTarget? Choose(IEnumerable<CombatTarget> targets, ulong? preferred = null)
	{
		return (from t in targets.Where(delegate(CombatTarget t)
			{
				bool flag = (object)t != null && !t.IsDead && t.Hp != 0 && t.IsTargetable && t.IsAttackable;
				if (flag)
				{
					uint nameId = t.NameId;
					bool flag2 = nameId - 14531 <= 1;
					flag = flag2;
				}
				return flag;
			})
			orderby (t.NameId != 14532) ? 1 : 0, t.ObjectId == preferred descending
			select t).FirstOrDefault();
	}
}
