using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;

namespace Beastmaster.Core.Arena;

public sealed class ArenaBoardRoute
{
	private static readonly IReadOnlyDictionary<int, ArenaBoardRoute> Routes = Enumerable.Range(1, 5).ToDictionary((int id) => id, (int id) => new ArenaBoardRoute(id));

	private readonly ArenaStageMap map;

	private readonly float minX;

	private readonly float maxX;

	private readonly float minZ;

	private readonly float maxZ;

	public IReadOnlyList<ArenaBoardNode> Nodes { get; }

	public static bool Supports(int stageId)
	{
		if (stageId >= 1)
		{
			return stageId <= 5;
		}
		return false;
	}

	public static ArenaBoardRoute Get(int stageId)
	{
		if (!Routes.TryGetValue(stageId, out ArenaBoardRoute value))
		{
			throw new NotSupportedException("该盘暂不支持自动走棋");
		}
		return value;
	}

	public static bool IsOnBoard(int stageId, Vector3 position)
	{
		if (Supports(stageId))
		{
			return Get(stageId).IsOnBoard(position);
		}
		return false;
	}

	private ArenaBoardRoute(int stageId)
	{
		map = ArenaMaps.Get(stageId);
		switch (stageId)
		{
		case 1:
			Nodes = FirstArenaBoard.Nodes;
			break;
		case 5:
			Nodes = HighTwoArenaBoard.Nodes;
			break;
		default:
		{
			float[] depths = new float[map.Depth + 1];
			int depth;
			for (depth = 1; depth <= map.Depth; depth++)
			{
				(ArenaMapNode, ArenaMapNode)[] array = (from e in map.Nodes.SelectMany((ArenaMapNode n) => n.Next.Select((int to) => (From: n, To: map.Nodes[to])))
					where e.To.Depth == depth
					select e).ToArray();
				if (array.Length == 0 || array.Any(((ArenaMapNode From, ArenaMapNode To) e) => e.From.Depth != depth - 1 || Math.Abs(e.To.X - e.From.X) > 1) || array.Select(((ArenaMapNode From, ArenaMapNode To) e) => e.From.X != e.To.X).Distinct().Count() != 1)
				{
					throw new InvalidOperationException($"第 {stageId} 盘的第 {depth} 行不符合已确认的间距规则");
				}
				depths[depth] = depths[depth - 1] + ((array[0].Item1.X != array[0].Item2.X) ? 7.5f : 9f);
			}
			Nodes = Array.AsReadOnly(map.Nodes.Select((ArenaMapNode n) => new ArenaBoardNode(n.Node, new Vector3(-700 + n.X * 5, 0f, 0f - depths[n.Depth]), n.Next.ToArray())).ToArray());
			break;
		}
		}
		minX = Nodes.Min((ArenaBoardNode n) => n.Center.X) - 5f;
		maxX = Nodes.Max((ArenaBoardNode n) => n.Center.X) + 5f;
		minZ = Nodes.Min((ArenaBoardNode n) => n.Center.Z) - 4f;
		maxZ = Nodes.Max((ArenaBoardNode n) => n.Center.Z) + 4f;
	}

	public bool IsOnBoard(Vector3 p)
	{
		if (float.IsFinite(p.X) && float.IsFinite(p.Y) && float.IsFinite(p.Z) && p.X >= minX && p.X <= maxX && Math.Abs(p.Y) < 1f && p.Z >= minZ)
		{
			return p.Z <= maxZ;
		}
		return false;
	}

	public bool InTile(int index, Vector3 p)
	{
		if (index >= 0 && index < Nodes.Count && IsOnBoard(p))
		{
			return Vector2.Distance(new Vector2(p.X, p.Z), new Vector2(Nodes[index].Center.X, Nodes[index].Center.Z)) <= 2.5f;
		}
		return false;
	}

	public int? FindTile(Vector3 p)
	{
		return Nodes.Where((ArenaBoardNode n) => InTile(n.Index, p)).Select((Func<ArenaBoardNode, int?>)((ArenaBoardNode n) => n.Index)).SingleOrDefault();
	}

	public bool IsBattle(int index)
	{
		return map.Nodes[index].Kind == ArenaTileKind.Battle;
	}

	public bool CanHaveBattle(int index)
	{
		ArenaTileKind kind = map.Nodes[index].Kind;
		if (kind == ArenaTileKind.Battle || kind == ArenaTileKind.Random)
		{
			return true;
		}
		return false;
	}

	public int? Next(int index)
	{
		int num = Nodes[index].Next.FirstOrDefault(-1);
		if (num < 0)
		{
			return null;
		}
		return num;
	}

	public (int From, int To)? FindBridge(Vector3 p)
	{
		if (!IsOnBoard(p) || FindTile(p).HasValue)
		{
			return null;
		}
		List<(int, int)> list = new List<(int, int)>();
		foreach (ArenaBoardNode node in Nodes)
		{
			int[] next = node.Next;
			foreach (int num in next)
			{
				Vector3 vector = Nodes[num].Center - node.Center;
				float num2 = Vector3.Dot(p - node.Center, vector) / vector.LengthSquared();
				if (num2 > 0f && num2 < 1f && Vector3.Distance(p, node.Center + vector * num2) <= 1f)
				{
					list.Add((node.Index, num));
				}
			}
		}
		if (list.Count != 1)
		{
			return null;
		}
		return list[0];
	}
}
