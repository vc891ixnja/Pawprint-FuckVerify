namespace Beastmaster.Core.Arena;

public sealed record ArenaItem(uint Id, string Name, string Description, int Category, string? Sub = null)
{
	public string CategoryLabel => Category switch
	{
		1 => "装备", 
		2 => (Sub == null) ? "道具" : ("道具/" + Sub), 
		3 => "食料", 
		_ => "", 
	};
}
