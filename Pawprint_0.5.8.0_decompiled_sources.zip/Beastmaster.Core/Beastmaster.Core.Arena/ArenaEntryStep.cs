using System;
using System.Linq;
using Beastmaster.Core.Automation;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public sealed class ArenaEntryStep : IWorkflowStep
{
	private enum Phase
	{
		Scan,
		CloseScan,
		Travel,
		Approach,
		Menu,
		BoardList,
		Roster,
		Entering
	}

	private readonly ArenaStage stage;

	private Phase phase;

	private bool scanStarted;

	private bool interacted;

	private bool choseChallenge;

	private bool choseBoard;

	private bool editorRequested;

	private bool closingEditor;

	private bool entrySent;

	private bool choseActivity;

	private uint[]? unlocked;

	private uint[]? desired;

	private uint? pendingPet;

	private bool rosterCleared;

	private bool clearSent;

	private bool entryConfirmed;

	private TimeSpan phaseAt;

	private TimeSpan requestAt;

	private TimeSpan nextUiAttempt;

	private bool resumeChecked;

	private bool preserveRoster;

	public string Name { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(12L);

	public uint[]? RosterOrder => desired;

	public ArenaEntryStep(IArenaEntryWorld world, LevelingTravelStep travel, bool resumeCurrent = false, ArenaStage? selectedStage = null, uint[]? preferredRoster = null)
	{
		_003Cworld_003EP = world;
		_003Ctravel_003EP = travel;
		_003CresumeCurrent_003EP = resumeCurrent;
		_003CpreferredRoster_003EP = preferredRoster;
		stage = selectedStage ?? ArenaStage.Get(1);
		Name = "斗兽 · 读取已解锁魔兽";
		base._002Ector();
	}

	public bool AcceptsTerritory(uint territory)
	{
		bool flag = phase == Phase.Entering;
		if (flag)
		{
			bool flag2 = ((territory == 0 || territory == 148) ? true : false);
			flag = flag2 || territory == stage.Territory;
		}
		if (!flag)
		{
			if (phase == Phase.Travel)
			{
				return _003Ctravel_003EP.AcceptsTerritory(territory);
			}
			return false;
		}
		return true;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed >= Timeout)
		{
			throw new TimeoutException("斗兽入场准备超时");
		}
		_003Cworld_003EP.Validate();
		if (_003CresumeCurrent_003EP && !resumeChecked)
		{
			ArenaEntryView arenaEntryView = _003Cworld_003EP.Read();
			if (arenaEntryView.Phase == ArenaEntryPhase.Loading)
			{
				Name = "斗兽 · 等待当前界面加载";
				CheckRequest(elapsed);
				return StepResult.Running;
			}
			resumeChecked = true;
			if (arenaEntryView.Phase == ArenaEntryPhase.EntryConfirmation)
			{
				uint[] array = _003CpreferredRoster_003EP;
				desired = ((array != null && array.Length > 0) ? _003CpreferredRoster_003EP.Distinct().Take(stage.RosterCapacity).ToArray() : arenaEntryView.Roster);
				ValidateEntryConfirmation(arenaEntryView);
				entrySent = true;
				this.phase = Phase.Entering;
				requestAt = elapsed;
			}
			ArenaEntryPhase arenaEntryPhase = arenaEntryView.Phase;
			bool flag = (((uint)(arenaEntryPhase - 1) <= 3u || arenaEntryPhase == ArenaEntryPhase.NpcMenu) ? true : false);
			preserveRoster = flag;
			if (preserveRoster)
			{
				interacted = true;
				requestAt = elapsed;
				Phase phase;
				switch (arenaEntryView.Phase)
				{
				case ArenaEntryPhase.Menu:
				case ArenaEntryPhase.NpcMenu:
					phase = Phase.Menu;
					break;
				case ArenaEntryPhase.StageList:
					phase = Phase.BoardList;
					break;
				default:
					phase = Phase.Roster;
					break;
				}
				this.phase = phase;
			}
		}
		if (this.phase == Phase.Scan)
		{
			if (!scanStarted)
			{
				if (!_003Cworld_003EP.StartNotebook())
				{
					return StepResult.Running;
				}
				scanStarted = true;
				requestAt = elapsed;
			}
			if (elapsed - requestAt > TimeSpan.FromSeconds(35L))
			{
				throw new TimeoutException("斗兽图鉴读取超时");
			}
			if (_003Cworld_003EP.NotebookBusy)
			{
				return StepResult.Running;
			}
			unlocked = _003Cworld_003EP.ReadUnlocked();
			ArenaRosterPolicy.Select(unlocked, Array.Empty<uint>(), _003CpreferredRoster_003EP, stage.RosterCapacity);
			if (!_003Cworld_003EP.CloseNotebook())
			{
				return StepResult.Running;
			}
			this.phase = Phase.CloseScan;
			requestAt = elapsed;
		}
		if (this.phase == Phase.CloseScan)
		{
			Name = "斗兽 · 等待图鉴关闭";
			if (!_003Cworld_003EP.NotebookClosed)
			{
				CheckRequest(elapsed);
				return StepResult.Running;
			}
			this.phase = Phase.Travel;
			phaseAt = elapsed;
		}
		if (this.phase == Phase.Travel)
		{
			Name = "斗兽 · 前往黑衣森林中央林区的劳妲（22.0, 22.8）";
			if (_003Ctravel_003EP.Tick(elapsed - phaseAt) != StepResult.Completed)
			{
				return StepResult.Running;
			}
			_003Ctravel_003EP.Cancel();
			this.phase = Phase.Approach;
			phaseAt = elapsed;
		}
		if (this.phase == Phase.Approach)
		{
			Name = "斗兽 · 接近劳妲";
			if (!_003Cworld_003EP.ApproachNpc(elapsed - phaseAt))
			{
				return StepResult.Running;
			}
			this.phase = Phase.Menu;
			requestAt = elapsed;
		}
		ArenaEntryView arenaEntryView2 = _003Cworld_003EP.Read();
		if (arenaEntryView2.Phase == ArenaEntryPhase.Blocked)
		{
			throw new InvalidOperationException("斗兽出现未识别的交互窗口，任务已停止");
		}
		if (this.phase == Phase.Entering)
		{
			if (arenaEntryView2.Phase == ArenaEntryPhase.Board)
			{
				Name = "斗兽 · 已进入" + stage.Name;
				return StepResult.Completed;
			}
			if (elapsed - requestAt > TimeSpan.FromSeconds(90L))
			{
				throw new TimeoutException("斗兽入场未完成");
			}
			if (arenaEntryView2.Phase == ArenaEntryPhase.EntryConfirmation)
			{
				ValidateEntryConfirmation(arenaEntryView2);
				Name = "斗兽 · 确认入场警告";
				if (!entryConfirmed && elapsed >= nextUiAttempt)
				{
					nextUiAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
					if (_003Cworld_003EP.TryConfirmEntry())
					{
						entryConfirmed = true;
						requestAt = elapsed;
					}
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase == ArenaEntryPhase.Loading)
			{
				Name = "斗兽 · 等待入场";
				return StepResult.Running;
			}
			Name = "斗兽 · 等待出发确认";
			if (elapsed >= nextUiAttempt)
			{
				nextUiAttempt = elapsed + TimeSpan.FromMilliseconds(500L);
				if (_003Cworld_003EP.TryCommenceEntry())
				{
					Name = "斗兽 · 已确认出发";
					requestAt = elapsed;
				}
			}
			return StepResult.Running;
		}
		if (this.phase == Phase.Menu)
		{
			Name = "斗兽 · 与劳妲交谈";
			if (!interacted)
			{
				if (_003Cworld_003EP.Interact())
				{
					interacted = true;
					requestAt = elapsed;
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase == ArenaEntryPhase.NpcMenu)
			{
				Name = (choseActivity ? "斗兽 · 等待挑战菜单" : "斗兽 · 选择斗兽奇弈");
				if (!choseActivity && TryUi(_003Cworld_003EP.TryChooseActivity, elapsed))
				{
					choseActivity = true;
					requestAt = elapsed;
				}
				else if (choseActivity)
				{
					CheckRequest(elapsed);
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase == ArenaEntryPhase.Menu && !choseChallenge)
			{
				Name = "斗兽 · 等待挑战选项就绪";
				if (TryUi(_003Cworld_003EP.TryChooseChallenge, elapsed))
				{
					choseChallenge = true;
					requestAt = elapsed;
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase != ArenaEntryPhase.StageList)
			{
				CheckRequest(elapsed);
				return StepResult.Running;
			}
			this.phase = Phase.BoardList;
			requestAt = elapsed;
		}
		if (this.phase == Phase.BoardList)
		{
			Name = "斗兽 · 选择" + stage.Name;
			if (arenaEntryView2.Phase == ArenaEntryPhase.StageList && !choseBoard)
			{
				Name = "斗兽 · 等待" + stage.Name + "列表就绪";
				if (TryUi(_003Cworld_003EP.TryChooseBoard, elapsed))
				{
					choseBoard = true;
					requestAt = elapsed;
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase != ArenaEntryPhase.Party)
			{
				CheckRequest(elapsed);
				return StepResult.Running;
			}
			this.phase = Phase.Roster;
			requestAt = elapsed;
		}
		if (this.phase == Phase.Roster)
		{
			ArenaEntryPhase arenaEntryPhase = arenaEntryView2.Phase;
			if ((uint)(arenaEntryPhase - 3) > 1u)
			{
				CheckRequest(elapsed);
				return StepResult.Running;
			}
			int? stageId = arenaEntryView2.StageId;
			if (stageId.HasValue)
			{
				int valueOrDefault = stageId.GetValueOrDefault();
				if (valueOrDefault != stage.Id)
				{
					throw new InvalidOperationException("当前编组属于" + ArenaStage.Get(valueOrDefault).Name + "，请返回奇盘列表后启动" + stage.Name);
				}
			}
			if (closingEditor)
			{
				if (arenaEntryView2.Phase == ArenaEntryPhase.RosterEditor)
				{
					CheckRequest(elapsed);
					return StepResult.Running;
				}
				closingEditor = false;
				editorRequested = false;
			}
			if (desired == null && preserveRoster && arenaEntryView2.Roster.Length == 0)
			{
				uint[] array = _003CpreferredRoster_003EP;
				if (array == null || array.Length <= 0)
				{
					throw new InvalidOperationException("当前编组为空，请先添加魔兽");
				}
			}
			object obj;
			if (!preserveRoster)
			{
				obj = unlocked;
			}
			else
			{
				uint[] array = _003CpreferredRoster_003EP;
				obj = ((array != null && array.Length > 0) ? ((object)_003CpreferredRoster_003EP) : ((object)arenaEntryView2.Roster));
			}
			uint[] array2 = (uint[])obj;
			if (desired == null)
			{
				desired = ArenaRosterPolicy.Select(array2, arenaEntryView2.Roster, _003CpreferredRoster_003EP, stage.RosterCapacity);
			}
			if (!rosterCleared)
			{
				uint[] array = _003CpreferredRoster_003EP;
				if (array != null && array.Length > 0 && ((ReadOnlySpan<uint>)arenaEntryView2.Roster).SequenceEqual((ReadOnlySpan<uint>)desired))
				{
					rosterCleared = true;
					requestAt = elapsed;
					Name = "斗兽 · 编组与设定一致，跳过重编";
				}
				else
				{
					if (arenaEntryView2.Phase == ArenaEntryPhase.RosterEditor)
					{
						CloseEditor(elapsed);
						return StepResult.Running;
					}
					if (arenaEntryView2.Roster.Length != 0)
					{
						Name = (clearSent ? "斗兽 · 等待队伍清空" : "斗兽 · 清空整个队伍");
						if (!clearSent && TryUi(_003Cworld_003EP.TryClearRoster, elapsed))
						{
							clearSent = true;
							requestAt = elapsed;
						}
						else if (clearSent)
						{
							CheckRequest(elapsed);
						}
						return StepResult.Running;
					}
					rosterCleared = true;
					requestAt = elapsed;
				}
			}
			uint? num = pendingPet;
			if (num.HasValue)
			{
				uint valueOrDefault2 = num.GetValueOrDefault();
				if (!((ReadOnlySpan<uint>)arenaEntryView2.Roster).Contains(valueOrDefault2))
				{
					CheckRequest(elapsed);
					return StepResult.Running;
				}
				pendingPet = null;
			}
			if (!arenaEntryView2.Roster.SequenceEqual(desired.Take(arenaEntryView2.Roster.Length)))
			{
				throw new InvalidOperationException("入场编组顺序与设定不一致，已停止");
			}
			Name = $"斗兽 · 编组 {arenaEntryView2.Roster.Length}/{desired.Length}";
			uint add = desired.Skip(arenaEntryView2.Roster.Length).FirstOrDefault();
			if (add != 0)
			{
				if (arenaEntryView2.Phase != ArenaEntryPhase.RosterEditor)
				{
					Name = "斗兽 · 等待编组图鉴打开";
					if (!editorRequested && TryUi(_003Cworld_003EP.TryOpenRoster, elapsed))
					{
						editorRequested = true;
						requestAt = elapsed;
					}
					else
					{
						CheckRequest(elapsed);
					}
					return StepResult.Running;
				}
				Name = $"斗兽 · 等待编组图鉴就绪（{arenaEntryView2.Roster.Length + 1}/{desired.Length}）";
				if (TryUi(() => _003Cworld_003EP.AddPet(add, elapsed), elapsed))
				{
					pendingPet = add;
					requestAt = elapsed;
				}
				return StepResult.Running;
			}
			if (arenaEntryView2.Phase == ArenaEntryPhase.RosterEditor)
			{
				CloseEditor(elapsed);
				return StepResult.Running;
			}
			if (!entrySent && _003Cworld_003EP.Enter())
			{
				entrySent = true;
				this.phase = Phase.Entering;
				requestAt = elapsed;
			}
		}
		return StepResult.Running;
	}

	private void CheckRequest(TimeSpan elapsed)
	{
		if (elapsed - requestAt > TimeSpan.FromSeconds(10L))
		{
			throw new TimeoutException(Name + "，操作结果未确认");
		}
	}

	private void ValidateEntryConfirmation(ArenaEntryView view)
	{
		if (view.StageId != stage.Id || view.Roster.Length < 1 || view.Roster.Length > stage.RosterCapacity || desired == null || !((ReadOnlySpan<uint>)view.Roster).SequenceEqual((ReadOnlySpan<uint>)desired))
		{
			throw new InvalidOperationException("入场确认的奇盘或编组与设定不一致，请返回编组窗口");
		}
	}

	private bool TryUi(Func<bool> action, TimeSpan elapsed)
	{
		CheckRequest(elapsed);
		if (elapsed < nextUiAttempt)
		{
			return false;
		}
		nextUiAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		return action();
	}

	private void CloseEditor(TimeSpan elapsed)
	{
		if (_003Cworld_003EP.CloseNotebook())
		{
			closingEditor = true;
			requestAt = elapsed;
		}
	}

	public void Cancel()
	{
		try
		{
			_003Ctravel_003EP.Cancel();
		}
		finally
		{
			_003Cworld_003EP.Cancel();
		}
		if (phase == Phase.Scan)
		{
			scanStarted = false;
		}
		editorRequested = false;
	}
}
