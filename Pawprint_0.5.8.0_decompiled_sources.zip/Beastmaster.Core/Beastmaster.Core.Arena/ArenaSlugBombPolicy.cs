using System;

namespace Beastmaster.Core.Arena;

public static class ArenaSlugBombPolicy
{
	public const uint SlugNameId = 14619u;

	public static readonly TimeSpan Fuse = TimeSpan.FromSeconds(5L);

	public static bool Applies(int stage, int? node)
	{
		if (stage == 4)
		{
			return node == 11;
		}
		return false;
	}

	public static bool IsAttackItem(uint itemId)
	{
		switch (itemId)
		{
		case 128u:
		case 129u:
		case 130u:
		case 131u:
		case 132u:
		case 133u:
		case 134u:
		case 139u:
			return true;
		default:
			return false;
		}
	}
}
