using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using Beastmaster.Core.Hunting;
using Beastmaster.Core.Models;

namespace Beastmaster.Core.Arena;

public sealed class ArenaBattleRuleEngine
{
	private readonly record struct RuleMatch(ulong? Instance);

	private sealed class Runtime(ArenaBattleRule rule)
	{
		public readonly ArenaBattleRule Rule = rule;

		public bool Firing;

		public bool Fired;

		public TimeSpan FiredAt;

		public TimeSpan? ConditionSince;

		public TimeSpan? RetryAfter;

		public TimeSpan NextAttempt;

		public TimeSpan ItemAt;

		public int ObserveGen = -1;

		public int Denials;

		public int ConsumedCount;

		public int BeforeCount;

		public int Attempts;

		public ArenaHealItem? Selected;

		public HashSet<ulong> InstancesFired = new HashSet<ulong>();

		public Dictionary<ulong, TimeSpan> SeenAt = new Dictionary<ulong, TimeSpan>();

		public HashSet<(int Slot, uint ItemId)> Exhausted = new HashSet<(int, uint)>();

		public RuleMatch Match;

		public long DutySeqBaseline;
	}

	private readonly IArenaRuleWorld world;

	private readonly IArenaRuleItems? items;

	private readonly ArenaResourcePolicy? resources;

	private readonly Action<string>? trace;

	private IReadOnlyList<ArenaBattleRule> rules = Array.Empty<ArenaBattleRule>();

	private IReadOnlyList<ArenaBattleRule> lastReset = Array.Empty<ArenaBattleRule>();

	private readonly List<Runtime> runtimes = new List<Runtime>();

	private (ulong ObjectId, uint BaseId)[] lastPets = Array.Empty<(ulong, uint)>();

	private int summonGeneration;

	private TimeSpan? noticeUntil;

	public bool HasRules { get; private set; }

	public IReadOnlyList<uint> PriorityEnemyIds { get; private set; } = Array.Empty<uint>();

	public bool HasCustomTargetRule => PriorityEnemyIds.Count > 0;

	public bool RearEnabled { get; private set; }

	public string Notice { get; private set; } = "";

	public bool ItemsBusy => runtimes.Any((Runtime r) => r.Firing && r.rule.Action.Kind == ArenaRuleActionKind.UseItems);

	public string Name { get; private set; } = "";

	public ArenaBattleRuleEngine(IArenaRuleWorld world, IArenaRuleItems? items = null, ArenaResourcePolicy? resources = null, Action<string>? trace = null)
	{
		this.world = world;
		this.items = items;
		this.resources = resources;
		this.trace = trace;
	}

	public void Restart()
	{
		Reset(lastReset);
	}

	public void Reset(IReadOnlyList<ArenaBattleRule> battleRules)
	{
		lastReset = battleRules;
		rules = battleRules.Where(delegate(ArenaBattleRule r)
		{
			bool flag = r?.Enabled ?? false;
			if (flag)
			{
				ArenaRuleActionKind kind = r.Action.Kind;
				bool flag2 = ((kind == ArenaRuleActionKind.SetTargetPriority || kind == ArenaRuleActionKind.MoveBehind) ? true : false);
				flag = !flag2;
			}
			return flag;
		}).ToArray();
		ArenaBattleRule[] source = battleRules.Where(delegate(ArenaBattleRule r)
		{
			bool flag = r.Enabled;
			if (flag)
			{
				ArenaRuleActionKind kind = r.Action.Kind;
				bool flag2 = ((kind == ArenaRuleActionKind.SetTargetPriority || kind == ArenaRuleActionKind.MoveBehind) ? true : false);
				flag = flag2;
			}
			return flag;
		}).ToArray();
		HasRules = battleRules.Any((ArenaBattleRule r) => r.Enabled);
		runtimes.Clear();
		foreach (ArenaBattleRule rule in rules)
		{
			runtimes.Add(new Runtime(rule));
		}
		PriorityEnemyIds = source.Where((ArenaBattleRule r) => r.Action.Kind == ArenaRuleActionKind.SetTargetPriority).SelectMany((ArenaBattleRule r) => r.Action.PriorityEnemyIds).Distinct()
			.ToArray();
		RearEnabled = source.Any((ArenaBattleRule r) => r.Action.Kind == ArenaRuleActionKind.MoveBehind);
		lastPets = Array.Empty<(ulong, uint)>();
		summonGeneration = 0;
		Name = "";
		Notice = "";
		noticeUntil = null;
	}

	private void Flash(string text, TimeSpan elapsed)
	{
		Notice = text;
		noticeUntil = elapsed + TimeSpan.FromSeconds(5L);
	}

	public CombatTarget? ChoosePriorityTarget(ulong? preferred)
	{
		CombatTarget[] source = SafeEnemies().Where(Alive).ToArray();
		foreach (uint id in PriorityEnemyIds)
		{
			CombatTarget combatTarget = (from e in source
				where e.NameId == id
				orderby e.ObjectId == preferred descending, e.ObjectId
				select e).FirstOrDefault();
			if (combatTarget != null)
			{
				return combatTarget;
			}
		}
		WorldPoint pos = SafePosition();
		if (!(pos == null))
		{
			return source.OrderBy((CombatTarget e) => Vector3.DistanceSquared(pos.Position, e.Location.Position)).FirstOrDefault();
		}
		return null;
	}

	public void Tick(TimeSpan elapsed)
	{
		Name = "";
		TimeSpan? timeSpan = noticeUntil;
		if (timeSpan.HasValue)
		{
			TimeSpan valueOrDefault = timeSpan.GetValueOrDefault();
			if (elapsed >= valueOrDefault)
			{
				Notice = "";
				noticeUntil = null;
			}
		}
		if (rules.Count == 0)
		{
			return;
		}
		(ulong, uint)[] array = SafePets();
		if (!((ReadOnlySpan<(ulong, uint)>)array).SequenceEqual((ReadOnlySpan<(ulong, uint)>)lastPets))
		{
			summonGeneration++;
			lastPets = array;
		}
		foreach (Runtime runtime4 in runtimes)
		{
			ArenaBattleRule rule = runtime4.rule;
			Runtime runtime = runtimes.FirstOrDefault((Runtime r) => r.Firing && r.rule.Action.Kind == ArenaRuleActionKind.UseItems);
			if (rule.Action.Kind == ArenaRuleActionKind.UseItems && runtime != null)
			{
				Runtime runtime2 = runtime;
				if (runtime2 != runtime4)
				{
					continue;
				}
			}
			if (runtime4.Firing)
			{
				TickFiring(runtime4, elapsed);
			}
			else
			{
				if (rule.Limit.WindowSeconds > 0 && elapsed.TotalSeconds >= (double)rule.Limit.WindowSeconds)
				{
					continue;
				}
				timeSpan = runtime4.RetryAfter;
				if (timeSpan.HasValue)
				{
					TimeSpan valueOrDefault2 = timeSpan.GetValueOrDefault();
					if (elapsed < valueOrDefault2)
					{
						continue;
					}
				}
				runtime4.RetryAfter = null;
				switch (rule.Limit.Once)
				{
				case ArenaRuleOnce.PerBattle:
					if (runtime4.Fired)
					{
						continue;
					}
					break;
				case ArenaRuleOnce.PerPetSummon:
					if (runtime4.ObserveGen == summonGeneration)
					{
						continue;
					}
					break;
				case ArenaRuleOnce.None:
					if (runtime4.Fired && elapsed - runtime4.FiredAt < TimeSpan.FromSeconds(Math.Max(1, rule.Limit.CooldownSeconds)))
					{
						continue;
					}
					break;
				}
				if (!EvaluateTrigger(runtime4, elapsed, array, out var match))
				{
					runtime4.ConditionSince = null;
					continue;
				}
				Runtime runtime3 = runtime4;
				TimeSpan valueOrDefault3 = runtime3.ConditionSince.GetValueOrDefault();
				if (!runtime3.ConditionSince.HasValue)
				{
					valueOrDefault3 = elapsed;
					runtime3.ConditionSince = valueOrDefault3;
				}
				TimeSpan timeSpan2 = TimeSpan.FromSeconds(Math.Max(0, rule.Limit.DebounceSeconds));
				if (elapsed - runtime4.ConditionSince.Value < timeSpan2)
				{
					continue;
				}
				if (rule.Limit.Once == ArenaRuleOnce.PerTargetInstance)
				{
					ulong? instance = match.Instance;
					if (instance.HasValue)
					{
						ulong valueOrDefault4 = instance.GetValueOrDefault();
						if (runtime4.InstancesFired.Contains(valueOrDefault4))
						{
							continue;
						}
					}
				}
				runtime4.Firing = true;
				runtime4.FiredAt = elapsed;
				runtime4.Match = match;
				runtime4.ConditionSince = null;
				runtime4.NextAttempt = elapsed;
				runtime4.Selected = null;
				runtime4.Exhausted.Clear();
				runtime4.ConsumedCount = 0;
				runtime4.RetryAfter = null;
				if (rule.Action.Kind == ArenaRuleActionKind.UseDutyAction)
				{
					try
					{
						runtime4.DutySeqBaseline = world.DutyConfirmSequence(rule.Action.DutyActionSlot);
					}
					catch (Exception)
					{
						runtime4.DutySeqBaseline = 0L;
					}
				}
				trace?.Invoke($"rule {rule.Id} ({ArenaRuleSummary.Describe(rule)}): fired");
				TickFiring(runtime4, elapsed);
			}
		}
	}

	public void Cancel()
	{
		foreach (Runtime runtime in runtimes)
		{
			runtime.Firing = false;
			runtime.Selected = null;
		}
		Name = "";
	}

	private void TickFiring(Runtime rt, TimeSpan elapsed)
	{
		ArenaBattleRule rule = rt.rule;
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(1, rule.Limit.RetrySeconds));
		switch (rule.Action.Kind)
		{
		case ArenaRuleActionKind.Countdown:
			if (world.TryCountdown(rule.Action.CountdownSeconds))
			{
				Complete(rt, elapsed);
				break;
			}
			if (elapsed - rt.FiredAt >= timeSpan)
			{
				Fail(rt, elapsed, "countdown rejected");
				break;
			}
			Name = $"本场战斗 · 倒计时 {rule.Action.CountdownSeconds} 秒";
			break;
		case ArenaRuleActionKind.CallPrcFinisher:
			if (world.TryPrcFinisher())
			{
				Complete(rt, elapsed);
			}
			else if (elapsed - rt.FiredAt >= timeSpan)
			{
				Fail(rt, elapsed, "PR finisher rejected");
			}
			else
			{
				Name = "本场战斗 · PR 最后一击";
			}
			break;
		case ArenaRuleActionKind.UseDutyAction:
			TickDuty(rt, elapsed, timeSpan);
			break;
		case ArenaRuleActionKind.UseItems:
			TickItems(rt, elapsed);
			break;
		default:
			Complete(rt, elapsed);
			break;
		}
	}

	private void TickDuty(Runtime rt, TimeSpan elapsed, TimeSpan window)
	{
		ArenaBattleRule rule = rt.rule;
		ulong targetId = ResolveTarget(rt);
		if (targetId == 0L)
		{
			Requeue(rt, elapsed, window, "no target");
			return;
		}
		if (world.DutyConfirmations(rule.Action.DutyActionSlot).Any(((ulong TargetId, long Seq) c) => c.TargetId == targetId && c.Seq > rt.DutySeqBaseline))
		{
			Complete(rt, elapsed);
			return;
		}
		if (elapsed - rt.FiredAt >= window)
		{
			Requeue(rt, elapsed, window, "duty action not confirmed");
			return;
		}
		if (elapsed >= rt.NextAttempt)
		{
			rt.NextAttempt = elapsed + TimeSpan.FromMilliseconds(250L);
			world.TryUseDutyAction(rule.Action.DutyActionSlot, targetId);
		}
		Name = "本场战斗 · " + DisplayName(rule);
	}

	private void Requeue(Runtime rt, TimeSpan elapsed, TimeSpan window, string reason)
	{
		trace?.Invoke($"rule {rt.rule.Id}: {reason}, requeue after {window.TotalSeconds:0.#}s");
		rt.Firing = false;
		rt.Selected = null;
		rt.RetryAfter = elapsed + window;
		Name = $"本场战斗 · {DisplayName(rt.rule)}（{Math.Ceiling(window.TotalSeconds)} 秒后重试）";
	}

	private void TickItems(Runtime rt, TimeSpan elapsed)
	{
		ArenaBattleRule rule = rt.rule;
		if (items == null)
		{
			Fail(rt, elapsed, "item dispatch unavailable");
			return;
		}
		ArenaHealView arenaHealView;
		try
		{
			arenaHealView = items.ReadHud();
		}
		catch (Exception ex) when (((ex is InvalidOperationException || ex is TimeoutException) ? 1 : 0) != 0)
		{
			Fail(rt, elapsed, "hud lost");
			return;
		}
		if (arenaHealView.Phase == ArenaHealPhase.Ended)
		{
			Complete(rt, elapsed);
			return;
		}
		ArenaHealPhase phase = arenaHealView.Phase;
		if ((phase == ArenaHealPhase.Loading || phase == ArenaHealPhase.Blocked) ? true : false)
		{
			Name = "本场战斗 · 等待道具栏";
			return;
		}
		TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(1, rule.Limit.RetrySeconds));
		int num = Math.Max(1, rule.Limit.MaxAttemptsPerItem);
		ArenaHealItem selected;
		while (true)
		{
			if (rt.Selected == null)
			{
				if (arenaHealView.Phase != ArenaHealPhase.Board)
				{
					return;
				}
				if (elapsed - rt.FiredAt >= TimeSpan.FromSeconds(90L))
				{
					trace?.Invoke("rule " + rule.Id + ": overall item timeout");
					Complete(rt, elapsed);
					return;
				}
				if (rule.Action.ItemLimit > 0 && rt.ConsumedCount >= rule.Action.ItemLimit)
				{
					Complete(rt, elapsed);
					return;
				}
				ArenaHealItem pick = null;
				foreach (ArenaHealItem item in arenaHealView.Items.OrderBy((ArenaHealItem i) => i.Slot))
				{
					if (item.Usable && Matches(item.ItemId) && !rt.Exhausted.Contains((item.Slot, item.ItemId)))
					{
						ArenaResourcePolicy? arenaResourcePolicy = resources;
						if (arenaResourcePolicy == null || arenaResourcePolicy.CanUse(item.ItemId, arenaHealView.Items.Length))
						{
							pick = item;
							break;
						}
					}
				}
				if (pick == null)
				{
					Flash("本场战斗 · " + DisplayName(rule) + "：没有匹配的道具", elapsed);
					trace?.Invoke("rule " + rule.Id + ": no matching items");
					Complete(rt, elapsed);
					return;
				}
				rt.Selected = pick;
				rt.BeforeCount = arenaHealView.Items.Count((ArenaHealItem i) => i.ItemId == pick.ItemId);
				rt.ItemAt = elapsed;
				rt.Attempts = 0;
				rt.NextAttempt = elapsed;
				rt.Denials = 0;
				trace?.Invoke($"rule {rule.Id}: picked slot {pick.Slot} item {pick.ItemId}, count={rt.BeforeCount}");
			}
			selected = rt.Selected;
			if (selected == null)
			{
				return;
			}
			if (arenaHealView.Items.Count((ArenaHealItem i) => i.ItemId == selected.ItemId) < rt.BeforeCount)
			{
				trace?.Invoke($"rule {rule.Id}: item {selected.ItemId} consumed");
				rt.ConsumedCount++;
				Advance(rt);
				continue;
			}
			if (elapsed - rt.ItemAt >= timeSpan)
			{
				trace?.Invoke($"rule {rule.Id}: item {selected.ItemId} not consumed in {timeSpan.TotalSeconds}s, skip");
				Advance(rt);
				continue;
			}
			if (arenaHealView.Phase != ArenaHealPhase.Board || !(elapsed >= rt.NextAttempt) || rt.Attempts >= num * 3)
			{
				break;
			}
			rt.NextAttempt = elapsed + TimeSpan.FromMilliseconds(600L);
			ulong num2 = ResolveTarget(rt);
			if (num2 == 0L)
			{
				Name = "本场战斗 · 使用" + ArenaItemCatalog.Items[selected.ItemId].Name;
				return;
			}
			if (items.TryUseItem(selected.Slot, selected.ItemId, num2))
			{
				rt.Attempts++;
				rt.Denials = 0;
				break;
			}
			string? lastDeny = items.LastDeny;
			if (lastDeny == null || !lastDeny.Contains("no valid target"))
			{
				break;
			}
			rt.Denials++;
			if (rt.Denials < 3)
			{
				break;
			}
			trace?.Invoke($"rule {rule.Id}: item {selected.ItemId} invalid on target {num2:X}, try next");
			Advance(rt);
		}
		if (rt.Firing && rt.Selected != null)
		{
			Name = "本场战斗 · 使用" + ArenaItemCatalog.Items[selected.ItemId].Name;
		}
		bool Matches(uint itemId)
		{
			return ArenaRuleItemFilters.Match(rule.Action.ItemFilter, rule.Action.ItemIds, itemId);
		}
	}

	private void Advance(Runtime rt)
	{
		ArenaHealItem selected = rt.Selected;
		if ((object)selected != null)
		{
			rt.Exhausted.Add((selected.Slot, selected.ItemId));
		}
		rt.Selected = null;
		if (rt.rule.Action.ItemLimit > 0 && rt.ConsumedCount >= rt.rule.Action.ItemLimit)
		{
			Complete(rt, rt.FiredAt);
		}
	}

	private void Complete(Runtime rt, TimeSpan elapsed)
	{
		rt.Firing = false;
		rt.Selected = null;
		rt.Fired = true;
		rt.FiredAt = elapsed;
		if (rt.rule.Limit.Once == ArenaRuleOnce.PerTargetInstance)
		{
			ulong? instance = rt.Match.Instance;
			if (instance.HasValue)
			{
				ulong valueOrDefault = instance.GetValueOrDefault();
				rt.InstancesFired.Add(valueOrDefault);
			}
		}
		if (rt.rule.Limit.Once == ArenaRuleOnce.PerPetSummon)
		{
			rt.ObserveGen = summonGeneration;
		}
	}

	private void Fail(Runtime rt, TimeSpan elapsed, string reason)
	{
		trace?.Invoke($"rule {rt.rule.Id}: {reason}, skip");
		Complete(rt, elapsed);
	}

	private ulong ResolveTarget(Runtime rt)
	{
		ArenaRuleTarget a = rt.rule.Target;
		return a.Kind switch
		{
			ArenaRuleTargetKind.Self => SafePlayer().ObjectId, 
			ArenaRuleTargetKind.CurrentTarget => world.CurrentTarget()?.ObjectId ?? NearestEnemyId().GetValueOrDefault(), 
			ArenaRuleTargetKind.TriggeredEnemy => rt.Match.Instance.GetValueOrDefault(), 
			ArenaRuleTargetKind.Enemy => SafeEnemies().FirstOrDefault((CombatTarget e) => Alive(e) && e.NameId == a.EnemyNameId)?.ObjectId ?? 0, 
			_ => 0uL, 
		};
	}

	private ulong? NearestEnemyId()
	{
		WorldPoint pos = SafePosition();
		if (!(pos == null))
		{
			return (from e in SafeEnemies().Where(Alive)
				orderby Vector3.DistanceSquared(pos.Position, e.Location.Position)
				select e).FirstOrDefault()?.ObjectId;
		}
		return null;
	}

	private bool EvaluateTrigger(Runtime rt, TimeSpan elapsed, (ulong ObjectId, uint BaseId)[] pets, out RuleMatch match)
	{
		match = default(RuleMatch);
		ArenaRuleTrigger t = rt.rule.Trigger;
		switch (t.Kind)
		{
		case ArenaRuleTriggerKind.Always:
			return true;
		case ArenaRuleTriggerKind.BattleElapsed:
			return elapsed.TotalSeconds >= (double)Math.Max(0, t.Seconds);
		case ArenaRuleTriggerKind.EnemyHpBelow:
		{
			CombatTarget[] source = SafeEnemies().Where(Alive).ToArray();
			CombatTarget combatTarget = ((t.EnemyNameId != 0) ? source.FirstOrDefault((CombatTarget e) => e.NameId == t.EnemyNameId) : source.OrderByDescending((CombatTarget e) => e.MaxHp).FirstOrDefault());
			if (combatTarget == null || combatTarget.MaxHp == 0)
			{
				return false;
			}
			uint num2 = (uint)Math.Clamp(t.Percent, 1, 99);
			if ((ulong)((long)combatTarget.Hp * 100L) >= (ulong)((long)combatTarget.MaxHp * (long)num2))
			{
				return false;
			}
			match = new RuleMatch(combatTarget.ObjectId);
			return true;
		}
		case ArenaRuleTriggerKind.EnemyAliveFor:
		{
			ulong[] alive = (from e in SafeEnemies()
				where Alive(e) && e.NameId == t.EnemyNameId
				select e.ObjectId).ToArray();
			ulong[] array = alive;
			foreach (ulong key in array)
			{
				rt.SeenAt.TryAdd(key, elapsed);
			}
			array = rt.SeenAt.Keys.Where((ulong id) => !((ReadOnlySpan<ulong>)alive).Contains(id)).ToArray();
			foreach (ulong key2 in array)
			{
				rt.SeenAt.Remove(key2);
			}
			TimeSpan timeSpan = TimeSpan.FromSeconds(Math.Max(0, t.Seconds));
			array = alive;
			foreach (ulong num4 in array)
			{
				if (elapsed - rt.SeenAt[num4] >= timeSpan && !rt.InstancesFired.Contains(num4))
				{
					match = new RuleMatch(num4);
					return true;
				}
			}
			return false;
		}
		case ArenaRuleTriggerKind.EnemyCount:
		{
			int num5 = Math.Max(1, t.Count);
			return SafeEnemies().Count((CombatTarget e) => Alive(e) && (t.EnemyNameId == 0 || e.NameId == t.EnemyNameId)) >= num5;
		}
		case ArenaRuleTriggerKind.TargetIs:
		{
			CombatTarget combatTarget2 = world.CurrentTarget();
			if (combatTarget2 == null || !Alive(combatTarget2) || combatTarget2.NameId != t.EnemyNameId)
			{
				return false;
			}
			match = new RuleMatch(combatTarget2.ObjectId);
			return true;
		}
		case ArenaRuleTriggerKind.PetSummoned:
			if (summonGeneration != rt.ObserveGen)
			{
				return pets.Length != 0;
			}
			return false;
		case ArenaRuleTriggerKind.PlayerHpBelow:
		{
			(ulong, uint, uint) tuple = SafePlayer();
			if (tuple.Item3 == 0)
			{
				return false;
			}
			uint num = (uint)Math.Clamp(t.Percent, 1, 99);
			return (ulong)((long)tuple.Item2 * 100L) < (ulong)((long)tuple.Item3 * (long)num);
		}
		default:
			return false;
		}
	}

	private static bool Alive(CombatTarget e)
	{
		if ((object)e != null && !e.IsDead && e.Hp != 0 && e.IsTargetable)
		{
			return e.IsAttackable;
		}
		return false;
	}

	private static string DisplayName(ArenaBattleRule rule)
	{
		if (string.IsNullOrWhiteSpace(rule.Name))
		{
			return ArenaRuleSummary.Describe(rule);
		}
		return rule.Name;
	}

	private IReadOnlyList<CombatTarget> SafeEnemies()
	{
		try
		{
			return world.AliveEnemies();
		}
		catch (Exception)
		{
			return Array.Empty<CombatTarget>();
		}
	}

	private (ulong ObjectId, uint BaseId)[] SafePets()
	{
		try
		{
			return world.SummonedPets();
		}
		catch (Exception)
		{
			return Array.Empty<(ulong, uint)>();
		}
	}

	private (ulong ObjectId, uint CurrentHp, uint MaxHp) SafePlayer()
	{
		try
		{
			return world.PlayerState();
		}
		catch (Exception)
		{
			return (ObjectId: 0uL, CurrentHp: 0u, MaxHp: 0u);
		}
	}

	private WorldPoint? SafePosition()
	{
		try
		{
			return world.PlayerPosition();
		}
		catch (Exception)
		{
			return null;
		}
	}
}
