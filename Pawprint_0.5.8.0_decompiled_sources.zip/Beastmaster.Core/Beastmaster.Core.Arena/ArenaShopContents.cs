namespace Beastmaster.Core.Arena;

public sealed record ArenaShopContents(uint Balance, ArenaShopOffer[] Offers, uint[] Owned, int EquipmentCount, int BagCount);
