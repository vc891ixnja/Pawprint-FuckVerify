using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

public static class ArenaPresetShare
{
	public const string Prefix = "Pawprint:2:";

	private const string LegacyPrefix = "Pawprint:1:";

	public const int MaxCodeLength = 65536;

	private const int MaxJsonBytes = 131072;

	private static readonly JsonSerializerOptions Options = new JsonSerializerOptions
	{
		UnmappedMemberHandling = JsonUnmappedMemberHandling.Disallow,
		DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingDefault
	};

	private static readonly string[] KeepEmptyArrays = new string[2] { "Priority", "ItemPriority" };

	private static readonly string[] CollapseEmptyObjects = new string[9] { "BattleRewards", "TreasureRewards", "Purchases", "Rewards", "Shop", "Trigger", "Target", "Action", "Limit" };

	public static string Export(ArenaPreset preset)
	{
		Validate(preset, preset.StageId);
		JsonObject jsonObject = JsonSerializer.SerializeToNode(preset, Options).AsObject();
		jsonObject.Remove("Id");
		jsonObject["StageId"] = preset.StageId;
		Compact(jsonObject);
		byte[] array = JsonSerializer.SerializeToUtf8Bytes(jsonObject, Options);
		if (array.Length > 131072)
		{
			throw new FormatException("预设内容过长");
		}
		using MemoryStream memoryStream = new MemoryStream();
		using (BrotliStream brotliStream = new BrotliStream(memoryStream, CompressionLevel.SmallestSize, leaveOpen: true))
		{
			brotliStream.Write(array);
		}
		byte[] array2 = memoryStream.ToArray();
		Span<byte> span = SHA256.HashData(array2).AsSpan(0, 16);
		byte[] array3 = array2;
		int num = 0;
		byte[] array4 = new byte[span.Length + array3.Length];
		span.CopyTo(new Span<byte>(array4).Slice(num, span.Length));
		num += span.Length;
		ReadOnlySpan<byte> readOnlySpan = new ReadOnlySpan<byte>(array3);
		readOnlySpan.CopyTo(new Span<byte>(array4).Slice(num, readOnlySpan.Length));
		num += readOnlySpan.Length;
		string text = "Pawprint:2:" + Convert.ToBase64String(new ReadOnlySpan<byte>(array4));
		if (text.Length > 65536)
		{
			throw new FormatException("预设字符串过长");
		}
		return text;
	}

	private static void Compact(JsonObject obj)
	{
		KeyValuePair<string, JsonNode>[] array = obj.ToArray();
		foreach (KeyValuePair<string, JsonNode> keyValuePair in array)
		{
			keyValuePair.Deconstruct(out var key, out var value);
			string text = key;
			value = value;
			if (!(value is JsonObject jsonObject))
			{
				if (!(value is JsonArray jsonArray))
				{
					if (value is JsonValue jsonValue)
					{
						JsonValue jsonValue2 = jsonValue;
						if (text == "Name" && jsonValue2.TryGetValue<string>(out string value2) && value2.Length == 0)
						{
							obj.Remove(text);
						}
					}
					continue;
				}
				JsonArray jsonArray2 = jsonArray;
				foreach (JsonNode item in jsonArray2)
				{
					if (item is JsonObject obj2)
					{
						Compact(obj2);
					}
				}
				if (jsonArray2.Count == 0 && !((ReadOnlySpan<string>)KeepEmptyArrays).Contains(text))
				{
					obj.Remove(text);
				}
				else if (text == "Categories" && IsDefaultCategories(jsonArray2))
				{
					obj.Remove(text);
				}
			}
			else
			{
				Compact(jsonObject);
				if (jsonObject.Count == 0 && ((ReadOnlySpan<string>)CollapseEmptyObjects).Contains(text))
				{
					obj.Remove(text);
				}
			}
		}
	}

	private static bool IsDefaultCategories(JsonArray array)
	{
		int value;
		if (array.Count == 3)
		{
			return array.Select((JsonNode node, int index) => (node: node, index: index)).All(((JsonNode node, int index) x) => x.node is JsonValue jsonValue && jsonValue.TryGetValue<int>(out value) && value == x.index + 1);
		}
		return false;
	}

	public static ArenaPreset Import(string code, int stage)
	{
		if (string.IsNullOrWhiteSpace(code))
		{
			throw new FormatException("请先粘贴预设字符串");
		}
		if (code.Length > 65536)
		{
			throw new FormatException("预设字符串过长");
		}
		code = string.Concat(code.Where((char c) => !char.IsWhiteSpace(c)));
		bool flag = !code.StartsWith("Pawprint:2:", StringComparison.Ordinal);
		if (flag && !code.StartsWith("Pawprint:1:", StringComparison.Ordinal))
		{
			throw new FormatException(code.StartsWith("Pawprint:", StringComparison.Ordinal) ? "不支持此预设格式版本" : "不是 Pawprint 预设字符串");
		}
		try
		{
			byte[] array;
			try
			{
				string text = code;
				int length = (flag ? "Pawprint:1:" : "Pawprint:2:").Length;
				array = Convert.FromBase64String(text.Substring(length, text.Length - length));
			}
			catch (FormatException)
			{
				throw new FormatException("预设字符串编码无效，请重新复制");
			}
			int num = (flag ? 32 : 16);
			if (array.Length <= num || !CryptographicOperations.FixedTimeEquals(array.AsSpan(0, num), SHA256.HashData(array.AsSpan(num)).AsSpan(0, num)))
			{
				throw new FormatException("预设字符串不完整或已损坏，请重新复制");
			}
			using MemoryStream stream = new MemoryStream(array, num, array.Length - num);
			using MemoryStream memoryStream = new MemoryStream();
			byte[] array2 = new byte[4096];
			if (flag)
			{
				using GZipStream gZipStream = new GZipStream(stream, CompressionMode.Decompress);
				int num2;
				while ((num2 = gZipStream.Read(array2)) > 0)
				{
					if (memoryStream.Length + num2 > 131072)
					{
						throw new FormatException("预设解压后的内容过长");
					}
					memoryStream.Write(array2, 0, num2);
				}
			}
			else
			{
				using BrotliStream brotliStream = new BrotliStream(stream, CompressionMode.Decompress);
				int num2;
				while ((num2 = brotliStream.Read(array2)) > 0)
				{
					if (memoryStream.Length + num2 > 131072)
					{
						throw new FormatException("预设解压后的内容过长");
					}
					memoryStream.Write(array2, 0, num2);
				}
			}
			using JsonDocument jsonDocument = JsonDocument.Parse(memoryStream.ToArray());
			JsonElement value = jsonDocument.RootElement;
			if (value.ValueKind != JsonValueKind.Object || !jsonDocument.RootElement.TryGetProperty("StageId", out value))
			{
				throw new FormatException("预设缺少地图信息");
			}
			ArenaPreset? obj = jsonDocument.Deserialize<ArenaPreset>(Options) ?? throw new FormatException("预设内容为空");
			Validate(obj, stage);
			obj.Id = Guid.NewGuid().ToString("N");
			return obj;
		}
		catch (JsonException)
		{
			throw new FormatException("预设内容不完整或格式不兼容");
		}
		catch (InvalidDataException)
		{
			throw new FormatException("预设压缩内容损坏，请重新复制");
		}
	}

	private static void Validate(ArenaPreset p, int stage)
	{
		ArenaOpeningMode? openingMode = p.OpeningMode;
		if (openingMode.HasValue)
		{
			ArenaOpeningMode valueOrDefault = openingMode.GetValueOrDefault();
			if (!Enum.IsDefined(valueOrDefault))
			{
				throw new FormatException("开怪方式无效");
			}
		}
		if (p.StageId != stage)
		{
			throw new FormatException("预设地图与当前选择不一致");
		}
		if (!ArenaMaps.All.TryGetValue(stage, out ArenaStageMap map))
		{
			throw new FormatException("预设地图无效");
		}
		if (string.IsNullOrWhiteSpace(p.Name) || p.Name.Length > 64 || p.Name.Any(char.IsControl))
		{
			throw new FormatException("预设名称须为 1–64 个字符");
		}
		int rosterCapacity = ArenaStage.Get(stage).RosterCapacity;
		if (p.Roster == null || p.Roster.Count > rosterCapacity || p.Roster.Any((uint id) => (id < 1 || id > 50) ? true : false) || p.Roster.Distinct().Count() != p.Roster.Count)
		{
			throw new FormatException($"本盘入场编组须为最多 {rosterCapacity} 只不重复的魔兽");
		}
		if (!Enum.IsDefined(p.Route) || p.Branches == null || p.Branches.Any((KeyValuePair<int, ArenaRoutePreference> b) => !map.Forks.Any((ArenaMapNode n) => n.Node == b.Key) || !Enum.IsDefined(b.Value)))
		{
			throw new FormatException("分支路线设置无效");
		}
		if (p.BranchTargets == null || p.BranchTargets.Any((KeyValuePair<int, int> b) => !map.Forks.Any((ArenaMapNode n) => n.Node == b.Key && ((ReadOnlySpan<int>)n.Next).Contains(b.Value))))
		{
			throw new FormatException("分支目标不是当前地图的相邻节点");
		}
		int healBelowPercent = p.HealBelowPercent;
		if ((healBelowPercent < 1 || healBelowPercent > 100) ? true : false)
		{
			throw new FormatException("回血阈值须为 1–100");
		}
		healBelowPercent = p.BattleHealBelowPercent;
		if ((healBelowPercent < 1 || healBelowPercent > 100) ? true : false)
		{
			throw new FormatException("战斗内回血阈值须为 1–100");
		}
		ValidateItems(p.BattleHealingPriority, healing: true);
		ValidateItems(p.EquipmentPriority);
		if (p.EquipmentPriority.Any((uint id) => ArenaItemCatalog.Items[id].Category != 1))
		{
			throw new FormatException("装备保留优先级只能包含装备");
		}
		ValidateItems(p.PurchasePriority);
		ValidateItems(p.TreasurePriority);
		ValidateItems(p.HealingPriority, healing: true);
		ValidateNodes(p.NodeTreasurePriorities, ArenaTileKind.Treasure, map);
		ValidateNodes(p.NodePurchasePriorities, ArenaTileKind.Shop, map);
		ValidateResources(p.Resources, map);
		if (p.Battles == null || p.Battles.Any((ArenaBattlePreset b) => b == null) || p.Battles.Select((ArenaBattlePreset b) => b.Node).Distinct().Count() != p.Battles.Count)
		{
			throw new FormatException("战斗格设置无效或重复");
		}
		foreach (ArenaBattlePreset battle in p.Battles)
		{
			battle.FoldLegacyHeal();
			if (!map.Nodes.Any((ArenaMapNode n) => n.Node == battle.Node && n.Kind == ArenaTileKind.Battle) || battle.Flutes == null || battle.Flutes.Length != 3 || battle.Flutes.Any((ArenaFluteChoice f) => f == null || f.A > 50 || f.B > 50))
			{
				throw new FormatException("战斗格须包含 1、2、3 号兽角的有效 A/B 候选");
			}
			ValidateBattleRules(battle.Rules);
		}
		if (p.RandomOutcomes == null || p.RandomOutcomes.Any((ArenaRandomOutcomePreset o) => o == null) || p.RandomOutcomes.Select((ArenaRandomOutcomePreset o) => (Node: o.Node, Outcome: o.Outcome)).Distinct().Count() != p.RandomOutcomes.Count)
		{
			throw new FormatException("随机事件结果设置无效或重复");
		}
		foreach (ArenaRandomOutcomePreset randomOutcome in p.RandomOutcomes)
		{
			ArenaRandomOutcome arenaRandomOutcome = ArenaRandomEvents.Find(stage, randomOutcome.Node, randomOutcome.Outcome) ?? throw new FormatException("当前地图没有此随机事件结果");
			if (randomOutcome.Resources != null)
			{
				ValidateResourceNode(randomOutcome.Resources);
			}
			if (arenaRandomOutcome.TileKind == ArenaTileKind.Battle)
			{
				ArenaBattlePreset battle2 = randomOutcome.Battle;
				if (battle2 == null || battle2.Node != randomOutcome.Node || battle2.Flutes == null || battle2.Flutes.Length != 3 || battle2.Flutes.Any((ArenaFluteChoice f) => f == null || f.A > 50 || f.B > 50) || randomOutcome.ItemPriority != null)
				{
					throw new FormatException("随机战斗须包含 1、2、3 号兽角的有效 A/B 候选");
				}
				continue;
			}
			if (randomOutcome.Battle != null || (arenaRandomOutcome.TileKind == ArenaTileKind.Camp && randomOutcome.ItemPriority != null))
			{
				throw new FormatException("随机事件配置与结果类型不符");
			}
			if (randomOutcome.ItemPriority != null)
			{
				ValidateItems(randomOutcome.ItemPriority);
			}
		}
	}

	private static void ValidateNodes(Dictionary<int, List<uint>>? orders, ArenaTileKind kind, ArenaStageMap map)
	{
		if (orders == null)
		{
			throw new FormatException("节点优先级内容为空");
		}
		foreach (KeyValuePair<int, List<uint>> order in orders)
		{
			var (node, items) = (KeyValuePair<int, List<uint>>)(ref order);
			if (!map.Nodes.Any((ArenaMapNode n) => n.Node == node && n.Kind == kind))
			{
				throw new FormatException("优先级指定了错误类型的棋格");
			}
			ValidateItems(items);
		}
	}

	private static void ValidateResources(ArenaResources? r, ArenaStageMap map)
	{
		bool flag = r == null || r.Nodes == null;
		int targetEquipment;
		if (!flag)
		{
			targetEquipment = r.TargetEquipment;
			bool flag2 = ((targetEquipment < 0 || targetEquipment > 10) ? true : false);
			flag = flag2;
		}
		bool flag3 = flag;
		if (!flag3)
		{
			targetEquipment = r.TargetItems;
			bool flag2 = ((targetEquipment < 0 || targetEquipment > 10) ? true : false);
			flag3 = flag2;
		}
		if (flag3 || r.ReserveCoins > 999999 || (r.NoEquipment && r.TargetEquipment > 0))
		{
			throw new FormatException("物品目标或限制冲突");
		}
		r.FoldLegacy();
		ValidateItems(r.Disabled);
		ValidateItems(r.SupplyPriority);
		ArenaAcquisitionPriority[] array = new ArenaAcquisitionPriority[3] { r.BattleRewards, r.TreasureRewards, r.Purchases };
		for (targetEquipment = 0; targetEquipment < array.Length; targetEquipment++)
		{
			ArenaAcquisitionPriority arenaAcquisitionPriority = array[targetEquipment];
			if (arenaAcquisitionPriority == null)
			{
				throw new FormatException("物品来源优先级为空");
			}
			ValidateItems(arenaAcquisitionPriority.Order);
			ValidateItems(arenaAcquisitionPriority.Disabled);
			if (arenaAcquisitionPriority != r.Purchases && arenaAcquisitionPriority.Order.Concat(arenaAcquisitionPriority.Disabled).Any((uint id) => ArenaItemCatalog.Items[id].Category == 3))
			{
				throw new FormatException("战斗结束与宝箱只支持装备和道具");
			}
		}
		if (r.SupplyPriority.Any((uint id) => ArenaItemCatalog.Items[id].Category == 1))
		{
			throw new FormatException("物品规则包含错误类别或相互冲突的设置");
		}
		ValidateResourceNode(r.Rewards);
		ValidateResourceNode(r.Shop);
		foreach (KeyValuePair<int, ArenaNodeResources> node2 in r.Nodes)
		{
			node2.Deconstruct(out targetEquipment, out var value);
			int node = targetEquipment;
			ArenaNodeResources rules = value;
			if (!map.Nodes.Any(delegate(ArenaMapNode n)
			{
				bool flag4 = n.Node == node;
				if (flag4)
				{
					ArenaTileKind kind = n.Kind;
					bool flag5 = ((kind == ArenaTileKind.Start || kind == ArenaTileKind.Random) ? true : false);
					flag4 = !flag5;
				}
				return flag4 && n.BattleTier != ArenaBattleTier.Boss;
			}))
			{
				throw new FormatException("节点物品规则不属于当前地图的可配置节点");
			}
			ValidateResourceNode(rules);
		}
	}

	private static void ValidateResourceNode(ArenaNodeResources? rules)
	{
		bool flag;
		switch (rules?.RestBelowPercent)
		{
		default:
			flag = true;
			break;
		case null:
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8:
		case 9:
		case 10:
		case 11:
		case 12:
		case 13:
		case 14:
		case 15:
		case 16:
		case 17:
		case 18:
		case 19:
		case 20:
		case 21:
		case 22:
		case 23:
		case 24:
		case 25:
		case 26:
		case 27:
		case 28:
		case 29:
		case 30:
		case 31:
		case 32:
		case 33:
		case 34:
		case 35:
		case 36:
		case 37:
		case 38:
		case 39:
		case 40:
		case 41:
		case 42:
		case 43:
		case 44:
		case 45:
		case 46:
		case 47:
		case 48:
		case 49:
		case 50:
		case 51:
		case 52:
		case 53:
		case 54:
		case 55:
		case 56:
		case 57:
		case 58:
		case 59:
		case 60:
		case 61:
		case 62:
		case 63:
		case 64:
		case 65:
		case 66:
		case 67:
		case 68:
		case 69:
		case 70:
		case 71:
		case 72:
		case 73:
		case 74:
		case 75:
		case 76:
		case 77:
		case 78:
		case 79:
		case 80:
		case 81:
		case 82:
		case 83:
		case 84:
		case 85:
		case 86:
		case 87:
		case 88:
		case 89:
		case 90:
		case 91:
		case 92:
		case 93:
		case 94:
		case 95:
		case 96:
		case 97:
		case 98:
		case 99:
		case 100:
			flag = false;
			break;
		}
		if (flag)
		{
			throw new FormatException("帐篷休息阈值必须为 1–100%");
		}
		if (rules?.Priority != null)
		{
			ValidateItems(rules.Priority);
		}
		if (rules == null || rules.Categories == null || !rules.Categories.Order().SequenceEqual(new int[3] { 1, 2, 3 }) || !Enum.IsDefined(rules.EquipmentSort) || !Enum.IsDefined(rules.ItemSort) || !Enum.IsDefined(rules.FoodSort) || rules.FoodSort == ArenaPurchaseSort.FillThenPriority || rules.Budget > 999999 || rules.ReserveCoins > 999999)
		{
			throw new FormatException("节点的类别顺序、购买方式或预算无效");
		}
	}

	private static void ValidateItems(List<uint>? items, bool healing = false)
	{
		if (items == null || items.Count > ArenaItemCatalog.Items.Count || items.Distinct().Count() != items.Count || items.Any((uint id) => !ArenaItemCatalog.Items.ContainsKey(id) || (healing && ArenaHealPolicy.Healing(id) <= 0)))
		{
			throw new FormatException("物品优先级包含无效、重复或不适用的物品");
		}
	}

	private static void ValidateBattleRules(List<ArenaBattleRule>? rules)
	{
		if (rules == null)
		{
			return;
		}
		if (rules.Any((ArenaBattleRule r) => r == null) || rules.Select((ArenaBattleRule r) => r.Id).Distinct().Count() != rules.Count)
		{
			throw new FormatException("战斗规则无效或 ID 重复");
		}
		foreach (ArenaBattleRule rule in rules)
		{
			if (!Enum.IsDefined(rule.Trigger.Kind) || !Enum.IsDefined(rule.Target.Kind) || !Enum.IsDefined(rule.Action.Kind) || !Enum.IsDefined(rule.Action.ItemFilter) || !Enum.IsDefined(rule.Limit.Once))
			{
				throw new FormatException("战斗规则包含无效类型");
			}
			bool flag;
			switch (rule.LegacySlot)
			{
			default:
				flag = true;
				break;
			case null:
			case 1:
			case 2:
			case 3:
				flag = false;
				break;
			}
			if (flag)
			{
				throw new FormatException("战斗规则来源无效");
			}
			int percent = rule.Trigger.Percent;
			flag = ((percent < 1 || percent > 99) ? true : false);
			bool flag2 = flag || rule.Trigger.Seconds < 0 || rule.Trigger.Count < 1;
			bool flag3;
			if (!flag2)
			{
				int petSlot = rule.Trigger.PetSlot;
				flag3 = ((petSlot < 0 || petSlot > 3) ? true : false);
				flag2 = flag3;
			}
			bool flag4 = flag2;
			if (!flag4)
			{
				int petSlot = rule.Target.PetSlot;
				flag3 = ((petSlot < 0 || petSlot > 3) ? true : false);
				flag4 = flag3;
			}
			if (flag4)
			{
				throw new FormatException("战斗规则参数越界");
			}
			percent = rule.Action.DutyActionSlot;
			flag4 = ((percent < 1 || percent > 2) ? true : false);
			flag2 = flag4;
			if (!flag2)
			{
				int petSlot = rule.Action.CountdownSeconds;
				flag = ((petSlot < 1 || petSlot > 30) ? true : false);
				flag2 = flag;
			}
			if (flag2 || rule.Action.ItemLimit < 0)
			{
				throw new FormatException("战斗规则动作参数越界");
			}
			percent = rule.Limit.RetrySeconds;
			flag2 = ((percent < 1 || percent > 60) ? true : false);
			flag4 = flag2;
			if (!flag4)
			{
				int petSlot = rule.Limit.MaxAttemptsPerItem;
				bool flag5 = ((petSlot < 1 || petSlot > 10) ? true : false);
				flag4 = flag5;
			}
			flag = flag4;
			if (!flag)
			{
				int petSlot = rule.Limit.WindowSeconds;
				bool flag5 = ((petSlot < 0 || petSlot > 600) ? true : false);
				flag = flag5;
			}
			flag3 = flag;
			if (!flag3)
			{
				int petSlot = rule.Limit.CooldownSeconds;
				bool flag5 = ((petSlot < 0 || petSlot > 600) ? true : false);
				flag3 = flag5;
			}
			bool flag6 = flag3;
			if (!flag6)
			{
				int petSlot = rule.Limit.DebounceSeconds;
				bool flag5 = ((petSlot < 0 || petSlot > 60) ? true : false);
				flag6 = flag5;
			}
			if (flag6)
			{
				throw new FormatException("战斗规则限制参数越界");
			}
			if ((rule.Action.ItemIds ?? throw new FormatException("战斗规则道具列表无效")).Any((uint id) => !ArenaItemCatalog.Items.ContainsKey(id)))
			{
				throw new FormatException("战斗规则包含未知道具");
			}
		}
	}
}
