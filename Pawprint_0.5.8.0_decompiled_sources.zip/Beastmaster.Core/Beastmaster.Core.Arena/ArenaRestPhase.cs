namespace Beastmaster.Core.Arena;

public enum ArenaRestPhase
{
	Loading,
	Selection,
	Confirmation,
	Reward,
	RewardConfirmation,
	Returned,
	Blocked,
	LeaveConfirmation,
	StaleConfirmation
}
