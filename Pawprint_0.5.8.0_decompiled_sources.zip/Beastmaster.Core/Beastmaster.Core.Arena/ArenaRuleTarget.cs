using System;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaRuleTarget
{
	public ArenaRuleTargetKind Kind { get; set; }

	public uint EnemyNameId { get; set; }

	public int PetSlot { get; set; }
}
