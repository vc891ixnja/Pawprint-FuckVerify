using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaHealStep(IArenaHealWorld world, int percent = 50, IReadOnlyList<uint>? priority = null, ArenaResourcePolicy? resources = null, bool untilThreshold = false) : IWorkflowStep
{
	private ArenaHealItem? selected;

	private int beforeCount;

	private bool opened;

	private bool used;

	private bool complete;

	private int attempts;

	private TimeSpan? sentAt;

	private TimeSpan? firstUseAt;

	private TimeSpan? unavailableAt;

	private TimeSpan? consumedAt;

	private TimeSpan? blockedAt;

	private uint hpBeforeUse;

	public string Name { get; private set; } = "斗兽 · 检查回血道具";

	public bool Skipped { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromSeconds(untilThreshold ? 120 : 30);

	public StepResult Tick(TimeSpan elapsed)
	{
		if (complete)
		{
			return StepResult.Completed;
		}
		if (elapsed >= Timeout)
		{
			return Skip("用药等待超时");
		}
		ArenaHealView view = world.Read();
		if (view.Phase == ArenaHealPhase.Ended)
		{
			complete = true;
			world.RestoreTarget();
			Name = "战斗已结束，继续结算";
			return StepResult.Completed;
		}
		if (view.Phase == ArenaHealPhase.Blocked)
		{
			TimeSpan valueOrDefault = blockedAt.GetValueOrDefault();
			if (!blockedAt.HasValue)
			{
				valueOrDefault = elapsed;
				blockedAt = valueOrDefault;
			}
			if (untilThreshold)
			{
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = blockedAt;
				if (!(value - timeSpan >= TimeSpan.FromSeconds(3L)))
				{
					Name = "斗兽 · 等待用药界面就绪";
					return StepResult.Running;
				}
			}
			return Skip("当前界面不能用药");
		}
		if (view.Phase == ArenaHealPhase.Loading)
		{
			return StepResult.Running;
		}
		blockedAt = null;
		TimeSpan? timeSpan2 = consumedAt;
		if (timeSpan2.HasValue)
		{
			TimeSpan valueOrDefault2 = timeSpan2.GetValueOrDefault();
			Name = "斗兽 · 等待体力更新";
			if (elapsed - valueOrDefault2 < TimeSpan.FromSeconds(1L) || (view.Hp == hpBeforeUse && elapsed - valueOrDefault2 < TimeSpan.FromSeconds(3L)))
			{
				return StepResult.Running;
			}
			consumedAt = null;
		}
		bool flag = attempts > 0;
		if (flag)
		{
			ArenaHealPhase phase = view.Phase;
			bool flag2 = (uint)(phase - 1) <= 1u;
			flag = flag2;
		}
		if (flag && view.Items.Count((ArenaHealItem i) => i.ItemId == selected.ItemId) < beforeCount)
		{
			world.RestoreTarget();
			if (!untilThreshold)
			{
				complete = true;
				Name = "斗兽 · 已使用回血道具";
				return StepResult.Completed;
			}
			selected = null;
			opened = (used = false);
			attempts = (beforeCount = 0);
			sentAt = (firstUseAt = (unavailableAt = null));
			consumedAt = elapsed;
			Name = "斗兽 · 等待体力更新";
			return StepResult.Running;
		}
		if (selected != null)
		{
			ArenaResourcePolicy? arenaResourcePolicy = resources;
			if (arenaResourcePolicy != null && !arenaResourcePolicy.CanUse(selected.ItemId, view.Items.Length))
			{
				return Skip("预设禁止使用此道具或需要保留数量");
			}
		}
		timeSpan2 = firstUseAt;
		if (timeSpan2.HasValue)
		{
			TimeSpan valueOrDefault3 = timeSpan2.GetValueOrDefault();
			if (elapsed - valueOrDefault3 >= TimeSpan.FromSeconds(8L))
			{
				return Skip("连续尝试 8 秒，未确认道具消耗");
			}
		}
		if (attempts > 0 && !ArenaHealPolicy.NeedsHealing(view.Hp, view.MaxHp, percent))
		{
			Name = "斗兽 · 等待回血道具消耗确认";
			return StepResult.Running;
		}
		if (selected != null && attempts == 0 && !ArenaHealPolicy.NeedsHealing(view.Hp, view.MaxHp, percent))
		{
			complete = true;
			world.RestoreTarget();
			Name = "斗兽 · 体力已达到设定阈值";
			return StepResult.Completed;
		}
		if (used)
		{
			ArenaHealPhase phase = view.Phase;
			if ((uint)(phase - 1) <= 1u)
			{
				TimeSpan value = elapsed;
				TimeSpan? timeSpan = sentAt;
				timeSpan2 = value - timeSpan;
				TimeSpan valueOrDefault = TimeSpan.FromMilliseconds(ArenaHealPolicy.UiIntervalMilliseconds(world.DuringBattle));
				if (timeSpan2.HasValue && timeSpan2.GetValueOrDefault() >= valueOrDefault && view.Items.Any((ArenaHealItem i) => i == selected && i.Usable))
				{
					if (attempts >= ArenaHealPolicy.MaxUseAttempts(world.DuringBattle))
					{
						return Skip("道具连续尝试后未消耗");
					}
					opened = view.Phase == ArenaHealPhase.Menu;
					used = false;
					Name = "回血道具尚未消耗，等待重试";
				}
			}
			return StepResult.Running;
		}
		if (selected == null)
		{
			if (view.Phase != ArenaHealPhase.Board)
			{
				return Skip("当前有其他道具菜单");
			}
			ArenaHealItem[] array = view.Items.Where((ArenaHealItem i) => resources?.CanUse(i.ItemId, view.Items.Length) ?? true).ToArray();
			selected = ArenaHealPolicy.Choose(view with
			{
				Items = array
			}, percent, priority);
			if (selected == null)
			{
				if (ArenaHealPolicy.NeedsHealing(view.Hp, view.MaxHp, percent) && array.Any((ArenaHealItem i) => ArenaHealPolicy.Healing(i.ItemId) > 0))
				{
					TimeSpan valueOrDefault = unavailableAt.GetValueOrDefault();
					if (!unavailableAt.HasValue)
					{
						valueOrDefault = elapsed;
						unavailableAt = valueOrDefault;
					}
					TimeSpan value = elapsed;
					TimeSpan? timeSpan = unavailableAt;
					if (value - timeSpan >= TimeSpan.FromSeconds(3L))
					{
						return Skip("道具暂不可用");
					}
					Name = "斗兽 · 等待回血道具可用";
					return StepResult.Running;
				}
				complete = true;
				Name = (ArenaHealPolicy.NeedsHealing(view.Hp, view.MaxHp, percent) ? "没有允许使用的回血道具" : "斗兽 · 体力已达到设定阈值");
				return StepResult.Completed;
			}
			hpBeforeUse = view.Hp;
			beforeCount = view.Items.Count((ArenaHealItem i) => i.ItemId == selected.ItemId);
		}
		ArenaHealItem arenaHealItem = view.Items.FirstOrDefault((ArenaHealItem i) => i.Slot == selected.Slot && i.ItemId == selected.ItemId);
		if (arenaHealItem == null)
		{
			return Skip("道具已变化");
		}
		if (!arenaHealItem.Usable)
		{
			TimeSpan valueOrDefault = unavailableAt.GetValueOrDefault();
			if (!unavailableAt.HasValue)
			{
				valueOrDefault = elapsed;
				unavailableAt = valueOrDefault;
			}
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = unavailableAt;
			if (value - timeSpan >= TimeSpan.FromSeconds(3L))
			{
				return Skip("道具暂不可用");
			}
			Name = "斗兽 · 等待回血道具可用";
			return StepResult.Running;
		}
		unavailableAt = null;
		if (opened)
		{
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = sentAt;
			if (value - timeSpan > TimeSpan.FromSeconds(10L))
			{
				return Skip("道具菜单未完成操作");
			}
		}
		if (opened && !used && view.Phase == ArenaHealPhase.Board)
		{
			TimeSpan value = elapsed;
			TimeSpan? timeSpan = sentAt;
			if (value - timeSpan >= TimeSpan.FromMilliseconds(ArenaHealPolicy.UiIntervalMilliseconds(world.DuringBattle)))
			{
				opened = false;
			}
		}
		Name = "斗兽 · 使用" + ArenaItemCatalog.Items[selected.ItemId].Name;
		if (world.DirectDispatch)
		{
			if (!used)
			{
				used = world.TryDispatch(selected);
				if (used)
				{
					sentAt = elapsed;
					TimeSpan valueOrDefault = firstUseAt.GetValueOrDefault();
					if (!firstUseAt.HasValue)
					{
						valueOrDefault = elapsed;
						firstUseAt = valueOrDefault;
					}
					attempts++;
				}
			}
		}
		else if (!opened)
		{
			opened = world.TryOpen(selected);
			if (opened)
			{
				sentAt = elapsed;
			}
		}
		else if (view.Phase == ArenaHealPhase.Menu)
		{
			used = world.TryUse(selected);
			if (used)
			{
				attempts++;
				sentAt = elapsed;
				TimeSpan valueOrDefault = firstUseAt.GetValueOrDefault();
				if (!firstUseAt.HasValue)
				{
					valueOrDefault = elapsed;
					firstUseAt = valueOrDefault;
				}
			}
		}
		return StepResult.Running;
	}

	private StepResult Skip(string reason)
	{
		bool flag = (Skipped = true);
		complete = flag;
		world.RestoreTarget();
		Name = "已跳过本次补血：" + reason;
		return StepResult.Completed;
	}

	public void Cancel()
	{
		world.RestoreTarget();
	}
}
