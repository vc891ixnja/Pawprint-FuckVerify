using System;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRepeatStep : IWorkflowStep
{
	private readonly Func<ArenaRunStep> factory;

	private readonly Func<int> target;

	private TimeSpan runAt;

	private bool needsNext;

	public ArenaRunStep Current { get; private set; }

	public int Target => Math.Clamp(target(), 1, 999);

	public int Completed { get; private set; }

	public int Failures { get; private set; }

	private string FailureCount
	{
		get
		{
			if (Failures <= 0)
			{
				return "";
			}
			return $"（失败 {Failures} 次）";
		}
	}

	public string Name
	{
		get
		{
			if (Completed >= Target)
			{
				return $"已完成 {Completed}/{Target} 次{FailureCount}";
			}
			return $"第 {Completed + 1}/{Target} 次{FailureCount} · {Current.Name}";
		}
	}

	public TimeSpan Timeout => TimeSpan.FromHours(3L * (long)Target);

	public ArenaRepeatStep(ArenaRunStep first, int count, Func<ArenaRunStep> next)
	{
		if ((count < 1 || count > 999) ? true : false)
		{
			throw new ArgumentOutOfRangeException("count");
		}
		Current = first;
		target = () => count;
		factory = next;
	}

	public ArenaRepeatStep(ArenaRunStep first, Func<int> target, Func<ArenaRunStep> next)
	{
		Current = first;
		this.target = target;
		factory = next;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (Completed >= Target)
		{
			return StepResult.Completed;
		}
		if (needsNext)
		{
			Current = factory();
			runAt = elapsed;
			needsNext = false;
		}
		if (elapsed - runAt >= Current.Timeout)
		{
			throw new TimeoutException("本局斗兽执行超时");
		}
		if (Current.Tick(elapsed - runAt) != StepResult.Completed)
		{
			return StepResult.Running;
		}
		Current.Cancel();
		if (Current.Failed)
		{
			Failures++;
		}
		Completed++;
		needsNext = true;
		if (Completed != Target)
		{
			return StepResult.Running;
		}
		return StepResult.Completed;
	}

	public void Cancel()
	{
		Current.Cancel();
	}
}
