using System;
using System.Collections.Generic;
using System.Numerics;
using System.Runtime.InteropServices;
using System.Threading;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaBoardStep : IWorkflowStep
{
	private readonly ArenaStage stage;

	private static int boardJitterSeed;

	private readonly Dictionary<int, Vector3> jitteredCenters;

	private readonly Random boardJitterRng;

	private int current;

	private int? destination;

	private bool initialized;

	private bool ownsMovement;

	private bool witnessedEvent;

	private bool battleSeen;

	private bool rewardSeen;

	private TimeSpan? moveStarted;

	private TimeSpan? arrivedAt;

	private TimeSpan? readySince;

	private TimeSpan? encounterStarted;

	private bool encounterCompleted;

	private bool awaitingReturn;

	private bool attachEncounter;

	private IWorkflowStep? activeEncounter;

	private IWorkflowStep? activeRest;

	private TimeSpan? restStarted;

	private bool restCompleted;

	private IWorkflowStep? activeTreasure;

	private TimeSpan? treasureStarted;

	private bool treasureCompleted;

	private IWorkflowStep? activeShop;

	private TimeSpan? shopStarted;

	private bool shopCompleted;

	private IWorkflowStep? activeHeal;

	private TimeSpan? healStarted;

	private bool healCompleted;

	private ArenaBoardRoute Route => ArenaBoardRoute.Get(stage.Id);

	public bool RestActive
	{
		get
		{
			if (restStarted.HasValue)
			{
				return !restCompleted;
			}
			return false;
		}
	}

	public bool TreasureActive
	{
		get
		{
			if (treasureStarted.HasValue)
			{
				return !treasureCompleted;
			}
			return false;
		}
	}

	public bool ShopActive
	{
		get
		{
			if (shopStarted.HasValue)
			{
				return !shopCompleted;
			}
			return false;
		}
	}

	public bool HealingActive
	{
		get
		{
			if (healStarted.HasValue)
			{
				return !healCompleted;
			}
			return false;
		}
	}

	public bool AutomatesFirstEncounterUi
	{
		get
		{
			if (_003CfirstEncounter_003EP == null)
			{
				return _003CencounterFactory_003EP != null;
			}
			return true;
		}
	}

	public bool FirstEncounterActive
	{
		get
		{
			if (encounterStarted.HasValue)
			{
				return !encounterCompleted;
			}
			return false;
		}
	}

	public int CurrentNode => current;

	public int? DestinationNode => destination;

	public string BattleStatus
	{
		get
		{
			if (!(activeEncounter is ArenaEncounterStep arenaEncounterStep) || encounterCompleted)
			{
				return "";
			}
			return arenaEncounterStep.BattleStatus;
		}
	}

	public string Name { get; private set; }

	public double JitterRadius { get; set; }

	public TimeSpan Timeout => TimeSpan.FromHours(2);

	public ArenaBoardStep(INavigationProvider nav, Func<ArenaBoardObservation> read, IWorkflowStep? firstEncounter = null, bool resumeFromCurrent = false, Func<int?, bool, IWorkflowStep>? encounterFactory = null, ArenaStage? selectedStage = null, Func<IWorkflowStep>? restFactory = null, Func<IWorkflowStep>? treasureFactory = null, Func<IWorkflowStep>? shopFactory = null, Func<int, IWorkflowStep?>? healFactory = null, Func<int, int?>? chooseNext = null, Func<int?, IWorkflowStep>? treasureAtFactory = null, Func<int?, IWorkflowStep>? shopAtFactory = null, Func<int?, IWorkflowStep>? restAtFactory = null)
	{
		_003Cnav_003EP = nav;
		_003Cread_003EP = read;
		_003CfirstEncounter_003EP = firstEncounter;
		_003CresumeFromCurrent_003EP = resumeFromCurrent;
		_003CencounterFactory_003EP = encounterFactory;
		_003CrestFactory_003EP = restFactory;
		_003CtreasureFactory_003EP = treasureFactory;
		_003CshopFactory_003EP = shopFactory;
		_003ChealFactory_003EP = healFactory;
		_003CchooseNext_003EP = chooseNext;
		_003CtreasureAtFactory_003EP = treasureAtFactory;
		_003CshopAtFactory_003EP = shopAtFactory;
		_003CrestAtFactory_003EP = restAtFactory;
		stage = selectedStage ?? ArenaStage.Get(1);
		jitteredCenters = new Dictionary<int, Vector3>();
		boardJitterRng = new Random(Interlocked.Increment(ref boardJitterSeed));
		Name = "斗兽 · 等待棋盘";
		base._002Ector();
	}

	public bool AcceptsTerritory(uint territory)
	{
		if (territory != 0)
		{
			return territory == stage.Territory;
		}
		return true;
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		ArenaBoardObservation arenaBoardObservation = _003Cread_003EP();
		if (arenaBoardObservation.Loading && AcceptsTerritory(arenaBoardObservation.Territory) && (arenaBoardObservation.Content == 0 || arenaBoardObservation.Content == stage.Content))
		{
			Wait(arenaBoardObservation.Phase);
			return StepResult.Running;
		}
		if (arenaBoardObservation.Territory != stage.Territory || arenaBoardObservation.Content != stage.Content)
		{
			throw new InvalidOperationException("已离开斗兽奇弈" + stage.Name);
		}
		if (arenaBoardObservation.Result)
		{
			ReleaseMovement();
			Name = stage.Name + " · 已到达结算";
			return StepResult.Completed;
		}
		Vector3? player = arenaBoardObservation.Player;
		Vector3 valueOrDefault;
		TimeSpan valueOrDefault2;
		TimeSpan value2;
		TimeSpan? timeSpan;
		if (player.HasValue)
		{
			valueOrDefault = player.GetValueOrDefault();
			if (!stage.HasNavigationRoute)
			{
				return TickUncalibrated(arenaBoardObservation, elapsed);
			}
			if (!initialized)
			{
				if (!_003CresumeFromCurrent_003EP)
				{
					if (!Route.InTile(0, valueOrDefault))
					{
						throw new InvalidOperationException("请在" + stage.Name + "初始格启动自动走棋");
					}
				}
				else if (!Route.IsOnBoard(valueOrDefault))
				{
					awaitingReturn = (attachEncounter = true);
					battleSeen = true;
					rewardSeen = arenaBoardObservation.BattleReward;
				}
				else
				{
					int? num = Route.FindTile(valueOrDefault);
					if (num.HasValue)
					{
						int value = (current = num.GetValueOrDefault());
						if (arenaBoardObservation.NodeEvent)
						{
							destination = value;
							witnessedEvent = (attachEncounter = true);
						}
						else
						{
							if (arenaBoardObservation.Blocked)
							{
								Wait(arenaBoardObservation.Phase);
								return StepResult.Running;
							}
							valueOrDefault2 = readySince.GetValueOrDefault();
							if (!readySince.HasValue)
							{
								valueOrDefault2 = elapsed;
								readySince = valueOrDefault2;
							}
							value2 = elapsed;
							timeSpan = readySince;
							if (value2 - timeSpan < TimeSpan.FromSeconds(1L))
							{
								Name = $"{stage.Name} · 接续第 {value} 格";
								return StepResult.Running;
							}
							readySince = null;
						}
					}
					else
					{
						(int, int) tuple = Route.FindBridge(valueOrDefault) ?? throw new InvalidOperationException("当前位置不在已标定的棋格或连接桥上");
						current = tuple.Item1;
						destination = tuple.Item2;
					}
				}
				initialized = true;
			}
			if (arenaBoardObservation.NodeEvent)
			{
				int? num = destination;
				if (num.HasValue)
				{
					int valueOrDefault3 = num.GetValueOrDefault();
					if (Route.InTile(valueOrDefault3, valueOrDefault))
					{
						witnessedEvent = true;
					}
				}
			}
			if (witnessedEvent && !Route.IsOnBoard(valueOrDefault))
			{
				battleSeen = true;
				if (arenaBoardObservation.BattleReward)
				{
					rewardSeen = true;
				}
			}
			if (HealingActive)
			{
				if (!Route.InTile(current, valueOrDefault))
				{
					throw new InvalidOperationException("回血尚未完成，角色已离开当前棋格");
				}
				TickHeal(elapsed);
				return StepResult.Running;
			}
			if (TickRest(arenaBoardObservation, elapsed))
			{
				return StepResult.Running;
			}
			if (TickTreasure(arenaBoardObservation, elapsed))
			{
				return StepResult.Running;
			}
			if (TickShop(arenaBoardObservation, elapsed))
			{
				return StepResult.Running;
			}
			if (activeEncounter == null && !encounterCompleted)
			{
				if (awaitingReturn)
				{
					goto IL_0435;
				}
				if (witnessedEvent)
				{
					int? num = destination;
					if (num.HasValue)
					{
						int valueOrDefault4 = num.GetValueOrDefault();
						if (Route.CanHaveBattle(valueOrDefault4) && (Route.IsBattle(valueOrDefault4) || arenaBoardObservation.EncounterSetup || battleSeen))
						{
							goto IL_0435;
						}
					}
				}
			}
			goto IL_0474;
		}
		Wait("等待角色加载");
		return StepResult.Running;
		IL_0474:
		if (activeEncounter != null && !encounterCompleted)
		{
			ReleaseMovement();
			valueOrDefault2 = encounterStarted.GetValueOrDefault();
			if (!encounterStarted.HasValue)
			{
				valueOrDefault2 = elapsed;
				encounterStarted = valueOrDefault2;
			}
			TimeSpan timeSpan2 = elapsed - encounterStarted.Value;
			if (timeSpan2 >= activeEncounter.Timeout)
			{
				throw new TimeoutException("斗兽战斗界面处理超时");
			}
			StepResult num2 = activeEncounter.Tick(timeSpan2);
			Name = activeEncounter.Name;
			if (num2 == StepResult.Completed)
			{
				activeEncounter.Cancel();
				encounterCompleted = true;
				battleSeen = (rewardSeen = true);
			}
			return StepResult.Running;
		}
		if (arenaBoardObservation.Blocked || arenaBoardObservation.NodeEvent || !Route.IsOnBoard(valueOrDefault))
		{
			Wait(arenaBoardObservation.Phase);
			return StepResult.Running;
		}
		if (awaitingReturn)
		{
			int? num = Route.FindTile(valueOrDefault);
			if (!num.HasValue)
			{
				Wait("等待返回棋格");
				return StepResult.Running;
			}
			int valueOrDefault5 = num.GetValueOrDefault();
			current = valueOrDefault5;
			destination = null;
			awaitingReturn = false;
			witnessedEvent = (battleSeen = (rewardSeen = false));
			ResetEncounter();
		}
		if (witnessedEvent)
		{
			int? num = destination;
			if (num.HasValue)
			{
				int valueOrDefault6 = num.GetValueOrDefault();
				if (Route.IsBattle(valueOrDefault6) && (!battleSeen || !rewardSeen))
				{
					Wait(battleSeen ? "等待战后奖励确认" : "等待进入战斗场地");
					return StepResult.Running;
				}
				if (!Route.InTile(valueOrDefault6, valueOrDefault))
				{
					throw new InvalidOperationException("事件结束后的落点不在目标格，请停止后核对位置");
				}
				valueOrDefault2 = readySince.GetValueOrDefault();
				if (!readySince.HasValue)
				{
					valueOrDefault2 = elapsed;
					readySince = valueOrDefault2;
				}
				value2 = elapsed;
				timeSpan = readySince;
				if (value2 - timeSpan < TimeSpan.FromSeconds(1L))
				{
					return StepResult.Running;
				}
				current = valueOrDefault6;
				destination = null;
				witnessedEvent = (battleSeen = (rewardSeen = false));
				ResetEncounter();
				moveStarted = (arrivedAt = (readySince = null));
			}
		}
		if (!destination.HasValue)
		{
			destination = ((_003CchooseNext_003EP != null) ? _003CchooseNext_003EP(current) : Route.Next(current));
			int? num = destination;
			if (num.HasValue)
			{
				int valueOrDefault7 = num.GetValueOrDefault();
				if (!((ReadOnlySpan<int>)Route.Nodes[current].Next).Contains(valueOrDefault7))
				{
					throw new InvalidOperationException("预设路线不是当前格的相邻连接");
				}
			}
			if (!destination.HasValue)
			{
				Name = stage.Name + " · 等待结算";
				return StepResult.Running;
			}
			if (!Route.InTile(current, valueOrDefault))
			{
				throw new InvalidOperationException("角色已偏离当前棋格");
			}
		}
		int value3 = destination.Value;
		if (!healCompleted && _003ChealFactory_003EP != null && Route.InTile(current, valueOrDefault))
		{
			if (activeHeal == null)
			{
				activeHeal = _003ChealFactory_003EP(value3);
			}
			if (activeHeal == null)
			{
				healCompleted = true;
				Name = stage.Name + " · 下一格禁止回血，跳过补血";
			}
			else
			{
				TickHeal(elapsed);
			}
			return StepResult.Running;
		}
		if (Vector3.Distance(valueOrDefault, JitteredCenter(value3)) <= 0.6f)
		{
			ReleaseMovement();
			valueOrDefault2 = arrivedAt.GetValueOrDefault();
			if (!arrivedAt.HasValue)
			{
				valueOrDefault2 = elapsed;
				arrivedAt = valueOrDefault2;
			}
			Name = $"{stage.Name} · 等待第 {value3} 格事件";
			value2 = elapsed;
			timeSpan = arrivedAt;
			if (value2 - timeSpan > TimeSpan.FromSeconds(10L))
			{
				throw new TimeoutException("已到格子中心，但未出现事件");
			}
			return StepResult.Running;
		}
		if (!_003Cnav_003EP.MovementAllowed)
		{
			Wait("vnavmesh 移动已禁用");
			return StepResult.Running;
		}
		valueOrDefault2 = moveStarted.GetValueOrDefault();
		if (!moveStarted.HasValue)
		{
			valueOrDefault2 = elapsed;
			moveStarted = valueOrDefault2;
		}
		value2 = elapsed;
		timeSpan = moveStarted;
		if (value2 - timeSpan > TimeSpan.FromSeconds(30L))
		{
			throw new TimeoutException("走棋未到达目标格");
		}
		if (!ownsMovement)
		{
			if (_003Cnav_003EP.IsRunning || _003Cnav_003EP.IsPathfinding)
			{
				throw new InvalidOperationException("vnavmesh 已被其他任务使用");
			}
			ownsMovement = true;
			INavigationProvider navigationProvider = _003Cnav_003EP;
			int num3 = 1;
			List<Vector3> list = new List<Vector3>(num3);
			CollectionsMarshal.SetCount(list, num3);
			CollectionsMarshal.AsSpan(list)[0] = JitteredCenter(value3);
			navigationProvider.Move(list);
		}
		else if (!_003Cnav_003EP.IsRunning)
		{
			throw new InvalidOperationException("走棋移动提前结束");
		}
		Name = $"{stage.Name} · 前往第 {value3} 格";
		return StepResult.Running;
		IL_0435:
		activeEncounter = _003CencounterFactory_003EP?.Invoke(destination, attachEncounter) ?? ((destination == 1) ? _003CfirstEncounter_003EP : null);
		goto IL_0474;
	}

	private Vector3 JitteredCenter(int node)
	{
		if (jitteredCenters.TryGetValue(node, out var value))
		{
			return value;
		}
		Vector3 center = Route.Nodes[node].Center;
		double num = boardJitterRng.NextDouble() * Math.PI * 2.0;
		double num2 = JitterRadius * Math.Sqrt(boardJitterRng.NextDouble());
		Vector3 vector = center + new Vector3((float)(Math.Cos(num) * num2), 0f, (float)(Math.Sin(num) * num2));
		jitteredCenters[node] = vector;
		return vector;
	}

	private StepResult TickUncalibrated(ArenaBoardObservation state, TimeSpan elapsed)
	{
		if (TickRest(state, elapsed))
		{
			return StepResult.Running;
		}
		if (TickTreasure(state, elapsed))
		{
			return StepResult.Running;
		}
		if (TickShop(state, elapsed))
		{
			return StepResult.Running;
		}
		if (restCompleted && !state.NodeEvent && !state.Blocked)
		{
			ResetRest();
		}
		if (treasureCompleted && !state.NodeEvent && !state.Blocked)
		{
			ResetTreasure();
		}
		if (shopCompleted && !state.NodeEvent && !state.Blocked)
		{
			ResetShop();
		}
		if (activeEncounter == null && (state.EncounterSetup || state.InCombat || state.BattleReward))
		{
			activeEncounter = _003CencounterFactory_003EP?.Invoke(null, arg2: true);
		}
		if (activeEncounter != null)
		{
			TimeSpan valueOrDefault = encounterStarted.GetValueOrDefault();
			if (!encounterStarted.HasValue)
			{
				valueOrDefault = elapsed;
				encounterStarted = valueOrDefault;
			}
			TimeSpan? timeSpan = encounterStarted;
			if (elapsed - timeSpan >= activeEncounter.Timeout)
			{
				throw new TimeoutException("斗兽战斗界面处理超时");
			}
			StepResult num = activeEncounter.Tick(elapsed - encounterStarted.Value);
			Name = activeEncounter.Name;
			if (num == StepResult.Completed)
			{
				activeEncounter.Cancel();
				ResetEncounter();
			}
		}
		else
		{
			Name = stage.Name + " · 自动走棋暂不支持";
		}
		return StepResult.Running;
	}

	private void TickHeal(TimeSpan elapsed)
	{
		ReleaseMovement();
		TimeSpan valueOrDefault = healStarted.GetValueOrDefault();
		if (!healStarted.HasValue)
		{
			valueOrDefault = elapsed;
			healStarted = valueOrDefault;
		}
		TimeSpan timeSpan = elapsed - healStarted.Value;
		if (timeSpan >= activeHeal.Timeout)
		{
			activeHeal.Cancel();
			healCompleted = true;
			Name = "已跳过本次补血：用药等待超时";
			return;
		}
		StepResult num = activeHeal.Tick(timeSpan);
		Name = activeHeal.Name;
		if (num == StepResult.Completed)
		{
			activeHeal.Cancel();
			healCompleted = true;
		}
	}

	private bool TickRest(ArenaBoardObservation state, TimeSpan elapsed)
	{
		if (activeRest == null && !restCompleted && activeEncounter == null && state.RestEvent)
		{
			activeRest = _003CrestAtFactory_003EP?.Invoke(stage.HasNavigationRoute ? destination : ((int?)null)) ?? _003CrestFactory_003EP?.Invoke();
		}
		if (activeRest == null || restCompleted)
		{
			return false;
		}
		ReleaseMovement();
		TimeSpan valueOrDefault = restStarted.GetValueOrDefault();
		if (!restStarted.HasValue)
		{
			valueOrDefault = elapsed;
			restStarted = valueOrDefault;
		}
		TimeSpan timeSpan = elapsed - restStarted.Value;
		if (timeSpan >= activeRest.Timeout)
		{
			throw new TimeoutException("斗兽休息处理超时");
		}
		StepResult num = activeRest.Tick(timeSpan);
		Name = activeRest.Name;
		if (num == StepResult.Completed)
		{
			activeRest.Cancel();
			restCompleted = true;
		}
		return true;
	}

	private void ResetRest()
	{
		activeRest = null;
		restStarted = null;
		restCompleted = false;
	}

	private bool TickTreasure(ArenaBoardObservation state, TimeSpan elapsed)
	{
		if (activeTreasure == null && !treasureCompleted && activeEncounter == null && !RestActive && state.TreasureEvent)
		{
			activeTreasure = _003CtreasureAtFactory_003EP?.Invoke(stage.HasNavigationRoute ? destination : ((int?)null)) ?? _003CtreasureFactory_003EP?.Invoke();
		}
		if (activeTreasure == null || treasureCompleted)
		{
			return false;
		}
		ReleaseMovement();
		TimeSpan valueOrDefault = treasureStarted.GetValueOrDefault();
		if (!treasureStarted.HasValue)
		{
			valueOrDefault = elapsed;
			treasureStarted = valueOrDefault;
		}
		TimeSpan timeSpan = elapsed - treasureStarted.Value;
		if (timeSpan >= activeTreasure.Timeout)
		{
			throw new TimeoutException("斗兽宝箱处理超时");
		}
		StepResult num = activeTreasure.Tick(timeSpan);
		Name = activeTreasure.Name;
		if (num == StepResult.Completed)
		{
			activeTreasure.Cancel();
			treasureCompleted = true;
		}
		return true;
	}

	private void ResetTreasure()
	{
		activeTreasure = null;
		treasureStarted = null;
		treasureCompleted = false;
	}

	private bool TickShop(ArenaBoardObservation state, TimeSpan elapsed)
	{
		if (activeShop == null && !shopCompleted && activeEncounter == null && !RestActive && !TreasureActive && state.ShopEvent)
		{
			activeShop = _003CshopAtFactory_003EP?.Invoke(stage.HasNavigationRoute ? destination : ((int?)null)) ?? _003CshopFactory_003EP?.Invoke();
		}
		if (activeShop == null || shopCompleted)
		{
			return false;
		}
		ReleaseMovement();
		TimeSpan valueOrDefault = shopStarted.GetValueOrDefault();
		if (!shopStarted.HasValue)
		{
			valueOrDefault = elapsed;
			shopStarted = valueOrDefault;
		}
		TimeSpan timeSpan = elapsed - shopStarted.Value;
		if (timeSpan >= activeShop.Timeout)
		{
			throw new TimeoutException("斗兽商店处理超时");
		}
		StepResult num = activeShop.Tick(timeSpan);
		Name = activeShop.Name;
		if (num == StepResult.Completed)
		{
			activeShop.Cancel();
			shopCompleted = true;
		}
		return true;
	}

	private void ResetShop()
	{
		activeShop = null;
		shopStarted = null;
		shopCompleted = false;
	}

	private void Wait(string phase)
	{
		ReleaseMovement();
		moveStarted = (arrivedAt = (readySince = null));
		Name = stage.Name + " · " + phase;
	}

	private void ResetEncounter()
	{
		activeEncounter = null;
		encounterStarted = null;
		encounterCompleted = (attachEncounter = false);
		ResetRest();
		ResetTreasure();
		ResetShop();
		activeHeal = null;
		healStarted = null;
		healCompleted = false;
	}

	private void ReleaseMovement()
	{
		if (ownsMovement)
		{
			ownsMovement = false;
			_003Cnav_003EP.Stop();
		}
	}

	public void Cancel()
	{
		ReleaseMovement();
		moveStarted = (arrivedAt = (readySince = null));
		if (FirstEncounterActive)
		{
			activeEncounter?.Cancel();
		}
		if (RestActive)
		{
			activeRest?.Cancel();
		}
		if (TreasureActive)
		{
			activeTreasure?.Cancel();
		}
		if (ShopActive)
		{
			activeShop?.Cancel();
		}
		if (HealingActive)
		{
			activeHeal?.Cancel();
		}
	}
}
