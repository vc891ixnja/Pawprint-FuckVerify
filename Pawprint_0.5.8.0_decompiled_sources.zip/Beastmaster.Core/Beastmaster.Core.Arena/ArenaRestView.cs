namespace Beastmaster.Core.Arena;

public sealed record ArenaRestView(ArenaRestPhase Phase, ArenaRestPet[] Pets, int Capacity = -1);
