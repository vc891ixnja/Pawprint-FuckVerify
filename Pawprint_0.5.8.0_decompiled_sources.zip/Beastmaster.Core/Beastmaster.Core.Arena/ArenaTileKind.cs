namespace Beastmaster.Core.Arena;

public enum ArenaTileKind
{
	Start,
	Battle,
	Camp,
	Treasure,
	Shop,
	Random
}
