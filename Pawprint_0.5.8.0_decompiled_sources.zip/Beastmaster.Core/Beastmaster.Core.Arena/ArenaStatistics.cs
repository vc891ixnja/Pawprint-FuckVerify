using System;
using System.Collections.Generic;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaStatistics
{
	public ulong Character { get; set; }

	public ulong Runs { get; set; }

	public ulong Failures { get; set; }

	public uint BestScore { get; set; }

	public ulong LowCrystals { get; set; }

	public ulong HighCrystals { get; set; }

	public Dictionary<string, ulong> Ratings { get; set; } = new Dictionary<string, ulong>();

	public ArenaRunResult? LastResult { get; set; }

	public DateTimeOffset? LastRecordedAt { get; set; }

	public ArenaRunResult? PendingResult { get; set; }

	public bool Record(ArenaRunResult result)
	{
		if (PendingResult == result)
		{
			return false;
		}
		checked
		{
			Runs++;
			if (result.Failed)
			{
				Failures++;
			}
			else if (!string.IsNullOrWhiteSpace(result.Rating))
			{
				Ratings[result.Rating] = Ratings.GetValueOrDefault(result.Rating) + 1;
			}
			BestScore = Math.Max(BestScore, result.Score);
			LowCrystals += result.LowCrystals;
			HighCrystals += result.HighCrystals;
			ArenaRunResult lastResult = (PendingResult = result);
			LastResult = lastResult;
			LastRecordedAt = DateTimeOffset.Now;
			return true;
		}
	}

	public bool ObserveExit()
	{
		if (PendingResult == null)
		{
			return false;
		}
		PendingResult = null;
		return true;
	}
}
