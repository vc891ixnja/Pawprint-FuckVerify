namespace Beastmaster.Core.Arena;

public enum ArenaTreasurePhase
{
	Loading,
	Selection,
	Confirmation,
	Returned,
	Blocked
}
