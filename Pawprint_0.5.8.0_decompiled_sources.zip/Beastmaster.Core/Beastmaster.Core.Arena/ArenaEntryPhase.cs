namespace Beastmaster.Core.Arena;

public enum ArenaEntryPhase
{
	Outside,
	Menu,
	StageList,
	Party,
	RosterEditor,
	Loading,
	Board,
	Blocked,
	EntryConfirmation,
	NpcMenu
}
