namespace Beastmaster.Core.Arena;

public interface IArenaRunSupport
{
	bool IsDead { get; }

	void Update();

	void Cancel();
}
