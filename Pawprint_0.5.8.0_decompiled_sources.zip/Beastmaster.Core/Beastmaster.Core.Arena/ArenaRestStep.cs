using System;
using System.Collections.Generic;
using System.Linq;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRestStep : IWorkflowStep
{
	private readonly ArenaEquipmentExchange equipment;

	private ArenaRewardStep? reward;

	private TimeSpan rewardAt;

	private bool rewardComplete;

	private bool leaveSent;

	private bool leaveConfirmed;

	private uint[]? desired;

	private uint? pending;

	private bool pendingSelected;

	private bool restSent;

	private bool confirmed;

	private bool dismissSent;

	private bool rewardSent;

	private bool rewardConfirmed;

	private TimeSpan requestAt;

	private TimeSpan nextAttempt;

	private TimeSpan? returnedAt;

	private ArenaRestPhase? previousPhase;

	private TimeSpan phaseAt;

	public string Name { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromMinutes(2L);

	public ArenaRestStep(IArenaRestWorld world, IReadOnlyList<uint>? equipmentPriority = null, ArenaResourcePolicy? resources = null)
	{
		_003Cworld_003EP = world;
		_003Cresources_003EP = resources;
		equipment = new ArenaEquipmentExchange(_003Cworld_003EP.Equipment, equipmentPriority, _003Cresources_003EP?.TriggeredRewards);
		Name = "休息 · 读取魔兽体力";
		base._002Ector();
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		if (elapsed >= Timeout)
		{
			throw new TimeoutException("休息流程超时");
		}
		if (!rewardComplete && _003Cresources_003EP != null)
		{
			IArenaRewardWorld rewards = _003Cworld_003EP.Rewards;
			if (rewards != null && (reward != null || rewards.IsOpen))
			{
				if (reward == null)
				{
					reward = new ArenaRewardStep(rewards, _003Cresources_003EP.TriggeredRewards);
					rewardAt = elapsed;
				}
				StepResult num = reward.Tick(elapsed - rewardAt);
				Name = reward.Name;
				if (num == StepResult.Completed)
				{
					rewardComplete = (rewardConfirmed = (confirmed = true));
					requestAt = elapsed;
				}
				return StepResult.Running;
			}
		}
		if (equipment.Tick(elapsed, out ArenaEquipmentOutcome outcome))
		{
			Name = equipment.Name;
			requestAt = (phaseAt = elapsed);
			return StepResult.Running;
		}
		if (outcome != null)
		{
			requestAt = (phaseAt = elapsed);
			rewardSent = (rewardConfirmed = false);
		}
		ArenaRestView view = _003Cworld_003EP.Read();
		if (previousPhase != view.Phase)
		{
			previousPhase = view.Phase;
			phaseAt = (requestAt = elapsed);
		}
		if (view.Phase == ArenaRestPhase.Blocked)
		{
			returnedAt = null;
			Name = "休息 · 等待窗口稳定";
			if (elapsed - phaseAt > TimeSpan.FromSeconds(15L))
			{
				_003Cworld_003EP.Dump(Name);
				throw new TimeoutException("休息界面持续未识别，请查看 arena-rest-latest.json");
			}
			return StepResult.Running;
		}
		if (view.Phase == ArenaRestPhase.StaleConfirmation)
		{
			returnedAt = null;
			Name = "休息 · 等待确认更新";
			if (confirmed)
			{
				Wait(elapsed);
				return StepResult.Running;
			}
			if (elapsed - phaseAt >= TimeSpan.FromSeconds(1L) && !dismissSent && Try(_003Cworld_003EP.TryDismissConfirmation, elapsed))
			{
				dismissSent = true;
				restSent = false;
				requestAt = elapsed;
			}
			Wait(elapsed);
			return StepResult.Running;
		}
		if (view.Phase != ArenaRestPhase.Returned)
		{
			returnedAt = null;
		}
		if (view.Phase == ArenaRestPhase.Loading)
		{
			Name = (confirmed ? "休息 · 等待返回棋盘" : "休息 · 等待界面加载");
			if (elapsed - phaseAt > TimeSpan.FromSeconds(60L))
			{
				throw new TimeoutException("休息界面加载超时");
			}
			return StepResult.Running;
		}
		ArenaResourcePolicy? arenaResourcePolicy = _003Cresources_003EP;
		if (arenaResourcePolicy != null && !arenaResourcePolicy.CanRest)
		{
			Name = "帐篷 · 不休息，离开";
			if (view.Phase == ArenaRestPhase.Returned && leaveSent)
			{
				return StepResult.Completed;
			}
			if (view.Phase == ArenaRestPhase.Confirmation)
			{
				if (Try(_003Cworld_003EP.TryDismissConfirmation, elapsed))
				{
					requestAt = elapsed;
				}
			}
			else if (view.Phase == ArenaRestPhase.Selection && !leaveSent)
			{
				if (Try(_003Cworld_003EP.TryLeave, elapsed))
				{
					leaveSent = true;
					requestAt = elapsed;
				}
			}
			else if (view.Phase == ArenaRestPhase.LeaveConfirmation && leaveSent && !leaveConfirmed)
			{
				if (Try(_003Cworld_003EP.TryConfirmLeave, elapsed))
				{
					leaveConfirmed = true;
					requestAt = elapsed;
				}
			}
			else
			{
				Wait(elapsed);
			}
			return StepResult.Running;
		}
		ArenaRestPhase phase = view.Phase;
		if ((uint)(phase - 1) <= 1u)
		{
			if (!confirmed)
			{
				desired = ArenaRestPolicy.Select(view.Pets, view.Capacity, _003Cresources_003EP?.RestBelowPercent ?? 100);
			}
			if (desired == null)
			{
				desired = Array.Empty<uint>();
			}
			if (desired.Any((uint id) => !view.Pets.Any((ArenaRestPet p) => p.Number == id)))
			{
				throw new InvalidOperationException("待休息的魔兽已不在列表中");
			}
			HashSet<uint> hashSet = (from p in view.Pets
				where p.Selected
				select p.Number).ToHashSet();
			if (view.Phase == ArenaRestPhase.Confirmation)
			{
				if (confirmed || dismissSent)
				{
					Wait(elapsed);
					return StepResult.Running;
				}
				if (!hashSet.SetEquals(desired))
				{
					Name = "休息 · 返回调整魔兽";
					if (Try(_003Cworld_003EP.TryDismissConfirmation, elapsed))
					{
						dismissSent = true;
						requestAt = elapsed;
					}
				}
				else
				{
					Name = "休息 · 确认";
					if (Try(() => _003Cworld_003EP.TryConfirm(desired), elapsed))
					{
						restSent = (confirmed = true);
						requestAt = elapsed;
					}
				}
				return StepResult.Running;
			}
			if (confirmed || (restSent && !dismissSent))
			{
				Wait(elapsed);
				return StepResult.Running;
			}
			if (dismissSent)
			{
				dismissSent = (restSent = false);
				requestAt = elapsed;
			}
			uint? num2 = pending;
			if (num2.HasValue)
			{
				uint valueOrDefault = num2.GetValueOrDefault();
				if (hashSet.Contains(valueOrDefault) != pendingSelected)
				{
					Wait(elapsed);
					return StepResult.Running;
				}
				pending = null;
				requestAt = elapsed;
			}
			ArenaRestPet change = view.Pets.FirstOrDefault((ArenaRestPet p) => p.Selected && !((ReadOnlySpan<uint>)desired).Contains(p.Number)) ?? desired.Select((uint id) => view.Pets.Single((ArenaRestPet p) => p.Number == id)).FirstOrDefault((ArenaRestPet p) => !p.Selected);
			if (change != null)
			{
				Name = "休息 · " + (change.Selected ? "取消" : "选择") + change.Name;
				if (Try(() => _003Cworld_003EP.TryToggle(change.Number), elapsed))
				{
					pending = change.Number;
					pendingSelected = !change.Selected;
					requestAt = elapsed;
				}
			}
			else
			{
				Name = "休息 · 开始休息";
				if (Try(_003Cworld_003EP.TryRest, elapsed))
				{
					restSent = true;
					requestAt = elapsed;
				}
			}
			return StepResult.Running;
		}
		if (!confirmed)
		{
			throw new InvalidOperationException("未确认本次休息，窗口已关闭");
		}
		if (view.Phase == ArenaRestPhase.Reward)
		{
			Name = "休息 · 领取奖励";
			if (!rewardSent && Try(_003Cworld_003EP.TryTakeReward, elapsed))
			{
				rewardSent = true;
				requestAt = elapsed;
			}
			else
			{
				Wait(elapsed);
			}
		}
		else if (view.Phase == ArenaRestPhase.RewardConfirmation)
		{
			Name = "休息 · 确认领取";
			if (!rewardSent)
			{
				throw new InvalidOperationException("未提交本次休息奖励领取");
			}
			if (!rewardConfirmed && Try(_003Cworld_003EP.TryConfirmReward, elapsed))
			{
				rewardConfirmed = true;
				requestAt = elapsed;
			}
			else
			{
				Wait(elapsed);
			}
		}
		else if (view.Phase == ArenaRestPhase.Returned)
		{
			TimeSpan valueOrDefault2 = returnedAt.GetValueOrDefault();
			if (!returnedAt.HasValue)
			{
				valueOrDefault2 = elapsed;
				returnedAt = valueOrDefault2;
			}
			TimeSpan? timeSpan = returnedAt;
			if (elapsed - timeSpan < TimeSpan.FromSeconds(2L))
			{
				Name = "休息 · 等待返回棋盘";
				return StepResult.Running;
			}
			Name = "休息完成";
			return StepResult.Completed;
		}
		return StepResult.Running;
	}

	private void Wait(TimeSpan elapsed)
	{
		if (elapsed - requestAt > TimeSpan.FromSeconds(15L))
		{
			throw new TimeoutException(Name + "，操作结果未确认");
		}
	}

	private bool Try(Func<bool> action, TimeSpan elapsed)
	{
		Wait(elapsed);
		if (elapsed < nextAttempt)
		{
			return false;
		}
		nextAttempt = elapsed + TimeSpan.FromMilliseconds(50L);
		return action();
	}

	public void Cancel()
	{
	}
}
