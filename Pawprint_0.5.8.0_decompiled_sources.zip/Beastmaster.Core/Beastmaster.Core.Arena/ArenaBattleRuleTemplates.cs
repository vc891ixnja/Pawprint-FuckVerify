using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaBattleRuleTemplates
{
	private static ArenaBattleRule PriorityRule(string name, int slot, params uint[] enemyIds)
	{
		return new ArenaBattleRule
		{
			Name = name,
			LegacySlot = slot,
			Trigger = new ArenaRuleTrigger
			{
				Kind = ArenaRuleTriggerKind.Always
			},
			Target = new ArenaRuleTarget
			{
				Kind = ArenaRuleTargetKind.None
			},
			Action = new ArenaRuleAction
			{
				Kind = ArenaRuleActionKind.SetTargetPriority,
				PriorityEnemyIds = enemyIds.ToList()
			},
			Limit = new ArenaRuleLimit
			{
				Once = ArenaRuleOnce.None
			}
		};
	}

	private static ArenaBattleRule DutyRule(string name, int slot, ArenaRuleTrigger trigger, int windowSeconds = 0)
	{
		return new ArenaBattleRule
		{
			Name = name,
			LegacySlot = slot,
			Trigger = trigger,
			Target = new ArenaRuleTarget
			{
				Kind = ArenaRuleTargetKind.CurrentTarget
			},
			Action = new ArenaRuleAction
			{
				Kind = ArenaRuleActionKind.UseDutyAction,
				DutyActionSlot = 1
			},
			Limit = new ArenaRuleLimit
			{
				Once = ArenaRuleOnce.PerPetSummon,
				WindowSeconds = windowSeconds,
				RetrySeconds = 8
			}
		};
	}

	private static ArenaBattleRule ItemsRule(string name, int slot, ArenaRuleTrigger trigger, ArenaRuleTarget target, ArenaRuleItemFilter filter, int itemLimit = 0, ArenaRuleOnce once = ArenaRuleOnce.PerBattle)
	{
		return new ArenaBattleRule
		{
			Name = name,
			LegacySlot = slot,
			Trigger = trigger,
			Target = target,
			Action = new ArenaRuleAction
			{
				Kind = ArenaRuleActionKind.UseItems,
				ItemFilter = filter,
				ItemLimit = itemLimit
			},
			Limit = new ArenaRuleLimit
			{
				Once = once,
				RetrySeconds = 8
			}
		};
	}

	public static bool HasBuiltIn(int stageId, int? node)
	{
		return BuiltIn(stageId, node).Count > 0;
	}

	public static IReadOnlyList<ArenaBattleRule> BuiltIn(int stageId, int? node)
	{
		if (!node.HasValue)
		{
			return Array.Empty<ArenaBattleRule>();
		}
		int value = node.Value;
		switch (stageId)
		{
		case 1:
			switch (value)
			{
			case 1:
				return new _003C_003Ez__ReadOnlyArray<ArenaBattleRule>(new ArenaBattleRule[2]
				{
					PriorityRule("目标优先：主教→骑士", 1, 14532u, 14531u),
					new ArenaBattleRule
					{
						Name = "背后接近（内置）",
						LegacySlot = 1,
						Trigger = new ArenaRuleTrigger
						{
							Kind = ArenaRuleTriggerKind.Always
						},
						Target = new ArenaRuleTarget
						{
							Kind = ArenaRuleTargetKind.None
						},
						Action = new ArenaRuleAction
						{
							Kind = ArenaRuleActionKind.MoveBehind
						},
						Limit = new ArenaRuleLimit
						{
							Once = ArenaRuleOnce.None
						}
					}
				});
			case 6:
				return new _003C_003Ez__ReadOnlySingleElementList<ArenaBattleRule>(DutyRule("45秒内·吸引注意", 1, new ArenaRuleTrigger
				{
					Kind = ArenaRuleTriggerKind.PetSummoned
				}, 45));
			case 8:
				return new _003C_003Ez__ReadOnlySingleElementList<ArenaBattleRule>(PriorityRule("目标优先：食人魔→妖火→大妖火", 1, 14538u, 14539u, 14748u));
			case 12:
				return new _003C_003Ez__ReadOnlySingleElementList<ArenaBattleRule>(ItemsRule("半血·全部道具", 1, new ArenaRuleTrigger
				{
					Kind = ArenaRuleTriggerKind.EnemyHpBelow,
					EnemyNameId = 14541u,
					Percent = 50
				}, new ArenaRuleTarget
				{
					Kind = ArenaRuleTargetKind.Self
				}, ArenaRuleItemFilter.All));
			}
			break;
		case 4:
			switch (value)
			{
			case 2:
				return new _003C_003Ez__ReadOnlySingleElementList<ArenaBattleRule>(new ArenaBattleRule
				{
					Name = "四幼苗·PR最后一击",
					LegacySlot = 1,
					Trigger = new ArenaRuleTrigger
					{
						Kind = ArenaRuleTriggerKind.EnemyCount,
						EnemyNameId = 14600u,
						Count = 4
					},
					Target = new ArenaRuleTarget
					{
						Kind = ArenaRuleTargetKind.None
					},
					Action = new ArenaRuleAction
					{
						Kind = ArenaRuleActionKind.CallPrcFinisher
					},
					Limit = new ArenaRuleLimit
					{
						Once = ArenaRuleOnce.PerBattle,
						RetrySeconds = 8
					}
				});
			case 11:
				return new _003C_003Ez__ReadOnlyArray<ArenaBattleRule>(new ArenaBattleRule[2]
				{
					ItemsRule("蛞蝓·攻击道具", 1, new ArenaRuleTrigger
					{
						Kind = ArenaRuleTriggerKind.EnemyAliveFor,
						EnemyNameId = 14619u,
						Seconds = (int)ArenaSlugBombPolicy.Fuse.TotalSeconds
					}, new ArenaRuleTarget
					{
						Kind = ArenaRuleTargetKind.TriggeredEnemy
					}, ArenaRuleItemFilter.Attack, 1, ArenaRuleOnce.PerTargetInstance),
					ItemsRule("树精半血·功能道具", 2, new ArenaRuleTrigger
					{
						Kind = ArenaRuleTriggerKind.EnemyHpBelow,
						EnemyNameId = 14618u,
						Percent = 50
					}, new ArenaRuleTarget
					{
						Kind = ArenaRuleTargetKind.Self
					}, ArenaRuleItemFilter.FunctionNoTimeSand)
				});
			case 14:
				return new _003C_003Ez__ReadOnlyArray<ArenaBattleRule>(new ArenaBattleRule[3]
				{
					PriorityRule("目标优先：怨毒龙→有毒物质", 1, 14628u, 14629u),
					ItemsRule("怨毒龙半血·全部非恢复道具", 2, new ArenaRuleTrigger
					{
						Kind = ArenaRuleTriggerKind.EnemyHpBelow,
						EnemyNameId = 14628u,
						Percent = 50
					}, new ArenaRuleTarget
					{
						Kind = ArenaRuleTargetKind.Self
					}, ArenaRuleItemFilter.NonHealing),
					ItemsRule("最强敌人半血·全部非恢复道具", 2, new ArenaRuleTrigger
					{
						Kind = ArenaRuleTriggerKind.EnemyHpBelow,
						EnemyNameId = 0u,
						Percent = 50
					}, new ArenaRuleTarget
					{
						Kind = ArenaRuleTargetKind.Self
					}, ArenaRuleItemFilter.NonHealing)
				});
			}
			break;
		}
		return Array.Empty<ArenaBattleRule>();
	}

	public static IReadOnlyList<ArenaBattleRule> Effective(ArenaBattlePreset? battle, int stageId, int? node)
	{
		if (battle != null)
		{
			List<ArenaBattleRule> rules = battle.Rules;
			if (rules != null && rules.Count > 0)
			{
				return rules;
			}
		}
		IReadOnlyList<ArenaBattleRule> readOnlyList = BuiltIn(stageId, node);
		if (readOnlyList.Count == 0)
		{
			return Array.Empty<ArenaBattleRule>();
		}
		return readOnlyList.Where((ArenaBattleRule r) => battle?.LogicEnabled(r.LegacySlot ?? 1) ?? true).ToArray();
	}
}
