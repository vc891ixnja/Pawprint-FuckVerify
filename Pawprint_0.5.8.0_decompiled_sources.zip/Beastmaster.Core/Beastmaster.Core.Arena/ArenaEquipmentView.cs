namespace Beastmaster.Core.Arena;

public sealed record ArenaEquipmentView(ArenaEquipmentPhase Phase, ArenaEquipmentContents? Contents = null, string Prompt = "", uint[]? Owned = null);
