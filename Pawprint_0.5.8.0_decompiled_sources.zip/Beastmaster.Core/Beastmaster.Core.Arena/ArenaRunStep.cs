using System;
using Beastmaster.Core.Automation;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRunStep(ArenaEntryStep? entry, ArenaBoardStep board, IWorkflowStep? result = null, IArenaRunSupport? support = null, bool retryAfterDeath = false, IWorkflowStep? food = null) : IWorkflowStep
{
	private readonly ArenaRevivalWait revival = new ArenaRevivalWait();

	private bool entered = entry == null;

	private bool foodDone = food == null;

	private TimeSpan boardAt;

	private TimeSpan resultAt;

	private bool finishing;

	public string Name
	{
		get
		{
			if (!finishing)
			{
				if (!revival.IsWaiting)
				{
					if (!entered)
					{
						if (foodDone)
						{
							return entry.Name;
						}
						return food.Name;
					}
					return board.Name;
				}
				return "等待道具复活（最多 10 秒）";
			}
			return result.Name;
		}
	}

	public string BattleStatus
	{
		get
		{
			if (!entered || finishing || revival.IsWaiting)
			{
				return "";
			}
			return board.BattleStatus;
		}
	}

	public bool Failed { get; private set; }

	public TimeSpan Timeout => TimeSpan.FromHours(3);

	public bool BoardActive => entered;

	public bool FirstEncounterActive
	{
		get
		{
			if (entered && !finishing)
			{
				return board.FirstEncounterActive;
			}
			return false;
		}
	}

	public bool RestActive
	{
		get
		{
			if (entered && !finishing)
			{
				return board.RestActive;
			}
			return false;
		}
	}

	public bool TreasureActive
	{
		get
		{
			if (entered && !finishing)
			{
				return board.TreasureActive;
			}
			return false;
		}
	}

	public bool ShopActive
	{
		get
		{
			if (entered && !finishing)
			{
				return board.ShopActive;
			}
			return false;
		}
	}

	public bool ResultActive => finishing;

	public bool HealingActive
	{
		get
		{
			if (entered && !finishing)
			{
				return board.HealingActive;
			}
			return false;
		}
	}

	public bool AcceptsTerritory(uint territory)
	{
		if (!finishing)
		{
			return entered ? board.AcceptsTerritory(territory) : entry.AcceptsTerritory(territory);
		}
		bool flag = ((territory == 0 || territory == 148) ? true : false);
		return flag || board.AcceptsTerritory(territory);
	}

	public StepResult Tick(TimeSpan elapsed)
	{
		bool isWaiting = revival.IsWaiting;
		if (!finishing && revival.Observe(support?.IsDead ?? false, elapsed, !retryAfterDeath))
		{
			if (!isWaiting)
			{
				Cancel();
			}
			if (!revival.Confirmed)
			{
				return StepResult.Running;
			}
			if (result == null)
			{
				throw new InvalidOperationException("死亡后无法读取斗兽结算");
			}
			Failed = true;
			if (result is ArenaResultStep arenaResultStep)
			{
				arenaResultStep.MarkFailed();
			}
			finishing = true;
			resultAt = revival.ActiveElapsed(elapsed);
		}
		elapsed = revival.ActiveElapsed(elapsed);
		if (!finishing)
		{
			support?.Update();
		}
		if (!entered && !finishing && !foodDone)
		{
			if (food.Tick(elapsed) != StepResult.Completed)
			{
				return StepResult.Running;
			}
			food.Cancel();
			foodDone = true;
		}
		if (!entered && !finishing)
		{
			if (entry.Tick(elapsed) != StepResult.Completed)
			{
				return StepResult.Running;
			}
			entry.Cancel();
			entered = true;
			boardAt = elapsed;
		}
		if (!finishing)
		{
			if (elapsed - boardAt >= board.Timeout)
			{
				throw new TimeoutException("斗兽执行超时");
			}
			StepResult stepResult = board.Tick(elapsed - boardAt);
			if (stepResult != StepResult.Completed || result == null)
			{
				return stepResult;
			}
			board.Cancel();
			finishing = true;
			resultAt = elapsed;
		}
		if (elapsed - resultAt >= result.Timeout)
		{
			throw new TimeoutException("斗兽结算处理超时");
		}
		StepResult result = result.Tick(elapsed - resultAt);
		if (result is ArenaResultStep arenaResultStep2)
		{
			ArenaRunResult? recordedResult = arenaResultStep2.RecordedResult;
			if ((object)recordedResult != null && recordedResult.Failed)
			{
				Failed = true;
			}
		}
		return result;
	}

	public void Cancel()
	{
		try
		{
			if (finishing)
			{
				result.Cancel();
			}
			else if (entered)
			{
				board.Cancel();
			}
			else
			{
				entry.Cancel();
			}
		}
		finally
		{
			support?.Cancel();
		}
	}
}
