using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Beastmaster.Core.I18N;

namespace Beastmaster.Core.Arena;

public static class ArenaShopDecoder
{
	public static uint Price(string text)
	{
		Match match = Regex.Match(text, "^\\s*(\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\s*\\(-\\d+%\\))?\\s*$");
		if (!match.Success || !uint.TryParse(match.Groups[1].Value.Replace(",", ""), out var result))
		{
			throw new InvalidOperationException("商店价格未就绪");
		}
		return result;
	}

	public static ArenaShopContents Decode(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue arenaValue) => arenaValue.Index);
		if (N(0) == 1)
		{
			switch (N(2))
			{
			case 0L:
			case 1L:
			case 2L:
			case 3L:
			case 4L:
			case 5L:
			case 6L:
			case 7L:
			case 8L:
			case 9L:
			case 10L:
			case 11L:
			case 12L:
			case 13L:
			case 14L:
			case 15L:
			case 16L:
			case 17L:
			case 18L:
			case 19L:
			case 20L:
			case 21L:
			case 22L:
			case 23L:
			case 24L:
			case 25L:
			case 26L:
			case 27L:
			case 28L:
			case 29L:
			case 30L:
			{
				List<ArenaShopOffer> list = new List<ArenaShopOffer>();
				int num = 0;
				while (num < N(2))
				{
					int num2 = 3 + num * 5;
					int num4;
					if (N(num2) == 1)
					{
						long? num3 = N(num2 + 1);
						if (num3.HasValue)
						{
							long valueOrDefault = num3.GetValueOrDefault();
							if (valueOrDefault > 0)
							{
								num4 = ((valueOrDefault <= 203) ? 1 : 0);
								goto IL_00f2;
							}
						}
						num4 = 0;
						goto IL_00f2;
					}
					int num5 = 1;
					goto IL_00f8;
					IL_00f8:
					bool flag = (byte)num5 != 0;
					bool flag2;
					if (!flag)
					{
						long? num3 = N(num2 + 4);
						if (num3.HasValue)
						{
							long valueOrDefault = num3.GetValueOrDefault();
							if ((ulong)valueOrDefault <= 1uL)
							{
								flag2 = true;
								goto IL_012b;
							}
						}
						flag2 = false;
						goto IL_012b;
					}
					goto IL_0132;
					IL_00f2:
					num5 = ((num4 == 0) ? 1 : 0);
					goto IL_00f8;
					IL_0132:
					if (flag)
					{
						throw new InvalidOperationException("商店商品字段未就绪");
					}
					uint num6 = (uint)N(num2 + 1).Value;
					if (!ArenaItemCatalog.Items.ContainsKey(num6))
					{
						throw new InvalidOperationException("商店商品编号未知");
					}
					list.Add(new ArenaShopOffer(num, num6, Price(v.GetValueOrDefault(num2 + 2)?.Text ?? ""), N(num2 + 4) == 1));
					num++;
					continue;
					IL_012b:
					flag = !flag2;
					goto IL_0132;
				}
				var (owned, equipmentCount, bagCount) = DecodeOwned(values);
				return new ArenaShopContents(Price(v.GetValueOrDefault(1)?.Text ?? ""), list.ToArray(), owned, equipmentCount, bagCount);
			}
			}
		}
		throw new InvalidOperationException("商店列表未就绪");
		long? N(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	public static (uint[] Owned, int Equipment, int Bag) DecodeOwned(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue arenaValue) => arenaValue.Index);
		List<uint> list = new List<uint>();
		int num = 0;
		int num2 = 0;
		for (int num3 = 0; num3 < 20; num3++)
		{
			int num4 = ((num3 < 10) ? (154 + num3 * 5) : (205 + (num3 - 10) * 5));
			long? num5 = N(num4 + 3);
			long? num6 = N(num4);
			bool flag;
			if (num6.HasValue)
			{
				long valueOrDefault = num6.GetValueOrDefault();
				if ((ulong)valueOrDefault <= 1uL)
				{
					flag = true;
					goto IL_0097;
				}
			}
			flag = false;
			goto IL_0097;
			IL_0097:
			if (!flag)
			{
				throw new InvalidOperationException("商店持有道具未就绪");
			}
			if (num3 >= 10 && N(num4) == 0)
			{
				continue;
			}
			if ((!num5.HasValue || num5.GetValueOrDefault() == 0L) ? true : false)
			{
				if (num3 >= 10 || !MatchesPouchLabel(v.GetValueOrDefault(num4 + 4)?.Text, num3))
				{
					throw new InvalidOperationException("商店持有道具未就绪");
				}
				continue;
			}
			if (num5.HasValue)
			{
				long valueOrDefault = num5.GetValueOrDefault();
				if (valueOrDefault > 0 && valueOrDefault <= 203 && ArenaItemCatalog.Items.TryGetValue((uint)num5.Value, out ArenaItem value) && (num3 < 10 || value.Category == 1) && (num3 >= 10 || value.Category == 2))
				{
					list.Add((uint)num5.Value);
					if (num3 >= 10)
					{
						num++;
					}
					else
					{
						num2++;
					}
					continue;
				}
			}
			throw new InvalidOperationException("商店持有道具未识别");
		}
		return (Owned: list.ToArray(), Equipment: num, Bag: num2);
		long? N(int i)
		{
			return v.GetValueOrDefault(i)?.Number;
		}
	}

	public static (uint Food, ArenaShopPet[] Pets) Feeding(IReadOnlyList<ArenaValue> values)
	{
		Dictionary<int, ArenaValue> v = values.ToDictionary((ArenaValue arenaValue) => arenaValue.Index);
		ArenaValue? valueOrDefault = v.GetValueOrDefault(2);
		if ((object)valueOrDefault != null && valueOrDefault.Number == 3)
		{
			long? num = v.GetValueOrDefault(1187)?.Number;
			if (num.HasValue)
			{
				long valueOrDefault2 = num.GetValueOrDefault();
				if (valueOrDefault2 > 0 && valueOrDefault2 <= 203)
				{
					uint num2 = (uint)v[1187].Number.Value;
					if (ArenaItemCatalog.Items[num2].Category != 3 || !ArenaPromptText.ItemThenFragment(v.GetValueOrDefault(1185)?.Text ?? "", "Tent.FeedPrompt", num2))
					{
						throw new InvalidOperationException("商店食料选择不匹配");
					}
					ArenaPet[] array = ArenaPartyDecoder.Decode(values, allowEmpty: true);
					if (array.Length > 15)
					{
						throw new InvalidOperationException("商店魔兽名单异常");
					}
					return (Food: num2, Pets: array.Select(delegate(ArenaPet p)
					{
						long? num3 = v.GetValueOrDefault(6 + p.Row * 77 + 8)?.Number;
						if (num3.HasValue)
						{
							long valueOrDefault3 = num3.GetValueOrDefault();
							if (valueOrDefault3 >= 0 && valueOrDefault3 <= 203 && (num3 == 0 || ArenaItemCatalog.Items[(uint)num3.Value].Category == 3))
							{
								return new ArenaShopPet(p.Row, p.PetId, p.Name, p.Hp, (uint)num3.Value);
							}
						}
						throw new InvalidOperationException("魔兽当前食料未就绪");
					}).ToArray());
				}
			}
		}
		throw new InvalidOperationException("商店食料选择未就绪");
	}

	public static string BuyPrompt(ArenaShopPurchase purchase, IReadOnlyList<ArenaShopPet> pets)
	{
		uint? petNumber = purchase.PetNumber;
		if (petNumber.HasValue)
		{
			uint number = petNumber.GetValueOrDefault();
			return $"确定要购买“{ArenaItemCatalog.Items[purchase.Offer.ItemId].Name}”，喂给“{pets.Single((ArenaShopPet p) => p.Number == number).Name}”吗？";
		}
		return "确定要购买“" + ArenaItemCatalog.Items[purchase.Offer.ItemId].Name + "”吗？";
	}

	public static bool MatchesBuyPrompt(string text, ArenaShopPurchase purchase, IReadOnlyList<ArenaShopPet> pets)
	{
		if (!ArenaPromptText.ContainsItem(text, "Shop.PurchaseConfirm", purchase.Offer.ItemId))
		{
			return false;
		}
		uint? petNumber = purchase.PetNumber;
		if (petNumber.HasValue)
		{
			uint number = petNumber.GetValueOrDefault();
			ArenaShopPet arenaShopPet = pets.SingleOrDefault((ArenaShopPet p) => p.Number == number);
			if (!(arenaShopPet == null) && !(GameText.Language != "zhCN"))
			{
				return GameText.Normalize(text).Contains(GameText.Normalize(arenaShopPet.Name), StringComparison.Ordinal);
			}
			return true;
		}
		return true;
	}

	private static bool MatchesPouchLabel(string? text, int row)
	{
		if (!(GameText.Language == "zhCN"))
		{
			if (text != null)
			{
				return text.Length > 0;
			}
			return false;
		}
		return text == $"奇弈道具{row + 1}";
	}

	public static string Compact(string text)
	{
		return string.Concat(text.Where((char c) => !char.IsWhiteSpace(c)));
	}

	public static bool IsExitPrompt(string text)
	{
		return GameText.Matches("Shop.ExitConfirm", text);
	}

	public static bool IsDuplicate(string text, uint item)
	{
		return ArenaPromptText.ContainsItem(text, "Shop.AlreadyOwned", item);
	}

	public static bool IsSellPrompt(string text, uint item)
	{
		return ArenaPromptText.ContainsItem(text, "Shop.SellConfirm", item);
	}
}
