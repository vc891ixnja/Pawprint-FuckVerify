namespace Beastmaster.Core.Arena;

public sealed record ArenaHealView(ArenaHealPhase Phase, uint Hp, uint MaxHp, ArenaHealItem[] Items);
