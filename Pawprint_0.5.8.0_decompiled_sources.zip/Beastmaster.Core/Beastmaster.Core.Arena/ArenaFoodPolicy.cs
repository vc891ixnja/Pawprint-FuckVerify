using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace Beastmaster.Core.Arena;

public static class ArenaFoodPolicy
{
	public static IReadOnlyDictionary<uint, ArenaPetFamily> Families { get; } = Load();

	private static IReadOnlyDictionary<uint, ArenaPetFamily> Load()
	{
		using Stream utf8Json = typeof(ArenaFoodPolicy).Assembly.GetManifestResourceStream("Beastmaster.Core.Data.arena-pet-families.json");
		return JsonSerializer.Deserialize<ArenaPetFamily[]>(utf8Json).ToDictionary((ArenaPetFamily p) => p.Number);
	}

	public static bool CanEat(uint number, uint itemId)
	{
		if (!Families.TryGetValue(number, out ArenaPetFamily value) || !ArenaItemCatalog.Items.TryGetValue(itemId, out ArenaItem value2) || value2.Category != 3)
		{
			return false;
		}
		int num = value2.Description.IndexOf("适于以下魔兽食用：", StringComparison.Ordinal);
		if (num >= 0)
		{
			string description = value2.Description;
			int num2 = num + "适于以下魔兽食用：".Length;
			return ((ReadOnlySpan<string>)description.Substring(num2, description.Length - num2).Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)).Contains(value.Family);
		}
		return false;
	}

	public static double DamageScore(uint id)
	{
		ArenaItem food = ArenaItemCatalog.Items[id];
		double num = Stat("加速") - Stat("减速");
		double num2 = Stat("造成伤害") + 0.7 * Stat("造成物理伤害") + 0.3 * Stat("造成魔法伤害") + 0.5 * Stat("暴击发动率") + 0.2 * Stat("以太爆发威力") + 100.0 / Math.Max(0.1, 1.0 - num / 100.0) - 100.0;
		return num2 + (double)(id switch
		{
			150u => 3, 
			151u => 2, 
			162u => 4, 
			167u => 2, 
			170u => 2, 
			171u => 3, 
			175u => 4, 
			178u => 2, 
			180u => 4, 
			185u => 2, 
			190u => 5, 
			192u => 3, 
			193u => 2, 
			195u => 2, 
			200u => 2, 
			201u => 3, 
			202u => 2, 
			_ => 0, 
		});
		double Stat(string label)
		{
			Match match = Regex.Match(food.Description, "(?:^|\\r?\\n)" + Regex.Escape(label) + "([+-]\\d+(?:\\.\\d+)?)%?");
			if (!match.Success)
			{
				return 0.0;
			}
			return double.Parse(match.Groups[1].Value, CultureInfo.InvariantCulture);
		}
	}
}
