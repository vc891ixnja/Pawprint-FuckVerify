using System;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public interface IArenaBattleWorld
{
	bool HasCustomTargetRule => false;

	bool ShouldUseAllItems => false;

	bool RearLogicEnabled
	{
		get
		{
			return false;
		}
		set
		{
		}
	}

	string LastActionStatus => "";

	ArenaCombatView Read();

	CombatTarget? FindNearestTarget();

	CombatTarget? ReadTarget(ulong id);

	bool TryOpeningAttack(ulong id);

	bool TrySelectTarget(ulong id);

	bool TryStartCountdown(int seconds)
	{
		return false;
	}

	bool TryAcrOpening(ulong id)
	{
		return false;
	}

	bool TryAssistantAcrOpening(ulong id)
	{
		return false;
	}

	CombatTarget? FindPriorityTarget(ulong? preferred)
	{
		return FindNearestTarget();
	}

	void UpdateTargetAction(ulong id)
	{
	}

	void UpdateBattleActions(TimeSpan elapsed)
	{
	}

	void SuspendBattleMovement()
	{
	}

	void ReleaseTargetControl()
	{
	}
}
