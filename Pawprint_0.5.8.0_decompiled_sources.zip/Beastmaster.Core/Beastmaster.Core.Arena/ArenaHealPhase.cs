namespace Beastmaster.Core.Arena;

public enum ArenaHealPhase
{
	Loading,
	Board,
	Menu,
	Blocked,
	Ended
}
