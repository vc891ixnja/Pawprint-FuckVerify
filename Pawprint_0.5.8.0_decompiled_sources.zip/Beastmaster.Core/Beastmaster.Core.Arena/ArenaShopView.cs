namespace Beastmaster.Core.Arena;

public sealed record ArenaShopView(ArenaShopPhase Phase, ArenaShopContents Contents, ArenaShopPet[]? Pets = null, uint FoodId = 0u, string Prompt = "");
