using System;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaFluteChoice
{
	public uint A { get; set; }

	public uint B { get; set; }
}
