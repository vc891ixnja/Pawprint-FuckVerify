namespace Beastmaster.Core.Arena;

public enum ArenaShopPhase
{
	Loading,
	Selection,
	Feeding,
	Confirmation,
	Duplicate,
	Returned,
	Blocked
}
