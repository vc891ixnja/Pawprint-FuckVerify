namespace Beastmaster.Core.Arena;

public enum ArenaPurchaseSort
{
	Priority,
	Price,
	FillThenPriority
}
