namespace Beastmaster.Core.Arena;

public enum ArenaBattleTier
{
	None,
	Normal,
	Elite,
	Boss
}
