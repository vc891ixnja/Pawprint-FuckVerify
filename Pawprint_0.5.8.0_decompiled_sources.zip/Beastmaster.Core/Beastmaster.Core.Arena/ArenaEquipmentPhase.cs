namespace Beastmaster.Core.Arena;

public enum ArenaEquipmentPhase
{
	Closed,
	Loading,
	Selection,
	Confirmation,
	ParentConfirmation
}
