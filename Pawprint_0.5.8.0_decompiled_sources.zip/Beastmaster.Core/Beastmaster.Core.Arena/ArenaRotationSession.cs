using System;
using Beastmaster.Core.Hunting;

namespace Beastmaster.Core.Arena;

public sealed class ArenaRotationSession(ITaskRotationBackend backend) : IDisposable
{
	private bool? initiallyRunning;

	public void Update()
	{
		bool valueOrDefault = initiallyRunning == true;
		if (!initiallyRunning.HasValue)
		{
			valueOrDefault = backend.IsRunning;
			initiallyRunning = valueOrDefault;
		}
		ArenaCombatPolicy.EnsureCaptureOff(backend);
		if (!backend.IsRunning)
		{
			backend.Start();
		}
	}

	public void Dispose()
	{
		if (initiallyRunning == false && backend.IsRunning)
		{
			backend.Stop();
		}
		initiallyRunning = null;
	}
}
