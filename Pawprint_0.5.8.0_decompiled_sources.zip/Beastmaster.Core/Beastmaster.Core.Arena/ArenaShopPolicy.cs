using System;
using System.Collections.Generic;
using System.Linq;

namespace Beastmaster.Core.Arena;

public static class ArenaShopPolicy
{
	public static IEnumerable<ArenaShopOffer> Available(ArenaShopContents shop, IReadOnlySet<uint> excluded)
	{
		return shop.Offers.Where((ArenaShopOffer o) => !o.Sold && o.Price <= shop.Balance && !excluded.Contains(o.ItemId) && (ArenaItemCatalog.Items[o.ItemId].Category == 2 || !((ReadOnlySpan<uint>)shop.Owned).Contains(o.ItemId)));
	}

	public static ArenaShopPurchase? Choose(ArenaShopContents shop, ArenaShopPet[]? pets, IReadOnlySet<uint> excluded, IReadOnlySet<uint> fed, Func<ArenaShopPet[], IEnumerable<uint>>? recipients = null, IReadOnlyList<uint>? priority = null, IReadOnlyList<uint>? equipmentPriority = null, ArenaResourcePolicy? resources = null, uint spent = 0u)
	{
		ArenaShopOffer[] source = (from o in Available(shop, excluded)
			where resources == null || resources.CanAfford(shop, o, spent)
			select o).ToArray();
		if (resources != null)
		{
			priority = resources.Order;
		}
		IEnumerable<ArenaShopPurchase> enumerable = (from o in source.Where(delegate(ArenaShopOffer o)
			{
				int category = ArenaItemCatalog.Items[o.ItemId].Category;
				return (uint)(category - 1) <= 1u;
			}).Where(delegate(ArenaShopOffer o)
			{
				if (ArenaItemCatalog.Items[o.ItemId].Category != 1)
				{
					return shop.BagCount < 10;
				}
				return shop.EquipmentCount < 10 || (equipmentPriority != null && shop.Owned.Count((uint id) => ArenaItemCatalog.Items[id].Category == 1) == 10 && (resources?.CanEquip(o.ItemId, (IReadOnlyCollection<uint>)(object)shop.Owned) ?? ArenaEquipmentPolicy.CanAcquire(o.ItemId, (IReadOnlyCollection<uint>)(object)shop.Owned, equipmentPriority)));
			})
			select new ArenaShopPurchase(o)).ToArray().AsEnumerable();
		if (pets != null)
		{
			HashSet<uint> eligibleNumbers = (recipients?.Invoke(pets) ?? pets.Select((ArenaShopPet p) => p.Number)).ToHashSet();
			enumerable = enumerable.Concat(source.Where((ArenaShopOffer o) => ArenaItemCatalog.Items[o.ItemId].Category == 3).SelectMany((ArenaShopOffer o) => from p in pets
				where eligibleNumbers.Contains(p.Number) && p.Hp != 0 && p.FoodId == 0 && !fed.Contains(p.Number) && ArenaFoodPolicy.CanEat(p.Number, o.ItemId)
				select new ArenaShopPurchase(o, p.Number)));
		}
		return (from p in enumerable
			orderby resources?.CategoryRank(p.Offer.ItemId, shop.EquipmentCount, shop.BagCount) ?? 0, resources?.ShopRank(p.Offer, shop) ?? ArenaPresetPolicy.Priority(priority, p.Offer.ItemId), ArenaPresetPolicy.Priority(priority, p.Offer.ItemId), p.PetNumber.HasValue ? 1 : 0, p.PetNumber.HasValue ? ArenaFoodPolicy.DamageScore(p.Offer.ItemId) : ArenaTreasurePolicy.Score(p.Offer.ItemId, (IReadOnlyCollection<uint>)(object)shop.Owned) descending, p.Offer.Price, p.Offer.Row, (pets != null) ? Array.FindIndex(pets, (ArenaShopPet pet) => pet.Number == p.PetNumber) : 0
			select p).FirstOrDefault();
	}
}
