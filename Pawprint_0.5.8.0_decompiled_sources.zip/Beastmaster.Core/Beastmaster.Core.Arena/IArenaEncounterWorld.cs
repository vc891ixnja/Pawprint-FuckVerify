using System;

namespace Beastmaster.Core.Arena;

public interface IArenaEncounterWorld
{
	IArenaEquipmentWorld? Equipment => null;

	IArenaRewardWorld? Rewards => null;

	ArenaEncounterView Read();

	bool TryAssign(int row);

	bool StartBattle();

	bool TakeAll();

	bool ConfirmTakeAll();

	bool ConfirmStartBattle()
	{
		throw new InvalidOperationException("开战确认接口不可用");
	}
}
