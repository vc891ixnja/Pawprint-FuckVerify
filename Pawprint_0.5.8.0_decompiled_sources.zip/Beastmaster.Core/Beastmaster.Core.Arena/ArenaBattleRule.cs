using System;
using System.Linq;
using System.Text.Json.Serialization;

namespace Beastmaster.Core.Arena;

[Serializable]
public sealed class ArenaBattleRule
{
	public string Id { get; set; } = Guid.NewGuid().ToString("N").Substring(0, 8);

	[JsonIgnore(Condition = JsonIgnoreCondition.Never)]
	public bool Enabled { get; set; } = true;

	public string Name { get; set; } = "";

	public ArenaRuleTrigger Trigger { get; set; } = new ArenaRuleTrigger();

	public ArenaRuleTarget Target { get; set; } = new ArenaRuleTarget();

	public ArenaRuleAction Action { get; set; } = new ArenaRuleAction();

	public ArenaRuleLimit Limit { get; set; } = new ArenaRuleLimit();

	public int? LegacySlot { get; set; }

	public ArenaBattleRule Copy()
	{
		return new ArenaBattleRule
		{
			Id = Guid.NewGuid().ToString("N").Substring(0, 8),
			Enabled = Enabled,
			Name = Name,
			Trigger = new ArenaRuleTrigger
			{
				Kind = Trigger.Kind,
				EnemyNameId = Trigger.EnemyNameId,
				Seconds = Trigger.Seconds,
				Percent = Trigger.Percent,
				Count = Trigger.Count,
				PetSlot = Trigger.PetSlot
			},
			Target = new ArenaRuleTarget
			{
				Kind = Target.Kind,
				EnemyNameId = Target.EnemyNameId,
				PetSlot = Target.PetSlot
			},
			Action = new ArenaRuleAction
			{
				Kind = Action.Kind,
				ItemFilter = Action.ItemFilter,
				ItemIds = Action.ItemIds.ToList(),
				DutyActionSlot = Action.DutyActionSlot,
				PriorityEnemyIds = Action.PriorityEnemyIds.ToList(),
				CountdownSeconds = Action.CountdownSeconds,
				ItemLimit = Action.ItemLimit
			},
			Limit = new ArenaRuleLimit
			{
				Once = Limit.Once,
				WindowSeconds = Limit.WindowSeconds,
				CooldownSeconds = Limit.CooldownSeconds,
				RetrySeconds = Limit.RetrySeconds,
				MaxAttemptsPerItem = Limit.MaxAttemptsPerItem,
				DebounceSeconds = Limit.DebounceSeconds
			},
			LegacySlot = LegacySlot
		};
	}
}
